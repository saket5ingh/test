import type { ActOption, CaseStatus, FilterOption } from '@/types'

export const ACT_OPTIONS: ActOption[] = [
  { key: 'pocso', label: 'POCSO Act, 2012', flag: true, match: (a) => /sexual offence|pocso/i.test(a) },
  {
    key: 'childmarriage',
    label: 'Prohibition of Child Marriage Act',
    flag: true,
    match: (a) => /child marriage/i.test(a),
  },
  {
    key: 'it',
    label: 'Information Technology Act',
    flag: true,
    match: (a) => /information technology|i\.t\. act/i.test(a),
  },
  { key: 'jj', label: 'Juvenile Justice Act', flag: true, match: (a) => /juvenile justice/i.test(a) },
  {
    key: 'ita',
    label: 'Immoral Traffic (Prevention) Act',
    flag: true,
    match: (a) => /immoral traffic/i.test(a),
  },
  {
    key: 'ipc',
    label: 'IPC / BNS',
    flag: false,
    match: (a) => /indian penal code|bharatiya nyaya/i.test(a),
  },
  {
    key: 'scst',
    label: 'SC/ST (Prevention of Atrocities) Act',
    flag: false,
    match: (a) => /scheduled caste|sc\/st/i.test(a),
  },
  { key: 'dowry', label: 'Dowry Prohibition Act', flag: false, match: (a) => /dowry/i.test(a) },
]

export const STATUS_OPTIONS: FilterOption[] = [
  { key: 'pending', label: 'Pending / Active' },
  { key: 'disposed', label: 'Disposed' },
  { key: 'acquitted', label: 'Acquitted' },
  { key: 'allowed', label: 'Allowed' },
  { key: 'rejected', label: 'Rejected' },
]

export const STATUS_META: Record<CaseStatus, { label: string }> = {
  pending: { label: 'Pending' },
  disposed: { label: 'Disposed' },
  acquitted: { label: 'Acquitted' },
  allowed: { label: 'Allowed' },
  rejected: { label: 'Rejected' },
}
