import type { Case } from './case'
export interface RunCriteria {
  allStates: boolean; stateCodes: string[]; allActs: boolean; actKeys: string[]
  sections: string[]; status: 'all' | 'pending' | 'disposed'
}
export interface ScraperRun {
  id: string; name: string; criteria: RunCriteria | null
  resolvedScope: { states: { code: string; name: string }[]; actKeys: string[] } | null
  trigger: 'manual' | 'scheduled'; triggeredBy: string | null
  queuedAt: string; startedAt: string | null; completedAt: string | null
  outcome: 'pending' | 'queued' | 'running' | 'success' | 'partial' | 'failed' | 'cancelled'
  tasks: Record<string, number>; counts: Record<string, number>; total: number
  coverage: { kind: string; status: string; count: number }[]
  snapshotsAvailable: boolean; error: string | null; cancelRequested: boolean
  legacyCriteria: { state: string | null; acts: string | null; sections: string | null; status: string }
}
export interface Page<T> { items: T[]; total: number; page: number; pageSize: number }
export interface RunSnapshot { snapshot: Case; fetched_at: string; change_kind: string }
export interface RunEvent { id: string; at: string; kind: string; message: string; actor_name: string | null; task_id: string | null }
export interface RunTask {
  id: string; kind: string; status: string; attempts: number; error_message: string | null
  payload: { state?: { name: string }; district?: { name: string }; court?: { name: string; code: string }; cnr?: string; act_code?: string; section?: string; status?: string }
}
export interface ScraperOptions {
  states: { code: string; name: string }[]; acts: { key: string; label: string }[]
  statesUpdatedAt: string | null; workerLastSeen: string | null; workerHealthy: boolean; monthlyEnabled: boolean
}
