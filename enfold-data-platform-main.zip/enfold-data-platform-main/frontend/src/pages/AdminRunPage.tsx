import { useCallback, useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { PageHead } from '@/components/ui/PageHead'
import { Button } from '@/components/ui/Button'
import { scrapeService } from '@/services/scrapeService'
import { USE_MOCK } from '@/services/config'
import { usePollingResource } from '@/hooks/usePollingResource'
import type { RunCriteria } from '@/types/scraper'
import styles from '@/components/admin/AdminRun.module.css'

const empty: RunCriteria = { allStates: false, stateCodes: [], allActs: false, actKeys: [], sections: [], status: 'all' }
export function AdminRunPage() {
  const navigate = useNavigate()
  const load = useCallback((signal: AbortSignal) => scrapeService.options(signal), [])
  const { data: options, error: loadError, refresh } = usePollingResource('scraper-options', load, 30000)
  const [criteria, setCriteria] = useState(empty)
  const [name, setName] = useState('')
  const [sections, setSections] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [requestId, setRequestId] = useState(() => crypto.randomUUID())
  function patch(value: Partial<RunCriteria>) { setCriteria((old) => ({ ...old, ...value })); setRequestId(crypto.randomUUID()) }
  const toggle = (group: 'stateCodes' | 'actKeys', key: string) => patch({ [group]: criteria[group].includes(key) ? criteria[group].filter((v) => v !== key) : [...criteria[group], key] })
  async function submit(event: FormEvent) {
    event.preventDefault()
    if (!name.trim() || (!criteria.allStates && !criteria.stateCodes.length) || (!criteria.allActs && !criteria.actKeys.length)) {
      setError('Enter a run name and select at least one state and act, or choose All.'); return
    }
    setBusy(true); setError('')
    try {
      const result = await scrapeService.runScrape({ ...criteria, name: name.trim(), sections: sections.split(',').map((s) => s.trim()).filter(Boolean), requestId })
      navigate(`/admin/runs/${result.id}`)
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not queue the scrape.') }
    finally { setBusy(false) }
  }
  return <>
    <PageHead title="Run custom scrape" description="Queue a background scan. You can close this page after submission and follow it in Scrape Run Logs." />
    {USE_MOCK ? <p role="status">Demo mode: switch to API mode to run the scraper.</p> : null}
    {loadError ? <p role="alert">{loadError} <button onClick={refresh}>Retry options</button></p> : null}
    {options && !options.workerHealthy ? <p role="status">The worker has not reported recently. Submitted runs will remain queued until it is available.</p> : null}
    <p>Monthly nationwide scan: {options?.monthlyEnabled ? 'enabled' : 'disabled — timing awaiting confirmation'}.</p>
    <form onSubmit={submit} className={styles.formRows}>
      {error ? <p role="alert">{error}</p> : null}
      <fieldset disabled={busy || USE_MOCK} style={{ border: 0, padding: 0 }}>
        <div className={styles.field}><label htmlFor="run-name">Scrape name</label>
          <input type="text" id="run-name" required maxLength={255} value={name} onChange={(e) => { setName(e.target.value); setRequestId(crypto.randomUUID()) }} /></div>
        <div className={styles.pair}>
          <fieldset className={styles.field}><legend>States</legend>
            <label><input type="checkbox" checked={criteria.allStates} onChange={(e) => patch({ allStates: e.target.checked, stateCodes: [] })} /> All states</label>
            {!options?.states.length ? <p>State options will appear after the worker loads the eCourts catalogue. “All states” resolves the catalogue when the run starts.</p> : null}
            <div style={{ maxHeight: 250, overflowY: 'auto' }}>{options?.states.map((state) => <label key={state.code} style={{ display: 'block' }}>
              <input type="checkbox" disabled={criteria.allStates} checked={criteria.allStates || criteria.stateCodes.includes(state.code)} onChange={() => toggle('stateCodes', state.code)} /> {state.name}
            </label>)}</div>
          </fieldset>
          <fieldset className={styles.field}><legend>Acts</legend>
            <label><input type="checkbox" checked={criteria.allActs} onChange={(e) => patch({ allActs: e.target.checked, actKeys: [] })} /> All acts</label>
            {options?.acts.map((act) => <label key={act.key} style={{ display: 'block' }}><input type="checkbox" disabled={criteria.allActs} checked={criteria.allActs || criteria.actKeys.includes(act.key)} onChange={() => toggle('actKeys', act.key)} /> {act.label}</label>)}
          </fieldset>
        </div>
        <div className={styles.pair}>
          <div className={styles.field}><label htmlFor="run-status">Case status</label><select id="run-status" value={criteria.status} onChange={(e) => patch({ status: e.target.value as RunCriteria['status'] })}>
            <option value="all">All (Pending &amp; Disposed)</option><option value="pending">Pending</option><option value="disposed">Disposed</option>
          </select></div>
          <div className={styles.field}><label htmlFor="run-sections">Sections (optional)</label><input type="text" id="run-sections" placeholder="9, 10, 11" value={sections} onChange={(e) => { setSections(e.target.value); setRequestId(crypto.randomUUID()) }} />
            <p>Blank includes all sections. Listed sections match any selected section, for each selected act.</p></div>
        </div>
        <Button type="submit" variant="primary" disabled={busy}>{busy ? 'Queuing…' : 'Run scrape'}</Button>
      </fieldset>
    </form>
  </>
}
