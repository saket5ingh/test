import { afterEach, describe, expect, it } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import { axe } from 'jest-axe'
import { CasesPage } from '@/pages/CasesPage'
import { renderWithProviders, signIn } from '@/test/renderWithProviders'

afterEach(() => sessionStorage.clear())

describe('CasesPage', () => {
  it('hides admin-only identifiers from field officers', async () => {
    signIn('user')
    renderWithProviders(<CasesPage />, { route: '/cases' })

    await screen.findByText('PCMA-BR-0001')

    expect(screen.queryByText('BRGA010125162025')).not.toBeInTheDocument()
    expect(screen.queryByText('Bail/2623/2025')).not.toBeInTheDocument()
    expect(screen.queryByText('Gaya DJ Division')).not.toBeInTheDocument()
    expect(screen.queryByRole('columnheader', { name: 'CNR' })).not.toBeInTheDocument()
  })

  it('shows real identifiers to admins', async () => {
    signIn('admin')
    renderWithProviders(<CasesPage />, { route: '/cases' })

    expect(await screen.findByText('BRGA010125162025')).toBeInTheDocument()
    expect(screen.getByRole('columnheader', { name: 'CNR' })).toBeInTheDocument()
  })

  it('has no detectable accessibility violations', async () => {
    signIn('admin')
    const { container } = renderWithProviders(<CasesPage />, { route: '/cases' })

    await screen.findByText('BRGA010125162025')
    await waitFor(async () => {
      expect(await axe(container)).toHaveNoViolations()
    })
  }, 20000)
})
