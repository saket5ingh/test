import { beforeEach, afterEach, expect, it, vi } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Routes, Route } from 'react-router-dom'
import { renderWithProviders, signIn } from '@/test/renderWithProviders'
import { ACCOUNTS } from '@/services/mock/accounts.mock'
import { CASES } from '@/services/mock/cases.mock'
import { AdminRunPage } from './AdminRunPage'
import { AdminRunDetailPage } from './AdminRunDetailPage'
import { AdminSnapshotPage } from './AdminSnapshotPage'
import { tokenStore } from '@/services/http'
vi.mock('@/services/config', () => ({ API_BASE_URL: '/api', USE_MOCK: false, delay: (v: unknown) => Promise.resolve(v) }))
let submissions: Record<string, unknown>[]
let outcome: string
const historical = { ...CASES[0], id: 'case-1', status: 'pending' }
beforeEach(() => {
  signIn('admin'); submissions = []; outcome = 'queued'
  vi.stubGlobal('fetch', vi.fn(async (url: string, init: RequestInit) => {
    if (url === '/api/auth/me') return Response.json(ACCOUNTS.find((a) => a.role === 'admin'))
    if (url.startsWith('/api/cases?')) return Response.json({ items: [{ ...historical, status: 'disposed' }], total: 1, page: 1, pageSize: 25 })
    if (url === '/api/options') return Response.json({ totalCases: 1, districts: [], acts: [], caseTypes: [], purposes: [], complexes: [], courts: [] })
    if (url === '/api/scrapes') return Response.json([])
    if (url === '/api/cases/updates') return Response.json({ items: [], total: 0, critical: 0 })
    if (url === '/api/scrapes/options') return Response.json({ states: [{ code: '5', name: 'Bihar' }, { code: '6', name: 'Rajasthan' }], acts: [{ key: 'childmarriage', label: 'Prohibition of Child Marriage Act' }, { key: 'ipc', label: 'IPC / BNS' }], workerHealthy: true, monthlyEnabled: false })
    if (url === '/api/scrapes/run') { submissions.push(JSON.parse(init.body as string)); return Response.json({ id: 'run-1' }, { status: 202 }) }
    if (url === '/api/scrapes/runs/run-1') return Response.json({ id: 'run-1', name: 'My scan', criteria: { allStates: true, allActs: true, sections: [], stateCodes: [], actKeys: [], status: 'all' }, resolvedScope: null, trigger: 'manual', triggeredBy: 'admin', queuedAt: '2026-09-01T00:00:00Z', startedAt: null, completedAt: null, outcome, tasks: { queued: 1 }, counts: {}, total: 0, coverage: [], snapshotsAvailable: true, error: null, cancelRequested: false })
    if (url.includes('/events?')) return Response.json({ items: [], total: 0, page: 1, pageSize: 50 })
    if (url.includes('/tasks?')) return Response.json({ items: [{ id: 'task-1', kind: 'case', status: 'failed', attempts: 3, payload: { state: { name: 'Bihar' }, district: { name: 'Gaya' }, court: { name: 'District court', code: '1' } }, error_message: 'Source unavailable' }], total: 1, page: 1, pageSize: 25 })
    if (url.includes('/results?')) return Response.json({ items: [{ snapshot: historical, fetched_at: '2026-09-01T00:00:00Z', change_kind: 'new' }], total: 1, page: 1, pageSize: 25 })
    if (url.endsWith('/results/case-1')) return Response.json({ snapshot: historical, fetched_at: '2026-09-01T00:00:00Z', change_kind: 'new' })
    if (url.endsWith('/cancel')) { outcome = 'cancelled'; return Response.json({ id: 'run-1' }, { status: 202 }) }
    throw new Error(`Unexpected request: ${url}`)
  }))
})
afterEach(() => { vi.unstubAllGlobals(); tokenStore.set(null) })
function views() { return <Routes><Route path="/admin/run" element={<AdminRunPage />} /><Route path="/admin/runs/:runId" element={<AdminRunDetailPage />} /><Route path="/admin/runs/:runId/cases/:caseId" element={<AdminSnapshotPage />} /></Routes> }
it('submits multiple states/acts and any-match sections, then shows the queued run', async () => {
  const user = userEvent.setup()
  renderWithProviders(views(), { route: '/admin/run' })
  await user.type(await screen.findByLabelText('Scrape name'), 'My scan')
  await user.click(await screen.findByLabelText('Bihar')); await user.click(screen.getByLabelText('Rajasthan'))
  await user.click(screen.getByLabelText('Prohibition of Child Marriage Act')); await user.click(screen.getByLabelText('IPC / BNS'))
  await user.type(screen.getByLabelText('Sections (optional)'), '9, 10, 11')
  await user.click(screen.getByRole('button', { name: 'Run scrape' }))
  expect(await screen.findByRole('heading', { name: 'My scan' })).toBeInTheDocument()
  expect(submissions[0]).toMatchObject({ stateCodes: ['5', '6'], actKeys: ['childmarriage', 'ipc'], allStates: false, allActs: false, status: 'all', sections: ['9', '10', '11'] })
  expect(submissions[0].requestId).toBeTruthy()
  expect(screen.getByRole('button', { name: 'Download CSV' })).toBeDisabled()
})
it('supports All selections and cancellation', async () => {
  const user = userEvent.setup()
  renderWithProviders(views(), { route: '/admin/run' })
  await user.type(await screen.findByLabelText('Scrape name'), 'My scan')
  await user.click(screen.getByLabelText('All states')); await user.click(screen.getByLabelText('All acts'))
  await user.click(screen.getByRole('button', { name: 'Run scrape' }))
  await user.click(await screen.findByRole('button', { name: 'Cancel run' }))
  await waitFor(() => expect(screen.getByRole('button', { name: 'Download CSV' })).toBeEnabled())
  expect(submissions[0]).toMatchObject({ allStates: true, allActs: true, stateCodes: [], actKeys: [], sections: [] })
})
it('renders the historical snapshot even when the catalogue has a newer status', async () => {
  renderWithProviders(views(), { route: '/admin/runs/run-1/cases/case-1' })
  expect(await screen.findByText(/Status then: pending/)).toBeInTheDocument()
  expect(screen.getByRole('link', { name: 'View the latest case record' })).toHaveAttribute('href', '/cases/case-1')
})
it('shows the court and source error when an admin inspects failed work', async () => {
  const user = userEvent.setup()
  renderWithProviders(views(), { route: '/admin/runs/run-1' })
  await user.click(await screen.findByRole('button', { name: 'Inspect work items and failures' }))
  expect(await screen.findByText('Source unavailable')).toBeInTheDocument()
  expect(screen.getByText('Bihar · Gaya · District court (1)')).toBeInTheDocument()
})
