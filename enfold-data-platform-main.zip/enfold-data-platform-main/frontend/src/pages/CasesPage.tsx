import { useFilters } from '@/context/filtersState'
import { ActiveFilterChips, FilterBar } from '@/components/cases/FilterBar'
import { AdvancedFilterDrawer } from '@/components/cases/AdvancedFilterDrawer'
import { CaseTable } from '@/components/cases/CaseTable'
import { PageHead } from '@/components/ui/PageHead'
import { useAuth } from '@/context/authState'
import { useCases } from '@/context/casesState'
import styles from '@/components/cases/FilterBar.module.css'

export function CasesPage() {
  const { searchQuery, setSearchQuery } = useFilters()
  const { isAdmin } = useAuth()
  const { cases, loading, error, reload, total, page, pageSize, setPage } = useCases()
  return (
    <>
      <PageHead
        title="Cases"
        description={`Normalized, filterable view of cases pulled from eCourts in our scheduled, monthly scrape.${
          isAdmin ? '' : " You're seeing the fields available to field officers."
        }`}
      />

      {error ? <p role="alert">{error} <button onClick={reload}>Retry</button></p> : null}
      <form onSubmit={(event) => {
        event.preventDefault()
        setSearchQuery(String(new FormData(event.currentTarget).get('search') ?? '').trim())
      }} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input key={searchQuery} name="search" aria-label="Search all cases" placeholder="Search all cases" defaultValue={searchQuery} maxLength={200} />
        <button type="submit">Search</button>
        {searchQuery ? <button type="button" onClick={() => setSearchQuery('')}>Clear search</button> : null}
      </form>
      <FilterBar />
      <ActiveFilterChips />

      <p className={styles.resultsCount} role="status">
        {loading ? 'Loading cases…' : `${total} case${total === 1 ? '' : 's'}`}
      </p>

      <CaseTable
        cases={cases}
        caption="Cases matching the current filters"
        emptyTitle="No cases match these filters"
        emptyDescription="Try removing a filter, switching the scrape, or use the search bar above."
      />

      <nav aria-label="Case pages" style={{ display: 'flex', alignItems: 'center', gap: 16, margin: '16px 0' }}>
        <button disabled={loading || page <= 1} onClick={() => setPage(page - 1)}>Previous page</button>
        <span>Page {page} of {Math.max(1, Math.ceil(total / pageSize))}</span>
        <button disabled={loading || page * pageSize >= total} onClick={() => setPage(page + 1)}>Next page</button>
      </nav>
      <AdvancedFilterDrawer />
    </>
  )
}
