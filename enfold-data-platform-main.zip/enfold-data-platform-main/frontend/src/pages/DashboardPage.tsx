import clsx from 'clsx'
import {
  OutcomeDonutChart,
  SectionsBarChart,
  StateBarChart,
  YearTrendChart,
} from '@/components/dashboard/PcmaCharts'
import { PageHead } from '@/components/ui/PageHead'
import styles from '@/components/dashboard/Charts.module.css'

export function DashboardPage() {
  return (
    <>
      <PageHead
        title="PCMA Dashboard"
        description="Prohibition of Child Marriage Act trends in the available case records."
      />

      <div className={clsx(styles.chartsGrid, styles.single)}>
        <StateBarChart />
      </div>
      <div className={styles.chartsGrid}>
        <OutcomeDonutChart />
        <SectionsBarChart />
      </div>
      <div className={clsx(styles.chartsGrid, styles.single)}>
        <YearTrendChart />
      </div>
    </>
  )
}
