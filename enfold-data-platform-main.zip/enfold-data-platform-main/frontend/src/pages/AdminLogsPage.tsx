import { useCallback, useState } from 'react'
import { Link } from 'react-router-dom'
import { PageHead } from '@/components/ui/PageHead'
import { scrapeService } from '@/services/scrapeService'
import { usePollingResource } from '@/hooks/usePollingResource'
import styles from '@/components/ui/DataTable.module.css'
export function AdminLogsPage() {
  const [page, setPage] = useState(1)
  const load = useCallback((signal: AbortSignal) => scrapeService.listRunPage(page, signal), [page])
  const { data, error, loading, refresh } = usePollingResource(`runs:${page}`, load)
  return <>
    <PageHead title="Scrape run logs" description="Manual and scheduled runs are shared with all administrators." />
    {loading ? <p role="status">Loading run history…</p> : null}
    {error ? <p role="alert">{error} <button onClick={refresh}>Retry</button></p> : null}
    <div className={styles.wrap}><table><caption>Scrape run history</caption><thead><tr>
      <th>Run</th><th>Trigger</th><th>Queued</th><th>Outcome</th><th>Saved cases</th><th>Results</th>
    </tr></thead><tbody>{data?.items.map((run) => <tr key={run.id}>
      <td>{run.name}</td><td>{run.trigger}</td><td>{new Date(run.queuedAt).toLocaleString()}</td><td>{run.outcome}</td><td>{run.total}</td>
      <td><Link to={`/admin/runs/${run.id}`}>Open results</Link></td>
    </tr>)}</tbody></table></div>
    {data && !data.total ? <p>No scrape runs recorded.</p> : null}
    <nav aria-label="Run pages" style={{ display: 'flex', gap: 16, margin: '16px 0' }}>
      <button disabled={page === 1 || loading} onClick={() => setPage((v) => v - 1)}>Previous page</button>
      <span>Page {page} of {Math.max(1, Math.ceil((data?.total ?? 0) / 25))}</span>
      <button disabled={!data || page * 25 >= data.total || loading} onClick={() => setPage((v) => v + 1)}>Next page</button>
    </nav>
  </>
}
