import { useCallback, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { PageHead } from '@/components/ui/PageHead'
import { scrapeService } from '@/services/scrapeService'
import { usePollingResource } from '@/hooks/usePollingResource'
import { ACT_OPTIONS } from '@/lib/caseMetadata'
import type { Page, RunSnapshot } from '@/types/scraper'
import styles from '@/components/ui/DataTable.module.css'

function WorkItems({ id }: { id: string }) {
  const [page, setPage] = useState(1)
  const [status, setStatus] = useState('failed')
  const load = useCallback((signal: AbortSignal) => scrapeService.tasks(id, page, status, signal), [id, page, status])
  const { data, error, loading, refresh } = usePollingResource(`tasks:${id}:${page}:${status}`, load)
  return <section><h2>Work items</h2>
    <label>Task status <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1) }}>{['failed', 'queued', 'running', 'success', 'cancelled', 'all'].map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
    {error ? <p role="alert">{error} <button onClick={refresh}>Retry work items</button></p> : null}
    <div className={styles.wrap}><table><thead><tr><th>Work type</th><th>Location / criteria</th><th>Status</th><th>Attempts</th><th>Error</th></tr></thead><tbody>{data?.items.map((task) => <tr key={task.id}>
      <td>{task.kind}</td><td>{[task.payload.state?.name, task.payload.district?.name, task.payload.court ? `${task.payload.court.name} (${task.payload.court.code})` : null, task.payload.cnr, task.payload.act_code ? `Act code ${task.payload.act_code}` : null, task.payload.section ? `Section ${task.payload.section}` : null, task.payload.status].filter(Boolean).join(' · ') || 'Nationwide discovery'}</td>
      <td>{task.status}</td><td>{task.attempts}</td><td>{task.error_message ?? '—'}</td>
    </tr>)}</tbody></table></div>
    {data && !data.total ? <p>No {status === 'all' ? '' : status} work items.</p> : null}
    <nav aria-label="Work item pages"><button disabled={page === 1 || loading} onClick={() => setPage((v) => v - 1)}>Previous work items</button> Page {page} <button disabled={!data || page * 25 >= data.total || loading} onClick={() => setPage((v) => v + 1)}>Next work items</button></nav>
  </section>
}

function Snapshots({ id, active }: { id: string; active: boolean }) {
  const [page, setPage] = useState(1)
  const load = useCallback((signal: AbortSignal): Promise<Page<RunSnapshot>> => scrapeService.results(id, page, signal), [id, page])
  const { data, error, loading, refresh } = usePollingResource(`results:${id}:${page}`, load, active ? 5000 : 0)
  return <section><h2>Results collected during this run</h2>
    {error ? <p role="alert">{error} <button onClick={refresh}>Retry results</button></p> : null}
    {loading ? <p role="status">Loading snapshots…</p> : null}
    <div className={styles.wrap}><table><caption>Historical case snapshots</caption><thead><tr><th>CNR</th><th>District</th><th>Status then</th><th>Change</th><th>Collected</th><th>Details</th></tr></thead><tbody>
      {data?.items.map(({ snapshot, fetched_at, change_kind }) => <tr key={snapshot.id}><td>{snapshot.cnr}</td><td>{snapshot.district}</td><td>{snapshot.status}</td><td>{change_kind}</td><td>{new Date(fetched_at).toLocaleString()}</td><td><Link to={`/admin/runs/${id}/cases/${snapshot.id}`}>View snapshot</Link></td></tr>)}
    </tbody></table></div>
    {data && !data.total ? <p>No case snapshots saved yet.</p> : null}
    <nav aria-label="Snapshot pages" style={{ display: 'flex', gap: 16, margin: '16px 0' }}><button disabled={page === 1 || loading} onClick={() => setPage((v) => v - 1)}>Previous results</button><span>Page {page} of {Math.max(1, Math.ceil((data?.total ?? 0) / 25))}</span><button disabled={!data || page * 25 >= data.total || loading} onClick={() => setPage((v) => v + 1)}>Next results</button></nav>
  </section>
}
export function AdminRunDetailPage() {
  const id = useParams().runId ?? ''
  const [eventPage, setEventPage] = useState(1)
  const load = useCallback((signal: AbortSignal) => scrapeService.getRun(id, signal), [id])
  const loadEvents = useCallback((signal: AbortSignal) => scrapeService.events(id, eventPage, signal), [id, eventPage])
  const runData = usePollingResource(`run:${id}`, load)
  const events = usePollingResource(`events:${id}:${eventPage}`, loadEvents)
  const [actionError, setActionError] = useState('')
  const [busy, setBusy] = useState(false)
  const [tasksOpen, setTasksOpen] = useState(false)
  const run = runData.data
  const active = run && ['queued', 'pending', 'running'].includes(run.outcome)
  async function action(kind: 'cancel' | 'retry' | 'download') {
    setBusy(true); setActionError('')
    try { await scrapeService[kind](id); runData.refresh(); events.refresh() }
    catch (error) { setActionError(error instanceof Error ? error.message : 'Action failed.') }
    finally { setBusy(false) }
  }
  if (!run) return <p role={runData.error ? 'alert' : 'status'}>{runData.error ?? 'Loading run…'} {runData.error ? <button onClick={runData.refresh}>Retry</button> : null}</p>
  const criteria = run.criteria
  return <>
    <Link to="/admin/logs">← Scrape Run Logs</Link>
    <PageHead title={run.name} description={`${run.trigger === 'scheduled' ? 'Monthly scheduled' : 'Manual'} run · ${run.outcome}`} />
    {runData.error || actionError ? <p role="alert">{actionError || runData.error}</p> : null}
    <dl><dt>Queued</dt><dd>{new Date(run.queuedAt).toLocaleString()}</dd><dt>Started</dt><dd>{run.startedAt ? new Date(run.startedAt).toLocaleString() : 'Waiting for worker'}</dd><dt>Completed</dt><dd>{run.completedAt ? new Date(run.completedAt).toLocaleString() : '—'}</dd>
      <dt>Initiated by</dt><dd>{run.trigger === 'scheduled' ? 'Monthly scheduler' : run.triggeredBy ?? 'Legacy/deleted account'}</dd>
      <dt>States</dt><dd>{criteria?.allStates ? 'All states' : run.resolvedScope?.states.map((s) => s.name).join(', ') || criteria?.stateCodes.join(', ') || run.legacyCriteria.state || '—'}</dd>
      <dt>Acts</dt><dd>{criteria?.allActs ? 'All eight act options' : criteria?.actKeys.map((key) => ACT_OPTIONS.find((a) => a.key === key)?.label ?? key).join(', ') || run.legacyCriteria.acts || '—'}</dd>
      <dt>Sections</dt><dd>{criteria ? criteria.sections.join(', ') || 'All sections' : run.legacyCriteria.sections || '—'}</dd>
      <dt>Case status</dt><dd>{criteria?.status ?? run.legacyCriteria.status}</dd></dl>
    <p role="status">{run.total} saved cases: {run.counts.new ?? 0} new, {run.counts.updated ?? 0} updated, {run.counts.unchanged ?? 0} unchanged.</p>
    <p>{run.tasks.success ?? 0} completed tasks · {run.tasks.queued ?? 0} queued · {run.tasks.running ?? 0} running · {run.tasks.failed ?? 0} failed · {run.tasks.cancelled ?? 0} cancelled. More tasks may be discovered as courts are scanned.</p>
    <details><summary>Coverage by work type</summary><ul>{run.coverage.map((row) => <li key={`${row.kind}:${row.status}`}>{row.kind}: {row.count} {row.status}</li>)}</ul></details>
    {run.snapshotsAvailable ? <><button aria-expanded={tasksOpen} onClick={() => setTasksOpen((value) => !value)}>{tasksOpen ? 'Hide work items' : 'Inspect work items and failures'}</button>{tasksOpen ? <WorkItems key={id} id={id} /> : null}</> : null}
    {run.error ? <p role="alert">Last recorded error: {run.error}</p> : null}
    <div style={{ display: 'flex', gap: 12, margin: '16px 0' }}>
      {active ? <button disabled={busy} onClick={() => void action('cancel')}>Cancel run</button> : null}
      {run.snapshotsAvailable && ['partial', 'failed', 'cancelled'].includes(run.outcome) ? <button disabled={busy || Boolean(run.tasks.running)} onClick={() => void action('retry')}>Retry unfinished work</button> : null}
      {run.snapshotsAvailable ? <button disabled={busy || Boolean(active)} onClick={() => void action('download')}>{busy ? 'Please wait…' : 'Download CSV'}</button> : null}
    </div>
    {run.snapshotsAvailable ? <Snapshots key={id} id={id} active={Boolean(active)} /> : <p>Historical case snapshots were not recorded for this legacy run.</p>}
    <section><h2>Audit history</h2>{events.error ? <p role="alert">{events.error} <button onClick={events.refresh}>Retry audit history</button></p> : null}
      <ol>{events.data?.items.map((event) => <li key={event.id}><time>{new Date(event.at).toLocaleString()}</time> · {event.kind}: {event.message}{event.actor_name ? ` — ${event.actor_name}` : ''}</li>)}</ol>
      <nav aria-label="Audit pages"><button disabled={eventPage === 1} onClick={() => setEventPage((v) => v - 1)}>Newer events</button> <span>Page {eventPage}</span> <button disabled={!events.data || eventPage * 50 >= events.data.total} onClick={() => setEventPage((v) => v + 1)}>Older events</button></nav>
    </section>
  </>
}
