import type { JSX, SVGProps } from 'react'

const PATHS: Record<string, JSX.Element> = {
  dashboard: (
    <>
      <rect x="3" y="3" width="7" height="9" rx="1" />
      <rect x="14" y="3" width="7" height="5" rx="1" />
      <rect x="14" y="12" width="7" height="9" rx="1" />
      <rect x="3" y="16" width="7" height="5" rx="1" />
    </>
  ),
  cases: <path d="M4 6a2 2 0 0 1 2-2h5l2 2h5a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6Z" />,
  run: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M10 8l6 4-6 4V8Z" />
    </>
  ),
  logs: (
    <>
      <path d="M9 4h9a2 2 0 0 1 2 2v13a1 1 0 0 1-1.4.9L15 18l-3.6 1.9A1 1 0 0 1 10 19V6a2 2 0 0 1 2-2Z" />
      <path d="M5 8v11a2 2 0 0 0 2 2h9" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4.3-4.3" />
    </>
  ),
  chev: <path d="m6 9 6 6 6-6" />,
  x: <path d="M18 6 6 18M6 6l12 12" />,
  check: <path d="M20 6 9 17l-5-5" />,
  filter: <path d="M4 5h16M7 12h10M10 19h4" />,
  bolt: <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" />,
  doc: (
    <>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Z" />
      <path d="M14 2v6h6" />
    </>
  ),
  logout: <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" />,
  inbox: (
    <>
      <path d="M4 12h4l2 3h4l2-3h4" />
      <path d="M5.5 5h13l2 7v7a1 1 0 0 1-1 1H4.5a1 1 0 0 1-1-1v-7l2-7Z" />
    </>
  ),
  bell: (
    <>
      <path d="M6 8a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z" />
      <path d="M10 20a2 2 0 0 0 4 0" />
    </>
  ),
  alert: (
    <path d="M12 9v4M12 17h.01M10.3 3.9 2.2 18a1.8 1.8 0 0 0 1.5 2.7h16.6a1.8 1.8 0 0 0 1.5-2.7L13.7 3.9a1.8 1.8 0 0 0-3.4 0Z" />
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M3 10h18M8 3v4M16 3v4" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3.5 2" />
    </>
  ),
  lock: (
    <>
      <rect x="4" y="10" width="16" height="11" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
  layers: (
    <>
      <path d="M12 2 2 7l10 5 10-5-10-5Z" />
      <path d="M2 17l10 5 10-5M2 12l10 5 10-5" />
    </>
  ),
  scale: (
    <>
      <path d="M12 3v18M7 21h10M12 6l-6 2 6-2 6 2-6-2Z" />
      <path d="M6 8 3 14a3 3 0 0 0 6 0L6 8Zm12 0-3 6a3 3 0 0 0 6 0l-3-6Z" />
    </>
  ),
  gavel: (
    <>
      <path d="m14 6-6 6 3 3 6-6-3-3Z" />
      <path d="m9 11-5 5 1.5 1.5 5-5M13 3l4 4M16 6l3 3M4 21h8" />
    </>
  ),
  shield: (
    <>
      <path d="M12 2 4 5v6c0 5 3.5 8.5 8 11 4.5-2.5 8-6 8-11V5l-8-3Z" />
      <path d="m9 12 2 2 4-4" />
    </>
  ),
  pinOutline: (
    <path d="M14.5 2.5 21.5 9.5l-3 1-3.2 3.2.4 4.6-2 2-3.6-3.6-4.3 4.3-1.4-1.4 4.3-4.3L3.3 12.7l2-2 4.6.4L13.1 8l1-3Z" />
  ),
}

const STROKE_WIDTHS: Record<string, number> = {
  chev: 2.5,
  x: 2.5,
  check: 3,
  scale: 1.9,
  gavel: 1.8,
  shield: 1.8,
  pinOutline: 1.9,
}

export type IconName = keyof typeof PATHS | 'pin'

interface IconProps extends Omit<SVGProps<SVGSVGElement>, 'name'> {
  name: IconName
  /** Announced to assistive tech; omit for purely decorative icons. */
  title?: string
}

export function Icon({ name, title, ...props }: IconProps) {
  const decorative = !title

  if (name === 'pin') {
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden={decorative} role={decorative ? undefined : 'img'} {...props}>
        {title ? <title>{title}</title> : null}
        <path d="M14.5 2.5 21.5 9.5l-3 1-3.2 3.2.4 4.6-2 2-3.6-3.6-4.3 4.3-1.4-1.4 4.3-4.3L3.3 12.7l2-2 4.6.4L13.1 8l1-3Z" />
      </svg>
    )
  }

  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={STROKE_WIDTHS[name] ?? 2}
      strokeLinejoin={name === 'pinOutline' ? 'round' : undefined}
      aria-hidden={decorative}
      role={decorative ? undefined : 'img'}
      {...props}
    >
      {title ? <title>{title}</title> : null}
      {PATHS[name]}
    </svg>
  )
}

export function GoogleIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <path
        fill="#4285F4"
        d="M22.5 12.2c0-.8-.1-1.5-.2-2.2H12v4.3h5.9c-.3 1.4-1 2.5-2.2 3.3v2.8h3.6c2.1-2 3.2-4.8 3.2-8.2Z"
      />
      <path
        fill="#34A853"
        d="M12 23c3 0 5.4-1 7.3-2.6l-3.6-2.8c-1 .7-2.2 1.1-3.7 1.1-2.8 0-5.2-1.9-6-4.5H2.3v2.9C4.2 20.6 7.8 23 12 23Z"
      />
      <path fill="#FBBC05" d="M6 14.2a6.6 6.6 0 0 1 0-4.4V6.9H2.3a11 11 0 0 0 0 9.9L6 14.2Z" />
      <path
        fill="#EA4335"
        d="M12 5.4c1.6 0 3.1.6 4.3 1.7l3.2-3.2C17.4 2 15 1 12 1 7.8 1 4.2 3.4 2.3 6.9L6 9.8c.8-2.6 3.2-4.4 6-4.4Z"
      />
    </svg>
  )
}
