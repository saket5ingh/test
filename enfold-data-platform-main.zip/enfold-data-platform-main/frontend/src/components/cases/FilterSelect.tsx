import { useCallback, useId, useRef, useState } from 'react'
import clsx from 'clsx'
import { Icon } from '@/components/icons/Icon'
import { useClickAway } from '@/hooks/useClickAway'
import type { FilterOption } from '@/types'
import styles from './FilterBar.module.css'

interface FilterSelectProps {
  label: string
  options: FilterOption[]
  selected: string[]
  onToggle: (value: string) => void
}

export function FilterSelect({ label, options, selected, onToggle }: FilterSelectProps) {
  const [open, setOpen] = useState(false)
  const wrapRef = useRef<HTMLDivElement>(null)
  const panelId = useId()

  const close = useCallback(() => setOpen(false), [])
  useClickAway(wrapRef, open, close)

  return (
    <div className={styles.fselect} ref={wrapRef}>
      <button
        type="button"
        className={clsx(styles.trigger, selected.length > 0 && styles.active)}
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen((v) => !v)}
        onKeyDown={(e) => e.key === 'Escape' && close()}
      >
        {label}
        {selected.length ? ` (${selected.length})` : ''}
        <Icon name="chev" />
      </button>

      {open ? (
        <div className={styles.panel} id={panelId} role="group" aria-label={label}>
          {options.map((o) => (
            <label className={styles.option} key={o.key}>
              <input
                type="checkbox"
                checked={selected.includes(o.key)}
                onChange={() => onToggle(o.key)}
              />
              {o.label}
            </label>
          ))}
        </div>
      ) : null}
    </div>
  )
}
