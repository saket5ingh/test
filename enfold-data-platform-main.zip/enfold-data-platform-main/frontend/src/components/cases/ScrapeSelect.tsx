import { useCallback, useId, useRef, useState } from 'react'
import clsx from 'clsx'
import { Icon } from '@/components/icons/Icon'
import { useCases } from '@/context/casesState'
import { useClickAway } from '@/hooks/useClickAway'
import { scrapeLabel } from '@/lib/freshness'
import styles from './FilterBar.module.css'

interface ScrapeSelectProps {
  value: string
  onChange: (value: string) => void
}

export function ScrapeSelect({ value, onChange }: ScrapeSelectProps) {
  const { options, scrapes } = useCases()
  const [open, setOpen] = useState(false)
  const wrapRef = useRef<HTMLDivElement>(null)
  const panelId = useId()

  const close = useCallback(() => setOpen(false), [])
  useClickAway(wrapRef, open, close)

  const label = value === 'all' ? 'All scrapes' : scrapeLabel(value)

  const select = (id: string) => {
    onChange(id)
    close()
  }

  const rows = [
    { id: 'all', label: 'All scrapes', count: options.totalCases, latest: false },
    ...scrapes.map((s, i) => ({
      id: s.id,
      label: s.short,
      count: s.count ?? 0,
      latest: i === 0,
    })),
  ]

  return (
    <div className={styles.fselect} ref={wrapRef}>
      <button
        type="button"
        className={clsx(styles.trigger, value !== 'all' && styles.active)}
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen((v) => !v)}
      >
        <Icon name="layers" /> {label} <Icon name="chev" />
      </button>

      {open ? (
        <div
          className={clsx(styles.panel, styles.panelRight)}
          id={panelId}
          role="radiogroup"
          aria-label="Scrape"
          style={{ minWidth: 230 }}
        >
          {rows.map((row) => (
            <button
              type="button"
              key={row.id}
              role="radio"
              aria-checked={value === row.id}
              className={clsx(styles.radioRow, value === row.id && styles.selected)}
              onClick={() => select(row.id)}
            >
              <span>
                {row.label}
                {row.latest ? <span className={styles.latestTag}>Latest</span> : null}
              </span>
              <span className={styles.radioCount}>{row.count}</span>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  )
}
