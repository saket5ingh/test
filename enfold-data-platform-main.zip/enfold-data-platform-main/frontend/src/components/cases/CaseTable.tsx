import clsx from 'clsx'
import { Link, useNavigate } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { ActTag } from '@/components/ui/Badges'
import { EmptyState } from '@/components/ui/EmptyState'
import { StatusBadge } from '@/components/ui/StatusBadge'
import { useAuth } from '@/context/authState'
import { useCases } from '@/context/casesState'
import { fmtDate } from '@/lib/format'
import type { Case } from '@/types'
import styles from '@/components/ui/DataTable.module.css'

const shortActLabel = (label: string) => label.split('(')[0].split('/')[0].split(',')[0].trim()

interface CaseTableProps {
  cases: Case[]
  caption: string
  emptyTitle: string
  emptyDescription: string
}

export function CaseTable({ cases, caption, emptyTitle, emptyDescription }: CaseTableProps) {
  const { isAdmin } = useAuth()
  const { togglePin } = useCases()
  const navigate = useNavigate()

  const columnCount = isAdmin ? 9 : 7

  return (
    <div className={styles.wrap}>
      <table>
        <caption>{caption}</caption>
        <thead>
          <tr>
            <th scope="col">
              <span className="visually-hidden">Pin</span>
            </th>
            {isAdmin ? (
              <>
                <th scope="col">CNR</th>
                <th scope="col">Case number</th>
                <th scope="col">Reg. no.</th>
                <th scope="col">Case type</th>
                <th scope="col">District &amp; court</th>
                <th scope="col">Acts</th>
                <th scope="col">Status</th>
                <th scope="col">Hearing</th>
              </>
            ) : (
              <>
                <th scope="col">Reference</th>
                <th scope="col">Case type</th>
                <th scope="col">District</th>
                <th scope="col">Acts</th>
                <th scope="col">Status</th>
                <th scope="col">Key dates</th>
              </>
            )}
          </tr>
        </thead>
        <tbody>
          {cases.length === 0 ? (
            <tr>
              <td colSpan={columnCount}>
                <EmptyState title={emptyTitle} description={emptyDescription} />
              </td>
            </tr>
          ) : (
            cases.map((c) => {
              const acts = c.acts.map((a) => a.name)
              const nextLine = c.nextHearing ? (
                <div className={styles.subtleLine}>Next: {fmtDate(c.nextHearing)}</div>
              ) : null

              return (
                <tr
                  key={c.id}
                  className={styles.clickableRow}
                  onClick={() => navigate(`/cases/${c.id}`)}
                >
                  <td onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      className={clsx(styles.pinBtn, c.pinned && styles.on)}
                      aria-pressed={c.pinned}
                      aria-label={`${c.pinned ? 'Unpin' : 'Pin'} case ${isAdmin ? c.caseNo : c.ref}`}
                      onClick={() => togglePin(c.id)}
                    >
                      <Icon name={c.pinned ? 'pin' : 'pinOutline'} />
                    </button>
                  </td>

                  <td>
                    <Link to={`/cases/${c.id}`} onClick={(e) => e.stopPropagation()}>
                      {isAdmin ? c.cnr : c.ref}
                    </Link>
                  </td>

                  {isAdmin ? (
                    <>
                      <td>{c.caseNo}</td>
                      <td>
                        {c.regNo} / {c.regYear}
                      </td>
                    </>
                  ) : null}

                  <td>{c.caseType}</td>

                  <td className={styles.loc}>
                    {c.district}
                    {isAdmin ? <div className={styles.court}>{c.court}</div> : null}
                    <div className={styles.state}>{c.state}</div>
                  </td>

                  <td>
                    <div className={styles.actsCell}>
                      {acts.map((label) => (
                        <ActTag key={label}>{shortActLabel(label)}</ActTag>
                      ))}
                    </div>
                  </td>

                  <td>
                    <StatusBadge status={c.status} />
                  </td>

                  {isAdmin ? (
                    <td>
                      {c.hearings && c.hearings.length > 0 ? fmtDate(c.hearings[c.hearings.length - 1].date) : ''}
                      <div className={styles.subtleLine}>{c.lastPurpose}</div>
                      {nextLine}
                    </td>
                  ) : (
                    <td>
                      <div style={{ fontSize: 11.5 }}>
                        Decision: <b>{fmtDate(c.decisionDate)}</b>
                      </div>
                      <div className={styles.subtleLine}>Filed {fmtDate(c.filingDate)}</div>
                      {nextLine}
                    </td>
                  )}
                </tr>
              )
            })
          )}
        </tbody>
      </table>
    </div>
  )
}
