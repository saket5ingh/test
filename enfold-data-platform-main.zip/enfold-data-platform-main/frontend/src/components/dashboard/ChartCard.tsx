import type { ReactNode } from 'react'
import { IllustrativeTag } from '@/components/ui/Badges'
import styles from './Charts.module.css'

interface ChartCardProps {
  title: string
  subtitle: string
  illustrative?: boolean
  children: ReactNode
  /** Screen-reader equivalent of the chart, rendered as a table. */
  dataTable: { caption: string; columns: [string, string]; rows: Array<[string, number]> }
}

export function ChartCard({
  title,
  subtitle,
  illustrative = true,
  children,
  dataTable,
}: ChartCardProps) {
  return (
    <section className={styles.chartCard} aria-label={title}>
      <div className={styles.chartHead}>
        <div>
          <h2>{title}</h2>
          <div className={styles.sub}>{subtitle}</div>
        </div>
        {illustrative ? <IllustrativeTag /> : null}
      </div>
      <div className={styles.chartBody}>
        <div aria-hidden="true">{children}</div>
        <table className="visually-hidden">
          <caption>{dataTable.caption}</caption>
          <thead>
            <tr>
              <th scope="col">{dataTable.columns[0]}</th>
              <th scope="col">{dataTable.columns[1]}</th>
            </tr>
          </thead>
          <tbody>
            {dataTable.rows.map(([label, value]) => (
              <tr key={label}>
                <th scope="row">{label}</th>
                <td>{value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
