import { USE_MOCK, delay } from './config'
import { request } from './http'
import {
  PCMA_BY_STATE,
  PCMA_OUTCOMES,
  PCMA_BY_SECTION,
  PCMA_BY_YEAR
} from './mock/analytics.mock'

export interface StateData {
  state: string
  value: number
}

export interface OutcomeData {
  label: string
  value: number
}

export interface SectionData {
  section: string
  value: number
}

export interface YearData {
  year: string
  value: number
}

export const analyticsService = {
  async getByState(): Promise<StateData[]> {
    if (!USE_MOCK) return request<StateData[]>('/analytics/by-state')
    return delay(PCMA_BY_STATE)
  },
  async getOutcomes(): Promise<OutcomeData[]> {
    if (!USE_MOCK) return request<OutcomeData[]>('/analytics/outcomes')
    return delay(PCMA_OUTCOMES)
  },
  async getBySection(): Promise<SectionData[]> {
    if (!USE_MOCK) return request<SectionData[]>('/analytics/by-section')
    return delay(PCMA_BY_SECTION)
  },
  async getByYear(): Promise<YearData[]> {
    if (!USE_MOCK) return request<YearData[]>('/analytics/by-year')
    return delay(PCMA_BY_YEAR)
  }
}
