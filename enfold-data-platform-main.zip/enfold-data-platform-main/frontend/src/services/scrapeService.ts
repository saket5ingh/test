import type { RunCriteria, ScraperRun, ScraperOptions, Page, RunSnapshot, RunEvent, RunTask } from '@/types/scraper'
import { API_BASE_URL, USE_MOCK } from './config'
import { request, tokenStore, ApiError } from './http'
import { CUSTOM_SCRAPES } from './mock/customScrapes.mock'
import { ACT_OPTIONS } from '@/lib/caseMetadata'

const demoRuns: ScraperRun[] = CUSTOM_SCRAPES.map((r) => ({ id: r.id, name: r.name, criteria: null,
  resolvedScope: null, trigger: 'manual', triggeredBy: r.triggeredBy, queuedAt: r.ranAt, startedAt: r.ranAt,
  completedAt: r.ranAt, outcome: r.outcome, tasks: {}, counts: {}, total: r.count,
  coverage: [], snapshotsAvailable: false, error: null, cancelRequested: false,
  legacyCriteria: { state: r.state, acts: r.acts, sections: r.sections, status: r.status } }))

export const scrapeService = {
  async options(signal?: AbortSignal): Promise<ScraperOptions> {
    if (USE_MOCK) return { states: [], acts: ACT_OPTIONS.map(({ key, label }) => ({ key, label })), statesUpdatedAt: null, workerLastSeen: null, workerHealthy: false, monthlyEnabled: false }
    return request('/scrapes/options', { signal })
  },
  async runScrape(form: RunCriteria & { name: string; requestId: string }): Promise<{ id: string }> {
    if (USE_MOCK) throw new Error('Live scraping requires API mode and the scraper worker.')
    return request('/scrapes/run', { method: 'POST', body: JSON.stringify(form) })
  },
  async listRunPage(page = 1, signal?: AbortSignal): Promise<Page<ScraperRun>> {
    if (USE_MOCK) return { items: demoRuns, total: demoRuns.length, page: 1, pageSize: 25 }
    return request(`/scrapes/runs?page=${page}`, { signal })
  },
  async listRuns(): Promise<ScraperRun[]> { return (await this.listRunPage()).items },
  async getRun(id: string, signal?: AbortSignal): Promise<ScraperRun> {
    if (USE_MOCK) { const run = demoRuns.find((r) => r.id === id); if (run) return run; throw new Error('Run not found') }
    return request(`/scrapes/runs/${encodeURIComponent(id)}`, { signal })
  },
  results(id: string, page: number, signal?: AbortSignal): Promise<Page<RunSnapshot>> {
    return request(`/scrapes/runs/${encodeURIComponent(id)}/results?page=${page}`, { signal })
  },
  events(id: string, page: number, signal?: AbortSignal): Promise<Page<RunEvent>> {
    if (USE_MOCK) return Promise.resolve({ items: [], total: 0, page: 1, pageSize: 50 })
    return request(`/scrapes/runs/${encodeURIComponent(id)}/events?page=${page}`, { signal })
  },
  tasks(id: string, page: number, status: string, signal?: AbortSignal): Promise<Page<RunTask>> {
    return request(`/scrapes/runs/${encodeURIComponent(id)}/tasks?page=${page}&status=${encodeURIComponent(status)}`, { signal })
  },
  cancel(id: string) { return request(`/scrapes/runs/${encodeURIComponent(id)}/cancel`, { method: 'POST' }) },
  retry(id: string) { return request(`/scrapes/runs/${encodeURIComponent(id)}/retry`, { method: 'POST' }) },
  async download(id: string) {
    // Bearer auth stays in headers, never in a URL. CSV has a longer timeout than JSON.
    const response = await fetch(`${API_BASE_URL}/scrapes/runs/${encodeURIComponent(id)}/csv`, {
      headers: { Authorization: `Bearer ${tokenStore.get() ?? ''}` }, signal: AbortSignal.timeout(300000),
    })
    if (!response.ok) {
      const body = await response.json().catch(() => null)
      throw new ApiError(body?.detail ?? 'CSV download failed.', response.status)
    }
    const url = URL.createObjectURL(await response.blob())
    const link = document.createElement('a')
    link.href = url; link.download = `ffg-run-${id}.csv`; link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  },
}
