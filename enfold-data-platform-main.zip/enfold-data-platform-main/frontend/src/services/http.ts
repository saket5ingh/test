import { API_BASE_URL } from './config'

export class ApiError extends Error {
  readonly status: number

  constructor(message: string, status: number) {
    super(message)
    this.name = 'ApiError'
    this.status = status
  }
}

const unauthorizedListeners = new Set<() => void>()
export function onUnauthorized(listener: () => void) {
  unauthorizedListeners.add(listener)
  return () => { unauthorizedListeners.delete(listener) }
}

let authToken: string | null = null

export const tokenStore = {
  get: () => authToken,
  set: (token: string | null) => {
    authToken = token
  },
}

export async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers)
  headers.set('Accept', 'application/json')
  if (init.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }
  const requestToken = authToken
  if (requestToken) headers.set('Authorization', `Bearer ${requestToken}`)

  const response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers, signal: init.signal ? AbortSignal.any([init.signal, AbortSignal.timeout(20000)]) : AbortSignal.timeout(20000) })

  if (!response.ok) {
    if (response.status === 401 && requestToken && requestToken === authToken && path !== '/auth/login') {
      unauthorizedListeners.forEach((listener) => listener())
    }
    const body = await response.json().catch(() => null)
    const detail = typeof body?.detail === 'string' ? body.detail : Array.isArray(body?.detail)
      ? body.detail.map((item: { msg?: string }) => item.msg ?? 'Invalid input').join('; ') : response.statusText
    throw new ApiError(detail || 'Request failed. Please try again.', response.status)
  }
  if (response.status === 204) return undefined as T
  return (await response.json()) as T
}
