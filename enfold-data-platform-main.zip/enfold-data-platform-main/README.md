# Enfold Data Platform (FFG)

FFG is a standalone React/Vite + FastAPI + PostgreSQL application. This
repository contains the FFG application only; it has no Django runtime dependency.

## Data handling

This repository holds code only. The data it processes concerns real litigants in child-protection matters, so:

- Never commit scraped records, exports, database dumps, or sample data drawn from real cases.
- Never commit credentials, API keys, or `.env` files. Use `.env.example` to document required variables.

`.gitignore` excludes the common cases, but it is not a substitute for checking what a commit contains.

## Scope and access

Implemented: password login, configurable Google sign-in, administrator password
resets, a shared case catalogue, server-side search/filtering and pagination,
personal pins, role-based responses, hearing details, PCMA reporting, and a durable
background scraper with historical snapshots, CSV downloads and pinned-case alerts.

All authenticated users can view cases across districts. District selection is
only a search filter; there are no organization/district access assignments.
Field officers receive redacted case identifiers, court names and hearing history.
Administrators receive those fields. Roles are assigned by an administrator,
never chosen during sign-in. Pins belong to the current user.

PDF viewing is **removed from the product**, including API response fields. Legacy
`case_documents` rows remain in storage for compatibility; no PDF endpoint is
exposed. Old global pins are also retained but never assigned to an arbitrary user.

Administrators can queue multi-state/multi-act scans, inspect progress and failures,
cancel/retry work, view historical results and download CSVs. The worker is an
independent Python process using a PostgreSQL queue; it does not require Django
or Redis. Monthly nationwide scanning is implemented but **disabled until the
schedule is confirmed**. See [scraper operations and verification](docs/SCRAPER.md).
Mock mode (`VITE_USE_MOCK=true`) is only for demonstrations and cannot run scrapes.

## Local development

Requirements: PostgreSQL 15+, Python 3.12, Node 24. Use an independent database;
do not point setup or demo seeding at the existing Django database.

1. Install dependencies:
   ```sh
   # Run from the repository root.
   python3.12 -m venv backend/.venv
   . backend/.venv/bin/activate
   pip install -r backend/requirements-dev.txt
   npm --prefix frontend ci
   ```
2. Set PostgreSQL administrator connection variables (`PGHOST`, `PGPORT`,
   `PGUSER`, and optionally `PGPASSWORD`). Set independent `FFG_DB_PASSWORD` and
   `FFG_WORKER_PASSWORD` values for the API and scraper roles, then run `bash db/setup_local_db.sh`. It creates the database/role if missing,
   applies migrations and grants, and verifies reads using the app role. It never
   drops the database or silently changes an existing role password.
   Optional names: `FFG_DB_NAME`, `FFG_DB_ROLE` and `FFG_WORKER_ROLE`.
3. Copy `backend/.env.example` to `backend/.env`. Set `DATABASE_URL` to the
   `postgresql+asyncpg` URL for the app role. Generate a JWT secret with
   `python -c 'import secrets; print(secrets.token_hex(32))'`. URL-encode special
   characters in database passwords. `CORS_ORIGINS` is a JSON array. Prefer the
   same-origin `/api` proxy, especially for Google sign-in cookies.
4. Provision an account using a **database-owner** connection:
   ```sh
   cd backend
   # Export DATABASE_URL with the owner connection for this command only.
   python -m app.create_user
   ```
   Restore the application-role URL before starting the API. This command updates
   an existing account's profile/role/password, activates it, and revokes prior
   API sessions. An email change also clears its linked Google identity.
5. Run `uvicorn app.main:app --reload --port 8000` from `backend/`. In another
   terminal run `npm --prefix frontend run dev` from the repository root.
   Vite proxies `/api` to `127.0.0.1:8000`. Mocks are off by default.
6. In a separate backend terminal, export `DATABASE_URL` using the **worker**
   role (`pcma_worker` by default), then run `python -m app.scraper.worker`.
   Keep the API process on its own role. The worker loads state options, picks up
   queued jobs and persists checkpoints. No scrape runs until an admin queues
   one or the monthly schedule is explicitly enabled.

Optional illustrative records: run setup with `FFG_SEED_DEMO=1`. Seed identities
are inactive and require explicit provisioning. Existing deployments using old
seed credentials must reset or disable those accounts before allowing access.
Seed records do not represent completed scraping. Do not seed production.

## Administrator password resets

There is no self-service email reset. Verify the requester's identity through
your organization's existing process, then run from `backend/` with a
**database-owner** `DATABASE_URL`:

```sh
python -m app.reset_password USER_ID
```

The command prompts privately for a new password and confirmation (12–72 UTF-8
bytes); it does not accept passwords in shell arguments. It preserves the
account's name, email, role, Google link and active/disabled status, and increments
`auth_version` so all previously issued API tokens stop working. Deliver the new
password through your organization's approved channel. Google sign-in remains
available for an active linked account. To suspend all access, disable the user;
a password reset alone does not revoke their Google account.

Sessions expire after eight hours by default. Logout clears the current browser
session; a copied bearer token remains valid until expiry, account disabling or
an administrator reset. Individual token blacklisting is not implemented.

## Google sign-in setup

The integration is prepared but **disabled until a Web OAuth Client ID is set**.
No client secret is required or accepted by this flow.

1. In Google Cloud, configure the OAuth consent screen/audience and create an
   OAuth client with application type **Web application**. If your consent setup
   is in testing, add the accounts that will test sign-in.
2. Add the exact frontend origins under **Authorized JavaScript origins**, for
   example `http://localhost:5173` for Vite, `http://localhost:8080` for Compose,
   and your deployed `https://…` origin. Include the port, with no path. This
   uses the Google Identity Services popup callback, not a redirect URI flow.
3. Put the public Client ID in backend `GOOGLE_CLIENT_ID` (or `.env` for
   Compose). Restart/recreate the API. Google configuration is read at runtime;
   rebuilding the frontend is unnecessary. Set `AUTH_COOKIE_SECURE=true` under
   HTTPS; `false` is only for local HTTP development.
4. Optionally set `GOOGLE_ALLOWED_DOMAINS=["your-workspace-domain.org"]` to
   require those Google Workspace hosted domains. Leave `[]` to permit either
   Gmail or Workspace identities matching provisioned accounts. This is a
   sign-in policy and does not restrict case access by district.
5. Provision each account with its exact Google email before sign-in. Test a
   field officer, an administrator, a disabled user, an unprovisioned user,
   disallowed domains (if configured), and password-login fallback.

The backend verifies Google's token signature, issuer, audience and expiry, plus
email verification and a browser-bound, ten-minute nonce. It links an existing
active account by email only when Google is authoritative for that address
(Gmail or a hosted Workspace domain), then stores the durable Google `sub`.
A Google account using a third-party non-Workspace email cannot automatically
link; use password login for that provisioned account. No account is created and
no role is accepted from Google claims. Cookies require the frontend/API to be
on the same site; the supplied Vite and nginx proxies satisfy this.

The login page keeps password login available if Google is not configured or its
script fails. Its retry action obtains a fresh nonce. If adding a custom CSP,
allow the official Google Identity Services script/frame/connect resources. Keep
popup-compatible COOP (`same-origin-allow-popups`, included in nginx).

References: [Google token verification](https://developers.google.com/identity/gsi/web/guides/verify-google-id-token)
and [Google button setup](https://developers.google.com/identity/gsi/web/guides/display-button).
Live Google verification still requires your Client ID and allowed origins.

## Database migrations and permissions

`db/01_schema.sql` is the historical baseline. Always run `db/migrate.sql` through
`setup_local_db.sh`; running the baseline alone is insufficient for the current
API. The runner adopts an existing baseline, uses an advisory lock and records
versions. Migration 003 creates personal pins. Migration 004 adds Google subjects,
session versions, unique case-insensitive emails, and constraints for roles,
case/run statuses, nonnegative counts, registration years, scrape months, JSON
act/update shape, and run completion ordering. Nullable unknown values remain
allowed where the API supports them. ORM lengths, defaults, indexes and checks
match the migrated SQL; SQL owns functions, views and timestamp triggers.
Migration 005 adds durable tasks, structured run criteria, immutable case snapshots,
audit events, catalogue/heartbeat metadata and per-user pinned-case notifications.
It also widens hearing purpose text. Existing runs retain their metadata but do
not receive fabricated historical snapshots.

Apply migrations **before starting the updated API**. Tokens issued before the
session-version change require signing in again. `setup_local_db.sh` uses one
transaction for migrations and refreshes grants afterwards. Back up an existing
database first. Invalid existing data (including case-variant duplicate emails)
stops the migration; resolve the reported records deliberately and rerun. No
records are deleted automatically. Known title-case run filter labels are
normalized to lowercase. Migration reruns use the version ledger.

The API role can read catalogue/user/run records, maintain personal-pin rows,
and update **only** the `users.google_sub` column for first Google sign-in.
It can create jobs/audit events and request cancellation/retry. It cannot provision
users, reset passwords, change roles or write case ingestion data. The dedicated
worker role can update cases/hearings and job state, insert snapshots/audit events,
and maintain notifications. It cannot update/delete snapshots or access user
passwords. Legacy scrape criteria and document parameters remain SQL text; new
run criteria and snapshots are JSONB.

## API list contract

`GET /api/cases` returns `{items, total, page, pageSize}`. Page numbers start at 1;
default page size is 25 and maximum is 100. Stable ordering is attention severity,
latest scrape, registration date, then UUID. List rows omit hearing history;
`GET /api/cases/{id}` loads detail independently of the current list page.

Parameters: `q` (up to 200 characters, all whitespace-separated terms must match),
`page`, `pageSize`, `scrape`, `pinnedOnly`; repeat `status`, `district`, `acts`
(exact act names), `caseType`, `purpose`, `complex`, `court` for multiple selections.
Within a selection group values are ORed; groups are ANDed. Ranges use
`regYearFrom/To`, `filingFrom/To`, `decisionFrom/To`, with inclusive bounds and
ISO dates. Invalid/reversed ranges return 422. Only administrators can filter or
search court identifiers. `%` and `_` in text search are treated literally.

`/api/options` returns catalogue-wide options and `totalCases`. `/api/scrapes`
returns month counts. `/api/cases/updates` returns at most 20 pinned-update rows
plus full `total` and `critical` counts. These are independent of the displayed
case page. The UI offers search suggestions and a link to all matching results.

## Independent container setup

For the new standalone repository and single-EC2 staging deployment, use
[the deployment guide](deploy/README.md). The CI workflow is
`.github/workflows/ffg.yml` at this repository root. See [the CI/CD reuse assessment](docs/DEPLOYMENT_REVIEW.md)
for why the existing Django deployment cannot be copied directly.

Copy `.env.example` to `.env` and replace the four secret placeholders with
independent random hexadecimal values, then run from the repository root:

```sh
docker compose up -d --build
```

The UI is available at http://localhost:8080. API/PostgreSQL ports are not
published. The initializer migrates without deleting data. Provision/reset users
with an owner connection; the API container intentionally uses a restricted role.
For HTTPS deployments set `AUTH_COOKIE_SECURE=true`.

This remains a local deployment baseline. An external rollout still needs TLS,
managed secrets, backups/restore verification, request limits, audit logging and
monitoring. Docker stack startup must be verified on a Docker-capable host.
The worker reads the same monthly configuration as the API and uses its own
database password; changing configuration requires recreating the containers.

## Verification and deferred checks

With the backend virtual environment activated, run `bash check.sh` from the repository root.
The default backend suite uses doubles and encrypted HTTP fixtures. The opt-in
PostgreSQL suite exercises actual API/worker roles against a migrated isolated
`*_test` database, using a synthetic eCourts source. See
[the verification instructions](docs/SCRAPER.md#verification).
Frontend tests cover pagination, filtering, pins, auth expiry, Google exchange,
scrape submissions/actions and historical result pages. `/api/health` checks the
process; `/api/ready` checks DB access and required authentication/scraper columns.

Fresh schema installation, migration-004 upgrade, migration reruns, SQL/ORM column
alignment and the synthetic-source PostgreSQL scraper pipeline have been checked
locally. Bounded live pilots saved real cases and snapshots, verified case API
responses and downloaded CSVs. Further diagnosis found and fixed JSON hearing
history parsing; an Assam POCSO sample saved three cases with six hearing entries.
A repeat preserved case IDs, pins and old snapshots without duplicates, and
recovered from a controlled one-time failure. See
[the live diagnostic record](docs/SCRAPER_LIVE_CHECK.md). Intermittent upstream
disconnects still occur; their precise cause remains unknown. These checks do
**not** establish reliable nationwide scraper coverage.

Final acceptance still includes broader live validation (field accuracy, regional
hearing formats, act aliases and complete coverage), a running Docker stack, dashboard counts
against representative records, production-scale CSV/queue behavior, restore
verification, and Google sign-in once configured. Monthly timing is still pending.
