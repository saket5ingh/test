"""Validate resolved Compose configuration without printing runtime secrets."""
import json
import re
import sys


def validate(config):
    services = config['services']
    if set(services) != {'db', 'db-init', 'api', 'worker', 'frontend', 'caddy'}:
        raise ValueError('Unexpected production services')
    domain = services['caddy']['environment']['SITE_DOMAIN']
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}', domain):
        raise ValueError('SITE_DOMAIN must be a DNS hostname without a URL/path')
    if domain.endswith(('.example.org', '.example.com', '.example.net')):
        raise ValueError('Replace the example domain before deployment')
    secrets = [services['db']['environment']['POSTGRES_PASSWORD'],
               services['db-init']['environment']['FFG_DB_PASSWORD'],
               services['db-init']['environment']['FFG_WORKER_PASSWORD'],
               services['api']['environment']['JWT_SECRET']]
    if any(not re.fullmatch(r'[0-9a-fA-F]{64}', value) for value in secrets):
        raise ValueError('Use four independently generated 64-character hexadecimal secrets')
    if len(set(secrets)) != 4:
        raise ValueError('Production secrets must be distinct')
    for name, service in services.items():
        if name != 'caddy' and service.get('ports'):
            raise ValueError('Only Caddy may publish host ports')
        if service.get('build'):
            raise ValueError('Production must pull release images, not build on EC2')
    for name in ('api', 'worker', 'frontend'):
        if not re.fullmatch(r'ghcr\.io/[a-z0-9._/-]+@sha256:[a-f0-9]{64}', services[name]['image']):
            raise ValueError('Application images must use immutable GHCR digests')
    if services['worker']['image'] != services['api']['image']:
        raise ValueError('API and worker must run the same release')
    if services['api']['environment']['AUTH_COOKIE_SECURE'] != 'true':
        raise ValueError('HTTPS authentication cookies are required')
    if any(services[name]['environment']['SCRAPER_MONTHLY_ENABLED'] != 'false' for name in ('api', 'worker')):
        raise ValueError('Monthly scanning must remain disabled during staging')
    return domain


if __name__ == '__main__':
    try:
        print(validate(json.load(sys.stdin)))
    except (ValueError, KeyError, TypeError):
        # Config contains passwords; never echo it or exception values.
        sys.exit('Invalid production configuration; check deploy/README.md requirements')
