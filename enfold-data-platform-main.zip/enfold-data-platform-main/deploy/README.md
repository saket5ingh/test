# FFG standalone repository and single-EC2 deployment

This is an FFG-only staging deployment. No Django application, Celery, Redis or
PDF service is deployed. See [the source-branch assessment](../docs/DEPLOYMENT_REVIEW.md).

## Repository layout and CI

This repository contains the imported **contents** of `ffg/`, including hidden
files, at its root. Its root contains `backend/`, `frontend/`, `db/`, `deploy/`,
`compose.production.yml`, `check.sh`, and `.github/workflows/ffg.yml`.
Do not copy local `.env`, `.venv`, `node_modules`, build output, dumps or caches.
Export the tracked FFG tree after the changes are reviewed/committed, rather
than copying a development working directory containing secrets.

The workflow uses this standalone layout. GitHub requires workflows
at [repository-root `.github/workflows`](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#about-yaml-syntax-for-workflows).
The original parent repository keeps this workflow under `ffg/`; GitHub runs it
from `.github/workflows/ffg.yml` in this standalone repository.

On pushes and PRs, **FFG CI and release / verify** runs:

1. Python 3.12 and Node 24 dependency installation.
2. PostgreSQL 16 setup with separate API/worker roles and a migration rerun.
3. Backend + real PostgreSQL tests, deployment-script tests, frontend tests,
   typecheck, lint and production build; shell checks.
4. Backend/worker and frontend image builds for Linux AMD64.
5. Disposable DB/API/frontend containers; `/api/ready`, nested SPA refresh,
   unauthenticated API rejection and unknown API route checks. Caddy syntax is
   validated, but public certificates are not requested. The live scraper worker
   is not started in CI; worker behavior is covered by the PostgreSQL tests.

After verification, an explicit **Run workflow → publish_images=true** publishes
the exact tested images to GHCR and uploads a release archive plus SHA-256
checksum. Publishing defaults to false. This workflow does not connect to AWS
or automatically deploy on push. Put the workflow on the new repository's
default branch before relying on the manual dispatch UI.

Images are `ghcr.io/<owner>/<repo>-backend` and `...-frontend`, tagged with the
full commit SHA. The bundle's `deploy/release.env` contains their immutable
digests and commit ID. It is data, not a script. Keep package visibility private
and configure repository package access. Use a read-only package credential
for EC2's registry login; do not give EC2 the CI publication token.
See [GHCR authentication and digest pulls](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry).

## AWS prerequisites — to provision later

- A new Linux **x86-64** EC2 instance (initial image artifacts are AMD64), with
  encrypted persistent storage and enough disk for PostgreSQL, image layers,
  logs and backups. Region, instance size, storage size and budget remain to be
  selected; capacity must be measured during staging.
- Docker Engine and a current Compose plugin supporting `up --wait`, plus
  Bash, Python 3, `flock`, curl, tar and registry authentication. Follow the
  [official Docker installation instructions](https://docs.docker.com/engine/install/ubuntu/)
  for the selected Ubuntu host. Building application images on EC2 is unnecessary.
- A stable public address and DNS hostname pointing to it. Security group:
  public TCP 80/443; no public PostgreSQL, API or frontend port. Prefer
  [AWS Session Manager](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html)
  for operator access; if SSH is needed, limit it to operator IPs.
- Outbound connectivity to GHCR, certificate services and eCourts. Configure an
  EC2 instance role for approved AWS access rather than sharing account passwords.
- An operator account permitted to run Docker. Docker access is privileged;
  grant it only to deployment operators.

Caddy obtains and renews certificates once DNS and inbound ports are correct;
its data volume preserves certificate state. See
[Caddy's HTTPS requirements](https://caddyserver.com/docs/automatic-https).

## First deployment

Commands below run from a release bundle on the EC2 host. Create persistent
operator-owned directories once (replace `ffg-operator` with the real OS user):

```sh
sudo install -d -m 700 -o ffg-operator -g ffg-operator \
  /opt/ffg/shared /opt/ffg/state /opt/ffg/releases
```

Download the release archive/checksum from the verified workflow run. Verify
the checksum, then extract the archive under `/opt/ffg/releases/` and retain
the previous release directories for recovery. Use the archive and manifest
from the same run; never mix SQL files from one release with another image.

```sh
sha256sum -c ffg-release-COMMIT.tar.gz.sha256
tar -xzf ffg-release-COMMIT.tar.gz -C /opt/ffg/releases
cd /opt/ffg/releases/ffg-release-COMMIT
cp deploy/production.env.example /opt/ffg/shared/ffg.env
chmod 600 /opt/ffg/shared/ffg.env
```

Edit the runtime file locally on EC2. Replace all four secrets using separate
`openssl rand -hex 32` results; set the real domain and certificate contact email.
Hexadecimal passwords also avoid URL-encoding ambiguities in DATABASE_URL.
Do not overwrite an existing runtime file during updates. Existing PostgreSQL
role passwords are not automatically rotated by rerunning setup.
Leave Google fields blank until the Web client is configured; when enabled,
register the exact `https://YOUR_DOMAIN` JavaScript origin with Google.

Authenticate to GHCR without putting the credential into a command argument or
shell history (use `docker login ghcr.io --password-stdin` with a protected input).
Then:

```sh
bash deploy/deploy.sh deploy/release.env
bash deploy/account.sh deploy/release.env create
```

The account tool prompts for identity, role and password and uses a temporary
owner connection. The long-running API/worker retain their restricted DB roles.
Password reset: `bash deploy/account.sh deploy/release.env reset USER_ID`.
No demo users or demo case data are seeded.

Test administrator and officer login, case restrictions, logout and a very small
manual scrape through the browser. Check run audit events, snapshots, pins and
CSV downloads. A healthy worker/process does not prove eCourts availability.
Monthly scanning is hard-disabled for both API and worker in this staging stack.

## Updating, observing and recovering

Extract a new verified bundle into a new release directory; reuse the same
runtime file, state directory and Compose project name. Run its deployment
script. It pulls images before stopping the API/worker, takes a custom-format
PostgreSQL backup, applies migrations before application startup, recreates the
frontend so its upstream DNS is refreshed, and waits for health/HTTPS checks.
Interrupted worker tasks are recovered on restart; the whole scrape is not
discarded. There is a maintenance outage during this process.

The last successful image manifest is `/opt/ffg/state/current.env`; the previous
one is `previous.env`. `current-bundle.txt` identifies the successful bundle.
If a deployment fails, inspect the named stage and logs. The script does not
automatically undo migrations or restart old code against an unknown schema.
Some services may be stopped, or a failed new release may already be running.
The old manifest alone does not mean the old application is still serving.

For status/logs using the same configuration, in a Bash shell in that bundle:

```sh
source deploy/common.sh
load_release deploy/release.env
compose ps
compose logs --tail=100 api worker
```

For rollback, use the retained previous **bundle**, only after confirming its
code and migration runner support the current database schema. Do not merely
swap an image digest while leaving new SQL/configuration files in place.
Production DB restoration is a separate, reviewed recovery operation, accounting
for writes since the backup. Never run `down --volumes` on the production project.

## Backups and restoration

```sh
bash deploy/backup.sh deploy/release.env
bash deploy/restore-drill.sh deploy/release.env /opt/ffg/state/backups/BACKUP.dump
```

The backup script creates a transactionally consistent custom-format dump and
checks its archive directory. The restore drill creates a uniquely named
disposable database, restores schema/data with errors fatal, checks case,
snapshot and pin counts, then removes only that disposable DB. It never replaces
`pcma_db`. Allow disk capacity and run drills when the extra load is acceptable.

Dumps contain account password hashes and application data. Preserve them with
restricted access and encrypted storage. Database roles/passwords are deliberately
not in the dump: retain runtime secrets separately and rerun the role/grant setup
during deliberate disaster recovery. These operator scripts do **not** yet
schedule backups or upload them off-host. Add encrypted off-host backups, retention
and failure alerts before public production; a dump on EC2 cannot survive loss of
that instance/volume by itself. Caddy volumes must also persist across updates.

## Validation status

Local verification: 74 backend tests including the real PostgreSQL integration
test; 11 deployment tests using fake Docker commands; 68 frontend tests, lint,
typecheck and build; shell syntax, ShellCheck and Actionlint. A fresh isolated
PostgreSQL setup, migration rerun and real dump/restore also passed, restoring
eight synthetic snapshots. One existing Starlette/AnyIO deprecation warning
remains. The temporary PostgreSQL server was stopped afterward.
The production Compose and CI override also passed Compose CLI validation;
resolved image/environment settings passed the production configuration validator.

The workflow, container builds/startup, Caddy issuance, EC2 networking, actual
operator scripts against Docker, browser acceptance, off-host backup automation
and production monitoring have **not** run yet. No cloud resources were created,
and no changes were committed/pushed in this deployment-preparation step.
