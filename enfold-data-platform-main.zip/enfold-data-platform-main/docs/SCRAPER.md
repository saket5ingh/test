# FFG scraper

This standalone implementation was imported from `ffg/`. The previous Django application's
mobile API protocol informed the standalone client, but FFG imports no Django
modules and does not use its database, result files, Celery worker or PDF proxy.

## Administrator workflow

1. Sign in as an administrator and open **Run custom scrape**.
2. Enter a name, select multiple states and acts or their **All** options, choose
   Pending/Disposed/both, and optionally enter comma-separated sections.
3. Submit. The API saves a durable job and returns its ID immediately. Closing
   the browser does not stop the job.
4. Open **Scrape Run Logs** to inspect queued/running/completed work, saved cases,
   new/updated/unchanged counts, coverage, failed tasks and audit history.
5. Cancel a run or retry its unfinished work. A cancellation discards any current
   network response before ingestion. Retry waits for that request to finish.
   Completed snapshots remain unchanged, while retry can add missing results.
6. Open a result to see its historical snapshot. The separate latest-case link
   opens the current catalogue record. Download CSV once a run finishes or is
   cancelled; partial/failed runs export whatever was successfully collected.

All administrators share run access and CSV downloads. Field officers cannot
access scraper endpoints or snapshots; they retain the shared, redacted case
catalogue and personal pins across districts. Demo mode does not execute jobs.

## Selection and coverage

The eight options are POCSO, Prohibition of Child Marriage, Information Technology,
Juvenile Justice, Immoral Traffic (Prevention), IPC / BNS, SC/ST (Prevention of
Atrocities), and Dowry Prohibition. IPC / BNS resolves both laws where present.
Names are resolved to each court's local act codes; a fixed nationwide act code
is not assumed. Matching is conservative, with explicit aliases and detection
of ambiguous abbreviated names. Rules/regulations are excluded. Unavailable acts
produce audit events; malformed or empty catalogues are failures.

Blank sections means all sections. `9, 10, 11` creates separate searches and
unions their cases by CNR. These section choices apply to every selected act.
The traversal is state → district → court establishment → act/status/section
search → case history. All states means all states returned by the live catalogue
when discovery executes; the resolved states and act keys are saved with the run.

Progress shows actual task counts, not a percentage: the total grows as more
districts/courts/cases are discovered. Inspect work items to see the location,
source act code, criteria, attempts and error for a failed operation. An act not
offered by a court is recorded separately from a failed request.

## Persistence and permissions

Migration `005_scraper.sql` extends `scrape_runs` and creates:

| Table | Purpose |
| --- | --- |
| `scrape_tasks` | Durable work items, checkpoints, attempts, retry timing and errors |
| `scrape_run_cases` | One immutable JSONB snapshot per run/case, collection timestamp and change classification |
| `scrape_run_events` | Append-only events for submission, execution, retry, cancellation and completion |
| `scraper_metadata` | Cached state catalogue and worker heartbeat |
| `case_notifications` | Latest alert per user/pinned case, linked to its originating run |

The latest catalogue is updated by unique CNR. Pins survive updates. Missing cases
are never deleted simply because a later scan does not return them. Ingestion,
hearing replacement, snapshot insertion and notifications commit atomically.
Case data excludes litigant names, raw response HTML and PDF/order content.

Run criteria are JSONB lists/flags, replacing the single-value limitations of
legacy columns. Legacy runs have no snapshots; the UI explicitly says so.
They cannot download today's data disguised as historical results.

CSV is generated on demand from stored snapshots, streamed by the backend and
downloaded by the browser. No CSV file/blob is stored in PostgreSQL or on disk.
Acts and hearings are JSON cells; timestamps identify collection time. Potential
spreadsheet formulas in text fields are escaped. The current browser download
buffers the CSV as a blob, so large nationwide exports need capacity testing.

`setup_local_db.sh` creates/grants separate roles:

- `pcma_app`: read application data, manage personal pins/Google account link,
  submit jobs and request cancellation/retry. Cannot write case ingestion data.
- `pcma_worker`: update cases/hearings, jobs and notifications; insert/read audit
  events and snapshots. Cannot update/delete snapshots or read/reset passwords.
- Owner: apply schema migrations and provision/reset accounts. Never run the API
  or worker with the owner connection.

Notifications go only to users pinning the case at ingestion time. New baseline
records and unchanged re-scrapes produce no alert. Status/disposition changes and
a hearing date moving earlier are critical; other hearing date changes and new
hearing entries are informational. Unpinning removes that user's alert; repinning
does not inherit past alerts. This version retains the latest alert per case/user,
not an email delivery system or a separate notification history inbox.

## Worker and scheduling

Start locally from `backend/`, after applying migrations:

```sh
# Export DATABASE_URL using pcma_worker and its password in this terminal.
# The API terminal must retain its pcma_app URL.
python -m app.scraper.worker
```

For Compose, set **both** `FFG_DB_PASSWORD` and `FFG_WORKER_PASSWORD`, plus the
owner password and JWT secret, in `.env`, then run from the repository root:

```sh
docker compose up -d --build
docker compose logs -f worker
```

The PostgreSQL advisory lock allows one active worker for this database. Task
claims use row locks, and attempt numbers fence stale work after recovery. On
restart, interrupted work is requeued. Default source spacing is two seconds;
requests time out at 120 seconds. Failed source operations retry up to three
times with 30/60-second backoff. The session token is renewed every five minutes
and discarded after a rejected request. Persistent errors remain visible as
failed/partial outcomes rather than successful empty results. No proxies or
throttle-bypass mechanism is used.

Worker logs include endpoint name, outcome, HTTP status (if received), elapsed
seconds, response byte count and transport exception type. They omit request
URLs/parameters, tokens, response bodies and exception text. HTTPX/httpcore INFO
logging is suppressed by the worker entry point to avoid logging full URLs.
`network_error` with no HTTP status means no usable response reached the client;
it does not identify whether the remote server or an intermediary closed it.

Automatic restarts are configured for the Compose worker. Its heartbeat health
check is `python -m app.scraper.health`. A stale heartbeat and cached-state
availability are visible on the admin form. Metadata refresh happens hourly;
failure keeps the previous catalogue and logs an error. A healthy process does
not guarantee upstream availability—monitor failed work and catalogue age too.

Monthly scheduling is **off by default**. When the timing has been confirmed,
configure the same values for API and worker (Compose passes them through):

| Variable | Default / behavior |
| --- | --- |
| `SCRAPER_MONTHLY_ENABLED` | `false`; enable only after agreeing timing and completing a live pilot |
| `SCRAPER_MONTHLY_DAY` | `1`; supported range 1–28 |
| `SCRAPER_MONTHLY_HOUR` | `2`; local 24-hour time |
| `SCRAPER_MONTHLY_MINUTE` | `0` |
| `SCRAPER_TIMEZONE` | `Asia/Kolkata` |
| `SCRAPER_REQUEST_INTERVAL` | `2` seconds; minimum 1 |
| `SCRAPER_MAX_ATTEMPTS` | `3`; local worker override, range 1–10 |

Each monthly job selects all states, all eight act options, all sections, both
statuses. A unique month key prevents duplicate creation after a restart. If the
worker starts after the scheduled time, it queues that month's run; it does not
backfill missed earlier months. Another active monthly run prevents overlap.
Manual and scheduled jobs share the same serialized queue, oldest run first.
A large nationwide job can delay later manual jobs. Throughput and nationwide
completion time must be measured before enabling recurring scans.

## API contract

Every endpoint below requires an administrator bearer token.

| Method / path (under `/api/scrapes`) | Behavior |
| --- | --- |
| `GET /options` | Cached states, supported acts, worker freshness, monthly enabled flag |
| `POST /run` | Validate criteria, enqueue atomically, return `202 {id}` |
| `GET /runs?page=1` | Paginated shared run history |
| `GET /runs/{id}` | Criteria, counts, timing, coverage and outcome |
| `GET /runs/{id}/tasks?status=failed&page=1` | Paginated scopes/attempts/errors; status can also be `all` |
| `GET /runs/{id}/events?page=1` | Paginated audit history, including initiating actor |
| `POST /runs/{id}/cancel` | Cancel pending work; discard in-flight result |
| `POST /runs/{id}/retry` | Requeue only unsuccessful work with a fresh retry budget |
| `GET /runs/{id}/results?page=1` | Paginated historical snapshots |
| `GET /runs/{id}/results/{caseId}` | One historical case |
| `GET /runs/{id}/csv` | Download saved historical results after completion/cancellation |

Submission includes `name`, `requestId` (UUID), `allStates`, `stateCodes`,
`allActs`, `actKeys`, `sections`, and `status` (`all`, `pending`, `disposed`).
Choose All or explicit selections for each dimension, never both. Reusing a
request ID with the same submission returns its existing job; a changed
submission returns 409. Invalid input returns 422. Failed/partial/cancelled runs
can be retried; legacy runs cannot. API lists use `{items,total,page,pageSize}`.

## Verification

Run the usual checks with the backend virtual environment activated:

```sh
# Run from the repository root.
bash check.sh
```

For actual PostgreSQL coverage, create a separate disposable database whose name
ends in `_test`, apply setup with separate API/worker roles, and export these
three `postgresql+asyncpg` URLs (never production URLs):

```sh
# FFG_TEST_PG_OWNER, FFG_TEST_PG_API, FFG_TEST_PG_WORKER
cd backend
python -m pytest tests/test_scraper_postgres.py -q
```

This test uses real tables, constraints, grants, transactions and API auth, with a
synthetic eCourts client. It verifies role redaction, idempotent submission,
upserts, pins/notifications, historical CSVs, SQL/ORM column alignment, retries,
partial success, restart recovery, stale attempts, in-flight cancellation,
invalid-record rollback and monthly scheduling. It leaves synthetic records for
inspection; it does not truncate/drop tables. Do not run a live worker against
that test database during the test.

A bounded read-only live probe is also available (no database writes):

```sh
python -m app.scraper.canary --state Bihar --district Gaya --act ipc
```

It requests at most two court catalogues and one case history, printing counts
and structural metadata rather than litigant data or tokens. Exit 0 means a
sample history normalized; exit 1 means a source/format error; exit 2 means no
matching case in the small sample, so case-level verification is incomplete.
Neither a successful probe nor synthetic tests establishes nationwide coverage.

A bounded Bihar/Gaya pilot saved three cases and snapshots and verified the case
API and CSV. Further Assam/Bajali POCSO testing exposed JSON hearing rows where
the parser expected HTML. The parser now accepts both formats, merges the latest
business entry without duplicates, and uses the hearing's actual date rather
than its future listing date. The corrected pilot saved three cases and six
hearings. A repeat preserved pins, IDs and original snapshots and recovered from
a controlled one-time failure. Intermittent `RemoteProtocolError` disconnects
were reproduced; their precise cause remains unknown. See
[the diagnostic record](SCRAPER_LIVE_CHECK.md) for scope and limits.

**Independent field-accuracy checks, other regional hearing formats, regional
act aliases, search completeness and nationwide capacity remain unverified.**
Complete broader live validation before enabling the monthly scan. Preserve
database backups, including snapshots and audit history, and test restoration
before rollout.
