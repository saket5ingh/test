-- Run with psql --single-transaction -v ON_ERROR_STOP=1.
SELECT pg_advisory_xact_lock(772639104);
SELECT to_regclass('pcma.users') IS NOT NULL AS initialized \gset
\if :initialized
\else
\ir 01_schema.sql
\endif
CREATE TABLE IF NOT EXISTS pcma.schema_migrations (
    version INTEGER PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO pcma.schema_migrations(version) VALUES (1) ON CONFLICT DO NOTHING;
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 3) AS apply_pins \gset
\if :apply_pins
\ir migrations/003_personal_pins.sql
INSERT INTO pcma.schema_migrations(version) VALUES (3);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 4) AS apply_contracts \gset
\if :apply_contracts
\ir migrations/004_contracts_and_auth.sql
INSERT INTO pcma.schema_migrations(version) VALUES (4);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 5) AS apply_scraper \gset
\if :apply_scraper
\ir migrations/005_scraper.sql
INSERT INTO pcma.schema_migrations(version) VALUES (5);
\endif
