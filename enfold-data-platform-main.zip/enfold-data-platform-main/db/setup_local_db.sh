#!/usr/bin/env bash
set -euo pipefail

# PGHOST/PGPORT/PGUSER/PGPASSWORD identify the database administrator.
# This script never drops a database and never seeds data unless explicitly asked.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DB_NAME="${FFG_DB_NAME:-pcma_db}"
APP_ROLE="${FFG_DB_ROLE:-pcma_app}"
WORKER_ROLE="${FFG_WORKER_ROLE:-pcma_worker}"
: "${FFG_WORKER_PASSWORD:?Set FFG_WORKER_PASSWORD for the scraper worker}"
: "${FFG_DB_PASSWORD:?Set FFG_DB_PASSWORD for the application role}"
export PGHOST="${PGHOST:-localhost}" PGPORT="${PGPORT:-5432}"

psql -X -v ON_ERROR_STOP=1 -d postgres -v db_name="$DB_NAME" -v app_role="$APP_ROLE" -v app_password="$FFG_DB_PASSWORD" -v worker_role="$WORKER_ROLE" -v worker_password="$FFG_WORKER_PASSWORD" <<'SQL'
SELECT format('CREATE DATABASE %I', :'db_name')
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = :'db_name') \gexec
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', :'app_role', :'app_password')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'app_role') \gexec
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', :'worker_role', :'worker_password')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'worker_role') \gexec
SELECT format('GRANT CONNECT ON DATABASE %I TO %I', :'db_name', :'worker_role') \gexec
SELECT format('GRANT CONNECT ON DATABASE %I TO %I', :'db_name', :'app_role') \gexec
SQL

psql -X -v ON_ERROR_STOP=1 --single-transaction -d "$DB_NAME" -f "$SCRIPT_DIR/migrate.sql"
if [[ "${FFG_SEED_DEMO:-0}" == "1" ]]; then
  psql -X -v ON_ERROR_STOP=1 --single-transaction -d "$DB_NAME" -f "$SCRIPT_DIR/02_seed_data.sql"
fi

psql -X -v ON_ERROR_STOP=1 --single-transaction -d "$DB_NAME" -v app_role="$APP_ROLE" -v worker_role="$WORKER_ROLE" <<'SQL'
GRANT USAGE ON SCHEMA pcma TO :"app_role";
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA pcma FROM :"app_role";
GRANT SELECT ON pcma.users, pcma.cases, pcma.case_hearings,
    pcma.scrape_runs TO :"app_role";
GRANT UPDATE (google_sub) ON pcma.users TO :"app_role";
GRANT SELECT, INSERT, DELETE ON pcma.case_pins TO :"app_role";
GRANT SELECT ON pcma.scrape_tasks, pcma.scrape_run_cases, pcma.scrape_run_events,
    pcma.scraper_metadata, pcma.case_notifications TO :"app_role";
GRANT INSERT ON pcma.scrape_runs, pcma.scrape_tasks, pcma.scrape_run_events TO :"app_role";
GRANT UPDATE (outcome, cancel_requested, completed_at, error_message) ON pcma.scrape_runs TO :"app_role";
GRANT UPDATE (status, available_at, completed_at, error_message, retry_base) ON pcma.scrape_tasks TO :"app_role";

GRANT USAGE ON SCHEMA pcma TO :"worker_role";
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA pcma FROM :"worker_role";
GRANT SELECT ON pcma.case_pins TO :"worker_role";
GRANT SELECT, INSERT, UPDATE ON pcma.cases, pcma.scrape_runs, pcma.scrape_tasks,
    pcma.scraper_metadata, pcma.case_notifications TO :"worker_role";
GRANT SELECT, INSERT, UPDATE, DELETE ON pcma.case_hearings TO :"worker_role";
GRANT SELECT, INSERT ON pcma.scrape_run_cases, pcma.scrape_run_events TO :"worker_role";
SQL

# A mismatched existing role password must fail here, not appear as success.
PGPASSWORD="$FFG_DB_PASSWORD" psql -X -v ON_ERROR_STOP=1 -U "$APP_ROLE" -d "$DB_NAME" \
  -c 'SELECT count(*) FROM pcma.cases' -c 'SELECT count(*) FROM pcma.case_pins'
PGPASSWORD="$FFG_WORKER_PASSWORD" psql -X -v ON_ERROR_STOP=1 -U "$WORKER_ROLE" -d "$DB_NAME" \
  -c 'SELECT count(*) FROM pcma.scrape_tasks' -c 'SELECT count(*) FROM pcma.scrape_run_cases'
echo "Database initialized/migrated and application/worker read access verified."
