"""Parameterized persistence for durable jobs, snapshots and notifications."""
import hashlib
import json
from datetime import datetime, timezone, date
from uuid import uuid4
from sqlalchemy import text, select
from sqlalchemy.orm import noload, selectinload
from app.models.case import Case
from app.models.hearing import CaseHearing
from app.schemas.case import CaseSchema
from app.scraper.normalize import change_notice


def utcnow(): return datetime.now(timezone.utc)


async def event(db, run_id, kind, message, task_id=None, actor_id=None):
    await db.execute(text('''INSERT INTO pcma.scrape_run_events(run_id, task_id, kind, message, actor_id)
        VALUES (:run, :task, :kind, :message, :actor)'''),
        dict(run=run_id, task=task_id, kind=kind, message=message, actor=actor_id))


async def enqueue(db, run_id, kind, payload, identity=None):
    identity = identity or json.dumps(payload, sort_keys=True)
    task_key = kind + ':' + hashlib.sha256(identity.encode()).hexdigest()
    await db.execute(text('''INSERT INTO pcma.scrape_tasks(run_id, task_key, kind, payload)
        VALUES (:run, :key, :kind, CAST(:payload AS jsonb)) ON CONFLICT (run_id, task_key) DO NOTHING'''),
        dict(run=run_id, key=task_key, kind=kind, payload=json.dumps(payload)))


async def create_run(db, request, actor=None, schedule_key=None):
    run_id = uuid4()
    criteria = request.criteria()
    # request_key makes a repeated HTTP submission idempotent.
    result = await db.execute(text('''INSERT INTO pcma.scrape_runs
        (id, name, outcome, status_filter, triggered_by, criteria, trigger_type, queued_at,
         started_at, request_key, schedule_key, snapshot_version)
        VALUES (:id, :name, 'queued', :status, :actor, CAST(:criteria AS jsonb), :trigger,
            CURRENT_TIMESTAMP, NULL, :request, :schedule, 1)
        ON CONFLICT DO NOTHING RETURNING id'''),
        dict(id=run_id, name=request.name, status=request.status, actor=actor,
             criteria=json.dumps(criteria), trigger='scheduled' if schedule_key else 'manual',
             request=request.requestId, schedule=schedule_key))
    inserted = result.scalar_one_or_none()
    if inserted is None:
        row = (await db.execute(text('''SELECT id, criteria, name, triggered_by FROM pcma.scrape_runs
            WHERE request_key = :request OR schedule_key = :schedule'''),
            dict(request=request.requestId, schedule=schedule_key))).mappings().one()
        if row['criteria'] != criteria or row['name'] != request.name or row['triggered_by'] != actor:
            raise ValueError('Request ID was already used for a different submission')
        return row['id']
    await enqueue(db, run_id, 'discover', {})
    await event(db, run_id, 'queued', 'Scheduled scan queued' if schedule_key else 'Manual scan queued', actor_id=actor)
    return run_id


ATTRIBUTES = {'cnr':'cnr_number','caseNo':'case_number','ref':'case_ref','regNo':'registration_number',
    'regYear':'registration_year','caseType':'case_type','caseTypeClass':'case_type_class',
    'state':'state','district':'district','complex':'complex_name','court':'court_name',
    'regDate':'registration_date','filingDate':'filing_date','decisionDate':'decision_date',
    'dispositionRaw':'disposition_raw','status':'status','numHearings':'hearings_count',
    'duration':'duration_days','lastPurpose':'last_purpose','nextHearing':'next_hearing','acts':'acts'}
DATES = {'regDate', 'filingDate', 'decisionDate', 'nextHearing'}


async def ingest(db, run_id, data):
    current = (await db.execute(select(Case).where(Case.cnr_number == data['cnr'])
        .options(selectinload(Case.hearings), noload(Case.documents)).with_for_update())).scalar_one_or_none()
    if current is not None:
        exists = (await db.execute(text('SELECT 1 FROM pcma.scrape_run_cases WHERE run_id=:run AND case_id=:case'),
                                  dict(run=run_id, case=current.id))).scalar_one_or_none()
        if exists: return  # Replayed tasks cannot change a completed snapshot or notify twice.
    before = CaseSchema.model_validate(current).model_dump(mode='json') if current else None
    if before:
        # An anonymized reference never changes when a case is refreshed.
        data['ref'] = before['ref'] or data['ref']
    kind = 'new' if before is None else ('updated' if any(before[key] != data[key] for key in [*ATTRIBUTES, 'hearings']) else 'unchanged')
    now = utcnow()
    notice = change_notice(before, data, now.isoformat())
    if current is None:
        current = Case(id=uuid4())
        db.add(current)
    for key, attribute in ATTRIBUTES.items():
        value = data[key]
        setattr(current, attribute, date.fromisoformat(value) if key in DATES and value else value)
    current.scrape_run_id = run_id
    current.last_scrape = now.strftime('%Y-%m')
    if notice: current.update_info = notice
    # Replace the latest hearing set atomically; historical sets live in snapshots.
    current.hearings = [CaseHearing(hearing_date=date.fromisoformat(h['date']), purpose=h['purpose'], sequence_order=i)
                        for i, h in enumerate(data['hearings'])]
    await db.flush()
    snapshot = {**data, 'id': str(current.id), 'lastScrape': current.last_scrape, 'pinned': False, 'update': None}
    CaseSchema.model_validate(snapshot)
    await db.execute(text('''INSERT INTO pcma.scrape_run_cases(run_id, case_id, snapshot, change_kind, fetched_at)
        VALUES (:run, :case, CAST(:snapshot AS jsonb), :kind, :at)'''),
        dict(run=run_id, case=current.id, snapshot=json.dumps(snapshot), kind=kind, at=now))
    if notice:
        await db.execute(text('''INSERT INTO pcma.case_notifications(user_id, case_id, run_id, payload)
            SELECT user_id, case_id, :run, CAST(:payload AS jsonb) FROM pcma.case_pins WHERE case_id=:case
            ON CONFLICT(user_id, case_id) DO UPDATE SET run_id=EXCLUDED.run_id, payload=EXCLUDED.payload'''),
            dict(run=run_id, case=current.id, payload=json.dumps(notice)))
