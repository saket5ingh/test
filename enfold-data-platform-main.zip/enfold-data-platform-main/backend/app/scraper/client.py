"""Rate-limited v4 eCourts client, adapted from the existing application's protocol.

No Django imports, proxies, import-time HTTP, PDFs, or silent error-to-empty conversion.
The durable worker handles retries; this client only refreshes an expired session.
"""
import asyncio
import base64
import json
import logging
import os
import time
import httpx
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7

BASE_URL = 'https://app.ecourts.gov.in/services_DC_4.0'
UID = 'in.gov.ecourts.eCourtsServices'
REQUEST_KEY = bytes.fromhex('4D6251655468576D5A7134743677397A')
RESPONSE_KEY = bytes.fromhex('3273357638782F413F4428472B4B6250')
log = logging.getLogger(__name__)


class UpstreamError(Exception):
    pass


def encrypt(data):
    suffix = os.urandom(8).hex()
    iv = bytes.fromhex('556A586E32723575' + suffix)
    padder = PKCS7(128).padder()
    padded = padder.update(json.dumps(data).encode()) + padder.finalize()
    cipher = Cipher(algorithms.AES(REQUEST_KEY), modes.CBC(iv)).encryptor()
    return suffix + '0' + base64.b64encode(cipher.update(padded) + cipher.finalize()).decode()


def decrypt(body):
    try:
        body = body.strip()
        iv = bytes.fromhex(body[:32])
        ciphertext = base64.b64decode(body[32:], validate=True)
        cipher = Cipher(algorithms.AES(RESPONSE_KEY), modes.CBC(iv)).decryptor()
        padded = cipher.update(ciphertext) + cipher.finalize()
        unpadder = PKCS7(128).unpadder()
        return json.loads((unpadder.update(padded) + unpadder.finalize()).decode())
    except (ValueError, TypeError, UnicodeError) as error:
        # Never include tokens, URLs with encrypted params, or litigant data in logs.
        raise UpstreamError('Unrecognized eCourts response; possible throttling or protocol change') from error


class ECourtsClient:
    def __init__(self, *, interval=2.0, transport=None):
        self.http = httpx.AsyncClient(timeout=120, transport=transport, follow_redirects=False)
        self.interval = interval
        self.last_request = 0.0
        self.token = None
        self.token_at = 0.0

    async def close(self):
        await self.http.aclose()

    async def _request(self, endpoint, payload, token=None):
        await asyncio.sleep(max(0, self.interval - (time.monotonic() - self.last_request)))
        self.last_request = time.monotonic()
        started = self.last_request
        status, error_type, received_bytes = None, None, 0
        outcome = 'network_error'
        try:
            try:
                response = await self.http.get(f'{BASE_URL}/{endpoint}', params={'params': encrypt(payload)},
                    headers={'Authorization': f'Bearer {token}'} if token else {})
            except httpx.HTTPError as error:
                error_type = type(error).__name__
                raise UpstreamError(f'{endpoint}: network failure ({error_type})') from error
            status, received_bytes = response.status_code, len(response.content)
            if status != 200:
                outcome = 'http_error'
                raise UpstreamError(f'{endpoint}: HTTP {status}; retry later')
            outcome = 'invalid_response'
            data = decrypt(response.text)
            if not isinstance(data, dict) or data.get('status') == 'N':
                outcome = 'rejected'
                raise UpstreamError(f'{endpoint}: upstream rejected request')
            outcome = 'success'
            return data
        except asyncio.CancelledError:
            outcome = 'cancelled'
            raise
        finally:
            # Never log request URLs/params, tokens, bodies or exception messages.
            # Timings include the full response, but exclude deliberate pacing.
            write = log.info if outcome == 'success' else log.warning
            write('ecourts endpoint=%s outcome=%s http_status=%s elapsed_s=%.3f bytes=%d error_type=%s',
                  endpoint, outcome, status, time.monotonic() - started, received_bytes, error_type)

    async def get(self, endpoint, payload):
        if not self.token or time.monotonic() - self.token_at >= 300:
            data = await self._request('appReleaseWebService.php', {'appVersion': '4.0.1', 'uid': UID})
            self.token = data.get('token')
            if not isinstance(self.token, str) or not self.token:
                raise UpstreamError('eCourts did not issue a session token')
            self.token_at = time.monotonic()
        try:
            return await self._request(endpoint, {**payload, 'uid': UID}, self.token)
        except UpstreamError:
            self.token = None  # A later durable retry obtains a fresh session.
            raise

    @staticmethod
    def rows(data, key, *, empty_ok=True):
        rows = data.get(key)
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows) or (not rows and not empty_ok):
            raise UpstreamError(f'eCourts returned missing/invalid {key}')
        return rows

    async def states(self):
        rows = self.rows(await self.get('stateWebService.php', {'action_code': 'fillState'}), 'states', empty_ok=False)
        return [{'code': str(row['state_code']), 'name': row['state_name']} for row in rows]

    async def districts(self, state):
        rows = self.rows(await self.get('districtWebService.php', {'state_code': state}), 'districts', empty_ok=False)
        return [{'code': str(row['dist_code']), 'name': row['dist_name']} for row in rows]

    async def courts(self, state, district):
        rows = self.rows(await self.get('courtEstWebService.php', {'action_code': 'fillCourtComplex',
            'state_code': state, 'dist_code': district}), 'courtComplex', empty_ok=False)
        courts = [{'code': code.strip(), 'name': row['court_complex_name']} for row in rows
                for code in str(row['njdg_est_code']).split(',') if code.strip()]
        if not courts or any(not court['code'].isdigit() for court in courts):
            raise UpstreamError('Missing or invalid court establishment codes')
        return courts

    def court_payload(self, scope):
        return {'state_code': scope['state']['code'], 'dist_code': scope['district']['code'],
                'court_code_arr': scope['court']['code'], 'language_flag': 'english', 'bilingual_flag': '0'}

    async def acts(self, scope):
        data = await self.get('actWebService.php', {**self.court_payload(scope), 'searchText': ''})
        rows = self.rows(data, 'actsList', empty_ok=False)
        if not isinstance(rows[0].get('acts'), str):
            raise UpstreamError('Invalid court act list')
        values = [value.strip() for value in rows[0]['acts'].split('#') if value.strip()]
        if not values or any('~' not in value for value in values):
            raise UpstreamError('Empty or malformed court act catalogue')
        acts = [tuple(value.split('~', 1)) for value in values]
        if any(not code.strip() or not name.strip() for code, name in acts):
            raise UpstreamError('Incomplete court act catalogue entry')
        return acts

    async def search(self, scope):
        data = await self.get('searchByActWebService.php', {**self.court_payload(scope),
            'selectActTypeText': scope['act_code'], 'underSectionText': scope['section'],
            'pendingDisposed': scope['status']})
        # An explicit [] is a legitimate empty result. Missing keys are failures.
        result = data.get('0')
        if not isinstance(result, dict): raise UpstreamError('Invalid case search response')
        return self.rows(result, 'caseNos')

    async def history(self, scope):
        data = await self.get('caseHistoryWebService.php', {'state_code': scope['state']['code'],
            'dist_code': scope['district']['code'], 'court_code': scope['court']['code'],
            'language_flag': 'english', 'bilingual_flag': '0', 'cino': scope['cnr']})
        history = data.get('history')
        if not isinstance(history, dict) or not history:
            raise UpstreamError('Missing case history')
        return history
