"""Product choices and explicit statute aliases; court act numbers are not global."""
import html
import re

ACTS = {
    'pocso': ('POCSO Act, 2012', ['Protection of Children from Sexual Offences Act', 'POCSO Act']),
    'childmarriage': ('Prohibition of Child Marriage Act', ['Prohibition of Child Marriage Act']),
    'it': ('Information Technology Act', ['Information Technology Act']),
    'jj': ('Juvenile Justice Act', ['Juvenile Justice Care and Protection of Children Act', 'Juvenile Justice Act']),
    'ita': ('Immoral Traffic (Prevention) Act', ['Immoral Traffic Prevention Act', 'Immoral Traffic Act']),
    'ipc': ('IPC / BNS', ['Indian Penal Code', 'Bharatiya Nyaya Sanhita']),
    'scst': ('SC/ST (Prevention of Atrocities) Act', ['Scheduled Castes and Scheduled Tribes Prevention of Atrocities Act', 'SC ST Prevention of Atrocities Act']),
    'dowry': ('Dowry Prohibition Act', ['Dowry Prohibition Act']),
}


def normalized(name):
    value = html.unescape(name or '').lower()
    value = re.sub(r'(?<=[a-z])(?=\d)', ' ', value)
    value = re.sub(r'[^a-z0-9]+', ' ', value).strip()
    value = re.sub(r'^the ', '', value)
    value = re.sub(r'\b(18|19|20)\d{2}\b', '', value)
    return ' '.join(re.sub(r's$', '', word) for word in value.split())


def act_codes(rows, key):
    """Select all exact aliases (IPC and BNS), with conservative truncation fallback.

    An ambiguous truncated name is reported, never silently assigned to a law.
    Subordinate instruments such as Rules are not the parent Act.
    """
    named = [(str(code), normalized(name)) for code, name in rows if name]
    matched = set()
    for alias in ACTS[key][1]:
        target = normalized(alias)
        exact = {code for code, name in named if name == target}
        if exact:
            matched.update(exact)
            continue
        candidates = {code for code, name in named
                      if len(name.split()) >= 3 and target.startswith(name + ' ')
                      and not {'rule', 'regulation', 'order', 'scheme'} & set(name.split())}
        if len(candidates) > 1:
            raise ValueError(f'Ambiguous court act mapping for {ACTS[key][0]}')
        matched.update(candidates)
    return sorted(matched)


def canonical_act(name):
    key_name = normalized(name)
    for key, (label, aliases) in ACTS.items():
        if key_name in {normalized(alias) for alias in aliases}:
            # IPC and BNS stay distinct in case records despite the grouped selector.
            return name.strip() if key == 'ipc' else label
    return html.unescape(name).strip()
