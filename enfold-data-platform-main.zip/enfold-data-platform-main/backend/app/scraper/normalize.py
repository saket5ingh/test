"""Normalize only fields used by FFG; do not retain parties, raw HTML or PDFs."""
from datetime import date, datetime
import hashlib
import re
from bs4 import BeautifulSoup
from app.scraper.catalog import canonical_act


def parse_date(value):
    value = str(value or '').strip()
    if value.lower() in ('', '-', '--', 'na', 'n/a', 'null', 'not available', '0000-00-00'):
        return None
    for fmt in ('%d-%m-%Y', '%Y-%m-%d', '%d/%m/%Y', '%d.%m.%Y'):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError('Unrecognized case date format')


def number(value):
    if value in (None, '', '-'): return None
    if re.fullmatch(r'\d+', str(value).strip()): return int(value)
    raise ValueError('Unrecognized case registration number/year')


def hearings_from_html(value):
    if not isinstance(value, (str, type(None))):
        raise ValueError('Invalid hearing history')
    soup = BeautifulSoup(value or '', 'html.parser')
    rows = soup.select('table.tbl-result tr')
    hearings = set()
    for row in rows:
        cells = row.find_all('td')
        if not cells: continue
        if len(cells) < 4: raise ValueError('Unrecognized hearing row layout')
        when = parse_date(cells[1].get_text(' ', strip=True))
        purpose = cells[3].get_text(' ', strip=True)
        if not when or not purpose: raise ValueError('Incomplete hearing row')
        hearings.add((when, purpose))
    if (value or '').strip() and not rows:
        # Known no-history text is allowed, unexpected markup isn't silently erased.
        if soup.get_text(' ', strip=True).lower() not in ('', 'no records found', 'no records found.'):
            raise ValueError('Unrecognized hearing history layout')
    return [{'date': when, 'purpose': purpose} for when, purpose in sorted(hearings)]


def hearings_from_source(value, latest=None, cnr=None):
    """v4 sends JSON hearing rows; older responses contain an HTML table.

    The latest business entry is a separate row in v4. Merge it without double
    counting. `nextdate` is a future listing date, not the hearing's own date.
    """
    if isinstance(value, list):
        entries = value
        hearings = set()
    else:
        entries = []
        hearings = {(row['date'], row['purpose']) for row in hearings_from_html(value)}
    if isinstance(latest, dict):
        if latest: entries = [*entries, latest]
    elif latest not in (None, '', []):
        # Legacy responses may expose just a date here, without a hearing row.
        if not isinstance(latest, str): raise ValueError('Invalid latest hearing entry')
        parse_date(latest)
    for row in entries:
        if not isinstance(row, dict): raise ValueError('Invalid JSON hearing entry')
        if cnr and row.get('cino') and str(row['cino']).strip().upper() != cnr:
            raise ValueError('Hearing CNR does not match requested case')
        when = parse_date(row.get('todays_date') or row.get('todays_date1'))
        purpose = row.get('purpose')
        if not when or not isinstance(purpose, str) or not purpose.strip():
            raise ValueError('Incomplete JSON hearing entry')
        purpose = BeautifulSoup(purpose, 'html.parser').get_text(' ', strip=True)
        if not purpose: raise ValueError('Incomplete JSON hearing purpose')
        hearings.add((when, purpose))
    return [{'date': when, 'purpose': purpose} for when, purpose in sorted(hearings)]


def normalize(history, scope):
    cnr = str(scope['cnr']).strip().upper()
    if not re.fullmatch(r'[A-Z0-9]{1,32}', cnr): raise ValueError('Invalid CNR')
    if history.get('cino') and str(history['cino']).strip().upper() != cnr:
        raise ValueError('Case-history CNR does not match requested case')
    if 'historyOfCaseHearing' not in history or not isinstance(history.get('act'), list):
        raise ValueError('Incomplete case history; existing data preserved')
    hearings = hearings_from_source(history['historyOfCaseHearing'], history.get('last_business_date'), cnr)
    act_map = {}
    for row in history['act']:
        if not isinstance(row, dict): raise ValueError('Invalid case act entry')
        name = canonical_act(str(row.get('actCodeName') or ''))
        if not name: continue
        sections = [s.strip() for s in re.split(r'[,;]', str(row.get('actSectionName') or '')) if s.strip()]
        act_map.setdefault(name, set()).update(sections)
    acts = [{'name': name, 'sections': sorted(sections), 'flag': None} for name, sections in sorted(act_map.items())]
    if not acts: raise ValueError('Case history has no usable acts')
    decision = parse_date(history.get('date_of_decision'))
    raw = str(history.get('disp_name') or '').strip()
    status = 'disposed' if decision or scope['status'] == 'Disposed' else 'pending'
    if status == 'disposed':
        for token, value in [('acquit', 'acquitted'), ('reject', 'rejected'), ('allow', 'allowed')]:
            if token in raw.lower(): status = value; break
    case_type = str(history.get('type_name') or '').strip()
    duration = (date.fromisoformat(hearings[-1]['date']) - date.fromisoformat(hearings[0]['date'])).days if hearings else None
    next_date = next((history[k] for k in ('date_next_list', 'date_of_next_hearing', 'next_hearing_date', 'next_date') if history.get(k)), None)
    result = dict(cnr=cnr, caseNo=str(history.get('case_no') or scope.get('case_no') or ''),
        ref='FFG-' + hashlib.sha256(cnr.encode()).hexdigest()[:16].upper(),
        regNo=number(history.get('reg_no')), regYear=number(history.get('reg_year')),
        caseType=case_type, caseTypeClass=case_type[:64],
        state=scope['state']['name'], district=scope['district']['name'],
        complex=scope['court']['name'], court=str(history.get('court_name') or ''),
        regDate=parse_date(history.get('dt_regis')), filingDate=parse_date(history.get('date_of_filing')),
        decisionDate=decision, dispositionRaw=raw, status=status,
        numHearings=len(hearings), duration=duration, lastPurpose=hearings[-1]['purpose'] if hearings else '',
        nextHearing=parse_date(next_date), acts=acts, hearings=hearings, pinned=False, update=None)
    for key, maximum in {'caseNo':64, 'caseType':128, 'state':100, 'district':100, 'complex':255, 'court':255, 'dispositionRaw':255}.items():
        if len(result[key]) > maximum: raise ValueError(f'{key} exceeds supported length')
    if result['regYear'] is not None and not 1 <= result['regYear'] <= 9999: raise ValueError('Invalid registration year')
    return result


def change_notice(before, after, at):
    if before is None: return None
    parts = []
    critical = False
    if before['status'] != after['status'] or before.get('dispositionRaw') != after.get('dispositionRaw'):
        parts.append('Case status/disposition changed')
        critical = True
    if before.get('nextHearing') != after.get('nextHearing'):
        parts.append('Next hearing date changed')
        if before.get('nextHearing') and after.get('nextHearing') and after['nextHearing'] < before['nextHearing']:
            critical = True
    prior = {(h['date'], h['purpose']) for h in before.get('hearings', [])}
    if any((h['date'], h['purpose']) not in prior for h in after['hearings']):
        parts.append('New hearing entry')
    if not parts: return None
    return {'text': '; '.join(parts), 'at': at, 'severity': 'critical' if critical else 'info'}
