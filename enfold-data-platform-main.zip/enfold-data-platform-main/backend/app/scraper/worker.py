"""Run with python -m app.scraper.worker using the dedicated worker DB role.

One globally serialized worker respects upstream throttling. PostgreSQL persists
all task checkpoints. No request handler performs scraping or starts a thread.
"""
import asyncio
import json
import logging
from datetime import datetime, timezone
from uuid import uuid4
from zoneinfo import ZoneInfo
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from pydantic import ValidationError
from app.config import settings
from app.database import engine, async_session_maker
from app.scraper.catalog import ACTS, act_codes
from app.scraper.client import ECourtsClient, UpstreamError
from app.scraper.contracts import RunRequest
from app.scraper.normalize import normalize
from app.scraper.store import enqueue, event, create_run, ingest

log = logging.getLogger(__name__)
LOCK_ID = 772639105


def due_month(now):
    if not settings.SCRAPER_MONTHLY_ENABLED: return None
    local = now.astimezone(ZoneInfo(settings.SCRAPER_TIMEZONE))
    if (local.day, local.hour, local.minute) < (settings.SCRAPER_MONTHLY_DAY, settings.SCRAPER_MONTHLY_HOUR, settings.SCRAPER_MONTHLY_MINUTE):
        return None
    return local.strftime('%Y-%m')


async def metadata(db, key, value):
    await db.execute(text('''INSERT INTO pcma.scraper_metadata(key,value) VALUES (:key, CAST(:value AS jsonb))
        ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, updated_at=CURRENT_TIMESTAMP'''),
        dict(key=key, value=json.dumps(value)))


async def schedule(db, now):
    month = due_month(now)
    if not month: return
    # At most one monthly run for each month, including restarts. Never overlap
    # another scheduled scan that has not finished; check again on later ticks.
    exists = (await db.execute(text("SELECT 1 FROM pcma.scrape_runs WHERE schedule_key=:key OR (trigger_type='scheduled' AND outcome IN ('queued','running')) LIMIT 1"), dict(key=month))).scalar_one_or_none()
    if exists: return
    request = RunRequest(name=f'Monthly nationwide scan — {month}', allStates=True, allActs=True,
                         status='all', requestId=uuid4())
    await create_run(db, request, schedule_key=month)


async def perform(client, task, criteria):
    """Network-only phase. Return work to commit atomically after cancellation check."""
    kind, scope = task['kind'], task['payload']
    children = []
    notes = []
    resolved = None
    record = None
    if kind == 'discover':
        states = await client.states()
        chosen = states if criteria['allStates'] else [s for s in states if s['code'] in criteria['stateCodes']]
        if not chosen or (not criteria['allStates'] and len(chosen) != len(criteria['stateCodes'])):
            raise ValueError('One or more requested states are unavailable')
        resolved = {'states': chosen, 'actKeys': list(ACTS) if criteria['allActs'] else criteria['actKeys']}
        children = [('state', {'state': state}, None) for state in chosen]
    elif kind == 'state':
        children = [('district', {**scope, 'district': district}, None)
                    for district in await client.districts(scope['state']['code'])]
    elif kind == 'district':
        children = [('court', {**scope, 'court': court}, None)
                    for court in await client.courts(scope['state']['code'], scope['district']['code'])]
    elif kind == 'court':
        rows = await client.acts(scope)
        keys = list(ACTS) if criteria['allActs'] else criteria['actKeys']
        statuses = ['Pending', 'Disposed'] if criteria['status'] == 'all' else [criteria['status'].title()]
        for key in keys:
            codes = act_codes(rows, key)
            if not codes:
                notes.append(f"Act not offered: {ACTS[key][0]}; state {scope['state']['code']}, district {scope['district']['code']}, court {scope['court']['code']}")
            for code in codes:
                for status in statuses:
                    for section in criteria['sections'] or ['']:
                        children.append(('search', {**scope, 'act_code': code, 'status': status, 'section': section}, None))
    elif kind == 'search':
        for row in await client.search(scope):
            cnr = str(row.get('cino') or '').strip().upper()
            if not cnr: raise ValueError('Search returned a case without a CNR')
            children.append(('case', {**scope, 'cnr': cnr, 'case_no': row.get('case_no')}, cnr))
    elif kind == 'case':
        record = normalize(await client.history(scope), scope)
    return children, notes, resolved, record


async def finalize(db, run_id):
    counts = dict((await db.execute(text('SELECT status, count(*) FROM pcma.scrape_tasks WHERE run_id=:run GROUP BY status'), dict(run=run_id))).all())
    if counts.get('queued', 0) or counts.get('running', 0): return
    row = (await db.execute(text('SELECT outcome,cancel_requested FROM pcma.scrape_runs WHERE id=:run FOR UPDATE'), dict(run=run_id))).mappings().one()
    found = (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=:run'), dict(run=run_id))).scalar_one()
    outcome = 'cancelled' if row['cancel_requested'] else ('partial' if found else 'failed') if counts.get('failed', 0) else 'success'
    await db.execute(text('UPDATE pcma.scrape_runs SET total_cases_found=:found WHERE id=:run'), dict(run=run_id, found=found))
    if row['outcome'] != outcome:
        await db.execute(text('UPDATE pcma.scrape_runs SET outcome=:outcome,completed_at=CURRENT_TIMESTAMP,total_cases_found=:found WHERE id=:run'), dict(run=run_id,outcome=outcome,found=found))
        await event(db, run_id, outcome, f'Run {outcome}; {found} case snapshots, {counts.get("failed", 0)} failed tasks')


async def claim(db):
    # Always lock run before task, matching cancellation, retry and ingestion.
    # Opposite lock ordering can deadlock a claim against an admin cancellation.
    run_id = (await db.execute(text('''SELECT r.id FROM pcma.scrape_runs r
        WHERE NOT r.cancel_requested AND r.outcome IN ('queued','running')
          AND EXISTS (SELECT 1 FROM pcma.scrape_tasks t WHERE t.run_id=r.id
            AND t.status='queued' AND t.available_at <= CURRENT_TIMESTAMP)
        ORDER BY r.queued_at,r.id FOR UPDATE OF r SKIP LOCKED LIMIT 1'''))).scalar_one_or_none()
    if run_id is None: return None
    task = (await db.execute(text('''SELECT * FROM pcma.scrape_tasks WHERE run_id=:run
        AND status='queued' AND available_at <= CURRENT_TIMESTAMP
        ORDER BY available_at,id FOR UPDATE SKIP LOCKED LIMIT 1'''), {'run':run_id})).mappings().first()
    if not task: return None
    task = dict(task)
    task['attempts'] += 1
    await db.execute(text("UPDATE pcma.scrape_tasks SET status='running',attempts=:attempts,started_at=CURRENT_TIMESTAMP WHERE id=:id"), task)
    await db.execute(text("UPDATE pcma.scrape_runs SET outcome='running',started_at=COALESCE(started_at,CURRENT_TIMESTAMP) WHERE id=:run"), dict(run=task['run_id']))
    await event(db, task['run_id'], 'task_started', f"{task['kind']} task, attempt {task['attempts']}", task['id'])
    return task


async def execute_task(client, task, guard=None):
    async with async_session_maker() as db:
        criteria = (await db.execute(text('SELECT criteria FROM pcma.scrape_runs WHERE id=:run'), dict(run=task['run_id']))).scalar_one()
    failure = None
    try:
        children, notes, resolved, record = await perform(client, task, criteria)
    except (UpstreamError, ValueError, KeyError, TypeError) as error:
        failure = str(error) if isinstance(error, (UpstreamError, ValueError)) else f'Unexpected upstream structure ({type(error).__name__})'
    # Ensure our global worker-lock connection is still alive before writing.
    if guard is not None:
        await guard.execute(text('SELECT 1'))
        await guard.commit()
    async with async_session_maker() as db, db.begin():
        run = (await db.execute(text('SELECT cancel_requested FROM pcma.scrape_runs WHERE id=:run FOR UPDATE'), dict(run=task['run_id']))).mappings().one()
        owned = (await db.execute(text("SELECT 1 FROM pcma.scrape_tasks WHERE id=:id AND status='running' AND attempts=:attempts FOR UPDATE"), task)).scalar_one_or_none()
        if not owned: return
        if run['cancel_requested']:
            await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled',completed_at=CURRENT_TIMESTAMP WHERE id=:id"), task)
        elif failure:
            terminal = task['attempts'] - task['retry_base'] >= settings.SCRAPER_MAX_ATTEMPTS
            await db.execute(text('''UPDATE pcma.scrape_tasks SET status=:status,error_message=:error,
                available_at=CURRENT_TIMESTAMP + make_interval(secs => :delay),
                completed_at=CASE WHEN :terminal THEN CURRENT_TIMESTAMP ELSE NULL END WHERE id=:id'''),
                dict(id=task['id'], status='failed' if terminal else 'queued', error=failure[:1000],
                     delay=min(1800, 30 * 2 ** min(10, task['attempts'] - task['retry_base'] - 1)), terminal=terminal))
            await event(db, task['run_id'], 'task_failed' if terminal else 'task_retry', failure[:1000], task['id'])
            await db.execute(text('UPDATE pcma.scrape_runs SET error_message=:message WHERE id=:run'), dict(run=task['run_id'], message=failure[:1000]))
        else:
            for kind, payload, identity in children:
                await enqueue(db, task['run_id'], kind, payload, identity)
            for note in notes: await event(db, task['run_id'], 'act_unavailable', note, task['id'])
            if resolved:
                await db.execute(text('UPDATE pcma.scrape_runs SET resolved_scope=CAST(:scope AS jsonb) WHERE id=:run'), dict(run=task['run_id'],scope=json.dumps(resolved)))
            if record: await ingest(db, task['run_id'], record)
            await db.execute(text("UPDATE pcma.scrape_tasks SET status='success',error_message=NULL,completed_at=CURRENT_TIMESTAMP WHERE id=:id"), task)
            await event(db, task['run_id'], 'task_completed', f"{task['kind']} task completed; {len(children)} discovered work items", task['id'])
        await finalize(db, task['run_id'])


async def reject_data(task, error_type):
    # A malformed record must not crash/restart forever and block every later case.
    # execute_task's transaction has rolled back before this independent audit write.
    async with async_session_maker() as db, db.begin():
        run = (await db.execute(text('SELECT cancel_requested FROM pcma.scrape_runs WHERE id=:run FOR UPDATE'), {'run':task['run_id']})).mappings().one()
        result = await db.execute(text("UPDATE pcma.scrape_tasks SET status=:status,error_message=:error,completed_at=CURRENT_TIMESTAMP WHERE id=:id AND status='running' AND attempts=:attempts"),
            {'id':task['id'],'attempts':task['attempts'],'status':'cancelled' if run['cancel_requested'] else 'failed',
             'error':f'Record rejected by database validation ({error_type}); existing data preserved'})
        if result.rowcount:
            await db.execute(text('UPDATE pcma.scrape_runs SET error_message=:error WHERE id=:run'),
                {'run':task['run_id'],'error':f'Record rejected by database validation ({error_type}); existing data preserved'})
            await event(db,task['run_id'],'data_rejected',f'Database validation rejected task ({error_type}); inspect the source mapping',task['id'])
            await finalize(db,task['run_id'])


async def process_task(client, task, guard=None):
    try:
        await execute_task(client, task, guard)
    except ValidationError:
        await reject_data(task, 'ValidationError')
    except DBAPIError as error:
        # asyncpg can wrap data errors in DBAPIError rather than DataError.
        # SQLSTATE classes 22/23 identify data/constraint rejection; connection
        # and server errors must still stop the worker for safe recovery.
        code = getattr(error.orig, 'sqlstate', '') or ''
        if code[:2] not in ('22', '23'): raise
        await reject_data(task, code)


async def recover(db):
    runs = (await db.execute(text("""SELECT r.id,r.cancel_requested FROM pcma.scrape_runs r
        WHERE r.snapshot_version=1 AND (r.outcome IN ('queued','running') OR
          (r.outcome='cancelled' AND EXISTS (SELECT 1 FROM pcma.scrape_tasks t
            WHERE t.run_id=r.id AND t.status IN ('queued','running'))))
        ORDER BY r.id FOR UPDATE OF r"""))).mappings().all()
    for run in runs:
        params = {'run':run['id']}
        rows = (await db.execute(text("UPDATE pcma.scrape_tasks SET status='queued',available_at=CURRENT_TIMESTAMP WHERE run_id=:run AND status='running' RETURNING id"), params)).scalars().all()
        for task_id in rows: await event(db, run['id'], 'task_recovered', 'Interrupted task requeued after worker restart', task_id)
        if run['cancel_requested']:
            await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled',completed_at=CURRENT_TIMESTAMP WHERE run_id=:run AND status='queued'"), params)
        await finalize(db, run['id'])


async def main():
    client = ECourtsClient(interval=settings.SCRAPER_REQUEST_INTERVAL)
    try:
        async with engine.connect() as guard:
            locked = (await guard.execute(text('SELECT pg_try_advisory_lock(:key)'), {'key': LOCK_ID})).scalar_one()
            if not locked: raise RuntimeError('Another scraper worker already owns the global lock')
            await guard.commit()
            # Claim/recover on the connection that owns the session lock. A lost
            # lock connection must not leave new claims after its replacement
            # worker has already performed startup recovery.
            async with async_session_maker(bind=guard) as db, db.begin(): await recover(db)
            refresh_at = 0.0
            while True:
                # Metadata errors are visible but do not erase the last successful catalogue.
                if asyncio.get_running_loop().time() >= refresh_at:
                    try:
                        states = await client.states()
                        async with async_session_maker() as db, db.begin(): await metadata(db, 'states', states)
                    except Exception as error:
                        log.warning('State catalogue refresh failed (%s)', type(error).__name__)
                    refresh_at = asyncio.get_running_loop().time() + 3600
                async with async_session_maker(bind=guard) as db, db.begin():
                    await metadata(db, 'worker', {'status': 'running'})
                    await schedule(db, datetime.now(timezone.utc))
                    task = await claim(db)
                if task:
                    try: await process_task(client, task, guard)
                    except Exception as error:
                        # Rollback protected existing data. Recover on restart; don't mark success.
                        log.error('Worker transaction failed (%s); stopping for restart', type(error).__name__)
                        raise RuntimeError(f'Worker stopped after {type(error).__name__}; task will recover on restart') from None
                else: await asyncio.sleep(3)
    finally:
        await client.close()
        await engine.dispose()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    # HTTPX INFO logs include the complete URL with encrypted source parameters.
    # Use our endpoint-only telemetry instead.
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('httpcore').setLevel(logging.WARNING)
    asyncio.run(main())
