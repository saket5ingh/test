from pydantic import BaseModel

class StateCountSchema(BaseModel):
    state: str
    value: int

class OutcomeCountSchema(BaseModel):
    label: str
    value: int

class SectionCountSchema(BaseModel):
    section: str
    value: int

class YearCountSchema(BaseModel):
    year: str
    value: int
