from pathlib import Path
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    DATABASE_URL: str
    JWT_SECRET: str = Field(min_length=32)
    JWT_ALGORITHM: str = 'HS256'
    CORS_ORIGINS: list[str] = ['http://localhost:5173', 'http://127.0.0.1:5173']
    JWT_EXPIRY_MINUTES: int = Field(default=480, gt=0)
    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_ALLOWED_DOMAINS: list[str] = []
    AUTH_COOKIE_SECURE: bool = True
    SCRAPER_REQUEST_INTERVAL: float = Field(default=2.0, ge=1)
    SCRAPER_MAX_ATTEMPTS: int = Field(default=3, ge=1, le=10)
    SCRAPER_MONTHLY_ENABLED: bool = False
    SCRAPER_MONTHLY_DAY: int = Field(default=1, ge=1, le=28)
    SCRAPER_MONTHLY_HOUR: int = Field(default=2, ge=0, le=23)
    SCRAPER_MONTHLY_MINUTE: int = Field(default=0, ge=0, le=59)
    SCRAPER_TIMEZONE: str = 'Asia/Kolkata'

    model_config = SettingsConfigDict(env_file=str(Path(__file__).resolve().parent.parent / '.env'))

settings = Settings()
