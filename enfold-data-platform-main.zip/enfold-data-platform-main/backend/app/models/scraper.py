"""Mappings for migration 005. SQL migrations remain authoritative for deployment."""
import uuid
from sqlalchemy import Column, String, Text, Integer, DateTime, ForeignKey, ForeignKeyConstraint, CheckConstraint, Index, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base


class ScrapeTask(Base):
    __tablename__ = 'scrape_tasks'
    __table_args__ = (
        UniqueConstraint('run_id','task_key'),
        CheckConstraint("kind IN ('discover','state','district','court','search','case')"),
        CheckConstraint("status IN ('queued','running','success','failed','cancelled')"),
        CheckConstraint("jsonb_typeof(payload) = 'object'"),
        CheckConstraint('attempts >= 0'), CheckConstraint('retry_base >= 0'),
        Index('idx_tasks_ready','status','available_at'), Index('idx_tasks_run_status','run_id','status'),
        {'schema':'pcma'},
    )
    id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,server_default=text('uuid_generate_v4()'))
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),nullable=False)
    task_key = Column(Text,nullable=False)
    kind = Column(String(20),nullable=False)
    payload = Column(JSONB,nullable=False)
    status = Column(String(20),nullable=False,server_default='queued')
    attempts = Column(Integer,nullable=False,server_default='0')
    retry_base = Column(Integer,nullable=False,server_default='0')
    available_at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    error_message = Column(Text)


class ScrapeRunCase(Base):
    __tablename__ = 'scrape_run_cases'
    __table_args__ = (CheckConstraint("jsonb_typeof(snapshot) = 'object'"),
        CheckConstraint("change_kind IN ('new','updated','unchanged')"),
        Index('idx_run_cases_case','case_id'), {'schema':'pcma'})
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='RESTRICT'),primary_key=True)
    case_id = Column(UUID(as_uuid=True),ForeignKey('pcma.cases.id',ondelete='RESTRICT'),primary_key=True)
    fetched_at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    snapshot = Column(JSONB,nullable=False)
    change_kind = Column(String(20),nullable=False)


class ScrapeRunEvent(Base):
    __tablename__ = 'scrape_run_events'
    __table_args__ = (Index('idx_run_events','run_id','at','id'), {'schema':'pcma'})
    id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,server_default=text('uuid_generate_v4()'))
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),nullable=False)
    task_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_tasks.id',ondelete='SET NULL'))
    at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    kind = Column(String(40),nullable=False)
    message = Column(Text,nullable=False)
    actor_id = Column(UUID(as_uuid=True),ForeignKey('pcma.users.id',ondelete='SET NULL'))


class ScraperMetadata(Base):
    __tablename__ = 'scraper_metadata'
    __table_args__ = {'schema':'pcma'}
    key = Column(String(40),primary_key=True)
    value = Column(JSONB,nullable=False)
    updated_at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))


class CaseNotification(Base):
    __tablename__ = 'case_notifications'
    __table_args__ = (
        ForeignKeyConstraint(['user_id','case_id'],['pcma.case_pins.user_id','pcma.case_pins.case_id'],ondelete='CASCADE'),
        CheckConstraint('pcma.valid_update(payload)'), {'schema':'pcma'},
    )
    user_id = Column(UUID(as_uuid=True),primary_key=True)
    case_id = Column(UUID(as_uuid=True),primary_key=True)
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id'),nullable=False)
    payload = Column(JSONB,nullable=False)
