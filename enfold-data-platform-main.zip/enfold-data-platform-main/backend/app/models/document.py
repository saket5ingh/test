from sqlalchemy import CheckConstraint, Index, text, Column, String, Date, ForeignKey, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import uuid
from app.database import Base
from datetime import datetime, timezone

class CaseDocument(Base):
    __tablename__ = 'case_documents'
    __table_args__ = (
        Index('idx_case_documents_case_id', 'case_id'),
        Index('idx_case_docs_unique_s3', 'case_id', 's3_key', unique=True, postgresql_where=text('s3_key IS NOT NULL')),
        {'schema': 'pcma'},
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("uuid_generate_v4()"))
    case_id = Column(UUID(as_uuid=True), ForeignKey('pcma.cases.id', ondelete='CASCADE'), nullable=False)
    document_type = Column(String(20), nullable=False)
    label = Column(String(500), nullable=False)
    document_date = Column(Date)
    s3_key = Column(String(500), nullable=True)
    external_link = Column(Text, nullable=True)
    params_blob = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=text("CURRENT_TIMESTAMP"), default=lambda: datetime.now(timezone.utc))

    case = relationship("Case", back_populates="documents")
