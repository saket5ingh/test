from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc, text, String
from app.database import get_db
from app.auth import get_current_user
from app.models.case import Case
from app.schemas.analytics import StateCountSchema, OutcomeCountSchema, SectionCountSchema, YearCountSchema

# Only cases explicitly citing PCMA belong in this dashboard.
pcma_case = Case.acts.contains([{"name": "Prohibition of Child Marriage Act"}])

router = APIRouter(prefix="/analytics", tags=["analytics"], dependencies=[Depends(get_current_user)])

@router.get("/by-state", response_model=list[StateCountSchema])
async def get_by_state(db: AsyncSession = Depends(get_db)):
    stmt = select(Case.state, func.count().label('value')).where(pcma_case).group_by(Case.state).order_by(desc('value'))
    result = await db.execute(stmt)
    return [{"state": r.state or "Unknown", "value": r.value} for r in result]

@router.get("/outcomes", response_model=list[OutcomeCountSchema])
async def get_outcomes(db: AsyncSession = Depends(get_db)):
    stmt = select(Case.disposition_raw.label('label'), func.count().label('value')).where(pcma_case, Case.disposition_raw != None).group_by(Case.disposition_raw)
    result = await db.execute(stmt)
    return [{"label": r.label, "value": r.value} for r in result]

@router.get("/by-section", response_model=list[SectionCountSchema])
async def get_by_section(db: AsyncSession = Depends(get_db)):
    # Using text for unnesting jsonb array
    query = text("""
        SELECT section_elem::text as section, COUNT(DISTINCT cases.id) as value
        FROM pcma.cases,
        jsonb_array_elements(acts) as act_elem,
        jsonb_array_elements_text(act_elem->'sections') as section_elem
        WHERE act_elem->>'name' = 'Prohibition of Child Marriage Act'
        GROUP BY section_elem
        ORDER BY value DESC
    """)
    result = await db.execute(query)
    return [{"section": r.section, "value": r.value} for r in result]

@router.get("/by-year", response_model=list[YearCountSchema])
async def get_by_year(db: AsyncSession = Depends(get_db)):
    stmt = select(Case.registration_year.cast(String).label('year'), func.count().label('value')).where(pcma_case, Case.registration_year != None).group_by(Case.registration_year).order_by('year')
    result = await db.execute(stmt)
    return [{"year": r.year, "value": r.value} for r in result]
