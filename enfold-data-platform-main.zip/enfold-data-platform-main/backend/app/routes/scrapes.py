from uuid import UUID
from typing import Literal
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.auth import require_admin
from app.database import get_db, async_session_maker
from app.models.user import User
from app.config import settings
from app.scraper.catalog import ACTS
from app.scraper.contracts import RunRequest
from app.scraper.store import create_run, event
from app.scraper.export import COLUMNS, csv_line

router = APIRouter(prefix='/scrapes', tags=['scrapes'], dependencies=[Depends(require_admin)])
TERMINAL = {'success', 'partial', 'failed', 'cancelled'}


async def get_run(db, run_id, lock=False):
    row = (await db.execute(text('SELECT * FROM pcma.scrape_runs WHERE id=:id' + (' FOR UPDATE' if lock else '')), {'id':run_id})).mappings().first()
    if row is None: raise HTTPException(404, 'Scrape run not found')
    return row


async def run_view(db, row):
    tasks = dict((await db.execute(text('SELECT status,count(*) FROM pcma.scrape_tasks WHERE run_id=:id GROUP BY status'), {'id':row['id']})).all())
    results = dict((await db.execute(text('SELECT change_kind,count(*) FROM pcma.scrape_run_cases WHERE run_id=:id GROUP BY change_kind'), {'id':row['id']})).all())
    coverage = (await db.execute(text('SELECT kind,status,count(*) AS count FROM pcma.scrape_tasks WHERE run_id=:id GROUP BY kind,status ORDER BY kind,status'), {'id':row['id']})).mappings().all()
    return dict(id=row['id'], name=row['name'], criteria=row['criteria'], resolvedScope=row['resolved_scope'],
        trigger=row['trigger_type'], triggeredBy=row['triggered_by'], queuedAt=row['queued_at'],
        startedAt=row['started_at'], completedAt=row['completed_at'], outcome=row['outcome'],
        cancelRequested=row['cancel_requested'], error=row['error_message'], tasks=tasks, counts=results,
        coverage=[dict(r) for r in coverage], total=sum(results.values()) if row['snapshot_version'] == 1 else row['total_cases_found'] or 0,
        snapshotsAvailable=row['snapshot_version'] == 1,
        legacyCriteria={'state':row['state'], 'acts':row['acts'], 'sections':row['sections'], 'status':row['status_filter']})


@router.get('/options')
async def options(db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(text("SELECT key,value,updated_at FROM pcma.scraper_metadata WHERE key IN ('states','worker')"))).mappings().all()
    data = {r['key']:r for r in rows}
    return {'states': data['states']['value'] if 'states' in data else [],
            'statesUpdatedAt': data['states']['updated_at'] if 'states' in data else None,
            'workerLastSeen': data['worker']['updated_at'] if 'worker' in data else None,
            'workerHealthy': 'worker' in data and data['worker']['updated_at'] > datetime.now(timezone.utc) - timedelta(minutes=10),
            'acts':[{'key':key,'label':label} for key,(label,_) in ACTS.items()],
            'monthlyEnabled':settings.SCRAPER_MONTHLY_ENABLED}


@router.post('/run', status_code=202)
async def run_scrape(data: RunRequest, db: AsyncSession = Depends(get_db), user: User = Depends(require_admin)):
    try: run_id = await create_run(db, data, actor=user.id)
    except ValueError as error: raise HTTPException(409, str(error))
    await db.commit()
    return {'id':run_id}


@router.get('/runs')
async def list_runs(page: int = Query(1, ge=1), pageSize: int = Query(25, ge=1, le=100), db: AsyncSession = Depends(get_db)):
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_runs'))).scalar_one()
    rows = (await db.execute(text('SELECT * FROM pcma.scrape_runs ORDER BY queued_at DESC,id DESC LIMIT :limit OFFSET :offset'),
                             {'limit':pageSize,'offset':(page-1)*pageSize})).mappings().all()
    return {'items':[await run_view(db,row) for row in rows], 'total':total, 'page':page, 'pageSize':pageSize}


@router.get('/runs/{run_id}')
async def detail(run_id: UUID, db: AsyncSession = Depends(get_db)):
    return await run_view(db, await get_run(db, run_id))


@router.post('/runs/{run_id}/cancel', status_code=202)
async def cancel(run_id: UUID, db: AsyncSession = Depends(get_db), user: User = Depends(require_admin)):
    row = await get_run(db, run_id, lock=True)
    if row['outcome'] in TERMINAL: raise HTTPException(409, 'This run has already finished')
    await db.execute(text("UPDATE pcma.scrape_runs SET cancel_requested=TRUE,outcome='cancelled',completed_at=CURRENT_TIMESTAMP WHERE id=:id"), {'id':run_id})
    await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled',completed_at=CURRENT_TIMESTAMP WHERE run_id=:id AND status='queued'"), {'id':run_id})
    await event(db, run_id, 'cancel_requested', 'Administrator requested cancellation; in-flight work will be discarded', actor_id=user.id)
    await db.commit()
    return {'id':run_id}


@router.post('/runs/{run_id}/retry', status_code=202)
async def retry(run_id: UUID, db: AsyncSession = Depends(get_db), user: User = Depends(require_admin)):
    row = await get_run(db, run_id, lock=True)
    if row['outcome'] not in ('partial','failed','cancelled') or row['snapshot_version'] != 1:
        raise HTTPException(409, 'Only failed, partial or cancelled scraper runs can be retried')
    running = (await db.execute(text("SELECT count(*) FROM pcma.scrape_tasks WHERE run_id=:id AND status='running'"), {'id':run_id})).scalar_one()
    if running: raise HTTPException(409, 'Wait for cancellation of the in-flight request before retrying')
    # Keep attempts monotonic to fence stale workers. Each explicit retry grants a
    # fresh attempt budget via a stored base offset, rather than replacing snapshots.
    await db.execute(text("UPDATE pcma.scrape_tasks SET status='queued',available_at=CURRENT_TIMESTAMP,completed_at=NULL,error_message=NULL,retry_base=attempts WHERE run_id=:id AND status IN ('failed','cancelled')"), {'id':run_id})
    await db.execute(text("UPDATE pcma.scrape_runs SET outcome='queued',cancel_requested=FALSE,completed_at=NULL,error_message=NULL WHERE id=:id"), {'id':run_id})
    await event(db, run_id, 'retry_requested', 'Administrator requeued unsuccessful work; completed snapshots preserved', actor_id=user.id)
    await db.commit()
    return {'id':run_id}


@router.get('/runs/{run_id}/results')
async def results(run_id: UUID, page: int = Query(1, ge=1), pageSize: int = Query(25, ge=1, le=100), db: AsyncSession = Depends(get_db)):
    row = await get_run(db, run_id)
    if row['snapshot_version'] != 1: raise HTTPException(409, 'Historical results were not recorded for this legacy run')
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=:id'), {'id':run_id})).scalar_one()
    rows = (await db.execute(text('SELECT snapshot,fetched_at,change_kind FROM pcma.scrape_run_cases WHERE run_id=:id ORDER BY case_id LIMIT :limit OFFSET :offset'),
        {'id':run_id,'limit':pageSize,'offset':(page-1)*pageSize})).mappings().all()
    return {'items':[dict(r) for r in rows], 'total':total,'page':page,'pageSize':pageSize}


@router.get('/runs/{run_id}/events')
async def events(run_id: UUID, page: int = Query(1, ge=1), db: AsyncSession = Depends(get_db)):
    await get_run(db, run_id)
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_events WHERE run_id=:id'), {'id':run_id})).scalar_one()
    rows = (await db.execute(text('''SELECT e.*,u.name AS actor_name FROM pcma.scrape_run_events e
        LEFT JOIN pcma.users u ON u.id=e.actor_id WHERE run_id=:id ORDER BY at DESC,e.id DESC LIMIT 50 OFFSET :offset'''),
        {'id':run_id,'offset':(page-1)*50})).mappings().all()
    return {'items':[dict(r) for r in rows],'total':total,'page':page,'pageSize':50}


@router.get('/runs/{run_id}/tasks')
async def tasks(run_id: UUID, status: Literal['all','queued','running','success','failed','cancelled'] = 'failed',
                page: int = Query(1, ge=1), db: AsyncSession = Depends(get_db)):
    await get_run(db, run_id)
    params = {'run':run_id, 'status':status, 'offset':(page-1)*25}
    where = "run_id=:run AND (:status='all' OR status=:status)"
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_tasks WHERE ' + where), params)).scalar_one()
    rows = (await db.execute(text('SELECT id,kind,payload,status,attempts,error_message FROM pcma.scrape_tasks WHERE '
        + where + ' ORDER BY id LIMIT 25 OFFSET :offset'), params)).mappings().all()
    return {'items':[dict(r) for r in rows], 'total':total, 'page':page, 'pageSize':25}


@router.get('/runs/{run_id}/csv')
async def download_csv(run_id: UUID, db: AsyncSession = Depends(get_db)):
    row = await get_run(db, run_id)
    if row['snapshot_version'] != 1: raise HTTPException(409, 'Historical results were not recorded for this legacy run')
    if row['outcome'] not in TERMINAL: raise HTTPException(409, 'Wait for the run to finish or cancel it before downloading')
    # A server-side cursor bounds memory and keeps the export view consistent
    # while a retried partial run may add further snapshots.
    async def content():
        yield '\ufeff' + csv_line(['Run ID','Run name','Collected at',*[label for _,label in COLUMNS]])
        async with async_session_maker() as session, session.begin():
            await session.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY'))
            statement = text('SELECT snapshot,fetched_at FROM pcma.scrape_run_cases WHERE run_id=:id ORDER BY case_id')
            rows = await session.stream(statement.execution_options(yield_per=200), {'id':run_id})
            async for result in rows.mappings():
                yield csv_line([str(run_id),row['name'],result['fetched_at'].isoformat(),*[result['snapshot'].get(key) for key,_ in COLUMNS]])
    return StreamingResponse(content(), media_type='text/csv', headers={
        'Content-Disposition':f'attachment; filename="ffg-run-{run_id}.csv"', 'Cache-Control':'no-store'})


@router.get('/runs/{run_id}/results/{case_id}')
async def snapshot_detail(run_id: UUID, case_id: UUID, db: AsyncSession = Depends(get_db)):
    await get_run(db, run_id)
    row = (await db.execute(text('SELECT snapshot,fetched_at,change_kind FROM pcma.scrape_run_cases WHERE run_id=:run AND case_id=:case'),
        {'run':run_id,'case':case_id})).mappings().first()
    if row is None: raise HTTPException(404, 'Snapshot not found')
    return dict(row)
