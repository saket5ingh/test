"""Opt-in tests against an isolated, migrated database (never production).

FFG_TEST_PG_OWNER, FFG_TEST_PG_API, FFG_TEST_PG_WORKER are asyncpg URLs.
Records use unique synthetic identifiers. The test does not drop/truncate tables.
"""
import asyncio
import os
from datetime import datetime, timezone
from uuid import uuid4
import bcrypt
import httpx
import pytest
from sqlalchemy import text, inspect
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from app.main import app
from app.database import Base, get_db
from app.scraper import worker
from app.scraper.client import UpstreamError
from test_scraper import history

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URLs not supplied')


class FakeECourts:
    def __init__(self,cnr):
        self.cnr=cnr; self.disposed=False; self.fail=False; self.extra_cnr=None; self.bad_cnr=None; self.invalid_record=False
    async def states(self): return [{'code':'5','name':'Bihar'}]
    async def districts(self,state): return [{'code':'1','name':'Gaya'}]
    async def courts(self,state,district): return [{'code':'1','name':'District court'}]
    async def acts(self,scope): return [('1','Prohibition of Child Marriage Act')]
    async def search(self,scope):
        return [{'cino':cnr,'case_no':'100/2024'} for cnr in [self.cnr,self.extra_cnr] if cnr] if scope['status']==('Disposed' if self.disposed else 'Pending') else []
    async def history(self,scope):
        if self.fail or scope['cnr']==self.bad_cnr: raise UpstreamError('Synthetic transient failure')
        row=history()
        # Exercise the JSON hearing format observed in live v4 responses through
        # normalization, database storage, snapshots and the restricted API.
        hearing={'todays_date':'01-08-2026','nextdate':'20261020','purpose':'Evidence','cino':scope['cnr']}
        row['historyOfCaseHearing']=[hearing]
        row['last_business_date']=hearing
        if self.invalid_record: row['reg_no']='99999999999999999999'
        if self.disposed: row.update(date_of_decision='20-09-2026',disp_name='Disposed')
        return row


def test_real_postgres_pipeline_permissions_snapshots_notifications_and_retry(monkeypatch):
    async def run():
        assert all(make_url(os.environ[key]).database.endswith('_test') for key in ['FFG_TEST_PG_OWNER','FFG_TEST_PG_API','FFG_TEST_PG_WORKER']), 'Use an isolated database ending in _test'
        assert len({(make_url(os.environ[key]).host,make_url(os.environ[key]).port,make_url(os.environ[key]).database) for key in ['FFG_TEST_PG_OWNER','FFG_TEST_PG_API','FFG_TEST_PG_WORKER']})==1
        engines=[create_async_engine(os.environ[key]) for key in ['FFG_TEST_PG_OWNER','FFG_TEST_PG_API','FFG_TEST_PG_WORKER']]
        owner,api,work=[async_sessionmaker(engine,expire_on_commit=False) for engine in engines]
        monkeypatch.setattr(worker,'async_session_maker',work)
        import app.routes.scrapes as routes
        monkeypatch.setattr(routes,'async_session_maker',api)
        async def connection():
            async with api() as db: yield db
        app.dependency_overrides[get_db]=connection
        suffix=uuid4().hex[:12]
        ids={role:uuid4() for role in ['admin','user','other']}
        async with owner() as db,db.begin():
            for role,uid in ids.items():
                await db.execute(text('''INSERT INTO pcma.users(id,user_id,email,name,password_hash,role)
                    VALUES (:id,:uid,:email,:name,:password,:role)'''),dict(id=uid,uid=role+suffix,email=role+suffix+'@example.org',name=role,
                    password=bcrypt.hashpw(b'test-long-password',bcrypt.gensalt(rounds=4)).decode(),role='admin' if role=='admin' else 'user'))
        client=httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test')
        async def login(role):
            response=await client.post('/api/auth/login',json={'userId':role+suffix,'password':'test-long-password'})
            assert response.status_code==200,response.text
            return {'Authorization':'Bearer '+response.json()['token']}
        admin,user,other=[await login(r) for r in ['admin','user','other']]
        fake=FakeECourts('TEST'+suffix.upper())
        guard=await engines[2].connect()
        assert (await guard.execute(text('SELECT pg_try_advisory_lock(:key)'),{'key':worker.LOCK_ID})).scalar_one()
        await guard.commit()
        async def queue():
            body={'name':'Synthetic '+suffix,'allStates':True,'allActs':True,'status':'all','requestId':str(uuid4())}
            first=await client.post('/api/scrapes/run',json=body,headers=admin)
            assert first.status_code==202,first.text
            second=await client.post('/api/scrapes/run',json=body,headers=admin)
            assert second.json()==first.json()
            conflict=await client.post('/api/scrapes/run',json={**body,'name':'Different criteria'},headers=admin)
            assert conflict.status_code==409
            return first.json()['id']
        async def drain():
            for _ in range(100):
                async with work(bind=guard) as db,db.begin():
                    await db.execute(text("UPDATE pcma.scrape_tasks SET available_at=CURRENT_TIMESTAMP WHERE status='queued'"))
                    task=await worker.claim(db)
                if not task: return
                await worker.process_task(fake,task,guard)
            raise AssertionError('Pipeline did not finish')
        try:
            # New SQL definitions and ORM mappings agree on column types/nullability.
            async with engines[0].connect() as connection:
                def check_schema(sync):
                    inspector=inspect(sync)
                    for name in ['scrape_tasks','scrape_runs','scrape_run_cases','scrape_run_events','scraper_metadata','case_notifications']:
                        actual={c['name']:c for c in inspector.get_columns(name,schema='pcma')}
                        model=Base.metadata.tables['pcma.'+name]
                        assert set(actual)==set(model.columns.keys())
                        for column in model.columns:
                            assert actual[column.name]['type'].compile(dialect=sync.dialect)==column.type.compile(dialect=sync.dialect), (name,column.name)
                            assert actual[column.name]['nullable']==column.nullable, (name,column.name)
                await connection.run_sync(check_schema)
            # API role cannot write case data; worker cannot reset passwords or mutate snapshots.
            async with owner() as db:
                permissions=(await db.execute(text("SELECT has_table_privilege(:api,'pcma.cases','INSERT'), has_column_privilege(:worker,'pcma.users','password_hash','UPDATE'),has_table_privilege(:worker,'pcma.scrape_run_cases','UPDATE')"), {"api":make_url(os.environ["FFG_TEST_PG_API"]).username,"worker":make_url(os.environ["FFG_TEST_PG_WORKER"]).username})).one()
                assert tuple(permissions)==(False,False,False)
            first=await queue(); await drain()
            detail=(await client.get(f'/api/scrapes/runs/{first}',headers=admin)).json()
            assert detail['outcome']=='success' and detail['counts']=={'new':1},detail
            snapshot=(await client.get(f'/api/scrapes/runs/{first}/results',headers=admin)).json()['items'][0]['snapshot']
            case_id=snapshot['id']; assert snapshot['status']=='pending'
            assert snapshot['numHearings']==1
            assert snapshot['hearings']==[{'date':'2026-08-01','purpose':'Evidence'}]
            assert (await client.get('/api/cases/'+case_id,headers=admin)).json()['hearings']==snapshot['hearings']
            assert (await client.get(f'/api/scrapes/runs/{first}/csv',headers=user)).status_code==403
            for route in ['','/results','/events','/tasks']:
                assert (await client.get(f'/api/scrapes/runs/{first}'+route,headers=user)).status_code==403
            officer_case=(await client.get('/api/cases/'+case_id,headers=user)).json()
            assert officer_case['cnr'] is None and officer_case['hearings']==[]
            assert (await client.put('/api/cases/'+case_id+'/pin',json={'pinned':True},headers=user)).status_code==204
            assert (await client.get('/api/cases/updates',headers=user)).json()['total']==0
            fake.disposed=True
            second=await queue(); await drain()
            assert (await client.get('/api/cases/'+case_id,headers=admin)).json()['status']=='disposed'
            old=(await client.get(f'/api/scrapes/runs/{first}/results',headers=admin)).json()['items'][0]['snapshot']
            assert old['status']=='pending'
            updates=(await client.get('/api/cases/updates',headers=user)).json()
            assert updates['total']==1 and updates['critical']==1,updates
            assert (await client.get('/api/cases/updates',headers=other)).json()['total']==0
            csv=await client.get(f'/api/scrapes/runs/{first}/csv',headers=admin)
            assert csv.status_code==200 and 'pending' in csv.text and fake.cnr in csv.text
            third=await queue(); await drain()
            assert (await client.get(f'/api/scrapes/runs/{third}',headers=admin)).json()['counts']=={'unchanged':1}
            fake.fail=True
            failed=await queue(); await drain()
            detail=(await client.get(f'/api/scrapes/runs/{failed}',headers=admin)).json()
            assert detail['outcome']=='failed' and detail['tasks']['failed']==1,detail
            failures=(await client.get(f'/api/scrapes/runs/{failed}/tasks?status=failed',headers=admin)).json()
            assert failures['total']==1 and failures['items'][0]['payload']['court']['name']=='District court'
            fake.fail=False
            assert (await client.post(f'/api/scrapes/runs/{failed}/retry',headers=admin)).status_code==202
            await drain()
            assert (await client.get(f'/api/scrapes/runs/{failed}',headers=admin)).json()['outcome']=='success'
            cancelled=await queue()
            assert (await client.post(f'/api/scrapes/runs/{cancelled}/cancel',headers=admin)).status_code==202
            await drain()
            assert (await client.get(f'/api/scrapes/runs/{cancelled}',headers=admin)).json()['total']==0
            # A stale task from before a restart cannot commit after a new claim.
            recovered=await queue()
            async with work() as db,db.begin(): abandoned=await worker.claim(db)
            async with work() as db,db.begin(): await worker.recover(db)
            async with work() as db,db.begin(): replacement=await worker.claim(db)
            assert replacement['id']==abandoned['id'] and replacement['attempts']>abandoned['attempts']
            await worker.execute_task(fake,abandoned)
            async with owner() as db:
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_tasks WHERE run_id=:id'),{'id':recovered})).scalar_one()==1
            await worker.execute_task(fake,replacement); await drain()
            assert (await client.get(f'/api/scrapes/runs/{recovered}',headers=admin)).json()['outcome']=='success'
            # Cancellation while a request is in flight discards its result.
            inflight=await queue()
            for _ in range(20):
                async with work() as db,db.begin(): task=await worker.claim(db)
                assert task
                if task['kind']=='case': break
                await worker.execute_task(fake,task)
            assert task['kind']=='case'
            assert (await client.post(f'/api/scrapes/runs/{inflight}/cancel',headers=admin)).status_code==202
            assert (await client.post(f'/api/scrapes/runs/{inflight}/retry',headers=admin)).status_code==409
            await worker.execute_task(fake,task)
            assert (await client.get(f'/api/scrapes/runs/{inflight}',headers=admin)).json()['total']==0
            assert (await client.post(f'/api/scrapes/runs/{inflight}/retry',headers=admin)).status_code==202
            await drain()
            # One bad case cannot discard good siblings or mutate their snapshots on retry.
            fake.extra_cnr='EXTRA'+suffix.upper(); fake.bad_cnr=fake.extra_cnr
            partial=await queue(); await drain()
            assert (await client.get(f'/api/scrapes/runs/{partial}',headers=admin)).json()['outcome']=='partial'
            saved=(await client.get(f'/api/scrapes/runs/{partial}/results/{case_id}',headers=admin)).json()
            fake.bad_cnr=None
            assert (await client.post(f'/api/scrapes/runs/{partial}/retry',headers=admin)).status_code==202
            await drain()
            assert (await client.get(f'/api/scrapes/runs/{partial}',headers=admin)).json()['total']==2
            assert (await client.get(f'/api/scrapes/runs/{partial}/results/{case_id}',headers=admin)).json()==saved
            fake.extra_cnr=None
            # SQL rejection rolls back the record, records failure and releases the queue.
            fake.invalid_record=True
            rejected=await queue(); await drain()
            assert (await client.get(f'/api/scrapes/runs/{rejected}',headers=admin)).json()['outcome']=='failed'
            assert (await client.get('/api/cases/'+case_id,headers=admin)).json()['regNo']==100
            fake.invalid_record=False
            # Monthly scheduling is idempotent and does not overlap a prior scheduled run.
            monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_ENABLED',True)
            monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_DAY',1)
            year=3000+int(suffix[:8],16)%5000
            async with work() as db,db.begin():
                await worker.schedule(db,datetime(year,1,15,tzinfo=timezone.utc))
                await worker.schedule(db,datetime(year,1,15,tzinfo=timezone.utc))
                await worker.schedule(db,datetime(year,2,15,tzinfo=timezone.utc))
            async with owner() as db:
                scheduled=(await db.execute(text('SELECT id,criteria FROM pcma.scrape_runs WHERE schedule_key IN (:first,:second)'),{'first':f'{year}-01','second':f'{year}-02'})).mappings().all()
                assert len(scheduled)==1 and scheduled[0]['criteria']['allStates'] and scheduled[0]['criteria']['allActs']
            await client.post(f"/api/scrapes/runs/{scheduled[0]['id']}/cancel",headers=admin)
            # Replayed completed case task cannot duplicate snapshots/hearings.
            async with owner() as db:
                count=(await db.execute(text('SELECT count(*) FROM pcma.case_hearings WHERE case_id=:id'),{'id':case_id})).scalar_one()
                assert count==1
        finally:
            # Keep a failed test from leaving work that contaminates a later run.
            async with owner() as db,db.begin():
                await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled' WHERE status IN ('queued','running') AND run_id IN (SELECT id FROM pcma.scrape_runs WHERE name=:name)"),{'name':'Synthetic '+suffix})
                await db.execute(text("UPDATE pcma.scrape_runs SET outcome='cancelled',cancel_requested=TRUE,completed_at=CURRENT_TIMESTAMP WHERE outcome IN ('queued','running') AND name=:name"),{'name':'Synthetic '+suffix})
            await client.aclose()
            await guard.close()
            app.dependency_overrides.clear()
            for engine in engines: await engine.dispose()
    asyncio.run(run())
