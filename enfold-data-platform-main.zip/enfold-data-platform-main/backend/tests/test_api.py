from datetime import date
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock
from uuid import uuid4

import bcrypt
import pytest
from fastapi.testclient import TestClient
from jose import jwt

from app.main import app
from app.auth import create_access_token, get_current_user
from app.config import settings
from app.database import get_db
from app.models.user import User
from app.schemas.case import CaseSchema


def result(rows):
    value = Mock()
    value.scalars.return_value.all.return_value = rows
    value.mappings.return_value.all.return_value = rows
    value.scalars.return_value.__iter__ = lambda _: iter(rows)
    value.scalar_one.return_value = rows[0] if rows else None
    value.scalar_one_or_none.return_value = rows[0] if rows else None
    return value


@pytest.fixture
def user():
    return User(id=uuid4(), user_id='officer', email='officer@example.org', name='Officer',
                password_hash=bcrypt.hashpw(b'correct-password', bcrypt.gensalt(rounds=4)).decode(),
                auth_version=0, role='user', role_label='Field Officer', initials='OF', is_active=True)


@pytest.fixture
def db():
    session = SimpleNamespace(execute=AsyncMock(), get=AsyncMock(), commit=AsyncMock())
    session.execute.side_effect = AssertionError('Unexpected database operation')
    return session


@pytest.fixture
def client(db):
    app.dependency_overrides[get_db] = lambda: db
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


def case_record():
    return SimpleNamespace(
        id=uuid4(), cnr_number='SECRET-CNR', case_number='SECRET-NUMBER', registration_number=123,
        registration_year=None, case_ref='PUBLIC-REF', case_type=None, case_type_class=None,
        state='Bihar', district='Gaya', complex_name='SECRET-COMPLEX', court_name='SECRET-COURT',
        registration_date=None, filing_date=None, decision_date=None, disposition_raw=None,
        status='pending', duration_days=None, hearings_count=None, last_purpose=None,
        acts=[], last_scrape=None, pinned=True, next_hearing=None, update_info=None,
        hearings=[SimpleNamespace(hearing_date=date(2026, 1, 1), purpose='Hearing')],
        documents=[SimpleNamespace(document_type='final', label='Order', document_date=None)])


def test_passwordless_endpoints_removed(client):
    assert client.get('/api/auth/accounts').status_code == 404
    assert client.post('/api/auth/select-account', json={'email': 'admin@example.org'}).status_code == 404


@pytest.mark.parametrize('path', ['/api/cases', '/api/options', '/api/analytics/by-state',
                                    '/api/analytics/by-year', '/api/analytics/by-section',
                                    '/api/analytics/outcomes', '/api/scrapes', '/api/auth/me'])
def test_anonymous_requests_denied(client, db, path):
    assert client.get(path).status_code == 401
    db.execute.assert_not_called()


@pytest.mark.parametrize('identifier', ['officer', 'OFFICER@EXAMPLE.ORG'])
def test_username_or_email_login(client, db, user, identifier):
    db.execute.side_effect = [result([user])]
    response = client.post('/api/auth/login', json={'userId': identifier, 'password': 'correct-password'})
    assert response.status_code == 200
    assert response.json()['account']['role'] == 'user'
    payload = jwt.decode(response.json()['token'], settings.JWT_SECRET, algorithms=['HS256'])
    assert payload['sub'] == 'officer' and 'exp' in payload
    # Ensure the actual query includes both identifier columns.
    statement = db.execute.call_args.args[0]
    assert 'lower(pcma.users.email)' in str(statement)


@pytest.mark.parametrize('active,password', [(False, 'correct-password'), (True, 'wrong-password')])
def test_invalid_login_denied(client, db, user, active, password):
    user.is_active = active
    db.execute.side_effect = [result([user])]
    assert client.post('/api/auth/login', json={'userId': user.user_id, 'password': password}).status_code == 401


def test_expired_token_denied(client, db):
    token = jwt.encode({'sub': 'officer', 'exp': 1}, settings.JWT_SECRET, algorithm='HS256')
    assert client.get('/api/cases', headers={'Authorization': f'Bearer {token}'}).status_code == 401
    db.execute.assert_not_called()


def test_deactivated_account_session_denied(client, db, user):
    user.is_active = False
    db.execute.side_effect = [result([user])]
    token = create_access_token({'sub': user.user_id})
    assert client.get('/api/auth/me', headers={'Authorization': f'Bearer {token}'}).status_code == 401


@pytest.mark.parametrize('role', ['user', 'admin'])
@pytest.mark.parametrize('detail', [False, True])
def test_case_permissions_and_nullable_values(client, db, user, role, detail):
    user.role = role
    app.dependency_overrides[get_current_user] = lambda: user
    case = case_record()
    db.execute.side_effect = [result([case])] if detail else [result([1]), result([case]), result([])]
    db.get.return_value = None
    response = client.get(f'/api/cases/{case.id}' if detail else '/api/cases')
    assert response.status_code == 200
    body = response.json() if detail else response.json()['items'][0]
    assert body['ref'] == 'PUBLIC-REF'
    assert body['pinned'] is False  # Never inherit the legacy global pin.
    assert body['duration'] is None
    if role == 'user':
        for key in ['cnr', 'caseNo', 'regNo', 'complex', 'court']:
            assert body[key] is None
        assert body['hearings'] == []
        assert 'SECRET' not in response.text
    else:
        assert body['cnr'] == 'SECRET-CNR'
        assert len(body['hearings']) == 1
    assert 'finalOrders' not in body and 'interimOrders' not in body


def test_personal_pin_queries_use_authenticated_owner(client, db, user):
    app.dependency_overrides[get_current_user] = lambda: user
    case = case_record()
    db.get.return_value = case
    db.execute.side_effect = [Mock(), Mock()]
    for pinned in [True, False]:
        response = client.put(f'/api/cases/{case.id}/pin', json={'pinned': pinned})
        assert response.status_code == 204
        params = db.execute.call_args.args[0].compile().params
        assert user.id in params.values() and case.id in params.values()
    assert db.commit.await_count == 2


def test_missing_case_cannot_be_pinned(client, db, user):
    app.dependency_overrides[get_current_user] = lambda: user
    db.get.return_value = None
    assert client.put(f'/api/cases/{uuid4()}/pin', json={'pinned': True}).status_code == 404
    db.commit.assert_not_called()


@pytest.mark.parametrize('role,expected', [('user', 403), ('admin', 422)])
def test_scraper_rejects_officers_and_obsolete_payloads_without_writes(client, db, user, role, expected):
    user.role = role
    app.dependency_overrides[get_current_user] = lambda: user
    response = client.post('/api/scrapes/run', json={'name': 'Test', 'state': 'Bihar',
        'acts': 'Prohibition of Child Marriage Act', 'sections': '9,10', 'status': 'all'})
    assert response.status_code == expected
    db.commit.assert_not_called()
    db.execute.assert_not_called()


def test_sql_nullable_metadata_can_be_serialized():
    case = case_record()
    case.case_ref = case.case_number = case.last_scrape = None
    assert CaseSchema.model_validate(case).caseNo is None


@pytest.mark.parametrize('query', ['page=0', 'pageSize=101', 'status=unknown',
    'regYearFrom=2026&regYearTo=2020', 'filingFrom=bad-date',
    'decisionFrom=2026-02-01&decisionTo=2026-01-01'])
def test_invalid_case_queries_rejected(client, db, user, query):
    app.dependency_overrides[get_current_user] = lambda: user
    assert client.get('/api/cases?' + query).status_code == 422
    db.execute.assert_not_called()


def test_pagination_and_repeated_filters_reach_sql(client, db, user):
    from sqlalchemy.dialects import postgresql
    app.dependency_overrides[get_current_user] = lambda: user
    db.execute.side_effect = [result([40]), result([])]
    response = client.get('/api/cases?page=3&pageSize=10&district=Gaya&district=Patna&status=pending&pinnedOnly=true&q=100%25')
    assert response.json() == {'items': [], 'total': 40, 'page': 3, 'pageSize': 10}
    statement = db.execute.call_args.args[0].compile(dialect=postgresql.dialect())
    assert 'LIMIT' in str(statement) and 'OFFSET' in str(statement) and 'EXISTS' in str(statement)
    params = statement.params.values()
    assert 10 in params and 20 in params and ['Gaya', 'Patna'] in params and user.id in params
    # Literal wildcard escaping and no hidden fields in the search predicate.
    assert '100/%' in params
    predicate = str(statement).split('WHERE', 1)[1]
    assert 'cnr_number' not in predicate and 'court_name' not in predicate


def test_shared_catalogue_has_no_district_access_boundary(user):
    from app.case_queries import case_conditions
    from app.schemas.query import CaseQuery
    assert case_conditions(CaseQuery(), user) == []


def test_restricted_search_filter_denied(client, db, user):
    app.dependency_overrides[get_current_user] = lambda: user
    assert client.get('/api/cases?court=Secret').status_code == 403
    db.execute.assert_not_called()


def test_updates_use_personal_pins_and_return_catalogue_counts(client, db, user):
    app.dependency_overrides[get_current_user] = lambda: user
    db.execute.side_effect = [result([42]), result([8]), result([])]
    response = client.get('/api/cases/updates')
    assert response.json() == {'items': [], 'total': 42, 'critical': 8}
    for call in db.execute.call_args_list:
        assert user.id in call.args[1].values()


@pytest.mark.parametrize('version,expected', [(0, 401), (1, 200), (None, 401)])
def test_password_reset_revokes_previous_sessions(client, db, user, version, expected):
    user.auth_version = 1
    db.execute.side_effect = [result([user])]
    token = create_access_token({'sub': user.user_id, 'ver': version})
    assert client.get('/api/auth/me', headers={'Authorization': f'Bearer {token}'}).status_code == expected


def test_google_disabled_without_client_id(client, db, monkeypatch):
    monkeypatch.setattr(settings, 'GOOGLE_CLIENT_ID', '')
    assert client.get('/api/auth/google/config').json()['enabled'] is False
    assert client.post('/api/auth/google', json={'credential': 'id-token'}).status_code == 503
    db.execute.assert_not_called()


def google_setup(client, monkeypatch, **overrides):
    from app.routes import google_auth
    monkeypatch.setattr(settings, 'GOOGLE_CLIENT_ID', 'test.apps.googleusercontent.com')
    monkeypatch.setattr(settings, 'AUTH_COOKIE_SECURE', False)
    config = client.get('/api/auth/google/config')
    assert 'HttpOnly' in config.headers['set-cookie'] and 'SameSite=strict' in config.headers['set-cookie']
    claims = dict(sub='google-user-123', email='officer@example.org', hd='example.org',
                  email_verified=True, nonce=config.json()['nonce'])
    claims.update(overrides)
    monkeypatch.setattr(google_auth, 'verify_credential', lambda credential: claims)
    return claims


def test_google_sign_in_links_only_existing_account(client, db, user, monkeypatch):
    google_setup(client, monkeypatch)
    update_result = Mock(rowcount=1)
    db.execute.side_effect = [result([]), result([user]), update_result]
    response = client.post('/api/auth/google', json={'credential': 'verified-id-token'})
    assert response.status_code == 200
    assert response.json()['account']['role'] == 'user'
    assert 'Max-Age=0' in response.headers['set-cookie']
    db.commit.assert_awaited_once()
    update = db.execute.call_args.args[0].compile().params
    assert update['google_sub'] == 'google-user-123' and user.id in update.values()


@pytest.mark.parametrize('claims', [{'nonce': 'wrong'}, {'email_verified': False}, {'sub': ''}])
def test_google_invalid_claims_denied_before_database(client, db, monkeypatch, claims):
    google_setup(client, monkeypatch, **claims)
    assert client.post('/api/auth/google', json={'credential': 'invalid'}).status_code == 401
    db.execute.assert_not_called()


def test_google_unprovisioned_account_denied(client, db, monkeypatch):
    google_setup(client, monkeypatch)
    db.execute.side_effect = [result([]), result([])]
    assert client.post('/api/auth/google', json={'credential': 'valid'}).status_code == 403
    db.commit.assert_not_called()


def test_google_third_party_email_cannot_automatically_link(client, db, monkeypatch):
    google_setup(client, monkeypatch, hd='', email='someone@third-party.example')
    db.execute.side_effect = [result([])]
    assert client.post('/api/auth/google', json={'credential': 'valid'}).status_code == 403
    assert db.execute.await_count == 1


def test_google_requires_browser_challenge(client, db, monkeypatch):
    google_setup(client, monkeypatch)
    client.cookies.clear()
    assert client.post('/api/auth/google', json={'credential': 'valid'}).status_code == 401
    db.execute.assert_not_called()


@pytest.mark.parametrize('active,linked', [(False, 'google-user-123'), (True, 'another-sub')])
def test_google_disabled_or_differently_linked_account_denied(client, db, user, monkeypatch, active, linked):
    google_setup(client, monkeypatch)
    user.is_active, user.google_sub = active, linked
    db.execute.side_effect = [result([]), result([user])]
    assert client.post('/api/auth/google', json={'credential': 'valid'}).status_code == 403
    db.commit.assert_not_called()


def test_google_domain_allowlist(client, db, monkeypatch):
    google_setup(client, monkeypatch)
    monkeypatch.setattr(settings, 'GOOGLE_ALLOWED_DOMAINS', ['allowed.example'])
    assert client.post('/api/auth/google', json={'credential': 'valid'}).status_code == 401
    db.execute.assert_not_called()


def test_admin_password_reset_preserves_identity_and_activation(user, monkeypatch):
    import asyncio
    from app import reset_password
    user.is_active = False
    session = AsyncMock()
    session.execute.return_value = result([user])
    session.__aenter__.return_value = session
    monkeypatch.setattr(reset_password, 'async_session_maker', lambda: session)
    hashed = reset_password.password_hash('new-secure-password', 'new-secure-password')
    asyncio.run(reset_password.reset(user.user_id, hashed))
    assert user.verify_password('new-secure-password')
    assert user.auth_version == 1 and user.role == 'user' and user.is_active is False
    session.commit.assert_awaited_once()


@pytest.mark.parametrize('password,confirmation', [('short', 'short'), ('a'*73, 'a'*73), ('valid-long-password', 'different')])
def test_invalid_reset_password_rejected(password, confirmation):
    from app.reset_password import password_hash
    with pytest.raises(ValueError):
        password_hash(password, confirmation)


@pytest.mark.parametrize('invalid_claim', [None, 'aud', 'iss', 'exp'])
def test_google_library_verifies_signed_tokens_and_bounds_transport(monkeypatch, invalid_claim):
    import json
    import time
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization
    from app.routes import google_auth
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    public = key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()
    claims = {'sub': 'google-sub', 'aud': 'our-client', 'iss': 'accounts.google.com',
              'iat': int(time.time()) - 100, 'exp': int(time.time()) + 600}
    if invalid_claim:
        claims[invalid_claim] = int(time.time()) - 60 if invalid_claim == 'exp' else 'wrong-value'
    token = jwt.encode(claims, private, algorithm='RS256', headers={'kid': 'local-test-key'})
    transport = Mock(return_value=SimpleNamespace(status=200, data=json.dumps({'local-test-key': public}).encode()))
    monkeypatch.setattr(google_auth, 'GoogleRequest', lambda: transport)
    monkeypatch.setattr(settings, 'GOOGLE_CLIENT_ID', 'our-client')
    if invalid_claim:
        from google.auth.exceptions import GoogleAuthError
        with pytest.raises((ValueError, GoogleAuthError)):
            google_auth.verify_credential(token)
    else:
        assert google_auth.verify_credential(token)['sub'] == 'google-sub'
    assert transport.call_args.kwargs['timeout'] == 10
