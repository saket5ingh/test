# FFG staging infrastructure

`staging.yml` provisions a new, independent CloudFormation stack. Use the name
`ffg-staging-small-20261005` in Mumbai (`ap-south-1`). The template does not import,
stop, change or delete any pre-existing resource. The separately approved old-server
cleanup is recorded below.

The template creates one Ubuntu 24.04 AMD64 `t3.small` (2 vCPU / 2 GiB),
a 30-GiB encrypted gp3 root disk, a dedicated VPC/subnet/internet route, one
Elastic IP, a security group, and an EC2 role/profile with only the AWS-managed
`AmazonSSMManagedInstanceCore` policy. No SSH key is installed. IMDSv2 is
required; a one-hop response limit keeps the instance role out of ordinary
Docker bridge containers. CPU credits use standard mode to avoid unlimited
CPU-credit charges; sustained workloads may throttle.
The 2-GiB host is for limited staging tests. Measure memory use before enabling
the complete workload, and do not use it for nationwide monthly scraping.

All inbound ports are initially closed (`EnablePublicWeb=false`). Outbound HTTP/HTTPS allow package
installation, SSM registration and eCourts. Administration uses Session Manager
with existing authorized operator identities. Creating the EC2 role does not
grant new IAM-user permissions. Public website ports 80/443 and a domain are
separate deployment steps. The template installs no application and starts no
scrapes. Verify SSM registration and boot logs after creation; a successful
CloudFormation stack alone does not verify operating-system readiness.

## Review and create

Use the CloudFormation console to upload `staging.yml`, select the new stack
name, review all resources and acknowledge IAM role creation. Alternatively,
from an already authenticated AWS CLI session, first verify the account:

```sh
aws sts get-caller-identity
aws cloudformation validate-template --template-body file://staging.yml --region ap-south-1
aws cloudformation create-change-set --stack-name ffg-staging-small-20261005 \
  --change-set-name initial-review --change-set-type CREATE \
  --template-body file://staging.yml --capabilities CAPABILITY_IAM \
  --region ap-south-1
aws cloudformation describe-change-set --stack-name ffg-staging-small-20261005 \
  --change-set-name initial-review --region ap-south-1
```

Only execute the reviewed change set after the IAM access and cost are approved.
No keys, tokens, application secrets or case data belong in the template.
The Ubuntu AMI resolves from Canonical's public SSM parameter at deployment;
check the resolved image owner, architecture and root device before launch.

## Enable public HTTPS access

After configuring the hostname and approving public access, set the template's
`EnablePublicWeb` parameter to `true`. It permits inbound IPv4 TCP **80 and 443**
only on the security group dedicated to this stack's `Host`. HTTP supports the
HTTPS redirect and certificate validation; HTTPS serves the application.
SSH, PostgreSQL and the direct API port remain closed. The default is `false`.

For a new stack, supply `ParameterKey=EnablePublicWeb,ParameterValue=true` when
creating its change set. For an existing stack, upload the updated template and
explicitly preserve or enable this parameter. Review the change set before
executing: the intended resource change is the security group's ingress rules,
with **no replacement**. Do not execute a change set that replaces the host,
disk, security group or address as part of this networking update.

The Ubuntu AMI parameter points at Canonical's latest image. Even reusing the
parameter can resolve a newer image during an update; inspect the proposed
`Host.ImageId` change and retain the deployed image rather than accidentally
replacing the server. Keep the existing `GroupDescription` unchanged because
changing it can replace the security group; its original wording describes the
initial closed-port state, not the current rules.

Turning `EnablePublicWeb` back to `false` removes public web access. This is not
a DNS or certificate switch: configure DNS, Caddy and the production environment
separately as described in [the deployment guide](../README.md). Only Caddy should
publish host ports; database and API access stay on the internal Docker network.

On 8 October 2026, read-only checks confirmed that
`https://enfold-ffg-test.duckdns.org/` served the application, HTTP redirected to
HTTPS, API readiness and unauthenticated-access checks passed, and the staging
security group admitted only ports 80/443. The historical provisioning notes
below describe the earlier, pre-deployment state. Committing this template does
not update the live CloudFormation stack or redeploy application containers.

## Costs, preservation and cleanup

The planning allowance is $23–27/month for this server, disk and public IPv4,
before additional backups, transfer or taxes. This is not a spending cap and
does not include the old account resources. On 5 October 2026, the EC2 console
reported $78.43 credit remaining and a free-plan end date of 29 October 2026;
the billing home showed a conflicting 26-day warning. Confirm the account's
free-plan deadline with its owner before relying on it for persistent hosting.

Termination protection is enabled. The root disk is retained if the instance is
terminated, and CloudFormation retains the instance on stack deletion or
replacement. Retained resources continue to cost money. Deleting this stack
is therefore **not** a complete cleanup operation; attached network resources
may prevent stack deletion, and removing its role would break SSM access.
Failed creation can also leave a retained root disk. Inventory resources and
take verified database backups before any deliberate teardown, then explicitly
remove only the new stack's resources. The older `enfold-prod` stack and its
remaining resources are outside the new deployment's teardown scope.

## Existing servers: read-only findings

Inspected EC2 metadata on 5 October 2026:

| Server | State | Disk | Findings |
| --- | --- | --- | --- |
| `Enfold Server` | Running `t3.micro` | 8 GiB, unencrypted | No instance role; public SSH rule; disk deletes on termination |
| `enfold-ffg-prod-app` | Stopped `t3.small` | 30 GiB, encrypted | Managed by CloudFormation stack `enfold-prod`; dedicated network and role; public SSH rule; disk deletes on termination |

These observations do not establish what either disk contains. Neither server
was started, stopped, logged into or modified during this inspection. Database
contents, containers, uploads, backups and credentials on their filesystems
were unverified. An earlier Mumbai EC2 dashboard showed zero EBS snapshots;
that does not rule out backups stored elsewhere.

The old `enfold-prod` stack also records an S3 data bucket
`enfold-ffg-prod-data-303602054674`, an Elastic IP and a scheduler IAM role.
Bucket contents and any schedules outside that stack were not inspected.
Its resource list contains no EventBridge schedule despite the stack description
mentioning a monthly trigger. Do not treat the description as proof of a working
schedule or assume the bucket is empty.

## Provisioning attempt — 5 October 2026

The template passed `cfn-lint 1.57.1` for Mumbai. It was uploaded to the account's
CloudFormation template bucket. The `initial-review` change set for stack
`ffg-staging-20261005` passed AWS deployment validations and contained 13 additions
with no modifications or deletions. After explicit approval, it was executed.
AWS created the network, management role/profile and public address, but rejected
the EC2 launch: **t3.medium is not eligible for this account's Free plan**.
CloudFormation initiated rollback. No successful host or SSM session was verified.
This illustrates that successful template/deployment validation does not guarantee
that account-plan restrictions permit an instance launch.

A live read-only `describe-instance-types` query in Mumbai confirmed these
eligible AMD64 types: `t3.micro`, `t3.small`, `t8i.micro`, `t8i.small`,
`c7i-flex.large`, and `m7i-flex.large`. The user selected the smaller `t3.small`
test host (2 GiB); the template now reflects that selection.
Do not retry the existing t3.medium template on the Free plan or upgrade the
account automatically. The first stack reached `ROLLBACK_COMPLETE`; its resource
inventory showed `DELETE_COMPLETE` for all attempted resources. The smaller
replacement was then launched with explicit user approval, stack termination
protection, and the same approved SSM permissions.

## Separately approved old-server cleanup

After the metadata review, the user explicitly confirmed permanent deletion of
the two exact instance IDs and disks, acknowledging that filesystem/database
contents had not been inspected or backed up by this agent. AWS confirmed:

- `i-05ebca9611110aa97` (`Enfold Server`): terminated;
  `vol-07d1076d092be9429` (8 GiB): no longer present.
- `i-0da6eae833dae3766` (`enfold-ffg-prod-app`): terminated;
  `vol-0a4996642b157f172` (30 GiB): no longer present.

The S3 bucket, old Elastic IP, roles, networks and `enfold-prod` stack were
explicitly excluded and remain outside the deletion scope. That old stack now
has drift because its instance was terminated directly; do not update it casually
or assume `CREATE_COMPLETE` means its former application is still running.
Remaining billable resources need a separate cleanup review. No production
replacement was created; production is deferred until staging acceptance tests.

## Verified staging host

The replacement stack `ffg-staging-small-20261005` reached `CREATE_COMPLETE`.

| Resource | Value |
| --- | --- |
| Region | `ap-south-1` (Mumbai) |
| Instance | `i-01576031814ab07c5` |
| Instance type / OS | `t3.small`, Ubuntu 24.04 AMD64 |
| Elastic IPv4 | `43.204.80.144` |
| Root disk | `vol-0f4200a23957a2edf`, 30 GiB encrypted gp3 |
| Security group | `sg-0d53a680cb07f83ef`, no inbound rules |

SSM reported `Online`. A read-only `AWS-RunShellScript` verification command
completed with `Success` and exit code 0: cloud-init reported `done` with no
errors, the architecture was `x86_64`, and SSM Agent was active. The fresh host
had about 1.5 GiB available memory, no swap and 27 GiB free disk space. These are
boot-time measurements, not application load-test results.
EC2 system and instance health checks both reported `ok`. Instance termination
protection is enabled, CPU credits use `standard`, and the instance role has
the approved `AmazonSSMManagedInstanceCore` managed policy attached.

No application deployment, production secrets, domain, DNS or public HTTPS
was configured in this infrastructure step. Keep the monthly scraper disabled
and complete image CI and staging acceptance before deciding on production
capacity. Access through Session Manager; no SSH key was installed.

`bootstrap-host.sh` installs Docker Engine and Compose from Docker's official
signed Ubuntu repository. Bash syntax and ShellCheck passed. After the console
session was renewed, the exact script was sent through SSM, with its SHA-256
verified before dispatch. Command `b13514e1-4e55-4b18-b7d9-a8d1b32263d3`
completed on `i-01576031814ab07c5` with `Success` and exit code 0:

- Docker Engine: `29.8.2`; Docker Compose: `v5.6.0`.
- The disposable `hello-world` container ran successfully with `--network none`.
  Its image was pulled successfully from Docker Hub before container creation.
- Root-owned deployment directories were created under `/opt/ffg/` without
  granting Docker group access or exposing a remote Docker API.

The bootstrap log is `/var/log/ffg-host-bootstrap.log` on the staging host.
This verifies the container runtime only; FFG images, database setup, application
health, HTTPS and end-to-end acceptance remain to be deployed and verified.
