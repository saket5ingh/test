#!/usr/bin/env bash
# Fresh Ubuntu 24.04 staging host; run as root through Systems Manager.
# Uses Docker's official signed apt repository. No application secrets needed.
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "Run this script as root through SSM or sudo." >&2
  exit 1
fi
# shellcheck source=/dev/null
source /etc/os-release
if [[ ${ID} != ubuntu || ${VERSION_ID} != 24.04 || $(dpkg --print-architecture) != amd64 ]]; then
  echo "This bootstrap supports Ubuntu 24.04 AMD64 only." >&2
  exit 1
fi

# Re-running host preparation must not silently upgrade a deployed Docker engine.
if command -v docker >/dev/null 2>&1; then
  docker info >/dev/null
  docker version --format '{{.Server.Version}}'
  docker compose version
  exit 0
fi

export DEBIAN_FRONTEND=noninteractive
apt-get -o DPkg::Lock::Timeout=180 -o Acquire::Retries=3 update
apt-get -o DPkg::Lock::Timeout=180 install -y ca-certificates curl python3
install -d -m 0755 /etc/apt/keyrings
curl --fail --silent --show-error --location --retry 3 --max-time 60 \
  https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
chmod 0644 /etc/apt/keyrings/docker.asc
cat > /etc/apt/sources.list.d/docker.sources <<'EOF'
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: noble
Components: stable
Architectures: amd64
Signed-By: /etc/apt/keyrings/docker.asc
EOF
apt-get -o DPkg::Lock::Timeout=180 -o Acquire::Retries=3 update
apt-get -o DPkg::Lock::Timeout=180 install -y \
  docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker

# Operator access remains through authorized SSM users with sudo; do not grant
# Docker group membership or open a remote Docker API.
install -d -m 0700 /opt/ffg/shared /opt/ffg/state /opt/ffg/releases
docker version --format '{{.Server.Version}}'
docker compose version
docker run --rm --network none hello-world
