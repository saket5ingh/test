# Scraper performance release: operator plan

This is a **planned rollout**, not evidence of a deployment. Do not run these steps
against the active nationwide scan until deployment and its maintenance window
are explicitly approved. No production task was cancelled, reset or restarted in
implementing this release.

## What changes

One coordinator still holds PostgreSQL advisory lock `772639105`. It runs a
bounded pool (default **1**, configurable 1–8), separate HTTP clients/sessions,
and a durable global admission gate. Production spacing remains **3 seconds or
slower across the entire pool**, including bootstrap requests. Additional
coordinator replicas are unsupported and rejected by configuration validation.
Concurrency overlaps slow requests and database work; it does not multiply the
source request budget. Keep concurrency 1 on the first rollout, then consider a
small approved canary at 2 after inspecting actual memory, source failures and
latency. Local synthetic concurrency tests do not establish eCourts permission.

The oldest active run finishes before a later run starts, including while its
requests are in flight or delayed for retry. A monthly run can wait behind a
manual run. Within a run, weighted round-robin serves every work type. Case work
receives 4 of 9 normal slots and 32 of 37 slots under backpressure. Empty kinds
are skipped. The cursor survives restarts.

A default 10,000 queued/running task high-water mark limits **new queue admission
per run**. Existing millions of tasks are preserved. Producer responses are
checkpointed in chunks; only capacity-fitting batches become task rows. Under
pressure, producer source calls still get occasional turns; their child
references remain durable checkpoints, not discarded responses. Checkpointed
references can themselves grow and consume disk; this is not a hard total disk
quota. If only producers/checkpoints remain, one child may be admitted beyond the
high-water mark to avoid deadlock. Do not mistake staged references for distinct
case records: deduplication happens on queue admission.

A task's lease, owner and monotonic claim version fence stale results. The
coordinator renews live leases and recovers expired ones. Restart recovery never
resets IDs, task keys, attempts, retry bases, run criteria or snapshots. Shutdown
stops claims, waits up to `SCRAPER_SHUTDOWN_SECONDS` (30 default, 120 maximum),
then cancels unfinished local requests and leaves/requeues durable work. Recovery
credits one unfinished non-expansion attempt without reducing its fencing counters;
expansion-only claims receive no credit. Compose
allows 150 seconds before forced termination. A replacement coordinator must
acquire the original advisory lock before recovering work.

Transport failures, session rejection and unrecognized response envelopes invalidate
the session and HTTP connection pool. Verified court Act-catalogue content errors
and hearing validation errors remain local to their task, retaining a valid session.
Unknown shapes remain errors; only validated `caseNos: []` means an empty search.
After five consecutive source failures (or a throttle response), a shared
cooldown opens. It starts at 60 seconds, doubles on failed recovery probes, and
caps at 1,800 seconds by default. Only one client probes after cooldown; an older
in-flight success cannot close another client's circuit. Recovery requires three
validated business-task successes, spaced 60 seconds apart; one success retains
the existing cooldown level. Deferral consumes no retry budget. Source failures
use a separate durable count and capped delayed retries; record validation keeps
the existing normal attempt limit. Restarting does not erase cooldown/pacing.
See the reliability policy below for migration and operator implications.

## Migration and preparation

1. Review the diff, run CI and build immutable images plus their matching release
   bundle. Confirm the bundle includes migrations `007_scraper_performance.sql`
   and `008_source_reliability.sql`,
   updated role grants and `db/reconcile_scraper.sql`. Do not use new images with
   an old bundle. The API readiness check now requires the new tables/columns.
2. Rehearse on an isolated copy representative of production. Record original
   task counts by kind/status, snapshots, run IDs, retry attempts/bases and pins;
   compare these after upgrade. The checked-in local rehearsal uses synthetic
   rows and a separate 2.5-million-task benchmark, not a copy of production data.
3. Confirm disk headroom for indexes, temporary index builds and WAL. Schedule a
   maintenance window: this is a transactional, locking migration, **not an
   online concurrent index build**. Runtime and disk use on the small EC2 server
   remain unmeasured. Do not infer its duration from a developer laptop.
4. Confirm a recoverable pre-change snapshot/archive for this migration. This is
   a one-time migration safeguard, not an implementation of the previously
   declined scheduled off-server backup service. The existing deploy script
   already creates a pre-deployment database archive; verify it is usable.
5. After approval, use the existing release operator flow in `deploy/README.md`.
   It pulls images first, stops API/worker writes, makes the archive, applies
   migrations/role grants atomically and starts the matching release. **Do not
   cancel the active run through the UI** and do not edit queued task rows.
6. Start with concurrency 1 and preserve the current request spacing, schedule,
   sections and the submitted act scope. Inspect readiness, container health, worker
   heartbeat and the run page. Recovery should requeue only interrupted work;
   existing queued IDs/attempts and completed snapshots must be unchanged.
7. Watch successful case completions, source-error share, queue/checkpoint growth,
   CPU/memory/disk and API latency. A heartbeat or increasing retry count alone
   does not establish successful scraping. Do not retry an entire failed backlog
   during an active source outage. Source cooldown is automatic.

`db/setup_local_db.sh` handles migration reruns and grants. Counters and minute
metrics update in the same database transaction as tasks/results. API and worker
roles can read counters but cannot directly alter them; statement-level trigger
functions have fixed search paths and narrowly scoped definer rights. Snapshots
remain immutable to application roles. Normal first-attempt case starts and
successes no longer add redundant event rows: their durable task timestamps and
immutable snapshots provide the per-case evidence. All previous audit records,
failures/retries, data rejection, cancellation and run lifecycle events remain.

## Reconciliation and rollback

Owner-only `db/reconcile_scraper.sql` rebuilds task/result/checkpoint counters
from their authoritative rows in one transaction. It preserves tasks, results,
minute metric history and `metrics_since`. Stop API/worker writers first, then
run with the database owner's normal connection settings:

```sh
psql -X -v ON_ERROR_STOP=1 --single-transaction -d pcma_db -f db/reconcile_scraper.sql
```

Routine restarts do not need reconciliation. Use it only if a deliberate owner
maintenance operation or a verified discrepancy warrants the full table scan.
The application roles cannot run it. Historical hourly rates cannot be rebuilt
from mutable task rows; they begin at migration/first task activity. Do not
fabricate rates for the preceding eight-hour failure period.

A failed migration rolls back its DDL and counters atomically; keep writers
stopped and fix the migration before starting the new release. This failure path
and migration reruns are tested locally.

**After the new worker has started, do not roll back to a pre-007 worker by
pointing at `previous.env`.** That worker cannot understand deferred expansion
checkpoints, leases or circuit state. Retain migration 007 and its checkpoints;
stop the worker and prefer a corrected, schema-compatible release. Concurrency
can safely be reduced to 1, but an environment edit takes effect only after an
approved restart. No automatic down migration is supplied.

If a pre-007 application rollback is unavoidable, an approved maintenance-only
procedure must first expand every deferred checkpoint into the legacy queue,
with the same task keys and all retries/results preserved, reconcile counters,
and test the old worker on an isolated copy. **That conversion tool is not part
of this release and has not been validated; do not improvise it on production.**
Restoring a pre-change archive is a separate last-resort decision because it
would lose post-archive work. Never drop the new tables as a shortcut.

## Monitoring interpretation

The run detail page uses small transactional counter tables and approximately
60 minute buckets. The runs list batches these reads across the page instead of
recounting each task table for each run. The worker reports its global concurrency,
in-flight count, configured spacing, observed admission spacing (including idle
periods), last request and source cooldown. Observed spacing uses up to five
minutes of heartbeat samples and is unavailable until at least two admissions
have been observed. It is not network latency.

The UI distinguishes successful tasks, successful case details, retries, terminal
failures, last success and source errors divided by task outcomes. This is not a
raw HTTP error rate: bootstrap/retries may produce several HTTP requests per
task. A run with no successful task for 15 minutes is marked stalled even if
retries continue. Heartbeat freshness is separate from successful progress.

The estimate covers **currently admitted case tasks only**. It requires at least
five minutes of observation, ten case completions, a fresh heartbeat and no
current stall/cooldown. Discovery, deferred references, future failures and other
work can add substantial time. It is never a whole-run promised finish time.
Completed runs suppress current worker/cooldown status.

## Scope and capacity decisions still required

Client-approved change on 14 October 2026: monthly scans now select only the
`childmarriage` option, across all states, all sections and both pending/disposed,
on the third Friday at 00:00 Asia/Kolkata. The four client-approved source
names are documented in `backend/app/scraper/config/README.md`. Manual runs
continue to support all eight options. Existing runs keep their submitted scope.
IPC/BNS without section restrictions is deliberately broad. Approved
name mapping resolves each court's act codes; case task identity is the CNR per
run, so overlapping act/section searches deduplicate without removing coverage.
An 87% IPC-origin sample is not proof of a mapping defect. A new live scope audit
was deliberately excluded from this task.

At a three-second minimum spacing, 2,455,506 case requests alone require about
85.3 days even with instantaneous replies and no bootstrap, discovery or retry
requests. Maximum ideal admissions are 1,200/hour or 864,000 per 30 days. SQL and
concurrency improvements cannot make that full workload finish monthly. These
figures describe the old all-eight-act backlog, not an estimate for the
new child-marriage-only scan. Measure the new scope before claiming its duration.

Proposed workflows (design only; no refresh policy implemented):

| Cohort | Possible workflow | Product decision needed |
|---|---|---|
| Initial historical backfill | Complete the full nationwide inventory once, retaining coverage/failure evidence | When backfill is considered complete; handling permanently inaccessible courts |
| Newly discovered cases | Nationwide act searches, fetch every newly seen CNR | Discovery cadence and allowed scope |
| Known pending cases | Refresh full details on an agreed cadence | Required notification freshness |
| Recently disposed cases | Continue refreshing for late hearings/orders | How long after disposal and at what interval |
| User-pinned cases | Priority refresh without suppressing shared coverage | Freshness target and fairness budget |
| Older historical cases | Slower rotating revalidation, preserve stored records | Whether less frequent refresh is acceptable |

Search results do not reliably prove that hearings/orders are unchanged. This
release therefore does not skip a known CNR's detail request merely because it
exists in the database. It only avoids rewriting an unchanged hearing set after
fetching and comparing it. Missed cases are never deleted.

Production deployment, a live canary, any higher upstream rate, additional
coordinator replicas, and any further changes to monthly scope/cadence require
separate approval and validation. The client separately authorized stopping the
old run and clearing scraping data while retaining accounts; this is operator
maintenance, never an automatic migration or application-startup action. The exact upstream cause of the previously observed
malformed responses is not established by these local tests.


## Source reliability policy (migration 008)

This change is implemented and tested locally only. It does not deploy, alter
production data, retry the eight historical content failures, or contact eCourts.
Keep `SCRAPER_REQUEST_INTERVAL=3` and `SCRAPER_CONCURRENCY=1`; application settings
now reject intervals below three seconds. No concurrency default is increased.

### Retry accounting and alerts

`attempts` remains monotonic and continues to fence stale completions alongside
`claim_version`. `source_attempts` counts actual source failures over the lifetime
of the task. Each new source failure credits one `retry_base` offset, so it cannot
consume the normal `SCRAPER_MAX_ATTEMPTS` record-validation budget. Gate deferrals
also credit an offset but do not increment `source_attempts` or count as requests.
Content errors remain bounded by the normal budget; non-transient HTTP statuses
are request errors, while HTTP 405/429/503 retain their throttle classification.
Other 5xx, network errors, session rejection and unreadable envelopes remain source
errors. Unknown envelopes are not proof of transport failure; their classification
is conservative and requires observation if they persist.

Per-task source retry delay is 30, 60, 120, ... seconds, capped at 1,800 seconds,
in addition to global admission/cooldown. An accepted server `Retry-After` can
require a longer shared pause and task delay; it is never shortened to this cap.
Source retry count is not terminal: a
prolonged outage retains work until recovery or an explicit operator cancellation.
This can hold up later runs under the existing oldest-run-first policy. Every
failure remains in task audit history. `source_retry_alert` appears under the
run's audit Errors filter at five source failures (configurable), then at every
20 attempts beyond that threshold, with a warning in worker logs. These are
in-application/log alerts, not email or external monitoring notifications.

### Recovery and failure isolation

The global circuit still opens after five consecutive source failures or an
explicit throttle response. The same durable cooldown level doubles on failed
recovery probes, capped at 1,800 seconds. Only its leased client can report a
successful recovery probe; bootstrap success alone never closes it.

`SCRAPER_RECOVERY_SUCCESSES=3` and `SCRAPER_RECOVERY_INTERVAL_SECONDS=60` require
three validated business-task completions with pauses between them. An intervening
source failure clears partial recovery and escalates the retained level immediately.
A court/hearing validation failure or auxiliary state-catalogue refresh cannot
close the circuit or increase its global failure streak. An inconclusive probe
releases ownership and clears the partial-success count, retaining backoff; another
task may probe at normal global spacing. Extra failures already in flight do not
extend an already-active cooldown. Transitions with a task are saved as
`source_transition` audit events; auxiliary transitions are logged. Cancellation
preserves the existing fencing/lease behavior; an interrupted probe may remain
leased until normal expiry, without admitting multiple probes.

The three hearing failures and five Act-catalogue failures did not retain the raw
alternative response shapes. No speculative parsing aliases, missing dates, blank
Act codes/names or malformed-to-empty conversions are added. Those failures are
now classified as validation errors when that specific invalid content is decoded.
Strict parsing happens before ingestion or child-work staging: saved hearings,
judgment references, pins and earlier snapshots survive a rejected refresh. A
future parser extension needs a verified, privacy-reviewed structural example.

### Compatibility and rollout boundary

Migration 008 adds nonnegative `source_attempts` and `recovery_successes` columns.
It recognizes only historical audit messages matching the existing exact network
failure / transient HTTP message patterns. It credits active queued/running tasks
for verified source failures after the most recent explicit run retry, bounded by
`attempts - retry_base`. Lifetime source counts include earlier cycles; unknown
historical error messages are not credited. Failed/successful/cancelled tasks keep
their status and retry base. No task is automatically requeued by this migration.

Cases, hearing rows, documents, pins, snapshots, payloads, IDs, attempts, current
leases/cooldowns and historical events remain unchanged. The normal transactional
migration runner records version 008 once; reruns do not duplicate credits. Its
legacy audit scan takes a schema lock and has not been timed on the live database.
Use the approved maintenance deployment procedure when separately authorized;
never apply it while production writers run. API readiness requires the new task
column. Keep the schema and worker versions paired. Rolling back to an older
worker would restore the old retry/recovery behavior; prefer a forward fix.

### Privacy-safe diagnostics and unresolved cause

Each naturally occurring request logs its endpoint, intended operation endpoint,
request outcome, status, byte count and elapsed time. Structured diagnostics add:

- Run/task UUID, task type, attempt and numeric state/district/court codes only.
- Random client/session generation IDs and session age, never the actual token.
- TCP-connect, TLS, HTTP/1 header/body/close phase durations and failure phase.
- Allowlisted exception class chains and categories such as EOF before headers,
  incomplete body or malformed status line; no raw exception text.
- Observed HTTP version, allowlisted TLS ALPN, numeric Content-Length/Retry-After
  and restricted Connection/Transfer-Encoding values.
- Opaque connection correlation, age and idle time. TCP starts are attempts;
  only completed TCP traces establish TCP connections. Failed TCP/TLS attempts
  never seed reuse evidence. Reuse on a sequential client without a connect trace
  is explicitly **inferred**.

No URL/query, encrypted params, authorization, cookies, CNR, names, response body,
raw headers or trace callback objects are logged. Synthetic localhost tests cover
EOF before headers, invalid status and partial response bodies with redaction
sentinels. Diagnostics send no requests of their own and do not change connection
pool policy, HTTP version, session lifetime or concurrency.

These observations can distinguish a failure phase and correlation, but cannot
prove which remote server, proxy or network device closed a connection. That
underlying `RemoteProtocolError` cause remains unresolved until naturally occurring
production evidence is available after an approved rollout. No live validation is
claimed. Do not enable blanket HTTPX/httpcore debug logs: they can expose URLs and
headers. Any deeper network capture needs separate approval and privacy review.

Local validation uses synthetic HTTP servers and isolated PostgreSQL with
`FFG_TEST_PG_OWNER`, `FFG_TEST_PG_API` and `FFG_TEST_PG_WORKER` pointed exclusively
at localhost test databases. `bash check.sh` runs backend/PG, deployment and
frontend checks. Tests cover retry budgets, capped delays, one-probe recovery,
cancellation, stale ownership, partial-data preservation, role permissions,
transaction rollback and repeated migrations. They do not establish upstream
availability or production migration duration.


The [17 October reliability review](SCRAPER_RELIABILITY_REVIEW.md) records the
interrupted-attempt, Retry-After and telemetry fixes, migration lock rehearsal,
and the implemented durable quarantine/admin-review mechanism (migration 009).
It requires repeated court-specific failures, fresh same-endpoint success from
another court, and a closed source circuit. Network/5xx outages are never
automatically quarantined. See that report for configuration, operator steps,
role grants, migration precautions and remaining conservative limits.
