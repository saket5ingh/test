"""Check container routing without contacting eCourts or needing real accounts."""
import json
from urllib.error import HTTPError
from urllib.request import urlopen

base = 'http://127.0.0.1:18080'
with urlopen(base + '/api/ready', timeout=10) as response:
    assert json.load(response) == {'status': 'ok'}
with urlopen(base + '/', timeout=10) as response:
    index = response.read()
assert b'<div id="root">' in index
with urlopen(base + '/cases/ci-nested-refresh', timeout=10) as response:
    assert response.read() == index, 'Nested URLs must return the SPA entry point'
for path, expected in [('/api/cases', 401), ('/api/not-a-real-route', 404)]:
    try:
        urlopen(base + path, timeout=10)
    except HTTPError as error:
        assert error.code == expected, (path, error.code)
    else:
        raise AssertionError('API request unexpectedly returned success: ' + path)
print('Container readiness, SPA refresh, API routing and unauthenticated access checks passed.')
