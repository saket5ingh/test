#!/usr/bin/env bash
# Run from an extracted, immutable release bundle. No git pull/build on EC2.
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck source=common.sh
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
[[ $# == 1 ]] || { echo 'Usage: bash deploy/deploy.sh deploy/release.env' >&2; exit 2; }
load_release "$1"
lock_deployment
preflight
stage=preflight
trap 'echo "Deployment failed at stage: $stage. Inspect logs; no automatic schema rollback. Last successful release is unchanged." >&2' ERR

# Download first so a registry failure does not interrupt the running app.
stage=pull
compose pull
stage=database-start
compose up -d --wait --wait-timeout 120 db
stage=pause-writes
compose stop -t 30 api
compose stop -t 150 worker
compose stop frontend caddy
stage=backup
exists="$(compose exec -T db psql -X -U postgres -d postgres -Atc "SELECT 1 FROM pg_database WHERE datname='pcma_db'")"
if [[ "$exists" == 1 ]]; then
  backup_database
elif [[ -f "$FFG_STATE_DIR/current.env" ]]; then
  echo 'Existing deployment database is missing; refusing to initialize an empty replacement' >&2
  exit 1
else
  echo 'First installation: no application database to back up yet.'
fi
stage=migrations
compose run --rm --no-deps db-init
stage=start
compose up -d --no-deps --force-recreate --wait --wait-timeout 300 api worker frontend caddy
stage=https-readiness
curl --fail --silent --show-error --retry 6 --retry-delay 5 --max-time 15 "https://$SITE_DOMAIN/api/ready" \
  | python3 -c 'import json,sys; assert json.load(sys.stdin) == {"status":"ok"}, "Unexpected readiness response"'
curl --fail --silent --show-error --max-time 15 "https://$SITE_DOMAIN/login" >/dev/null
stage=record-release
if [[ -f "$FFG_STATE_DIR/current.env" ]]; then cp "$FFG_STATE_DIR/current.env" "$FFG_STATE_DIR/previous.env"; fi
printf 'FFG_API_IMAGE=%s\nFFG_FRONTEND_IMAGE=%s\nFFG_RELEASE_SHA=%s\n' \
  "$FFG_API_IMAGE" "$FFG_FRONTEND_IMAGE" "$FFG_RELEASE_SHA" > "$FFG_STATE_DIR/current.env.tmp"
mv "$FFG_STATE_DIR/current.env.tmp" "$FFG_STATE_DIR/current.env"
printf '%s\n' "$FFG_BUNDLE_DIR" > "$FFG_STATE_DIR/current-bundle.txt"
echo "Deployed release $FFG_RELEASE_SHA; HTTPS readiness passed."
