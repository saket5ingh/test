#!/usr/bin/env bash
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck source=common.sh
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
[[ $# == 1 ]] || { echo 'Usage: bash deploy/backup.sh deploy/release.env' >&2; exit 2; }
load_release "$1"
lock_deployment
preflight
backup_database
