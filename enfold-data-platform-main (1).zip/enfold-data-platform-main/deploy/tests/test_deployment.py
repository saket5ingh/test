"""Deployment failure paths with a fake Docker executable, never real services."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import pytest

DEPLOY = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('validate_config', DEPLOY / 'validate_config.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def configuration():
    api = 'ghcr.io/test/ffg-backend@sha256:' + 'a' * 64
    return {'services': {
        'db': {'environment': {'POSTGRES_PASSWORD': '1' * 64}},
        'db-init': {'environment': {'FFG_DB_PASSWORD': '2' * 64, 'FFG_WORKER_PASSWORD': '3' * 64}},
        'api': {'image': api, 'environment': {'JWT_SECRET': '4' * 64, 'AUTH_COOKIE_SECURE': 'true', 'SCRAPER_MONTHLY_ENABLED': 'false'}},
        'worker': {'image': api, 'environment': {'SCRAPER_MONTHLY_ENABLED': 'false'}},
        'frontend': {'image': 'ghcr.io/test/ffg-frontend@sha256:' + 'b' * 64},
        'caddy': {'environment': {'SITE_DOMAIN': 'ffg.team.org'}}}}


def test_production_configuration_rejects_unsafe_settings():
    original = configuration()
    assert module.validate(original) == 'ffg.team.org'
    changes = [('db', 'ports', ['5432:5432']), ('api', 'image', 'ghcr.io/test/ffg:latest'),
               ('worker', 'image', 'ghcr.io/test/other@sha256:' + 'c' * 64),
               ('api', 'build', './backend')]
    for service, key, value in changes:
        config = copy.deepcopy(original)
        config['services'][service][key] = value
        with pytest.raises(ValueError): module.validate(config)
    for service, key, value in [('api', 'AUTH_COOKIE_SECURE', 'false'), ('worker', 'SCRAPER_MONTHLY_ENABLED', 'true'),
                                ('api', 'JWT_SECRET', '1' * 64), ('caddy', 'SITE_DOMAIN', 'https://site.org/path')]:
        config = copy.deepcopy(original)
        config['services'][service]['environment'][key] = value
        with pytest.raises(ValueError): module.validate(config)


@pytest.fixture
def operator(tmp_path):
    binaries = tmp_path / 'bin'
    binaries.mkdir()
    (binaries / 'python3').symlink_to(sys.executable)
    config = tmp_path / 'config.json'
    config.write_text(json.dumps(configuration()))
    log = tmp_path / 'commands.log'
    runtime = tmp_path / 'runtime.env'
    runtime.write_text('# Fake Docker supplies the resolved configuration\n')
    release = tmp_path / 'release.env'
    release.write_text('FFG_API_IMAGE=ghcr.io/test/ffg-backend@sha256:' + 'a' * 64 + '\n'
                       'FFG_FRONTEND_IMAGE=ghcr.io/test/ffg-frontend@sha256:' + 'b' * 64 + '\n'
                       'FFG_RELEASE_SHA=' + 'c' * 40 + '\n')
    docker = binaries / 'docker'
    docker.write_text('''#!''' + sys.executable + '''
import json, os, sys
from pathlib import Path
args = sys.argv[1:]
with open(os.environ['COMMAND_LOG'], 'a') as out: out.write(json.dumps(args) + '\\n')
def has(word): return word in args
failure = os.environ.get('FAIL_STEP', '')
if has('config'):
    print(Path(os.environ['FAKE_CONFIG']).read_text())
elif has('pull'):
    sys.exit(1 if failure == 'pull' else 0)
elif has('psql'):
    print('' if os.environ.get('NO_DATABASE') else '1')
elif has('pg_dump'):
    print('synthetic archive')
    sys.exit(1 if failure == 'backup' else 0)
elif has('pg_restore'):
    sys.stdin.buffer.read()
    sys.exit(1 if failure == 'restore' else 0)
elif has('run') and has('db-init'):
    sys.exit(1 if failure == 'migrations' else 0)
''')
    docker.chmod(0o755)
    for name, body in [('flock', 'exit 0'), ('curl', 'test "${FAIL_STEP:-}" != https || exit 1\nprintf \'{"status":"ok"}\\n\'')]:
        path = binaries / name
        path.write_text('#!/bin/sh\n' + body + '\n')
        path.chmod(0o755)
    state = tmp_path / 'state'
    state.mkdir()
    env = {**os.environ, 'PATH': str(binaries) + os.pathsep + os.environ['PATH'],
           'FFG_STATE_DIR': str(state), 'FFG_ENV_FILE': str(runtime),
           'COMMAND_LOG': str(log), 'FAKE_CONFIG': str(config)}
    def run(script='deploy.sh', extra=(), **overrides):
        return subprocess.run(['bash', str(DEPLOY / script), str(release), *extra],
                              env={**env, **overrides}, capture_output=True, text=True)
    return run, state, log, release


def test_deployment_orders_backup_migrations_and_health_before_recording(operator):
    run, state, log, release = operator
    (state / 'current.env').write_text('old release\n')
    result = run()
    assert result.returncode == 0, result.stderr
    commands = [json.loads(line) for line in log.read_text().splitlines()]
    positions = {word: next(i for i, args in enumerate(commands) if word in args)
                 for word in ['pull', 'stop', 'pg_dump', 'run', '--force-recreate']}
    assert positions['pull'] < positions['stop'] < positions['pg_dump'] < positions['run'] < positions['--force-recreate']
    assert (state / 'current.env').read_text() == release.read_text()
    assert (state / 'previous.env').read_text() == 'old release\n'
    assert len(list((state / 'backups').glob('*.dump'))) == 1


@pytest.mark.parametrize('step', ['pull', 'backup', 'migrations', 'https'])
def test_failure_preserves_release_and_blocks_later_steps(operator, step):
    run, state, log, _ = operator
    (state / 'current.env').write_text('old release\n')
    result = run(FAIL_STEP=step)
    assert result.returncode != 0
    assert (state / 'current.env').read_text() == 'old release\n'
    commands = [json.loads(line) for line in log.read_text().splitlines()]
    if step == 'pull': assert not any('stop' in args for args in commands)
    if step == 'backup': assert not any('run' in args for args in commands)
    if step == 'migrations': assert not any('--force-recreate' in args for args in commands)


def test_missing_existing_database_fails_closed(operator):
    run, state, log, _ = operator
    (state / 'current.env').write_text('old release\n')
    assert run(NO_DATABASE='1').returncode != 0
    assert not any('run' in json.loads(line) for line in log.read_text().splitlines())


def test_first_install_can_initialize_new_database(operator):
    run, state, _, _ = operator
    result = run(NO_DATABASE='1')
    assert result.returncode == 0, result.stderr
    assert (state / 'current.env').exists()


def test_release_manifest_is_data_not_shell_code(operator):
    run, state, log, release = operator
    marker = state / 'must-not-exist'
    release.write_text(f'FFG_API_IMAGE=$(touch {marker})\n')
    assert run().returncode != 0
    assert not marker.exists() and not log.exists()


@pytest.mark.parametrize('failure', ['', 'restore'])
def test_restore_drill_only_uses_and_removes_disposable_database(operator, failure):
    run, state, log, _ = operator
    archive = state / 'sample.dump'
    archive.write_text('synthetic archive')
    result = run('restore-drill.sh', (str(archive),), FAIL_STEP=failure)
    assert (result.returncode == 0) == (not failure)
    commands = [json.loads(line) for line in log.read_text().splitlines()]
    created = next(args[-1] for args in commands if 'createdb' in args)
    assert created.startswith('ffg_restore_test_')
    assert next(args[-1] for args in commands if 'dropdb' in args) == created
    restores = [args for args in commands if 'pg_restore' in args]
    assert all('pcma_db' not in args and created in args for args in restores)


def test_production_allows_matching_monthly_enablement():
    config = configuration()
    for service in ('api', 'worker'):
        config['services'][service]['environment']['SCRAPER_MONTHLY_ENABLED'] = 'true'
    assert module.validate(config) == 'ffg.team.org'


@pytest.mark.parametrize('key,value', [('WEEK', '5'), ('WEEKDAY', '7'), ('HOUR', '24'), ('MINUTE', '-1'), ('WEEK', 'abc')])
def test_production_rejects_invalid_schedule(key, value):
    config = configuration()
    config['services']['worker']['environment']['SCRAPER_MONTHLY_' + key] = value
    with pytest.raises(ValueError): module.validate(config)


def test_production_rejects_invalid_timezone():
    config = configuration()
    config['services']['worker']['environment']['SCRAPER_TIMEZONE'] = 'not/a-zone'
    with pytest.raises(ValueError): module.validate(config)


@pytest.mark.parametrize('key,value', [('SCRAPER_MONTHLY_WEEK', '2'), ('SCRAPER_TIMEZONE', 'UTC')])
def test_production_rejects_api_worker_calendar_drift(key, value):
    config = configuration()
    config['services']['worker']['environment'][key] = value
    with pytest.raises(ValueError, match='calendar settings must match'):
        module.validate(config)
    config['services']['api']['environment'][key] = value
    assert module.validate(config) == 'ffg.team.org'


@pytest.mark.parametrize('key,value', [('SCRAPER_CONCURRENCY','9'),('SCRAPER_SHUTDOWN_SECONDS','151'),
    ('SCRAPER_QUEUE_HIGH_WATER','0'),('SCRAPER_REQUEST_INTERVAL','2'),('SCRAPER_INSERT_BATCH','5000')])
def test_invalid_performance_configuration_is_rejected(key,value):
    config=configuration(); config['services']['worker']['environment'][key]=value
    with pytest.raises(ValueError): module.validate(config)


def test_replica_scaling_is_not_authorized_by_bounded_concurrency():
    config=configuration(); config['services']['worker']['deploy']={'replicas':2}
    with pytest.raises(ValueError): module.validate(config)
