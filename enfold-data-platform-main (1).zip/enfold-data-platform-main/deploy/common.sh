#!/usr/bin/env bash
# Shared by operator scripts. Never source runtime .env files as shell code.
set -euo pipefail
umask 077
FFG_BUNDLE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
FFG_STATE_DIR="${FFG_STATE_DIR:-/opt/ffg/state}"
FFG_ENV_FILE="${FFG_ENV_FILE:-/opt/ffg/shared/ffg.env}"

load_release() {
  local release="${1:?Supply the matching release.env manifest}"
  [[ -f "$release" && -f "$FFG_ENV_FILE" ]] || { echo 'Missing release manifest or runtime env file' >&2; return 1; }
  # Read only three strictly validated assignments, never evaluate shell content.
  local assignments
  assignments="$(python3 - "$release" <<'PY'
import re, sys
from pathlib import Path
values = {}
for line in Path(sys.argv[1]).read_text().splitlines():
    if not line.strip() or line.startswith('#'): continue
    key, sep, value = line.partition('=')
    if not sep or key in values: sys.exit('Invalid release manifest')
    values[key] = value
if set(values) != {'FFG_API_IMAGE', 'FFG_FRONTEND_IMAGE', 'FFG_RELEASE_SHA'}:
    sys.exit('Invalid release keys')
for key, value in values.items():
    pattern = r'[a-f0-9]{40}' if key == 'FFG_RELEASE_SHA' else r'ghcr\.io/[a-z0-9._/-]+@sha256:[a-f0-9]{64}'
    if not re.fullmatch(pattern, value): sys.exit('Invalid release value')
    print(key + '=' + value)
PY
)"
  while IFS='=' read -r key value; do export "$key=$value"; done <<< "$assignments"
}

compose() {
  docker compose --project-name enfold-ffg-production --env-file "$FFG_ENV_FILE" \
    --project-directory "$FFG_BUNDLE_DIR" -f "$FFG_BUNDLE_DIR/compose.production.yml" "$@"
}

lock_deployment() {
  mkdir -p "$FFG_STATE_DIR/backups"
  exec 9>"$FFG_STATE_DIR/deploy.lock"
  flock -n 9 || { echo 'Another deployment/backup/restore drill is active' >&2; exit 1; }
}

preflight() {
  command -v docker >/dev/null
  command -v python3 >/dev/null
  command -v flock >/dev/null
  SITE_DOMAIN="$(compose config --format json | python3 "$FFG_BUNDLE_DIR/deploy/validate_config.py")"
  export SITE_DOMAIN
}

backup_database() {
  local dest
  dest="$FFG_STATE_DIR/backups/$(date -u +%Y%m%dT%H%M%SZ)-${FFG_RELEASE_SHA:0:12}.dump"
  [[ ! -e "$dest" ]] || { echo 'Backup filename already exists' >&2; return 1; }
  if ! compose exec -T db pg_dump -U postgres -d pcma_db --format=custom --no-owner --no-privileges > "$dest.partial"; then
    rm -f -- "$dest.partial"
    echo 'Database backup failed; deployment stopped' >&2
    return 1
  fi
  compose exec -T db pg_restore --list < "$dest.partial" >/dev/null
  mv -- "$dest.partial" "$dest"
  echo "$dest"
}
