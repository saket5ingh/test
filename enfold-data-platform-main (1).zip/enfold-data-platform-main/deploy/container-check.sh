#!/usr/bin/env bash
# CI-only isolated containers. Does not start the worker or contact eCourts.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
export FFG_API_IMAGE=ffg-backend:ci FFG_FRONTEND_IMAGE=ffg-frontend:ci
export POSTGRES_PASSWORD=ci-container-owner FFG_DB_PASSWORD=ci-container-app FFG_WORKER_PASSWORD=ci-container-worker
export JWT_SECRET=ci-container-jwt-secret-at-least-32-characters
export SITE_DOMAIN=ffg-ci.invalid ACME_EMAIL=ci@ffg-ci.invalid
compose() {
  docker compose --project-name ffg-ci --env-file /dev/null -f compose.production.yml -f deploy/compose.ci.yml "$@"
}
cleanup() {
  local result=$?
  if [[ $result != 0 ]]; then compose logs --no-color --tail=80 api frontend db-init; fi
  # Only this uniquely named disposable CI project is removed.
  compose down --volumes --remove-orphans
  exit "$result"
}
trap cleanup EXIT
compose config --quiet
docker run --rm -v "$PWD/deploy/Caddyfile:/etc/caddy/Caddyfile:ro" \
  -e SITE_DOMAIN -e ACME_EMAIL caddy:2 caddy validate --config /etc/caddy/Caddyfile
compose up -d --wait --wait-timeout 180 api frontend
python deploy/smoke.py
