"""Validate resolved Compose configuration without printing runtime secrets."""
import json
import re
import sys
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def validate(config):
    services = config['services']
    if set(services) != {'db', 'db-init', 'api', 'worker', 'frontend', 'caddy'}:
        raise ValueError('Unexpected production services')
    domain = services['caddy']['environment']['SITE_DOMAIN']
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}', domain):
        raise ValueError('SITE_DOMAIN must be a DNS hostname without a URL/path')
    if domain.endswith(('.example.org', '.example.com', '.example.net')):
        raise ValueError('Replace the example domain before deployment')
    secrets = [services['db']['environment']['POSTGRES_PASSWORD'],
               services['db-init']['environment']['FFG_DB_PASSWORD'],
               services['db-init']['environment']['FFG_WORKER_PASSWORD'],
               services['api']['environment']['JWT_SECRET']]
    if any(not re.fullmatch(r'[0-9a-fA-F]{64}', value) for value in secrets):
        raise ValueError('Use four independently generated 64-character hexadecimal secrets')
    if len(set(secrets)) != 4:
        raise ValueError('Production secrets must be distinct')
    for name, service in services.items():
        if name != 'caddy' and service.get('ports'):
            raise ValueError('Only Caddy may publish host ports')
        if service.get('build'):
            raise ValueError('Production must pull release images, not build on EC2')
    for name in ('api', 'worker', 'frontend'):
        if not re.fullmatch(r'ghcr\.io/[a-z0-9._/-]+@sha256:[a-f0-9]{64}', services[name]['image']):
            raise ValueError('Application images must use immutable GHCR digests')
    if services['worker']['image'] != services['api']['image']:
        raise ValueError('API and worker must run the same release')
    if services['api']['environment']['AUTH_COOKIE_SECURE'] != 'true':
        raise ValueError('HTTPS authentication cookies are required')
    enabled = [services[name]['environment']['SCRAPER_MONTHLY_ENABLED'] for name in ('api', 'worker')]
    if enabled[0] not in ('true', 'false') or enabled[0] != enabled[1]:
        raise ValueError('API and worker monthly enablement must match')
    worker = services['worker']['environment']
    for key, default, lower, upper in [('WEEK', 3, 1, 4), ('WEEKDAY', 4, 0, 6), ('HOUR', 0, 0, 23), ('MINUTE', 0, 0, 59)]:
        if not lower <= int(worker.get('SCRAPER_MONTHLY_' + key, default)) <= upper:
            raise ValueError('Invalid monthly schedule')
    for key,default,lower,upper in [
        ('CONCURRENCY',1,1,8),('LEASE_SECONDS',600,180,3600),('SHUTDOWN_SECONDS',30,1,120),
        ('QUEUE_HIGH_WATER',10000,10,100000),('INSERT_BATCH',500,1,1000),
        ('SOURCE_FAILURE_THRESHOLD',5,1,100),('SOURCE_COOLDOWN_SECONDS',60,1,1800),
        ('SOURCE_MAX_COOLDOWN_SECONDS',1800,60,86400),('STALL_SECONDS',900,60,86400)]:
        if not lower<=int(worker.get('SCRAPER_'+key,default))<=upper:
            raise ValueError('Invalid scraper performance setting')
    if float(worker.get('SCRAPER_REQUEST_INTERVAL',3))<3:
        raise ValueError('Do not reduce the established production request interval')
    if int(services['worker'].get('deploy',{}).get('replicas',1))!=1:
        raise ValueError('Only one scraper coordinator is supported')
    if int(worker.get('SCRAPER_SOURCE_MAX_COOLDOWN_SECONDS',1800))<int(worker.get('SCRAPER_SOURCE_COOLDOWN_SECONDS',60)):
        raise ValueError('Maximum cooldown must cover initial cooldown')
    api = services['api']['environment']
    for key, default in [('SCRAPER_MONTHLY_WEEK', '3'), ('SCRAPER_MONTHLY_WEEKDAY', '4'), ('SCRAPER_MONTHLY_HOUR', '0'), ('SCRAPER_MONTHLY_MINUTE', '0'), ('SCRAPER_TIMEZONE', 'Asia/Kolkata')]:
        if str(api.get(key, default)) != str(worker.get(key, default)):
            raise ValueError('API and worker calendar settings must match')
    try: ZoneInfo(worker.get('SCRAPER_TIMEZONE', 'Asia/Kolkata'))
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise ValueError('Invalid scraper timezone') from error
    return domain


if __name__ == '__main__':
    try:
        print(validate(json.load(sys.stdin)))
    except (ValueError, KeyError, TypeError):
        # Config contains passwords; never echo it or exception values.
        sys.exit('Invalid production configuration; check deploy/README.md requirements')
