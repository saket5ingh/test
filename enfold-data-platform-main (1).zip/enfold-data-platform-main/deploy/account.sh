#!/usr/bin/env bash
# Interactive account provisioning/reset using a short-lived owner connection.
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck source=common.sh
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
[[ $# -ge 2 ]] || { echo 'Usage: bash deploy/account.sh deploy/release.env create|reset [user-id]' >&2; exit 2; }
load_release "$1"
action="$2"
shift 2
case "$action" in
  create) [[ $# == 0 ]] || exit 2; module=app.create_user ;;
  reset) [[ $# == 1 ]] || exit 2; module=app.reset_password ;;
  *) echo 'Use create or reset' >&2; exit 2 ;;
esac
lock_deployment
preflight
owner_password="$(compose exec -T db printenv POSTGRES_PASSWORD)"
export DATABASE_URL="postgresql+asyncpg://postgres:${owner_password}@db:5432/pcma_db"
unset owner_password
compose run --rm --no-deps -e DATABASE_URL api python -m "$module" "$@"
