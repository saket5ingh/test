#!/usr/bin/env bash
# Restore into a NEW disposable database; never overwrite pcma_db.
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck source=common.sh
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
[[ $# == 2 && -f "$2" ]] || { echo 'Usage: bash deploy/restore-drill.sh deploy/release.env backup.dump' >&2; exit 2; }
load_release "$1"
lock_deployment
preflight
drill_db="ffg_restore_test_$(date -u +%Y%m%d%H%M%S)_$$"
compose exec -T db createdb -U postgres "$drill_db"
trap 'compose exec -T db dropdb -U postgres "$drill_db"' EXIT
compose exec -T db pg_restore -U postgres -d "$drill_db" --exit-on-error --single-transaction --no-owner --no-privileges < "$2"
compose exec -T db psql -X -U postgres -d "$drill_db" -v ON_ERROR_STOP=1 \
  -c 'SELECT count(*) AS cases FROM pcma.cases' \
  -c 'SELECT count(*) AS snapshots FROM pcma.scrape_run_cases' \
  -c 'SELECT count(*) AS pins FROM pcma.case_pins'
echo 'Restore drill passed; disposable database will be removed.'
