# Final-judgment downloads

Deploy a tested release containing migration 006 before using this feature.
Both authenticated admins and field officers can download source final orders.
This permission includes the PDF's original contents; existing restrictions on
case JSON fields remain unchanged. No source document identifiers or generated eCourts
URLs are included in the case API or historical run snapshots.

The worker captures `finalOrder` references during case ingestion. An order with
no uploaded filename is unavailable; disposed status alone is not evidence of a
judgment. Multiple final orders are shown separately with dates. Interim orders
are excluded. References are deduplicated by case and court-scoped source path,
and a subsequent scrape missing an order does not delete it.

Downloads resolve a fresh eCourts URL using a fresh session. The API accepts only
HTTPS URLs on `app.ecourts.gov.in` or `csc.ecourts.gov.in`, follows no redirects,
verifies the PDF signature, and limits each download to 20 MiB and 60 seconds.
At most two downloads run concurrently per API process. PDF bytes are held only
in memory for the response, never saved to disk or PostgreSQL. Source failures
return a retryable error, without leaking identifiers or tokens. eCourts
availability and permanent retention are not guaranteed.

## Existing cases

Existing cases have no references until refreshed or backfilled. After deployment,
from the matching release bundle and with its release manifest:

```sh
source deploy/common.sh
load_release deploy/release.env
compose run --rm --no-deps worker python -m app.scraper.backfill_documents --limit 100
```

This uses the worker role and pacing, selecting up to 100 unchecked disposed
cases with successful saved case-task scopes. Repeat batches until none remain.
Run during low scraping load: backfill and the worker share the server's eCourts
IP limit. Failed cases remain eligible for retry; successful empty discoveries
are marked checked. To check an existing case again after a later upload:

```sh
compose run --rm --no-deps worker python -m app.scraper.backfill_documents --case-id CASE_UUID --limit 1
```

Backfill adds document references only; it does not change pins, hearings, run
snapshots or case status. It does not fetch PDF files. Historical snapshots/CSV
remain unchanged. This command is an explicit operator step, not a deploy hook.
