# Reliability review follow-up — 17 October 2026

Local changes on `feature/scraper-source-reliability`, based on commit `53153a8`.
No production inspection, upstream traffic, deployment, push or merge was performed
for this follow-up. The review below distinguishes reproduced behavior from
hypothetical upstream scenarios. The global interval stays three seconds and
concurrency stays one.

## Findings and disposition

| Finding | Classification | Disposition |
| --- | --- | --- |
| Persistent `response` / `rejected` errors retry indefinitely and block later runs | Confirmed operational risk in the intentional unlimited-source-retry policy | Reproduced locally; evidence-gated quarantine and authenticated operator review now implemented (section 1). Source-wide outages remain delayed retries. |
| Interrupted claims consume normal validation budget | Confirmed defect | Fixed in `worker.recover()`. |
| HTTP 401/403 never refresh credentials | False for the current client | Session is invalidated; the next durable attempt bootstraps a fresh token. Bounded request-error classification retained. |
| HTTP 401/403 always mean a transient session fault | Unverified upstream hypothesis | No evidence justifies unlimited auth retries or treating all forbidden responses as source-wide outages. |
| `Retry-After` is ignored | Confirmed implementation gap; live incidence unknown | Accepted hints now govern both task availability and durable shared pause. |
| TCP attempt is recorded as connected / reusable | Confirmed telemetry defect | Separate attempted TCP from completed TCP and later HTTP use; failed attempts cannot seed reuse inference. |
| Validation during partial recovery clears provisional successes | Intentional conservative policy | Documented and tested; unchanged. |
| Migration 008 is safe to run alongside normal traffic | Incorrect operational assumption | Requires maintenance: its schema locks block readers/writers. Local rollback, lock contention, rerun and preservation tests pass. |

## 1. Durable quarantine and operator review (implemented locally)

Previously, all `response` / `rejected` failures retried indefinitely. The oldest
active run could therefore prevent subsequent monthly runs from starting. The
existing no-recovery-evidence reproduction remains a deliberate safety test.

Migration **009_operator_review.sql** adds review counters, cycle start/session,
review-required flag/reason/time/evidence, and `source_validated_at`. It never
quarantines or requeues historical tasks automatically. No cases, snapshots,
task identities, attempts, retry credits, leases, staged references or events are
rewritten. Old tasks have no inferred validation timestamp.

Automatic quarantine requires **all** of:

- `response` or `rejected` at the expected business endpoint: Act discovery
  (`actWebService.php`), search (`searchByActWebService.php`) or case details
  (`caseHistoryWebService.php`), with numeric state/district/court identity and
  an opaque session-generation UUID. Bootstrap and unknown provenance are excluded.
- Configured persistence thresholds, within the current operator-review cycle:

  | Variable | Default | Meaning |
  | --- | --- | --- |
  | `SCRAPER_QUARANTINE_FAILURES` | 5 | Completed eligible failures |
  | `SCRAPER_QUARANTINE_MIN_SECONDS` | 21600 | At least six hours since the first eligible failure |
  | `SCRAPER_QUARANTINE_SESSIONS` | 2 | Different fresh session generations observed |
  | `SCRAPER_QUARANTINE_RECOVERY_SECONDS` | 900 | Recovery evidence must be at most fifteen minutes old |

- The global circuit is fully closed; an expired cooldown or partial recovery
  is insufficient. An error carrying a positive `Retry-After` is excluded.
- Another court in the **same run** completed the same task type successfully,
  validated its source response after this failure cycle began, and did so
  within the evidence window. Bootstrap success and a different endpoint cannot
  establish that recovery. `source_validated_at` is recorded only on real task
  validation, never refreshed by checkpoint-only draining. Recent completion of
  old staged work therefore cannot masquerade as source recovery.

Thresholds are conservative operational defaults, not proven properties of the
upstream service. They are configurable in both Compose files and environment
examples. Three-second request pacing, concurrency one, source backoff and the
PCMA/CMRA monthly scope are unchanged. Evidence uses existing natural work; no
extra source probes or traffic are introduced.

Qualified tasks become **failed + review_required**, retaining the original
classification and all lifetime attempt counters. They remain visible as failed
coverage, not successful empty courts. `operator_review_required` stores the
reason, counts, court codes and successful evidence-task reference/time. The
court-isolated error does not escalate the global source circuit, while source
failure accounting is retained. All other failure policies remain unchanged.

Runs with saved cases finish `partial`, or `failed` with no saved results, after
other work drains. Quarantined tasks are no longer pending and do not block later
monthly runs. Future runs generate their own work and may discover that court
again; no permanent blacklist is created.

**Admin workflow:** open a run, select **View quarantined tasks** (or Failures →
Task status → Needs review), inspect location, operation, attempts, error and
recovery evidence, then **Review and retry task**. Supply a review reason and
confirm. `POST /api/scrapes/runs/{run}/tasks/{task}/review-retry` requires an
authenticated administrator. Anonymous and field-officer access is rejected.
The review checks current state under run/task row locks, records the actor,
reason and previous evidence/counters, and requeues **only that task**. Concurrent
requests cannot create duplicate review actions. Ordinary bulk retry excludes
quarantined tasks. Cancellation with in-flight work must finish before review.

Review opens a fresh per-task review cycle and ordinary retry allowance while
preserving `attempts`, `source_attempts`, claim fencing, old evidence and all
history. It does not clear source cooldowns or change pacing. Replaying a case
still uses existing CNR uniqueness and immutable run snapshots. Explicitly
reopening an older run makes it eligible under the existing oldest-run policy;
operators should expect it to take precedence over newer queued work.

**Conservative limits:** persistent global outages, bootstrap failures, a final
isolated task with no recent other-court success, or a repeatedly inconclusive
half-open probe remain delayed retries and can still hold an active run. They
are not automatically labelled court-specific or quarantined. Existing source
retry alerts/cooldown displays remain the operator signal. Investigate and make
any cancellation/retry decision separately; this feature cannot prove the cause
of `RemoteProtocolError` or guarantee unattended completion during an outage.

Migration 009 was rehearsed from schema 008 with **13,001 synthetic tasks**, a
saved case/snapshot plus pin, hearing and document, source control, audit history,
and **1,000 staged references**. Checks cover lock contention, forced transaction
rollback, exact preservation of existing columns/data, zero inferred historical
review state, index definitions, invalid-state constraints and idempotent reruns.
Migration 008's larger preservation rehearsal remains in the suite below.

Deployment requires the existing maintenance procedure: stop writers, apply the
full migration chain **and updated role grants**, then start the matching API and
worker images. Schema locking/index creation can delay readers; production timing
is unmeasured. Readiness now requires the new columns. Transaction rollback is
tested; rolling back application binaries after creating quarantined tasks is
**not** equivalent—older bulk-retry code does not know this review policy. Retain
the new schema and use a reviewed forward fix or explicitly assess compatibility.
No such deployment or rollback was performed here.

## 2. Interrupted claims

Before the fix, all three PostgreSQL reproduction modes failed with
`(attempts,retry_base,source_attempts,claim_version) = (1,0,0,1)` where the unused
ordinary budget required `(1,1,0,1)`:

- shutdown recovery;
- expired-lease recovery;
- coordinator replacement.

`recover()` now credits one unused attempt only on a running, non-expanding task
with remaining spent budget. Its status transition and audit insert are atomic.
A second recovery cannot credit again because the task is already queued. It
never decrements `attempts` or `claim_version`, and ownership/lease checks still
reject stale completions. Expansion-only claims get no credit because they do
not increment request attempts. The real pool shutdown test also checks the
refunded budget after cancelling a hanging synthetic request.

Historical `task_recovered` events do not reliably establish whether work was
expanding at that time. They are not retroactively credited by migration 008.
Existing historical rows and event text remain unchanged. The fix covers future
recovery, including an in-flight legacy claim recovered after an approved upgrade.

## 3. HTTP status and server delay

401/403 still invalidate the token/HTTP pool and consume a normal bounded request
attempt. Tests observe exactly one bootstrap and one business request per attempt,
with a fresh session on the next attempt and no hidden immediate retry. There is
no new live evidence that those statuses explain the original disconnects.

`Retry-After` accepts integer seconds or a timezone-aware HTTP date. Past dates
and zero do not defeat normal pacing; malformed, overlong or driver-unrepresentable
values fall back to normal policy. Accepted delays are never shortened to the
1,800-second local backoff cap. They persist in `available_at` and shared
`paused_until`, including for request-specific 4xx responses. Existing longer
cooldowns survive shorter hints. A new hint revokes an older in-flight probe's
ability to shorten the pause. These changes use existing columns, with no new
migration. A hint received in headers survives a subsequently truncated error
body. Global three-second pacing still applies after the pause.

Very long accepted hints can cause prolonged pauses; they are visible in the
run's existing cooldown display and transition audit. They are not evidence of
successful scraping. The local tests establish implementation behavior, not
whether eCourts currently returns such a header or whether it caused any live
stall. External alert delivery remains outside this work.

## 4. Connection telemetry

`connection_attempt_id` and `tcp_attempt` are emitted on TCP start;
`connection_id`, `tcp_established=true` and `tcp_connected` only follow the
completion trace. TCP completion does not claim TLS success. A future reuse
candidate is retained only after reaching HTTP, and failures clear it. Tests
cover TCP failure and TLS failure as well as the existing real localhost
HTTP/1 tests. Connection reuse without a new connect trace remains explicitly
inferred, not socket-level proof. No raw headers, exception text, tokens or case
identifiers were added to logs. The remote disconnect cause remains unknown.

## 5. Validation during partial recovery

One success begins partial recovery. A subsequent validation/request-content
failure owned by the probe releases that probe and clears `recovery_successes`.
It leaves `cooldown_level`, `failure_streak` and the expired pause deadline
unchanged. Another task may probe at the global pace; recovery requires a new
sequence of three validated business successes. Validation does not increase
source failure metrics or escalate cooldown. Tests assert these exact state
transitions for both validation and request errors. No policy change was made.
An explicit server `Retry-After` is a separate reason to extend a pause.

## 6. Migration 008 rehearsal

Unchanged migration SQL was exercised against an isolated PostgreSQL 16 database
seeded at schema 007 with **13,009 tasks, 821 cases/snapshots, and 1,000 staged
references**, plus hearings, a document, pin, audit events and persisted source
control. This is representative synthetic workload shape/volume, not a production
clone or a claim about the live database's current size or migration time.

Checks passed:

- a held read transaction blocks the required schema lock; a short rehearsal
  lock timeout fails cleanly;
- uncommitted migration DDL blocks both reads and writes;
- forced failure rolls back DDL and retry credits atomically;
- queued/running tasks receive only verified transport/HTTP credits within the
  current explicit retry cycle, bounded by their spent budget;
- terminal statuses, IDs, attempts, payloads, leases, source cooldown and
  historical audit rows remain unchanged;
- cases, hearings, documents, pins, immutable snapshots, all staged references
  and derived counters survive unchanged;
- a second complete migration run does not apply credits again;
- negative new counters remain rejected.

Stop writers and use the existing maintenance deployment procedure only after
approval. Investigate long-lived readers before migration. Production lock
waits, WAL/disk consumption and execution time have not been measured here.

## Earlier review fixes retained in this follow-up

Runtime:
- `backend/app/scraper/worker.py`: interruption refunds; Retry-After task deadline;
  accurate alert wording.
- `backend/app/scraper/client.py`: safe Retry-After parsing, propagation including
  interrupted error bodies.
- `backend/app/scraper/control.py`: shared deadline, stale-probe invalidation and
  audit transition.
- `backend/app/scraper/diagnostics.py`: TCP attempt/connection distinction.

Tests:
- `backend/tests/test_reliability_review_postgres.py` (new): interruption modes,
  fencing, expansion accounting, partial recovery, retry deadlines and explicit
  reproduction of the retained indefinite-response risk.
- `backend/tests/test_reliability_review_http.py` (new): 401/403 sequence, header
  parser, header propagation, incomplete response bodies, TCP/TLS trace failures.
- `backend/tests/test_scraper_performance_postgres.py`: real pool shutdown budget.
- `backend/tests/test_source_diagnostics.py`: corrected connection evidence label.
- `backend/tests/test_source_reliability_migration.py`: representative volume,
  populated staged work and actual lock contention.

Documentation:
- `deploy/SCRAPER_PERFORMANCE.md`: updated operator semantics and review link.
- `deploy/SCRAPER_RELIABILITY_REVIEW.md`: this classification/report and implemented quarantine policy.

## Quarantine implementation files

- `backend/app/scraper/quarantine.py` (new): durable eligibility and evidence checks.
- `backend/app/scraper/client.py`: safe endpoint/session provenance on errors.
- `backend/app/scraper/worker.py`: fenced quarantine, audit and validation timestamps.
- `backend/app/routes/scrapes.py`: summary/filter fields, admin selected-task retry,
  authenticated role checks and exclusion from bulk retry.
- `backend/app/scraper/monitor.py`: review-required totals.
- `backend/app/models/scraper.py`, `backend/app/main.py`: model/readiness alignment.
- `db/migrations/009_operator_review.sql` (new), `db/migrate.sql`,
  `db/setup_local_db.sh`: additive schema/indexes and narrowly extended API grants.
- `backend/app/config.py`, `.env.example`, `deploy/production.env.example`,
  `compose.yml`, `compose.production.yml`: configurable conservative defaults.
- `frontend/src/pages/AdminRunDetailPage.tsx` and `.module.css`: incomplete-coverage
  banner, task filter, evidence display and reasoned retry form.
- `frontend/src/services/scrapeService.ts`, `frontend/src/types/scraper.ts`:
  authenticated API contract and response types.
- `backend/tests/test_quarantine_postgres.py` (new): eligibility boundaries across
  all three endpoints, preserved records, future scheduling, real API/worker role
  permissions, cancellation, stale lease/coordinator fencing and concurrent review.
- `backend/tests/test_operator_review_migration.py` (new): migration 009 rehearsal.
- `backend/tests/test_reliability_review_http.py`: mocked provenance across fresh
  sessions; no token/content disclosure or hidden requests.
- `backend/tests/test_scraper_performance_postgres.py`: checkpoint timestamp stability.
- `backend/tests/test_scraper_migration.py`,
  `backend/tests/test_source_reliability_migration.py`: additive-column compatibility.
- `frontend/src/pages/AdminRunDetailPage.test.tsx`,
  `frontend/src/services/scrapeService.test.ts`: filter, reason validation, selected
  retry, error handling, accessibility and request contract.
- `deploy/SCRAPER_PERFORMANCE.md`, this report: operator policy and rollout limits.

## Verification and merge assessment

`bash check.sh` passed with all three isolated PostgreSQL role URLs supplied:
**313 backend tests, 26 deployment-tooling tests, 115 frontend tests**. No tests
were skipped. TypeScript checking, frontend lint/build and shell syntax passed;
`git diff --check` passed. The existing Starlette/AnyIO deprecation warning remains.
All source traffic in tests is synthetic; PostgreSQL is isolated on localhost.

The implementation is ready for code review and merge approval based on these
local checks. Prior retry, fencing, diagnostics and circuit-recovery fixes remain
covered. Deployment still needs its own approval and coordinated migration/grants;
live acceptance and production lock duration are not established by this suite.
The upstream disconnect cause and production migration timings remain unverified.
No changes were committed, pushed, merged, deployed or applied to production.
