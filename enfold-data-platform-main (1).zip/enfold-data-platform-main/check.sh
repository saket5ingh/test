#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
python -m pytest backend/tests -q -p no:cacheprovider
python -m pytest deploy/tests -q -p no:cacheprovider
npm --prefix frontend run typecheck
npm --prefix frontend test
npm --prefix frontend run lint
npm --prefix frontend run build
bash -n db/setup_local_db.sh
for script in deploy/*.sh; do bash -n "$script"; done
