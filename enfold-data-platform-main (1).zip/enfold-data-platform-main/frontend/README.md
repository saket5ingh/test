# FFG frontend

See [the FFG runbook](../README.md) for database, backend and deployment setup.

Use Node 24, then `npm ci` and `npm run dev`. The development server proxies
`/api` to the FastAPI server on port 8000. API mode is the default. Set
`VITE_USE_MOCK=true` only for an explicit local UI demonstration.

Checks: `npm run typecheck`, `npm test`, `npm run lint`, `npm run build`.
