import type { RunCriteria, ScraperRun, ScraperOptions, Page, RunSnapshot, RunEvent, RunTask } from '@/types/scraper'
import { API_BASE_URL, USE_MOCK } from './config'
import { request, tokenStore, ApiError } from './http'
import { CUSTOM_SCRAPES } from './mock/customScrapes.mock'
import { ACT_OPTIONS } from '@/lib/caseMetadata'

const demoRuns: ScraperRun[] = CUSTOM_SCRAPES.map((r) => ({ id: r.id, name: r.name, criteria: null,
  resolvedScope: null, trigger: 'manual', triggeredBy: r.triggeredBy, queuedAt: r.ranAt, startedAt: r.ranAt,
  completedAt: r.ranAt, outcome: r.outcome, tasks: {}, counts: {}, total: r.count,
  coverage: [], snapshotsAvailable: false, error: null, cancelRequested: false,
  legacyCriteria: { state: r.state, acts: r.acts, sections: r.sections, status: r.status } }))

export interface RunListFilters { pageSize?: number; q?: string; outcome?: ScraperRun['outcome'] | 'all'; trigger?: ScraperRun['trigger'] | 'all' }
export interface RunFilters { pageSize?: number; q?: string; state?: string; status?: string; change_kind?: string; kind?: string }
function query(page: number, filters: RunFilters | RunListFilters = {}) {
  const params = new URLSearchParams({ page: String(page) })
  Object.entries(filters).forEach(([key, value]) => { if (value !== undefined && value !== '') params.set(key, String(value)) })
  return params.toString()
}

export const scrapeService = {
  reviewRetry(id: string, taskId: string, reason: string): Promise<{ id: string }> {
    if (USE_MOCK) return Promise.reject(new Error('Operator review requires API mode.'))
    return request(`/scrapes/runs/${encodeURIComponent(id)}/tasks/${encodeURIComponent(taskId)}/review-retry`, { method: 'POST', body: JSON.stringify({ reason }) })
  },
  async options(signal?: AbortSignal): Promise<ScraperOptions> {
    if (USE_MOCK) return { states: [], acts: ACT_OPTIONS.map(({ key, label }) => ({ key, label })), statesUpdatedAt: null, workerLastSeen: null, workerHealthy: false, monthlyEnabled: false }
    return request('/scrapes/options', { signal })
  },
  async runScrape(form: RunCriteria & { name: string; requestId: string }): Promise<{ id: string }> {
    if (USE_MOCK) throw new Error('Live scraping requires API mode and the scraper worker.')
    return request('/scrapes/run', { method: 'POST', body: JSON.stringify(form) })
  },
  async listRunPage(page = 1, signal?: AbortSignal, filters: RunListFilters = {}): Promise<Page<ScraperRun>> {
    if (USE_MOCK) {
      const matching = demoRuns.filter((run) => (!filters.q || run.name.toLowerCase().includes(filters.q.trim().toLowerCase()))
        && (!filters.outcome || filters.outcome === 'all' || run.outcome === filters.outcome)
        && (!filters.trigger || filters.trigger === 'all' || run.trigger === filters.trigger))
      const pageSize = filters.pageSize ?? 25
      return { items: matching.slice((page - 1) * pageSize, page * pageSize), total: matching.length, page, pageSize }
    }
    return request(`/scrapes/runs?${query(page, filters)}`, { signal })
  },
  async listRuns(): Promise<ScraperRun[]> { return (await this.listRunPage()).items },
  async getRun(id: string, signal?: AbortSignal): Promise<ScraperRun> {
    if (USE_MOCK) { const run = demoRuns.find((r) => r.id === id); if (run) return run; throw new Error('Run not found') }
    return request(`/scrapes/runs/${encodeURIComponent(id)}`, { signal })
  },
  results(id: string, page: number, signal?: AbortSignal, filters: RunFilters = {}): Promise<Page<RunSnapshot>> {
    return request(`/scrapes/runs/${encodeURIComponent(id)}/results?${query(page, filters)}`, { signal })
  },
  events(id: string, page: number, signal?: AbortSignal, filters: RunFilters = {}): Promise<Page<RunEvent>> {
    if (USE_MOCK) return Promise.resolve({ items: [], total: 0, page: 1, pageSize: 50 })
    return request(`/scrapes/runs/${encodeURIComponent(id)}/events?${query(page, filters)}`, { signal })
  },
  tasks(id: string, page: number, status: string, signal?: AbortSignal, filters: RunFilters = {}): Promise<Page<RunTask>> {
    return request(`/scrapes/runs/${encodeURIComponent(id)}/tasks?${query(page, { ...filters, status })}`, { signal })
  },
  cancel(id: string) { return request(`/scrapes/runs/${encodeURIComponent(id)}/cancel`, { method: 'POST' }) },
  retry(id: string) { return request(`/scrapes/runs/${encodeURIComponent(id)}/retry`, { method: 'POST' }) },
  async download(id: string) {
    // Bearer auth stays in headers, never in a URL. CSV has a longer timeout than JSON.
    const response = await fetch(`${API_BASE_URL}/scrapes/runs/${encodeURIComponent(id)}/csv`, {
      headers: { Authorization: `Bearer ${tokenStore.get() ?? ''}` }, signal: AbortSignal.timeout(300000),
    })
    if (!response.ok) {
      const body = await response.json().catch(() => null)
      throw new ApiError(body?.detail ?? 'CSV download failed.', response.status)
    }
    const url = URL.createObjectURL(await response.blob())
    const link = document.createElement('a')
    link.href = url; link.download = `ffg-run-${id}.csv`; link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  },
}
