import type { Case, Scrape, CaseFilters } from '@/types'
import { CASES } from './mock/cases.mock'
import { SCRAPES } from './mock/scrapes.mock'
import { delay, USE_MOCK } from './config'
import { request, requestPdf, ApiError } from './http'
import { applyFilters, makeEmptyFilters, sortForAttention, getUpdates } from '@/lib/filters'
import { searchFields, tokenize } from '@/lib/search'

type NullableText = 'ref' | 'cnr' | 'caseNo' | 'caseType' | 'caseTypeClass' | 'complex' | 'court' |
  'regDate' | 'filingDate' | 'dispositionRaw' | 'lastPurpose' | 'lastScrape'
export type CaseResponse = Omit<Case, NullableText> & Record<NullableText, string | null>

export interface FinalJudgment { id: string; date: string | null }

export const caseService = {
  async finalJudgments(id: string, signal?: AbortSignal): Promise<FinalJudgment[]> {
    if (USE_MOCK) return delay([])
    return request<FinalJudgment[]>(`/cases/${encodeURIComponent(id)}/final-judgments`, { signal })
  },

  async downloadJudgment(caseId: string, documentId: string, signal?: AbortSignal): Promise<Blob> {
    return requestPdf(`/cases/${encodeURIComponent(caseId)}/final-judgments/${encodeURIComponent(documentId)}/download`, signal)
  },

  async listCases(query: CaseQuery = {}, signal?: AbortSignal): Promise<CasePage> {
    const page = query.page ?? 1, pageSize = query.pageSize ?? 25
    if (!USE_MOCK) {
      const params = new URLSearchParams()
      for (const [key, value] of Object.entries(query)) {
        if (key === 'admin') continue
        if (Array.isArray(value)) value.forEach((v) => params.append(key, v))
        else if (value !== '' && value !== undefined) params.set(key, String(value))
      }
      const data = await request<Omit<CasePage, 'items'> & { items: CaseResponse[] }>(`/cases?${params}`, { signal })
      return { ...data, items: data.items.map(normalizeCase) }
    }
    let rows = applyFilters(CASES, { ...makeEmptyFilters(), ...query })
    if (query.scrape && query.scrape !== 'all') rows = rows.filter((c) => c.lastScrape === query.scrape)
    if (query.q) rows = rows.filter((c) => tokenize(query.q!).every((t) => searchFields(c, query.admin ?? false).some((f) => f.value?.toLowerCase().includes(t))))
    rows = sortForAttention(rows)
    return delay({ items: rows.slice((page - 1) * pageSize, page * pageSize).map((c) => ({ ...c })), total: rows.length, page, pageSize })
  },

  async getCase(id: string, signal?: AbortSignal): Promise<Case | null> {
    if (!USE_MOCK) {
      try { return normalizeCase(await request<CaseResponse>(`/cases/${encodeURIComponent(id)}`, { signal })) }
      catch (error) { if (error instanceof ApiError && error.status === 404) return null; throw error }
    }
    const row = CASES.find((c) => c.id === id)
    return delay(row ? { ...row } : null)
  },

  async options(signal?: AbortSignal): Promise<CaseOptions> {
    if (!USE_MOCK) return request<CaseOptions>('/options', { signal })
    const unique = (items: string[]) => [...new Set(items.filter(Boolean))].sort()
    return delay({ totalCases: CASES.length, districts: unique(CASES.map((c) => c.district)),
      acts: unique(CASES.flatMap((c) => c.acts.map((a) => a.name))), caseTypes: unique(CASES.map((c) => c.caseTypeClass)),
      purposes: unique(CASES.map((c) => c.lastPurpose)), complexes: unique(CASES.map((c) => c.complex)), courts: unique(CASES.map((c) => c.court)) })
  },

  async updates(signal?: AbortSignal): Promise<CaseUpdates> {
    if (!USE_MOCK) {
      const data = await request<Omit<CaseUpdates, 'items'> & { items: CaseResponse[] }>('/cases/updates', { signal })
      return { ...data, items: data.items.map(normalizeCase) }
    }
    const items = getUpdates(CASES)
    return delay({ items: items.slice(0, 20), total: items.length, critical: items.filter((c) => c.update?.severity === 'critical').length })
  },

  async setPinned(id: string, pinned: boolean): Promise<void> {
    if (!USE_MOCK) {
      await request<void>(`/cases/${encodeURIComponent(id)}/pin`, {
        method: 'PUT',
        body: JSON.stringify({ pinned }),
      })
      return
    }
    const target = CASES.find((c) => c.id === id)
    if (target) target.pinned = pinned
  },

  async listScrapes(signal?: AbortSignal): Promise<Scrape[]> {
    if (!USE_MOCK) return request<Scrape[]>('/scrapes', { signal })
    return delay(SCRAPES.map((s) => ({ ...s, count: CASES.filter((c) => c.lastScrape === s.id).length })))
  },
}

/** Missing text is displayed/searched as empty; numeric unknowns remain null. */
export function normalizeCase(row: CaseResponse): Case {
  return {
    ...row,
    ref: row.ref ?? '', cnr: row.cnr ?? '', caseNo: row.caseNo ?? '',
    caseType: row.caseType ?? '', caseTypeClass: row.caseTypeClass ?? '',
    complex: row.complex ?? '', court: row.court ?? '',
    regDate: row.regDate ?? '', filingDate: row.filingDate ?? '',
    dispositionRaw: row.dispositionRaw ?? '', lastPurpose: row.lastPurpose ?? '',
    lastScrape: row.lastScrape ?? '',
  }
}

export type CaseQuery = Partial<CaseFilters> & { page?: number; pageSize?: number; q?: string; scrape?: string; admin?: boolean }
export interface CasePage { items: Case[]; total: number; page: number; pageSize: number }
export interface CaseUpdates { items: Case[]; total: number; critical: number }
export interface CaseOptions { totalCases: number; districts: string[]; acts: string[]; caseTypes: string[]; purposes: string[]; complexes: string[]; courts: string[] }
export const EMPTY_OPTIONS: CaseOptions = { totalCases: 0, districts: [], acts: [], caseTypes: [], purposes: [], complexes: [], courts: [] }
