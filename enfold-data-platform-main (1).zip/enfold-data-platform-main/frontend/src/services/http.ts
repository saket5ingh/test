import { API_BASE_URL } from './config'

export class ApiError extends Error {
  readonly status: number

  constructor(message: string, status: number) {
    super(message)
    this.name = 'ApiError'
    this.status = status
  }
}

const unauthorizedListeners = new Set<() => void>()
export function onUnauthorized(listener: () => void) {
  unauthorizedListeners.add(listener)
  return () => { unauthorizedListeners.delete(listener) }
}

let authToken: string | null = null

export const tokenStore = {
  get: () => authToken,
  set: (token: string | null) => {
    authToken = token
  },
}

async function send(path: string, init: RequestInit, accept: string, timeout = 20000): Promise<Response> {
  const headers = new Headers(init.headers)
  headers.set('Accept', accept)
  if (init.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }
  const requestToken = authToken
  if (requestToken) headers.set('Authorization', `Bearer ${requestToken}`)

  const response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers, signal: init.signal ? AbortSignal.any([init.signal, AbortSignal.timeout(timeout)]) : AbortSignal.timeout(timeout) })

  if (!response.ok) {
    if (response.status === 401 && requestToken && requestToken === authToken && path !== '/auth/login') {
      unauthorizedListeners.forEach((listener) => listener())
    }
    const body = await response.json().catch(() => null)
    const detail = typeof body?.detail === 'string' ? body.detail : Array.isArray(body?.detail)
      ? body.detail.map((item: { msg?: string }) => item.msg ?? 'Invalid input').join('; ') : response.statusText
    throw new ApiError(detail || 'Request failed. Please try again.', response.status)
  }
  return response
}

export async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await send(path, init, 'application/json')
  if (response.status === 204) return undefined as T
  return (await response.json()) as T
}

export async function requestPdf(path: string, signal?: AbortSignal): Promise<Blob> {
  const response = await send(path, { signal }, 'application/pdf', 90000)
  if (!response.headers.get('content-type')?.includes('application/pdf')) {
    throw new ApiError('The document could not be downloaded. Please try again.', 502)
  }
  return response.blob()
}
