import { describe, expect, it } from 'vitest'
import { normalizeCase } from './caseService'
import { CASES } from './mock/cases.mock'
import { getSuggestions } from '@/lib/search'
import { relTime } from '@/lib/format'
import { applyFilters, makeEmptyFilters } from '@/lib/filters'

describe('nullable API data', () => {
  it('can search a pending case with null disposition and court metadata', () => {
    const row = normalizeCase({ ...CASES[0], dispositionRaw: null, lastPurpose: null, court: null, complex: null })
    expect(getSuggestions([row], row.district, true)).toHaveLength(1)
  })
  it('can filter a statute that is absent from demo metadata', () => {
    const row = { ...CASES[0], acts: [{ name: 'New statute', sections: ['1'] }] }
    expect(applyFilters([row], { ...makeEmptyFilters(), acts: ['New statute'] })).toHaveLength(1)
  })
  it('does not treat an unknown registration year as a matching year', () => {
    const row = { ...CASES[0], regYear: null }
    expect(applyFilters([row], { ...makeEmptyFilters(), regYearTo: '2026' })).toHaveLength(0)
  })
  it('does not display negative relative time for future timestamps', () => {
    expect(relTime('2026-09-27T09:00:00', new Date('2026-08-20T09:00:00'))).toBe('0m ago')
  })
})
