import { afterEach, expect, it, vi } from 'vitest'
import { scrapeService } from './scrapeService'
vi.mock('./config', () => ({ API_BASE_URL: '/api', USE_MOCK: false }))
afterEach(() => vi.unstubAllGlobals())
it('encodes server-side filters and pagination without changing existing positional calls', async () => {
  const fetchMock = vi.fn(async (_url: string, _init?: RequestInit) => Response.json({ items: [], total: 0, page: 1, pageSize: 25 }))
  vi.stubGlobal('fetch', fetchMock)
  const signal = new AbortController().signal
  await scrapeService.results('run/one', 3, signal, { pageSize: 100, q: 'CNR% & court', state: 'Example state', status: 'disposed', change_kind: 'updated' })
  const url = new URL(fetchMock.mock.calls[0][0], 'https://example.test')
  expect(url.pathname).toBe('/api/scrapes/runs/run%2Fone/results')
  expect(Object.fromEntries(url.searchParams)).toEqual({ page: '3', pageSize: '100', q: 'CNR% & court', state: 'Example state', status: 'disposed', change_kind: 'updated' })
  await scrapeService.tasks('one', 2, 'failed', signal, { pageSize: 50, q: 'source error', kind: 'case' })
  expect(Object.fromEntries(new URL(fetchMock.mock.calls[1][0], 'https://example.test').searchParams)).toEqual({ page: '2', pageSize: '50', q: 'source error', kind: 'case', status: 'failed' })
  await scrapeService.events('one', 2, signal, { pageSize: 25, kind: 'warnings', q: 'Act label' })
  expect(Object.fromEntries(new URL(fetchMock.mock.calls[2][0], 'https://example.test').searchParams)).toEqual({ page: '2', pageSize: '25', kind: 'warnings', q: 'Act label' })
  await scrapeService.results('one', 1, signal)
  expect(fetchMock.mock.calls[3][0]).toBe('/api/scrapes/runs/one/results?page=1')
})

it('encodes run history filters while preserving the existing unfiltered call', async () => {
  const fetchMock = vi.fn(async (_url: string) => Response.json({ items: [], total: 0, page: 1, pageSize: 25 }))
  vi.stubGlobal('fetch', fetchMock)
  const signal = new AbortController().signal
  await scrapeService.listRunPage(3, signal, { pageSize: 25, q: 'Monthly & child marriage', outcome: 'running', trigger: 'scheduled' })
  const url = new URL(fetchMock.mock.calls[0][0], 'https://example.test')
  expect(url.pathname).toBe('/api/scrapes/runs')
  expect(Object.fromEntries(url.searchParams)).toEqual({ page: '3', pageSize: '25', q: 'Monthly & child marriage', outcome: 'running', trigger: 'scheduled' })
  await scrapeService.listRunPage(1, signal)
  expect(fetchMock.mock.calls[1][0]).toBe('/api/scrapes/runs?page=1')
})

it('posts an explicit review reason to the selected task and encodes identifiers', async () => {
  const fetchMock = vi.fn(async (_url: string, _init?: RequestInit) => Response.json({ id: 'task' }))
  vi.stubGlobal('fetch', fetchMock)
  await scrapeService.reviewRetry('run/one', 'task/two', 'Verified response')
  expect(fetchMock.mock.calls[0][0]).toBe('/api/scrapes/runs/run%2Fone/tasks/task%2Ftwo/review-retry')
  expect(fetchMock.mock.calls[0][1]?.method).toBe('POST')
  expect(JSON.parse(fetchMock.mock.calls[0][1]?.body as string)).toEqual({ reason: 'Verified response' })
})
