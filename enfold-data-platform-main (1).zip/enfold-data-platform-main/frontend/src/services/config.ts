export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '/api'

/** Demo data is opt-in; normal builds use the API. */
export const USE_MOCK = import.meta.env.VITE_USE_MOCK === 'true'

const MOCK_LATENCY_MS = 120

export function delay<T>(value: T, ms = MOCK_LATENCY_MS): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms))
}
