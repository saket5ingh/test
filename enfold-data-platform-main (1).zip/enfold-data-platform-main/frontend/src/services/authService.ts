import type { Account, Credentials } from '@/types'
import { ACCOUNTS } from './mock/accounts.mock'
import { delay, USE_MOCK } from './config'
import { request, tokenStore } from './http'

export interface Session {
  account: Account
  token: string
}

type AccountResponse = Omit<Account, 'roleLabel' | 'initials'> & {
  roleLabel: string | null
  initials: string | null
}
function normalizeAccount(account: AccountResponse): Account {
  return { ...account, roleLabel: account.roleLabel ?? '',
    initials: account.initials ?? account.name.split(/\s+/).map((part) => part[0]).join('').slice(0, 2) }
}

type GoogleConfig = { enabled: boolean; clientId: string; nonce: string }
let pendingGoogleConfig: Promise<GoogleConfig> | undefined

const SESSION_KEY = 'ecourts.session'

function persist(session: Session | null) {
  tokenStore.set(session?.token ?? null)
  if (session) sessionStorage.setItem(SESSION_KEY, JSON.stringify(session))
  else sessionStorage.removeItem(SESSION_KEY)
}

export const authService = {
  /** Demo sign-in resolves to the standard field-officer account. */
  async login(credentials: Credentials): Promise<Session> {
    if (!USE_MOCK) {
      const response = await request<{ account: AccountResponse; token: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      })
      const session = { ...response, account: normalizeAccount(response.account) }
      persist(session)
      return session
    }
    const account = ACCOUNTS.find((a) => a.role === 'user')!
    const session: Session = { account, token: 'mock-token' }
    persist(session)
    return delay(session)
  },

  googleConfig(): Promise<GoogleConfig> {
    // Share concurrent initialization (including React StrictMode) so the nonce
    // cookie cannot be replaced by an older configuration response.
    pendingGoogleConfig ??= request<GoogleConfig>('/auth/google/config', { credentials: 'include' })
      .finally(() => { pendingGoogleConfig = undefined })
    return pendingGoogleConfig
  },

  async googleLogin(credential: string): Promise<Session> {
    const response = await request<{ account: AccountResponse; token: string }>('/auth/google', {
      method: 'POST', credentials: 'include', body: JSON.stringify({ credential }),
    })
    const session = { ...response, account: normalizeAccount(response.account) }
    persist(session)
    return session
  },

  async listAccounts(): Promise<Account[]> {
    if (!USE_MOCK) return []
    return delay(ACCOUNTS)
  },

  async selectAccount(email: string): Promise<Session> {
    if (!USE_MOCK) throw new Error('Account selection is available only in demo mode.')
    const account = ACCOUNTS.find((a) => a.email === email) ?? ACCOUNTS[0]
    const session: Session = { account, token: 'mock-token' }
    persist(session)
    return delay(session)
  },

  async currentAccount(): Promise<Account> {
    if (USE_MOCK) return this.restore()!.account
    return request<AccountResponse>('/auth/me').then(normalizeAccount)
  },

  logout(): void {
    persist(null)
  },

  restore(): Session | null {
    const raw = sessionStorage.getItem(SESSION_KEY)
    if (!raw) return null
    try {
      const session = JSON.parse(raw) as Session
      if (!session.account?.email || !['user', 'admin'].includes(session.account.role) || !session.token) {
        persist(null)
        return null
      }
      tokenStore.set(session.token)
      return session
    } catch {
      persist(null)
      return null
    }
  },
}
