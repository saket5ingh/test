import { afterEach, expect, it, vi } from 'vitest'
import { requestPdf, tokenStore, onUnauthorized } from './http'

afterEach(() => { vi.unstubAllGlobals(); tokenStore.set(null) })

it('sends the login token in the header and returns PDF bytes', async () => {
  tokenStore.set('synthetic-token')
  const fetchMock = vi.fn().mockResolvedValue(new Response('%PDF-1.7', { headers: { 'content-type': 'application/pdf' } }))
  vi.stubGlobal('fetch', fetchMock)
  const pdf = await requestPdf('/cases/example/final-judgments/doc/download')
  expect(pdf.size).toBeGreaterThan(0)
  const [url, init] = fetchMock.mock.calls[0]
  expect(url).not.toContain('synthetic-token')
  expect(init.headers.get('Authorization')).toBe('Bearer synthetic-token')
  expect(init.headers.get('Accept')).toBe('application/pdf')
})

it('handles expired sessions through the existing sign-out mechanism', async () => {
  tokenStore.set('synthetic-token')
  const expired = vi.fn(), remove = onUnauthorized(expired)
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('{"detail":"Session expired"}', { status: 401 })))
  try {
    await expect(requestPdf('/document')).rejects.toThrow('Session expired')
    expect(expired).toHaveBeenCalledOnce()
  } finally { remove() }
})

it('does not save a successful HTML error page as a PDF', async () => {
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('<html>Error</html>', { headers: { 'content-type': 'text/html' } })))
  await expect(requestPdf('/document')).rejects.toThrow('could not be downloaded')
})
