import type { Account } from '@/types'

export const ACCOUNTS: Account[] = [
  {
    name: 'Anita Verma',
    role: 'user',
    roleLabel: 'Field Officer · Child Welfare Committee',
    email: 'anita.verma@cwc-fieldops.org',
    initials: 'AV',
  },
  {
    name: 'Rahul Nair',
    role: 'admin',
    roleLabel: 'Data Operations Admin',
    email: 'rahul.nair@cwc-fieldops.org',
    initials: 'RN',
  },
]
