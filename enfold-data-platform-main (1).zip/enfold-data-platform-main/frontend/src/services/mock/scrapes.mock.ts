import type { Scrape } from '@/types'

/* The scraper runs once a month; each run is labelled by its month. The most
   recent run is the "latest scrape". Freshness is measured against it. */
export const SCRAPES: Scrape[] = [
  { id: '2026-08', label: 'August 2026', short: 'Aug 2026', date: '2026-08-03' },
  { id: '2026-07', label: 'July 2026', short: 'Jul 2026', date: '2026-07-02' },
  { id: '2026-06', label: 'June 2026', short: 'Jun 2026', date: '2026-06-04' },
  { id: '2026-05', label: 'May 2026', short: 'May 2026', date: '2026-05-05' },
]

export const LATEST_SCRAPE = SCRAPES[0].id
