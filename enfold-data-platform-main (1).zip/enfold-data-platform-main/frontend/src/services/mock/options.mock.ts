import { CASES } from './cases.mock'

export const INDIAN_STATES = [
  'Andhra Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Gujarat',
  'Haryana',
  'Jharkhand',
  'Karnataka',
  'Kerala',
  'Madhya Pradesh',
  'Maharashtra',
  'Odisha',
  'Punjab',
  'Rajasthan',
  'Tamil Nadu',
  'Telangana',
  'Uttar Pradesh',
  'West Bengal',
]

export { ACT_OPTIONS, STATUS_OPTIONS, STATUS_META } from '@/lib/caseMetadata'

const unique = (values: string[]) => [...new Set(values)].sort()

export const PURPOSE_OPTIONS = unique(CASES.map((c) => c.lastPurpose))
export const DISTRICTS = unique(CASES.map((c) => c.district))
export const CASE_TYPES = unique(CASES.map((c) => c.caseTypeClass))
export const COMPLEXES = unique(CASES.map((c) => c.complex))
export const COURTS = unique(CASES.map((c) => c.court))
