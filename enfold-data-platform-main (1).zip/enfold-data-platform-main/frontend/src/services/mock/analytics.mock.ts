/* Illustrative, India-wide PCMA placeholder figures — awaiting real reporting integration. */
export const PCMA_BY_STATE = [
  { state: 'Uttar Pradesh', value: 1240 },
  { state: 'Bihar', value: 980 },
  { state: 'Madhya Pradesh', value: 860 },
  { state: 'Rajasthan', value: 810 },
  { state: 'West Bengal', value: 705 },
  { state: 'Maharashtra', value: 640 },
  { state: 'Karnataka', value: 512 },
  { state: 'Assam', value: 468 },
]

export const PCMA_BY_YEAR = [
  { year: '2019', value: 4200 },
  { year: '2020', value: 3650 },
  { year: '2021', value: 4700 },
  { year: '2022', value: 5400 },
  { year: '2023', value: 6100 },
  { year: '2024', value: 6800 },
  { year: '2025', value: 7300 },
]

export const PCMA_OUTCOMES = [
  { label: 'Pending', value: 450, color: 'var(--orange)' },
  { label: 'Acquitted', value: 220, color: 'var(--ok)' },
  { label: 'Convicted', value: 180, color: 'var(--pink)' },
  { label: 'Compounded / withdrawn', value: 100, color: 'var(--neutral)' },
  { label: 'Other', value: 50, color: 'var(--blue)' },
]

export const PCMA_BY_SECTION = [
  { act: 'Prohibition of Child Marriage Act', section: '11', value: 3200 },
  { act: 'Prohibition of Child Marriage Act', section: '9', value: 2400 },
  { act: 'Prohibition of Child Marriage Act', section: '10', value: 1800 },
  { act: 'Prohibition of Child Marriage Act', section: '3', value: 1200 },
  { act: 'Prohibition of Child Marriage Act', section: '12', value: 640 },
]
