import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/renderWithProviders'
import { GoogleSignIn } from './GoogleSignIn'
import { useAuth } from '@/context/authState'
import { tokenStore } from '@/services/http'

vi.mock('@/services/config', () => ({ API_BASE_URL: '/api', USE_MOCK: false, delay: (v: unknown) => Promise.resolve(v) }))
let enabled = true
let allowed = true
const initialize = vi.fn()
function Harness() {
  const { account } = useAuth()
  return <><p>{account?.role ?? 'anonymous'}</p>{!account && <GoogleSignIn />}</>
}
beforeEach(() => {
  sessionStorage.clear(); tokenStore.set(null); enabled = true; allowed = true
  initialize.mockReset()
  window.google = { accounts: { id: { initialize, renderButton: (element) => {
    const button = document.createElement('button')
    button.textContent = 'Sign in with Google'
    button.onclick = () => initialize.mock.calls.at(-1)![0].callback({ credential: 'google-id-token' })
    element.append(button)
  } } } }
  vi.stubGlobal('fetch', vi.fn(async (url: string) => {
    if (url === '/api/auth/google/config') return Response.json({ enabled, clientId: 'public-client-id', nonce: 'browser-nonce' })
    if (url === '/api/auth/google') return allowed
      ? Response.json({ account: { name: 'Officer', email: 'user@example.org', role: 'user', roleLabel: null, initials: null }, token: 'api-session' })
      : Response.json({ detail: 'An active provisioned account is required.' }, { status: 403 })
    if (url.startsWith('/api/cases?')) return Response.json({ items: [], total: 0, page: 1, pageSize: 25 })
    if (url === '/api/options') return Response.json({ totalCases: 0, districts: [], acts: [], caseTypes: [], purposes: [], complexes: [], courts: [] })
    if (url === '/api/cases/updates') return Response.json({ items: [], total: 0, critical: 0 })
    if (url === '/api/scrapes') return Response.json([])
    throw new Error(`Unexpected request: ${url}`)
  }))
})
afterEach(() => { delete window.google; vi.unstubAllGlobals(); tokenStore.set(null) })

it('exchanges the Google credential for the application session and stored role', async () => {
  const user = userEvent.setup()
  renderWithProviders(<Harness />)
  await user.click(await screen.findByRole('button', { name: 'Sign in with Google' }))
  expect(await screen.findByText('user')).toBeInTheDocument()
  expect(tokenStore.get()).toBe('api-session')
  expect(initialize.mock.calls[0][0]).toMatchObject({ client_id: 'public-client-id', nonce: 'browser-nonce', auto_select: false })
  expect(fetch).toHaveBeenCalledWith('/api/auth/google', expect.objectContaining({ credentials: 'include', body: JSON.stringify({ credential: 'google-id-token' }) }))
})

it('shows denied-account errors without creating a session', async () => {
  allowed = false
  const user = userEvent.setup()
  renderWithProviders(<Harness />)
  await user.click(await screen.findByRole('button', { name: 'Sign in with Google' }))
  expect(await screen.findByRole('alert')).toHaveTextContent('An active provisioned account is required.')
  expect(tokenStore.get()).toBeNull()
})

it('does not show a nonfunctional Google button before configuration', async () => {
  enabled = false
  renderWithProviders(<Harness />)
  await waitFor(() => expect(fetch).toHaveBeenCalled())
  expect(initialize).not.toHaveBeenCalled()
  expect(screen.queryByRole('button', { name: 'Sign in with Google' })).not.toBeInTheDocument()
})
