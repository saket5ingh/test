import { useEffect, useRef, useState } from 'react'
import { useAuth } from '@/context/authState'
import { authService } from '@/services/authService'

type GoogleIdentity = {
  initialize: (options: { client_id: string; nonce: string; callback: (response: { credential: string }) => void; auto_select: boolean }) => void
  renderButton: (element: HTMLElement, options: { type: string; theme: string; size: string }) => void
}
declare global { interface Window { google?: { accounts: { id: GoogleIdentity } } } }
let scriptPromise: Promise<void> | undefined
function loadGoogle() {
  if (window.google) return Promise.resolve()
  if (!scriptPromise) scriptPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement('script')
    script.src = 'https://accounts.google.com/gsi/client'
    script.async = true
    const timeout = window.setTimeout(() => { script.remove(); scriptPromise = undefined; reject(new Error('Google sign-in took too long to load.')) }, 15000)
    script.onload = () => { clearTimeout(timeout); resolve() }
    script.onerror = () => { clearTimeout(timeout); script.remove(); scriptPromise = undefined; reject(new Error('Google sign-in could not load.')) }
    document.head.append(script)
  })
  return scriptPromise
}

export function GoogleSignIn() {
  const { googleLogin } = useAuth()
  const container = useRef<HTMLDivElement>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [attempt, setAttempt] = useState(0)
  useEffect(() => {
    let active = true
    const element = container.current
    async function setup() {
      const config = await authService.googleConfig()
      if (!active || !config.enabled) return
      await loadGoogle()
      if (!active || !element || !window.google) return
      window.google.accounts.id.initialize({ client_id: config.clientId, nonce: config.nonce, auto_select: false,
        callback: ({ credential }) => {
          if (!active) return
          setBusy(true)
          setError('')
          void googleLogin(credential).catch((reason: unknown) => {
            if (active) setError(reason instanceof Error ? reason.message : 'Google sign-in failed.')
          }).finally(() => { if (active) setBusy(false) })
        },
      })
      window.google.accounts.id.renderButton(element, { type: 'standard', theme: 'outline', size: 'large' })
    }
    void setup().catch(() => { if (active) setError('Google sign-in could not load. You can still use your password.') })
    return () => { active = false; element?.replaceChildren() }
  }, [googleLogin, attempt])
  return <div style={{ marginTop: 16 }}>
    <div ref={container} hidden={busy || Boolean(error)} />
    {busy ? <p role="status">Signing in with Google…</p> : null}
    {error ? <p role="alert">{error} <button onClick={() => { setError(''); setAttempt((v) => v + 1) }}>Retry Google sign-in</button></p> : null}
  </div>
}
