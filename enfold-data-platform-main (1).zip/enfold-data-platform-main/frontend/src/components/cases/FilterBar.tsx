import clsx from 'clsx'
import { Icon } from '@/components/icons/Icon'
import { Button } from '@/components/ui/Button'
import { FilterPill } from '@/components/ui/Badges'
import { useFilters } from '@/context/filtersState'
import { scrapeLabel } from '@/lib/freshness'
import { ACT_OPTIONS, STATUS_OPTIONS } from '@/lib/caseMetadata'
import { useCases } from '@/context/casesState'
import { FilterSelect } from './FilterSelect'
import { ScrapeSelect } from './ScrapeSelect'
import styles from './FilterBar.module.css'

const asOptions = (values: string[]) => values.filter((value) => value.trim()).map((v) => ({ key: v, label: v }))

export function FilterBar() {
  const { options: { districts, caseTypes, acts } } = useCases()
  const {
    filters,
    scrapeFilter,
    toggleFilter,
    togglePinnedOnly,
    setScrapeFilter,
    openDrawer,
  } = useFilters()

  return (
    <div className={styles.filterBar}>
      <button
        type="button"
        className={clsx(styles.toggleChip, filters.pinnedOnly && styles.on)}
        aria-pressed={filters.pinnedOnly}
        onClick={togglePinnedOnly}
      >
        <Icon name="pinOutline" /> Pinned only
      </button>

      <div className={styles.divider} />

      <FilterSelect
        label="Status"
        options={STATUS_OPTIONS}
        selected={filters.status}
        onToggle={(v) => toggleFilter('status', v)}
      />
      <FilterSelect
        label="District"
        options={asOptions(districts)}
        selected={filters.district}
        onToggle={(v) => toggleFilter('district', v)}
      />
      <FilterSelect
        label="Acts / charges"
        options={asOptions(acts)}
        selected={filters.acts}
        onToggle={(v) => toggleFilter('acts', v)}
      />
      <FilterSelect
        label="Case type"
        options={asOptions(caseTypes)}
        selected={filters.caseType}
        onToggle={(v) => toggleFilter('caseType', v)}
      />

      <Button variant="subtle" onClick={openDrawer}>
        <Icon name="filter" /> More filters
      </Button>

      <div className={styles.spacer}>
        <ScrapeSelect value={scrapeFilter} onChange={setScrapeFilter} />
      </div>
    </div>
  )
}

export function ActiveFilterChips() {
  const { filters, removeChip, clearAll, setPinnedOnly, searchQuery, scrapeFilter, setSearchQuery, setScrapeFilter } = useFilters()

  const chips: Array<{ label: string; remove: () => void }> = []
  if (searchQuery) chips.push({ label: `Search: ${searchQuery}`, remove: () => setSearchQuery('') })
  if (scrapeFilter !== 'all') chips.push({ label: `Last scraped: ${scrapeLabel(scrapeFilter)}`, remove: () => setScrapeFilter('all') })

  for (const key of filters.status) {
    const label = STATUS_OPTIONS.find((o) => o.key === key)?.label ?? key
    chips.push({ label, remove: () => removeChip('status', key) })
  }
  for (const key of filters.district) {
    chips.push({ label: key, remove: () => removeChip('district', key) })
  }
  for (const key of filters.acts) {
    const label = ACT_OPTIONS.find((o) => o.key === key)?.label ?? key
    chips.push({ label, remove: () => removeChip('acts', key) })
  }
  for (const key of filters.caseType) {
    chips.push({ label: key, remove: () => removeChip('caseType', key) })
  }
  for (const key of filters.purpose) {
    chips.push({ label: `Purpose: ${key}`, remove: () => removeChip('purpose', key) })
  }
  for (const key of filters.complex) {
    chips.push({ label: `Complex: ${key}`, remove: () => removeChip('complex', key) })
  }
  for (const key of filters.court) {
    chips.push({ label: `Court: ${key}`, remove: () => removeChip('court', key) })
  }
  if (filters.pinnedOnly) {
    chips.push({ label: 'Pinned only', remove: () => setPinnedOnly(false) })
  }

  const ranges = [
    ['Registration year', filters.regYearFrom, filters.regYearTo],
    ['Filing date', filters.filingFrom, filters.filingTo],
    ['Decision date', filters.decisionFrom, filters.decisionTo],
  ].filter(([, from, to]) => from || to)
  if (!chips.length && !ranges.length) return null

  return (
    <div className={styles.activeFilters}>
      {ranges.map(([label, from, to]) => <span key={label}>{label}: {from || 'any'} – {to || 'any'}</span>)}
      {chips.map((chip) => (
        <FilterPill key={chip.label} label={chip.label} onRemove={chip.remove} />
      ))}
      <Button variant="subtle" style={{ padding: '3px 7px', fontSize: 11 }} onClick={clearAll}>
        Clear all
      </Button>
    </div>
  )
}
