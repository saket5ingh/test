import { useRef } from 'react'
import clsx from 'clsx'
import { Icon } from '@/components/icons/Icon'
import { RestrictedPill } from '@/components/ui/Badges'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/context/authState'
import { useFilters } from '@/context/filtersState'
import { useFocusTrap } from '@/hooks/useFocusTrap'
import { useCases } from '@/context/casesState'
import styles from './AdvancedFilterDrawer.module.css'

export function AdvancedFilterDrawer() {
  const { options: { complexes: COMPLEXES, courts: COURTS, purposes: PURPOSE_OPTIONS } } = useCases()
  const { isAdmin } = useAuth()
  const { drawerOpen, draft, cancelDraft, applyDraft, toggleDraftFilter, patchDraft } = useFilters()
  const rangeErrors = [
    draft.regYearFrom && draft.regYearTo && Number(draft.regYearFrom) > Number(draft.regYearTo) ? 'Registration year: From must not be after To.' : '',
    draft.filingFrom && draft.filingTo && draft.filingFrom > draft.filingTo ? 'Filing date: From must not be after To.' : '',
    draft.decisionFrom && draft.decisionTo && draft.decisionFrom > draft.decisionTo ? 'Decision date: From must not be after To.' : '',
  ].filter(Boolean)
  const drawerRef = useRef<HTMLDivElement>(null)

  useFocusTrap(drawerRef, drawerOpen, cancelDraft)

  return (
    <>
      {drawerOpen ? (
        <button
          type="button"
          className={styles.overlay}
          aria-label="Close filters"
          tabIndex={-1}
          onClick={cancelDraft}
        />
      ) : null}

      <div
        ref={drawerRef}
        className={clsx(styles.drawer, drawerOpen && styles.open)}
        role="dialog"
        aria-modal="true"
        aria-label="More filters"
        aria-hidden={!drawerOpen}
        inert={!drawerOpen}
      >
        <div className={styles.head}>
          <h2>More filters</h2>
          <Button variant="subtle" iconOnly aria-label="Close filters" onClick={cancelDraft}>
            <Icon name="x" />
          </Button>
        </div>

        <div className={styles.body}>
          <div className={styles.groupLabel}>Case parameters</div>

          <fieldset className={styles.section} style={{ border: 'none', margin: 0, padding: '0 0 18px' }}>
            <legend className={styles.sectionLabel}>Registration year</legend>
            <div className={styles.rangeRow}>
              <input
                type="number"
                inputMode="numeric"
                placeholder="From e.g. 2018"
                aria-label="Registration year from"
                value={draft.regYearFrom}
                onChange={(e) => patchDraft({ regYearFrom: e.target.value })}
              />
              <span className={styles.rangeSep}>–</span>
              <input
                type="number"
                inputMode="numeric"
                placeholder="To e.g. 2026"
                aria-label="Registration year to"
                value={draft.regYearTo}
                onChange={(e) => patchDraft({ regYearTo: e.target.value })}
              />
            </div>
          </fieldset>

          <fieldset className={styles.section} style={{ border: 'none', margin: 0, padding: '0 0 18px' }}>
            <legend className={styles.sectionLabel}>Date of filing</legend>
            <div className={styles.rangeRow}>
              <input
                type="date"
                aria-label="Filing date from"
                value={draft.filingFrom}
                onChange={(e) => patchDraft({ filingFrom: e.target.value })}
              />
              <span className={styles.rangeSep}>–</span>
              <input
                type="date"
                aria-label="Filing date to"
                value={draft.filingTo}
                onChange={(e) => patchDraft({ filingTo: e.target.value })}
              />
            </div>
          </fieldset>

          <fieldset className={styles.section} style={{ border: 'none', margin: 0, padding: '0 0 18px' }}>
            <legend className={styles.sectionLabel}>Date of decision</legend>
            <div className={styles.sectionSub}>Only applies to disposed cases</div>
            <div className={styles.rangeRow}>
              <input
                type="date"
                aria-label="Decision date from"
                value={draft.decisionFrom}
                onChange={(e) => patchDraft({ decisionFrom: e.target.value })}
              />
              <span className={styles.rangeSep}>–</span>
              <input
                type="date"
                aria-label="Decision date to"
                value={draft.decisionTo}
                onChange={(e) => patchDraft({ decisionTo: e.target.value })}
              />
            </div>
          </fieldset>

          <fieldset className={styles.section} style={{ border: 'none', margin: 0, padding: '0 0 18px' }}>
            <legend className={styles.sectionLabel}>Last purpose of hearing</legend>
            {PURPOSE_OPTIONS.filter((value) => value.trim()).map((p) => (
              <label className={styles.option} key={p}>
                <input
                  type="checkbox"
                  checked={draft.purpose.includes(p)}
                  onChange={() => toggleDraftFilter('purpose', p)}
                />
                {p}
              </label>
            ))}
          </fieldset>

          {isAdmin ? (
            <>
              <div className={styles.groupLabel}>
                Court identifiers <RestrictedPill label="Admin only" />
              </div>
              <fieldset className={styles.section} style={{ border: 'none', margin: 0, padding: '0 0 18px' }}>
                <legend className={styles.sectionLabel}>Complex name</legend>
                <div className={styles.checkScroll}>
                  {COMPLEXES.filter((value) => value.trim()).map((c) => (
                    <label className={styles.option} key={c}>
                      <input
                        type="checkbox"
                        checked={draft.complex.includes(c)}
                        onChange={() => toggleDraftFilter('complex', c)}
                      />
                      {c}
                    </label>
                  ))}
                </div>
              </fieldset>
              <fieldset className={styles.section} style={{ border: 'none', margin: 0, padding: 0 }}>
                <legend className={styles.sectionLabel}>Court name / bench</legend>
                <div className={styles.checkScroll}>
                  {COURTS.filter((value) => value.trim()).map((c) => (
                    <label className={styles.option} key={c}>
                      <input
                        type="checkbox"
                        checked={draft.court.includes(c)}
                        onChange={() => toggleDraftFilter('court', c)}
                      />
                      {c}
                    </label>
                  ))}
                </div>
              </fieldset>
            </>
          ) : (
            <div className={styles.section} style={{ borderBottom: 'none' }}>
              <div className={styles.accessNote}>
                <Icon name="lock" /> Complex and court-bench filters are available to admins only.
              </div>
            </div>
          )}
        </div>

        {rangeErrors.length ? <p className={styles.validation} role="alert">{rangeErrors.join(" ")}</p> : null}
        <div className={styles.foot}>
          <Button onClick={cancelDraft}>Cancel</Button>
          <Button variant="primary" disabled={rangeErrors.length > 0} onClick={applyDraft}>
            Apply
          </Button>
        </div>
      </div>
    </>
  )
}
