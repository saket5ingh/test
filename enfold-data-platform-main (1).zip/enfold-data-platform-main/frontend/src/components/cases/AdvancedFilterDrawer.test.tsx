import { afterEach, describe, expect, it } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { CASES } from '@/services/mock/cases.mock'
import { CasesPage } from '@/pages/CasesPage'
import { renderWithProviders, signIn } from '@/test/renderWithProviders'

afterEach(() => sessionStorage.clear())

const openDrawer = async (user: ReturnType<typeof userEvent.setup>) => {
  await user.click(screen.getByRole('button', { name: /more filters/i }))
  return screen.getByRole('dialog', { name: 'More filters' })
}

describe('AdvancedFilterDrawer', () => {
  it('discards draft edits when cancelled', async () => {
    const user = userEvent.setup()
    signIn('user')
    renderWithProviders(<CasesPage />, { route: '/cases' })
    await screen.findByText('PCMA-BR-0001')

    const drawer = await openDrawer(user)
    await user.click(within(drawer).getByLabelText('Evidence'))
    await user.click(within(drawer).getByRole('button', { name: 'Cancel' }))

    expect(screen.queryByText('Purpose: Evidence')).not.toBeInTheDocument()
    // All available records are shown unless a month is explicitly selected.
    expect(screen.getByText(`${CASES.length} cases`)).toBeInTheDocument()
  })

  it('commits draft edits when applied', async () => {
    const user = userEvent.setup()
    signIn('user')
    renderWithProviders(<CasesPage />, { route: '/cases' })
    await screen.findByText('PCMA-BR-0001')

    const drawer = await openDrawer(user)
    await user.click(within(drawer).getByLabelText('Evidence'))
    await user.click(within(drawer).getByRole('button', { name: 'Apply' }))

    expect(screen.getByText('Purpose: Evidence')).toBeInTheDocument()
    expect(await screen.findByText(/^2 cases$/)).toBeInTheDocument()
  })

  it('closes on Escape without committing', async () => {
    const user = userEvent.setup()
    signIn('user')
    renderWithProviders(<CasesPage />, { route: '/cases' })
    await screen.findByText('PCMA-BR-0001')

    const drawer = await openDrawer(user)
    await user.click(within(drawer).getByLabelText('Evidence'))
    await user.keyboard('{Escape}')

    expect(screen.queryByText('Purpose: Evidence')).not.toBeInTheDocument()
  })
})

it('prevents reversed date and registration ranges from being applied', async () => {
  const user = userEvent.setup(); signIn('admin'); renderWithProviders(<CasesPage />, { route: '/cases' })
  await screen.findByText('BRGA010125162025')
  const drawer = await openDrawer(user)
  await user.type(within(drawer).getByLabelText('Registration year from'), '2026')
  await user.type(within(drawer).getByLabelText('Registration year to'), '2020')
  expect(within(drawer).getByRole('alert')).toHaveTextContent('From must not be after To.')
  expect(within(drawer).getByRole('button', { name: 'Apply' })).toBeDisabled()
  await user.clear(within(drawer).getByLabelText('Registration year to'))
  await user.type(within(drawer).getByLabelText('Registration year to'), '2026')
  expect(within(drawer).getByRole('button', { name: 'Apply' })).toBeEnabled()
})
