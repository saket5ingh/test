import { useCallback, useId, useRef, useState } from 'react'
import clsx from 'clsx'
import { Icon } from '@/components/icons/Icon'
import { useClickAway } from '@/hooks/useClickAway'
import type { FilterOption } from '@/types'
import styles from './FilterBar.module.css'

interface FilterSelectProps {
  label: string
  options: FilterOption[]
  selected: string[]
  onToggle: (value: string) => void
}

export function FilterSelect({ label, options, selected, onToggle }: FilterSelectProps) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const triggerRef = useRef<HTMLButtonElement>(null)
  const visible = options.filter((option) => option.label.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase()))
  const wrapRef = useRef<HTMLDivElement>(null)
  const panelId = useId()

  const close = useCallback(() => { setOpen(false); setSearch('') }, [])
  useClickAway(wrapRef, open, close)

  return (
    <div className={styles.fselect} ref={wrapRef} onKeyDown={(event) => {
      if (event.key === 'Escape') { event.stopPropagation(); close(); triggerRef.current?.focus() }
    }}>
      <button
        type="button"
        ref={triggerRef}
        className={clsx(styles.trigger, selected.length > 0 && styles.active)}
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => { if (open) close(); else setOpen(true) }}
      >
        {label}
        {selected.length ? ` (${selected.length})` : ''}
        <Icon name="chev" />
      </button>

      {open ? (
        <div className={styles.panel} id={panelId} role="group" aria-label={label}>
          {options.length > 6 ? <label className={styles.optionSearch}>Find {label.toLowerCase()}<input type="search" value={search} maxLength={160} onChange={(event) => setSearch(event.target.value)} /></label> : null}
          {!visible.length ? <p className={styles.panelNote}>{options.length ? 'No matching options.' : 'No options available.'}</p> : null}
          {visible.map((o) => (
            <label className={styles.option} key={o.key}>
              <input
                type="checkbox"
                checked={selected.includes(o.key)}
                onChange={() => onToggle(o.key)}
              />
              {o.label}
            </label>
          ))}
        </div>
      ) : null}
    </div>
  )
}
