import { useId, useState } from 'react'
import clsx from 'clsx'
import { Link, useNavigate } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { EmptyState } from '@/components/ui/EmptyState'
import { StatusBadge } from '@/components/ui/StatusBadge'
import { useAuth } from '@/context/authState'
import { useCases } from '@/context/casesState'
import { fmtDate } from '@/lib/format'
import type { Case } from '@/types'
import styles from './CaseTable.module.css'


interface CaseTableProps {
  cases: Case[]
  caption: string
  emptyTitle: string
  emptyDescription: string
}

export function CaseTable({ cases, caption, emptyTitle, emptyDescription }: CaseTableProps) {
  const { isAdmin } = useAuth()
  const { togglePin } = useCases()
  const navigate = useNavigate()
  const hintId = useId()
  const [pendingPins, setPendingPins] = useState<Set<string>>(new Set())
  async function pin(id: string) {
    setPendingPins((old) => new Set(old).add(id))
    try { await togglePin(id) } finally { setPendingPins((old) => { const next = new Set(old); next.delete(id); return next }) }
  }

  if (!cases.length) return <div className={styles.wrap}><EmptyState title={emptyTitle} description={emptyDescription} /></div>

  return (
    <>
    <p className={styles.scrollHint} id={hintId}>Scroll horizontally if needed to see all case information.</p>
    <div className={styles.wrap} role="region" aria-label={caption} aria-describedby={hintId} tabIndex={0}>
      <table data-admin={isAdmin}>
        <caption>{caption}</caption>
        <thead>
          <tr>
            <th scope="col">
              <span className="visually-hidden">Pin</span>
            </th>
            {isAdmin ? (
              <>
                <th scope="col">CNR</th>
                <th scope="col">Case number</th>
                <th scope="col">Reg. no.</th>
                <th scope="col">Case type</th>
                <th scope="col">District &amp; court</th>
                <th scope="col">Acts</th>
                <th scope="col">Status</th>
                <th scope="col">Hearing</th>
              </>
            ) : (
              <>
                <th scope="col">Reference</th>
                <th scope="col">Case type</th>
                <th scope="col">District</th>
                <th scope="col">Acts</th>
                <th scope="col">Status</th>
                <th scope="col">Key dates</th>
              </>
            )}
          </tr>
        </thead>
        <tbody>
          {cases.map((c) => {
              const acts = [...new Set(c.acts.map((a) => a.name))]
              const identifier = (isAdmin ? c.cnr || c.caseNo || c.ref : c.ref) || 'View case'
              const hearingDate = c.nextHearing ? new Date(`${c.nextHearing}T00:00:00`) : null
              const today = new Date(); today.setHours(0, 0, 0, 0)
              const hearingLabel = c.status !== 'pending' ? null : hearingDate
                ? `${hearingDate < today ? 'Last reported hearing date' : 'Next'}: ${fmtDate(c.nextHearing)}`
                : 'Next date not available'
              const nextLine = hearingLabel ? <div className={styles.subtleLine}>{hearingLabel}</div> : null

              return (
                <tr
                  key={c.id}
                  className={styles.clickableRow}
                  onClick={() => navigate(`/cases/${c.id}`)}
                >
                  <td onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      className={clsx(styles.pinBtn, c.pinned && styles.on)}
                      aria-pressed={c.pinned}
                      aria-label={`${c.pinned ? 'Unpin' : 'Pin'} case ${identifier}`}
                      aria-busy={pendingPins.has(c.id)}
                      disabled={pendingPins.has(c.id)}
                      onClick={() => void pin(c.id)}
                    >
                      <Icon name={c.pinned ? 'pin' : 'pinOutline'} />
                    </button>
                  </td>

                  <td className={styles.identifier}>
                    <Link to={`/cases/${c.id}`} onClick={(e) => e.stopPropagation()}>
                      {identifier}
                    </Link>
                  </td>

                  {isAdmin ? (
                    <>
                      <td>{c.caseNo || '—'}</td>
                      <td>
                        {[c.regNo, c.regYear].filter((value) => value !== null && value !== undefined).join(' / ') || '—'}
                      </td>
                    </>
                  ) : null}

                  <td>{c.caseType || '—'}</td>

                  <td className={styles.loc}>
                    {c.district || '—'}
                    {isAdmin ? <div className={styles.court}>{c.court}</div> : null}
                    <div className={styles.state}>{c.state}</div>
                  </td>

                  <td>
                    <div className={styles.actsCell}>
                      {!acts.length ? '—' : null}
                      {acts.map((label) => (
                        <span className={styles.actTag} key={label}>{label}</span>
                      ))}
                    </div>
                  </td>

                  <td>
                    <StatusBadge status={c.status} />
                  </td>

                  {isAdmin ? (
                    <td className={styles.dates}>
                      {hearingLabel ? <div>{hearingLabel}</div> : null}
                      {c.decisionDate ? <div className={styles.subtleLine}>Decision: {fmtDate(c.decisionDate)}</div> : null}
                      {c.lastPurpose ? <div className={styles.subtleLine}>{c.lastPurpose}</div> : null}
                      {c.numHearings !== null ? <div className={styles.subtleLine}>{c.numHearings} recorded hearing{c.numHearings === 1 ? '' : 's'}</div> : null}
                    </td>
                  ) : (
                    <td className={styles.dates}>
                      <div>
                        Decision: <b>{fmtDate(c.decisionDate)}</b>
                      </div>
                      <div className={styles.subtleLine}>Filed {fmtDate(c.filingDate)}</div>
                      {nextLine}
                    </td>
                  )}
                </tr>
              )
            })}
        </tbody>
      </table>
    </div>
    </>
  )
}
