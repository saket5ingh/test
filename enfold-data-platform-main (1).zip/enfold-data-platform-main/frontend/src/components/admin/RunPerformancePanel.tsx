import type { ScraperRun } from '@/types/scraper'
import { Icon } from '@/components/icons/Icon'
import styles from './RunPerformancePanel.module.css'

const number = (value: number) => value.toLocaleString()
function Timestamp({ value }: { value: string | null }) {
  return value ? <time dateTime={value}>{new Date(value).toLocaleString()}</time> : <>None recorded</>
}
function duration(seconds: number) {
  if (seconds < 60) return 'Less than 1 minute'
  const minutes = Math.ceil(seconds / 60)
  const days = Math.floor(minutes / 1440)
  const hours = Math.floor(minutes % 1440 / 60)
  return [days ? `${days}d` : '', hours ? `${hours}h` : '', minutes % 60 ? `${minutes % 60}m` : ''].filter(Boolean).join(' ')
}
const spacing = (seconds: number | null) => seconds === null ? 'Not available' : `${seconds.toLocaleString(undefined, { maximumFractionDigits: 2 })}s between admissions`

export function RunPerformancePanel({ run, now }: { run: ScraperRun; now: number }) {
  const performance = run.performance
  const active = ['pending', 'queued', 'running'].includes(run.outcome)
  if (!performance) return <section className={styles.panel} aria-labelledby="performance-title"><h2 id="performance-title">Scraper performance</h2><p className={styles.unavailable}>Performance metrics are not available for this run.</p></section>
  const p = performance
  const paused = active && p.sourcePausedUntil !== null && new Date(p.sourcePausedUntil).getTime() > now
  const backlog = run.coverage.filter((row) => row.kind === 'case' && ['queued', 'running'].includes(row.status)).reduce((total, row) => total + row.count, 0)
  // The API estimate covers admitted CASE work, never the undiscovered nationwide workload.
  const estimate = p.etaBasis === 'current_case_backlog' && p.etaSeconds !== null ? duration(p.etaSeconds) : 'Insufficient recent successful samples'
  return <section className={styles.panel} aria-labelledby="performance-title">
    <header className={styles.heading}><div><h2 id="performance-title">Scraper performance</h2><p>Recent throughput · approximately {p.windowMinutes} minutes</p></div><span className={styles.window}>Metrics available since <Timestamp value={p.observedSince} /></span></header>
    {active && p.stalled ? <div className={styles.stalled} role="alert"><Icon name="alert" width={17} height={17} /><div><strong>No recent successful progress</strong><p>This run is stalled. Retry activity does not mean work is completing. Check worker status and source errors.</p></div></div> : null}
    {paused ? <div className={styles.warning} role="status"><Icon name="alert" width={17} height={17} /><div><strong>Source cooldown is active</strong><p>Global source requests are paused until <Timestamp value={p.sourcePausedUntil} />. {(p.sourceRecoverySuccesses ?? 0) > 0 ? `Recovery checks: ${number(p.sourceRecoverySuccesses ?? 0)} of ${number(p.sourceRecoveryRequired ?? 3)} successful. Previous backoff is retained until recovery is confirmed.` : `Consecutive source failures: ${number(p.sourceFailureStreak)}.`}</p></div></div> : null}
    <dl className={styles.throughput} aria-label="Recent throughput">
      <div className={styles.progress}><dt>Case details completed</dt><dd>{number(p.caseDetailsLastHour)}<small>Successful case fetches</small></dd></div>
      <div><dt>Tasks completed</dt><dd>{number(p.successfulTasksLastHour)}<small>All work types</small></dd></div>
      <div><dt>Retries</dt><dd>{number(p.retriedTasksLastHour)}<small>Attempts, not progress</small></dd></div>
      <div><dt>Tasks failed</dt><dd>{number(p.failedTasksLastHour)}<small>Failed task outcomes</small></dd></div>
    </dl>
    <div className={styles.progressDetails}>
      <dl className={styles.facts}>
        <div><dt>Last successful task</dt><dd><Timestamp value={p.lastSuccessfulTaskAt} /></dd></div>
        <div><dt>Last case completed</dt><dd><Timestamp value={p.lastCaseAt} /></dd></div>
        <div><dt>Source failures / task outcomes</dt><dd>{p.sourceErrorRate === null ? 'No recent outcomes' : `${(p.sourceErrorRate * 100).toLocaleString(undefined, { maximumFractionDigits: 1 })}%`} <span>· {number(p.sourceErrorsLastHour)} source failures</span></dd></div>
      </dl>
      <section className={styles.estimate} aria-labelledby="backlog-estimate-title">
        <h3 id="backlog-estimate-title">Admitted case backlog estimate</h3>
        <strong className={styles.estimateValue}>{active ? estimate : 'Run finished'}</strong>
        <p>{number(backlog)} admitted case tasks queued or running. {active ? 'Estimate covers this backlog only.' : 'No remaining-time estimate for a finished run.'}</p>
        <p>Discovery adds work. Source issues can invalidate the estimate. This is not a whole-run finish time.</p>
        <div className={styles.deferred}><strong>{number(p.deferredTasks)}</strong> staged child references <span>Awaiting queue admission; may include duplicates. Not a unique case count.</span></div>
      </section>
    </div>
    {active ? <section className={styles.runtime} aria-labelledby="worker-runtime-title">
      <header><h3 id="worker-runtime-title">Global worker & source pacing</h3><span className={styles.health} data-healthy={p.workerHealthy}>{p.workerHealthy ? 'Worker reporting' : p.workerLastSeen ? 'Worker heartbeat stale' : 'No worker heartbeat'}</span></header>
      {!p.workerHealthy ? <p className={styles.stale}>Runtime values may be stale. Check the worker before relying on throughput or timing.</p> : null}
      <dl className={styles.runtimeFacts}>
        <div><dt>Concurrency limit</dt><dd>{p.workerConcurrency === null ? 'Not available' : number(p.workerConcurrency)}</dd></div>
        <div><dt>Tasks in flight</dt><dd>{p.inFlight === null ? 'Not available' : number(p.inFlight)}</dd></div>
        <div><dt>Configured spacing</dt><dd>{spacing(p.requestIntervalSeconds)}</dd></div>
        <div><dt>Observed spacing</dt><dd>{spacing(p.observedRequestIntervalSeconds)}<small>Includes idle time</small></dd></div>
      </dl>
      <p className={styles.runtimeNote}>Shared across all runs · global request admissions, not per-worker timing. Last heartbeat: <Timestamp value={p.workerLastSeen} />.</p>
    </section> : <p className={styles.runtimeNote}>Finished run · current global worker health and source cooldown are not shown.</p>}
    <p className={styles.footnote}>Minute-bucket counts cover the current and previous {Math.max(0, p.windowMinutes - 1)} minutes. Earlier hourly history is unavailable before metrics were enabled.</p>
  </section>
}
