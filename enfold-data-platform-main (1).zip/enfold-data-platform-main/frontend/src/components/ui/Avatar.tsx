import clsx from 'clsx'
import styles from './Avatar.module.css'

interface AvatarProps {
  initials: string
  tone?: 'ink' | 'orange'
  size?: 'sm' | 'lg'
}

export function Avatar({ initials, tone = 'ink', size = 'sm' }: AvatarProps) {
  return (
    <div
      className={clsx(styles.avatar, tone === 'orange' && styles.orange, size === 'lg' && styles.large)}
      aria-hidden="true"
    >
      {initials}
    </div>
  )
}
