import clsx from 'clsx'
import type { HTMLAttributes, ReactNode } from 'react'
import styles from './Card.module.css'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode
}

export function Card({ className, ...props }: CardProps) {
  return <div className={clsx(styles.card, className)} {...props} />
}

interface CardHeadProps extends HTMLAttributes<HTMLDivElement> {
  title: string
  count?: ReactNode
  headingId?: string
}

export function CardHead({ title, count, headingId, className, ...props }: CardHeadProps) {
  return (
    <div className={clsx(styles.head, className)} {...props}>
      <h3 id={headingId}>{title}</h3>
      {count !== undefined ? <span className={styles.count}>{count}</span> : null}
    </div>
  )
}

export function CardBody({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={clsx(styles.body, className)} {...props} />
}
