import type { ReactNode } from 'react'
import styles from './PageHead.module.css'

interface PageHeadProps {
  title: string
  description?: ReactNode
  actions?: ReactNode
}

export function PageHead({ title, description, actions }: PageHeadProps) {
  return (
    <div className={styles.pageHead}>
      <div>
        <h1>{title}</h1>
        {description ? <p>{description}</p> : null}
      </div>
      {actions}
    </div>
  )
}
