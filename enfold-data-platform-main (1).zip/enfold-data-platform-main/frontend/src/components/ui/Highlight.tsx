import { splitHighlight } from '@/lib/search'

interface HighlightProps {
  value: string
  tokens: string[]
}

export function Highlight({ value, tokens }: HighlightProps) {
  return (
    <>
      {splitHighlight(value, tokens).map((part, i) =>
        part.match ? <mark key={i}>{part.text}</mark> : <span key={i}>{part.text}</span>,
      )}
    </>
  )
}
