import clsx from 'clsx'
import type { HTMLAttributes, ReactNode } from 'react'
import styles from './FieldCard.module.css'

export function FieldCard({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={clsx(styles.fieldCard, className)} {...props} />
}

export function FieldGrid({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={clsx(styles.fieldGrid, className)} {...props} />
}

interface FieldProps {
  label: string
  children: ReactNode
  mono?: boolean
}

export function Field({ label, children, mono = false }: FieldProps) {
  return (
    <div>
      <div className={styles.label}>{label}</div>
      <div className={clsx(styles.value, mono && styles.mono)}>{children}</div>
    </div>
  )
}
