import clsx from 'clsx'
import { STATUS_META } from '@/lib/caseMetadata'
import type { CaseStatus } from '@/types'
import styles from './StatusBadge.module.css'

const TONE: Record<CaseStatus, string> = {
  pending: styles.tonePending,
  disposed: styles.toneDisposed,
  acquitted: styles.toneAcquitted,
  allowed: styles.toneAllowed,
  rejected: styles.toneRejected,
}

interface StatusBadgeProps {
  status: CaseStatus
  prominent?: boolean
}

/** Status is always dot + text so it never relies on colour alone. */
export function StatusBadge({ status, prominent = false }: StatusBadgeProps) {
  return (
    <span
      className={clsx(
        prominent ? styles.prominent : styles.label,
        prominent && TONE[status],
        !prominent && status === 'rejected' && styles.rejectedLabel,
      )}
    >
      <span className={clsx(styles.dot, styles[status])} />
      {STATUS_META[status]?.label ?? status}
    </span>
  )
}
