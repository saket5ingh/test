import clsx from 'clsx'
import styles from './BrandMark.module.css'

interface BrandMarkProps {
  subtitle?: string
  onDark?: boolean
}

export function BrandMark({ subtitle, onDark = false }: BrandMarkProps) {
  return (
    <div className={clsx(styles.brand, onDark && styles.onDark)}>
      <div className={styles.logo} aria-hidden="true">
        e
      </div>
      <div>
        <div className={styles.word}>eCourts Scraper</div>
        {subtitle ? <div className={styles.sub}>{subtitle}</div> : null}
      </div>
    </div>
  )
}
