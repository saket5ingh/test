import clsx from 'clsx'
import { Icon } from '@/components/icons/Icon'
import { FRESHNESS_LABEL } from '@/lib/freshness'
import type { Freshness } from '@/types'
import styles from './Badges.module.css'

export function RestrictedPill({ label = 'Admin-only field' }: { label?: string }) {
  return (
    <span className={styles.restricted}>
      <Icon name="lock" title={label} />
      Restricted
    </span>
  )
}

export function ActTag({ children }: { children: string }) {
  return <span className={styles.actTag}>{children}</span>
}

export function SectionChip({ children }: { children: string }) {
  return <span className={styles.sectionChip}>§ {children}</span>
}

export function FreshnessIndicator({ freshness, text }: { freshness: Freshness; text: string }) {
  return (
    <span className={styles.freshnessCell}>
      <span className={clsx(styles.freshnessDot, styles[freshness])} />
      {text} · {FRESHNESS_LABEL[freshness]}
    </span>
  )
}

export function IllustrativeTag() {
  return <span className={styles.illusTag}>Illustrative</span>
}

interface FilterPillProps {
  label: string
  onRemove: () => void
}

export function FilterPill({ label, onRemove }: FilterPillProps) {
  return (
    <span className={styles.filterPill}>
      {label}
      <button type="button" onClick={onRemove} aria-label={`Remove filter ${label}`}>
        <Icon name="x" />
      </button>
    </span>
  )
}
