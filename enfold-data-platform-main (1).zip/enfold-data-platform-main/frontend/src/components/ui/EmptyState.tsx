import { Icon } from '@/components/icons/Icon'
import styles from './EmptyState.module.css'

interface EmptyStateProps {
  title: string
  description?: string
}

export function EmptyState({ title, description }: EmptyStateProps) {
  return (
    <div className={styles.empty}>
      <Icon name="inbox" />
      <div className={styles.title}>{title}</div>
      {description ? <div className={styles.description}>{description}</div> : null}
    </div>
  )
}
