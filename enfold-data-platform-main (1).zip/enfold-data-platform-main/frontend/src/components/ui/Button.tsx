import clsx from 'clsx'
import type { ButtonHTMLAttributes, Ref } from 'react'
import styles from './Button.module.css'

type ButtonVariant = 'default' | 'primary' | 'subtle'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant
  block?: boolean
  iconOnly?: boolean
  ref?: Ref<HTMLButtonElement>
}

export function Button({
  variant = 'default',
  block = false,
  iconOnly = false,
  className,
  type = 'button',
  ...props
}: ButtonProps) {
  return (
    <button
      type={type}
      className={clsx(
        styles.btn,
        variant === 'primary' && styles.primary,
        variant === 'subtle' && styles.subtle,
        block && styles.block,
        iconOnly && styles.iconOnly,
        className,
      )}
      {...props}
    />
  )
}
