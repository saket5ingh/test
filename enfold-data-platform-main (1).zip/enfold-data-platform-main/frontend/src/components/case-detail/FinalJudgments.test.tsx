import { afterEach, expect, it, vi } from 'vitest'
import { fireEvent, render, screen } from '@testing-library/react'
import { FinalJudgments } from './FinalJudgments'
import { DetailsTab } from './CaseTabs'
import { caseService } from '@/services/caseService'
import { CASES } from '@/services/mock/cases.mock'
import { renderWithProviders, signIn } from '@/test/renderWithProviders'

afterEach(() => { vi.restoreAllMocks(); sessionStorage.clear() })

it.each(['admin', 'user'] as const)('shows downloads below Complex name for %s', async (role) => {
  signIn(role)
  vi.spyOn(caseService, 'finalJudgments').mockResolvedValue([{ id: 'doc', date: '2026-10-08' }])
  renderWithProviders(<DetailsTab caseRecord={CASES[0]} />)
  expect(await screen.findByRole('button', { name: 'Download final judgment' })).toBeEnabled()
  const field = screen.getByText('Final judgment').parentElement!
  expect(field.previousElementSibling).toHaveTextContent('Court name')
  expect(screen.getByText('Complex name')).toBeInTheDocument()
})

it('shows unavailable documents without a dead download button', async () => {
  vi.spyOn(caseService, 'finalJudgments').mockResolvedValue([])
  render(<FinalJudgments caseId="case" />)
  expect(await screen.findByText('No final judgment available yet.')).toBeInTheDocument()
  expect(screen.queryByRole('button')).not.toBeInTheDocument()
})

it('offers retry after a list error', async () => {
  vi.spyOn(caseService, 'finalJudgments').mockRejectedValueOnce(new Error('Network unavailable')).mockResolvedValueOnce([])
  render(<FinalJudgments caseId="case" />)
  fireEvent.click(await screen.findByRole('button', { name: 'Retry' }))
  expect(await screen.findByText('No final judgment available yet.')).toBeInTheDocument()
})

it('reports download errors and lets the user try again', async () => {
  vi.spyOn(caseService, 'finalJudgments').mockResolvedValue([{ id: 'doc', date: null }])
  const download = vi.spyOn(caseService, 'downloadJudgment').mockRejectedValue(new Error('eCourts unavailable'))
  render(<FinalJudgments caseId="case" />)
  fireEvent.click(await screen.findByRole('button', { name: 'Download final judgment' }))
  expect(await screen.findByRole('alert')).toHaveTextContent('eCourts unavailable')
  expect(screen.getByRole('button', { name: 'Download final judgment' })).toBeEnabled()
  expect(download).toHaveBeenCalledWith('case', 'doc', expect.any(AbortSignal))
})
