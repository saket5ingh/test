import type { KeyboardEvent, ReactNode } from 'react'
import styles from './CaseDetail.module.css'

export interface TabDef {
  key: string
  label: string
}

interface TabsProps {
  idPrefix: string
  tabs: TabDef[]
  active: string
  onChange: (key: string) => void
  label: string
}

export function Tabs({ idPrefix, tabs, active, onChange, label }: TabsProps) {
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    const index = tabs.findIndex((t) => t.key === active)
    if (index < 0) return

    let next = index
    if (event.key === 'ArrowRight') next = (index + 1) % tabs.length
    else if (event.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length
    else if (event.key === 'Home') next = 0
    else if (event.key === 'End') next = tabs.length - 1
    else return

    event.preventDefault()
    onChange(tabs[next].key)
    document.getElementById(`${idPrefix}-${tabs[next].key}`)?.focus()
  }

  return (
    <div className={styles.tabs} role="tablist" aria-label={label} onKeyDown={onKeyDown}>
      {tabs.map((tab) => (
        <button
          type="button"
          key={tab.key}
          id={`${idPrefix}-${tab.key}`}
          role="tab"
          className={styles.tab}
          aria-selected={tab.key === active}
          aria-controls={`${idPrefix}-${tab.key}-panel`}
          tabIndex={tab.key === active ? 0 : -1}
          onClick={() => onChange(tab.key)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  )
}

interface TabPanelProps {
  idPrefix: string
  tabKey: string
  active: string
  children: ReactNode
}

export function TabPanel({ idPrefix, tabKey, active, children }: TabPanelProps) {
  if (tabKey !== active) return null
  return (
    <div
      id={`${idPrefix}-${tabKey}-panel`}
      role="tabpanel"
      aria-labelledby={`${idPrefix}-${tabKey}`}
      tabIndex={0}
    >
      {children}
    </div>
  )
}
