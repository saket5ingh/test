import { RestrictedPill, SectionChip } from '@/components/ui/Badges'
import { Field, FieldCard, FieldGrid } from '@/components/ui/FieldCard'
import { useAuth } from '@/context/authState'
import { fmtDate } from '@/lib/format'
import type { Case } from '@/types'
import styles from './CaseDetail.module.css'
import { FinalJudgments } from './FinalJudgments'

export function DetailsTab({ caseRecord: c }: { caseRecord: Case }) {
  const { isAdmin } = useAuth()

  return (
    <>
      <FieldCard>
        <FieldGrid>
          <Field label="Reference" mono>
            {c.ref}
          </Field>
          <Field label="Case type">{c.caseType}</Field>
          <Field label="Registration date">{fmtDate(c.regDate)}</Field>
          <Field label="Date of filing">{fmtDate(c.filingDate)}</Field>
          <Field label="Date of decision">{fmtDate(c.decisionDate)}</Field>
          <Field label="Disposition">{c.dispositionRaw}</Field>
          <Field label="Number of hearings" mono>
            {c.numHearings}
          </Field>
          <Field label="Duration — first to last hearing" mono>
            {c.duration == null ? '—' : `${c.duration} days`}
          </Field>
          <Field label="State / District">
            {c.district}, {c.state}
          </Field>
          <Field label="Complex name">{isAdmin ? c.complex : <RestrictedPill />}</Field>
          <Field label="Court name">{isAdmin ? c.court : <RestrictedPill />}</Field>
          <Field label="Final judgment"><FinalJudgments key={c.id} caseId={c.id} /></Field>
        </FieldGrid>
      </FieldCard>

      <FieldCard style={{ marginTop: 16 }}>
        <h2 className={styles.subheading}>Acts &amp; sections</h2>
        <ul className={styles.actsList}>
          {c.acts.map((a) => (
            <li className={styles.actsItem} key={a.name}>
              <span className={styles.actName}>{a.name}</span>
              <span className={styles.actSections}>
                {a.sections.map((s) => (
                  <SectionChip key={s}>{s}</SectionChip>
                ))}
              </span>
            </li>
          ))}
        </ul>
      </FieldCard>
    </>
  )
}

export function TimelineTab({ caseRecord: c }: { caseRecord: Case }) {
  return (
    <FieldCard>
      <ol className={styles.timeline}>
        {c.hearings
          .slice()
          .reverse()
          .map((h) => (
            <li className={styles.tlItem} key={`${h.date}-${h.purpose}`}>
              <div className={styles.tlDotCol} aria-hidden="true">
                <div className={styles.tlDot} />
                <div className={styles.tlLine} />
              </div>
              <div className={styles.tlContent}>
                <div className={styles.tlDate}>{fmtDate(h.date)}</div>
                <div className={styles.tlPurpose}>{h.purpose}</div>
              </div>
            </li>
          ))}
      </ol>
    </FieldCard>
  )
}
