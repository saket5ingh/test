import { useCallback, useEffect, useRef, useState } from 'react'
import { useResource } from '@/hooks/useResource'
import { caseService } from '@/services/caseService'
import { Button } from '@/components/ui/Button'
import { fmtDate } from '@/lib/format'
import styles from './CaseDetail.module.css'

export function FinalJudgments({ caseId }: { caseId: string }) {
  const [revision, setRevision] = useState(0)
  const load = useCallback((signal: AbortSignal) => caseService.finalJudgments(caseId, signal), [caseId])
  const { data, loading, error } = useResource(`${caseId}:${revision}`, load)
  const [downloading, setDownloading] = useState<string | null>(null)
  const [downloadError, setDownloadError] = useState<string | null>(null)
  const controller = useRef<AbortController | null>(null)
  useEffect(() => () => controller.current?.abort(), [])

  async function download(documentId: string) {
    if (controller.current) return
    const current = new AbortController()
    controller.current = current
    setDownloading(documentId)
    setDownloadError(null)
    try {
      const blob = await caseService.downloadJudgment(caseId, documentId, current.signal)
      if (current.signal.aborted) return
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `final-judgment-${documentId}.pdf`
      document.body.appendChild(link)
      link.click()
      link.remove()
      // Allow the browser to begin reading before releasing the temporary URL.
      window.setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (reason) {
      if (!current.signal.aborted) setDownloadError(reason instanceof Error ? reason.message : 'Download failed. Please try again.')
    } finally {
      controller.current = null
      if (!current.signal.aborted) setDownloading(null)
    }
  }

  if (loading) return <span role="status">Checking availability…</span>
  if (error) return <div><p role="alert">{error}</p><Button onClick={() => setRevision((value) => value + 1)}>Retry</Button></div>
  if (!data?.length) return <span>No final judgment available yet.</span>
  return <div className={styles.judgments}>
    {data.map((item, index) => <div key={item.id}>
      <Button disabled={downloading !== null} onClick={() => void download(item.id)}>
        {downloading === item.id ? 'Downloading…' : 'Download final judgment'}
        {data.length > 1 ? ` ${index + 1}` : ''}
      </Button>
      {item.date ? <span className={styles.judgmentDate}>Order dated {fmtDate(item.date)}</span> : null}
    </div>)}
    {downloading ? <span role="status">Retrieving the document from eCourts…</span> : null}
    {downloadError ? <p role="alert">{downloadError}</p> : null}
  </div>
}
