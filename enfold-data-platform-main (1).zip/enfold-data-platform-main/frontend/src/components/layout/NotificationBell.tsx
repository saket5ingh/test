import { useCallback, useRef, useState } from 'react'
import clsx from 'clsx'
import { useNavigate } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { useAuth } from '@/context/authState'
import { useCases } from '@/context/casesState'
import { useFilters } from '@/context/filtersState'
import { useClickAway } from '@/hooks/useClickAway'
import { relTime } from '@/lib/format'
import styles from './Topbar.module.css'

export function NotificationBell() {
  const navigate = useNavigate()
  const { isAdmin } = useAuth()
  const { updates: summary } = useCases()
  const { setPinnedOnly, clearAll, setScrapeFilter } = useFilters()
  const [open, setOpen] = useState(false)
  const wrapRef = useRef<HTMLDivElement>(null)

  const close = useCallback(() => setOpen(false), [])
  useClickAway(wrapRef, open, close)

  const updates = summary.items
  const hasCritical = summary.critical > 0
  const dotTone = hasCritical ? 'critical' : updates.length ? 'notice' : null

  const label = updates.length
    ? `Updates — ${summary.total} on pinned cases`
    : 'Updates — none right now'

  return (
    <div className={styles.notifWrap} ref={wrapRef}>
      <button
        type="button"
        className={styles.notifBtn}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={label}
        onClick={() => setOpen((v) => !v)}
      >
        <Icon name="bell" />
        {dotTone ? <span className={clsx(styles.notifDot, hasCritical && styles.critical)} /> : null}
      </button>

      <span className="visually-hidden" role="status">
        {label}
      </span>

      {open ? (
        <div className={styles.notifDropdown} role="dialog" aria-label="Updates on pinned cases">
          <div className={styles.groupLabel}>Updates on cases you pinned</div>
          {updates.length ? (
            updates.map((c) => (
              <button
                type="button"
                key={c.id}
                className={clsx(
                  styles.notifRow,
                  c.update!.severity === 'critical' && styles.critical,
                )}
                onClick={() => {
                  close()
                  navigate(`/cases/${c.id}`)
                }}
              >
                <span
                  className={clsx(
                    styles.notifRowDot,
                    c.update!.severity === 'critical' && styles.critical,
                  )}
                />
                <span style={{ minWidth: 0, flex: 1 }}>
                  <span className={styles.notifTitle}>
                    {isAdmin ? c.caseNo : c.ref}{' '}
                    <span className="mono" style={{ fontWeight: 400, color: 'var(--ink-muted)' }}>
                      · {c.district}
                    </span>
                  </span>
                  <span className={styles.notifText} style={{ display: 'block' }}>
                    {c.update!.text}
                  </span>
                  <span className={styles.notifTime} style={{ display: 'block' }}>
                    {relTime(c.update!.at)}
                  </span>
                </span>
              </button>
            ))
          ) : (
            <div className={styles.emptyMsg}>No new updates right now.</div>
          )}
          <button
            type="button"
            className={styles.notifFooter}
            onClick={() => {
              close()
              clearAll()
              setScrapeFilter('all')
              setPinnedOnly(true)
              navigate('/cases')
            }}
          >
            View all pinned cases →
          </button>
        </div>
      ) : null}
    </div>
  )
}
