import { useCallback, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { Avatar } from '@/components/ui/Avatar'
import { useAuth } from '@/context/authState'
import { useClickAway } from '@/hooks/useClickAway'
import styles from './Topbar.module.css'

export function UserMenu() {
  const navigate = useNavigate()
  const { account, isAdmin, logout } = useAuth()
  const [open, setOpen] = useState(false)
  const wrapRef = useRef<HTMLDivElement>(null)

  const close = useCallback(() => setOpen(false), [])
  useClickAway(wrapRef, open, close)

  if (!account) return null

  return (
    <div className={styles.userMenuWrap} ref={wrapRef}>
      <button
        type="button"
        className={styles.userChip}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <Avatar initials={account.initials} tone="orange" />
        <span>
          <span className={styles.name} style={{ display: 'block' }}>
            {account.name}
          </span>
          <span className={styles.role} style={{ display: 'block' }}>
            {isAdmin ? 'Admin' : 'Field Officer'}
          </span>
        </span>
      </button>

      {open ? (
        <div className={styles.userMenu} role="menu" aria-label="Account">
          <div className={styles.userMenuHead}>
            <div className={styles.n}>{account.name}</div>
            <div className={styles.e}>{account.email}</div>
            <div className={styles.userMenuRole}>{isAdmin ? 'Admin access' : 'Standard access'}</div>
          </div>
          <button
            type="button"
            role="menuitem"
            className={styles.menuItem}
            onClick={() => {
              close()
              logout()
              navigate('/login', { replace: true })
            }}
          >
            <Icon name="logout" /> Sign out
          </button>
        </div>
      ) : null}
    </div>
  )
}
