import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '@/context/authState'

export function ProtectedRoute() {
  const { isAuthenticated, initializing } = useAuth()
  const location = useLocation()

  if (initializing) return <p role="status">Checking session…</p>
  if (!isAuthenticated) return <Navigate to="/login" replace state={{ from: location.pathname }} />
  return <Outlet />
}

export function AdminRoute() {
  const { isAdmin } = useAuth()

  if (!isAdmin) return <Navigate to="/dashboard" replace />
  return <Outlet />
}
