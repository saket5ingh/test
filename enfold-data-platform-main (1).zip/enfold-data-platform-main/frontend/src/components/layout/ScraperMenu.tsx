import { useCallback, useEffect, useRef, useState } from 'react'
import clsx from 'clsx'
import { useLocation, useNavigate } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { useClickAway } from '@/hooks/useClickAway'
import { scrapeService } from '@/services/scrapeService'
import styles from './Topbar.module.css'

export function ScraperMenu() {
  const navigate = useNavigate()
  const location = useLocation()
  const [open, setOpen] = useState(false)
  const [hasFailedRun, setHasFailedRun] = useState(false)
  const wrapRef = useRef<HTMLDivElement>(null)

  const close = useCallback(() => setOpen(false), [])
  useClickAway(wrapRef, open, close)

  useEffect(() => {
    let cancelled = false
    scrapeService.listRuns().then((runs) => {
      if (!cancelled) setHasFailedRun(runs.some((r) => r.outcome === 'failed' || r.outcome === 'partial'))
    }).catch(() => { /* Run-history page exposes errors and retry controls. */ })
    return () => {
      cancelled = true
    }
  }, [])

  const active = location.pathname.startsWith('/admin')

  const go = (path: string) => {
    close()
    navigate(path)
  }

  return (
    <div className={styles.scraperNav} ref={wrapRef}>
      <button
        type="button"
        className={clsx(styles.navItem, active && styles.active)}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <Icon name="run" />
        <span className={styles.navLabel}>Scraper</span>
        {hasFailedRun ? (
          <span className={styles.badge} aria-label="A recent scrape run failed">
            !
          </span>
        ) : null}
        <Icon name="chev" />
      </button>

      {open ? (
        <div className={styles.menuPanel} role="menu" aria-label="Scraper">
          <button
            type="button"
            role="menuitem"
            className={styles.menuItem}
            onClick={() => go('/admin/run')}
          >
            <Icon name="bolt" /> Run Custom Scrape
          </button>
          <button
            type="button"
            role="menuitem"
            className={styles.menuItem}
            onClick={() => go('/admin/logs')}
          >
            <Icon name="logs" /> Scrape Run Logs
            {hasFailedRun ? (
              <span className={styles.badge} style={{ marginLeft: 'auto' }}>
                !
              </span>
            ) : null}
          </button>
        </div>
      ) : null}
    </div>
  )
}
