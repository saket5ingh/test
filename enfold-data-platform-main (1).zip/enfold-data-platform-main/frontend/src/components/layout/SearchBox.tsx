import { useFilters } from '@/context/filtersState'
import { useCallback, useEffect, useId, useMemo, useRef, useState, type KeyboardEvent } from 'react'
import clsx from 'clsx'
import { useNavigate } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { Highlight } from '@/components/ui/Highlight'
import { StatusBadge } from '@/components/ui/StatusBadge'
import { useAuth } from '@/context/authState'
import { caseService } from '@/services/caseService'
import { useResource } from '@/hooks/useResource'
import { useClickAway } from '@/hooks/useClickAway'
import { useKeyboardShortcut } from '@/hooks/useKeyboardShortcut'
import { getSuggestions, groupSuggestions, tokenize, type SearchResult } from '@/lib/search'
import styles from './SearchBox.module.css'

export function SearchBox() {
  const navigate = useNavigate()
  const { setSearchQuery, clearAll, setScrapeFilter } = useFilters()
  const { isAdmin } = useAuth()

  const [query, setQuery] = useState('')
  const [open, setOpen] = useState(false)
  const [activeIndex, setActiveIndex] = useState(-1)

  const wrapRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const listboxId = useId()

  const close = useCallback(() => {
    setOpen(false)
    setActiveIndex(-1)
  }, [])

  useClickAway(wrapRef, open, close)
  useKeyboardShortcut('/', () => inputRef.current?.focus())

  const [debouncedQuery, setDebouncedQuery] = useState('')
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 200)
    return () => clearTimeout(timer)
  }, [query])
  const loadSearch = useCallback((signal: AbortSignal) => caseService.listCases({ q: debouncedQuery, pageSize: 6, admin: isAdmin }, signal), [debouncedQuery, isAdmin])
  const search = useResource(`${debouncedQuery}:${isAdmin}`, loadSearch, Boolean(debouncedQuery.trim()))
  const suggestions = useMemo(() => {
    if (query !== debouncedQuery) return []
    return (search.data?.items ?? []).map((row) => getSuggestions([row], query, isAdmin)[0] ?? {
      case: row, score: 0, matchedFields: [], allTokensMatched: true, tokensMatched: tokenize(query).length,
    })
  }, [search.data, query, debouncedQuery, isAdmin])
  const groups = useMemo(() => groupSuggestions(suggestions), [suggestions])
  const flat = useMemo(() => groups.flatMap((g) => g.items), [groups])
  const tokens = useMemo(() => tokenize(query), [query])

  const expanded = open && query.length > 0

  const select = (result: SearchResult) => {
    setQuery('')
    close()
    navigate(`/cases/${result.case.id}?flash=1`)
  }

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Escape') {
      close()
      return
    }
    if (!expanded || !flat.length) {
      if (event.key === 'ArrowDown') setOpen(true)
      return
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault()
      setActiveIndex((i) => (i + 1) % flat.length)
    } else if (event.key === 'ArrowUp') {
      event.preventDefault()
      setActiveIndex((i) => (i <= 0 ? flat.length - 1 : i - 1))
    } else if (event.key === 'Enter') {
      event.preventDefault()
      select(flat[activeIndex >= 0 ? activeIndex : 0])
    }
  }

  const placeholder = isAdmin
    ? 'Find a case — CNR, case no., act, district…'
    : 'Find a case — reference, act, district, section…'

  let optionIndex = -1

  return (
    <div className={styles.wrap} ref={wrapRef}>
      <div className={styles.box}>
        <Icon name="search" />
        <input
          ref={inputRef}
          type="text"
          role="combobox"
          aria-expanded={expanded}
          aria-controls={expanded ? listboxId : undefined}
          aria-autocomplete="list"
          aria-activedescendant={
            activeIndex >= 0 && flat[activeIndex] ? `${listboxId}-opt-${activeIndex}` : undefined
          }
          aria-label="Search cases"
          placeholder={placeholder}
          value={query}
          autoComplete="off"
          maxLength={200}
          onChange={(e) => {
            setQuery(e.target.value)
            setOpen(true)
            setActiveIndex(-1)
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={onKeyDown}
        />
      </div>

      {expanded ? (
        <div className={styles.suggest} id={listboxId} role="listbox" aria-label="Case search results">
          <button type="button" onClick={() => {
            clearAll(); setScrapeFilter('all'); setSearchQuery(query); close(); navigate('/cases')
          }}>View all results for “{query}”</button>
          {flat.length === 0 ? (
            <div className={styles.empty}>
              {search.loading || query !== debouncedQuery ? 'Searching…' : search.error ? 'Search failed. Change your search to retry.' : `No case matches "${query}". Try a district, act name, or section number.`}
            </div>
          ) : (
            groups.map((group) => (
              <div key={group.label} role="group" aria-label={group.label}>
                <div className={styles.groupLabel} aria-hidden="true">
                  {group.label}
                </div>
                {group.items.map((result) => {
                  optionIndex += 1
                  const index = optionIndex
                  const primary = isAdmin ? result.case.cnr : result.case.ref
                  const rest = result.matchedFields.slice(1, 3)
                  return (
                    <div
                      key={result.case.id}
                      id={`${listboxId}-opt-${index}`}
                      role="option"
                      aria-selected={index === activeIndex}
                      className={clsx(styles.option, index === activeIndex && styles.active)}
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => select(result)}
                    >
                      <span className={styles.top}>
                        <span className={styles.primary}>
                          <Highlight value={primary} tokens={tokens} />
                        </span>
                        <span className={styles.district}>{result.case.district}</span>
                        <StatusBadge status={result.case.status} />
                      </span>
                      {rest.length ? (
                        <span className={styles.match}>
                          {rest.map((f, i) => (
                            <span key={f.field}>
                              {i > 0 ? ' · ' : ''}
                              {f.field}: <Highlight value={f.value ?? ''} tokens={tokens} />
                            </span>
                          ))}
                        </span>
                      ) : null}
                    </div>
                  )
                })}
              </div>
            ))
          )}
        </div>
      ) : null}
    </div>
  )
}
