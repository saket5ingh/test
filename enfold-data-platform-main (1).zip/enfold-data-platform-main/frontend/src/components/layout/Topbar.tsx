import clsx from 'clsx'
import { NavLink } from 'react-router-dom'
import { Icon, type IconName } from '@/components/icons/Icon'
import { BrandMark } from '@/components/ui/BrandMark'
import { useAuth } from '@/context/authState'
import { useCases } from '@/context/casesState'
import { scrapeLabel } from '@/lib/freshness'
import { NotificationBell } from './NotificationBell'
import { ScraperMenu } from './ScraperMenu'
import { SearchBox } from './SearchBox'
import { UserMenu } from './UserMenu'
import styles from './Topbar.module.css'

interface NavItemProps {
  to: string
  icon: IconName
  label: string
  badge?: number
  badgeLabel?: string
}

function NavItem({ to, icon, label, badge, badgeLabel }: NavItemProps) {
  return (
    <NavLink to={to} className={({ isActive }) => clsx(styles.navItem, isActive && styles.active)}>
      <Icon name={icon} />
      <span className={styles.navLabel}>{label}</span>
      {badge ? (
        <span className={styles.badge} aria-label={badgeLabel}>
          {badge}
        </span>
      ) : null}
    </NavLink>
  )
}

export function Topbar() {
  const { isAdmin } = useAuth()
  const { updates, scrapes } = useCases()
  const criticalCount = updates.critical
  const updateCount = updates.total

  return (
    <header className={styles.topbar}>
      <div className={styles.left}>
        <BrandMark subtitle="Case monitor" onDark />
        <nav className={styles.nav} aria-label="Primary">
          <NavItem
            to="/dashboard"
            icon="dashboard"
            label="Dashboard"
            badge={criticalCount}
            badgeLabel={`${criticalCount} critical updates`}
          />
          <NavItem
            to="/cases"
            icon="scale"
            label="Cases"
            badge={updateCount}
            badgeLabel={`${updateCount} case updates`}
          />
          {isAdmin ? <ScraperMenu /> : null}
        </nav>
      </div>

      <div className={styles.right}>
        <div className={styles.scrapePill}>
          <span className={styles.pulse} aria-hidden="true" /> Latest scrape ·{' '}
          <b>{scrapes.length ? scrapeLabel(scrapes[0].id) : 'Not available'}</b>
        </div>
        <SearchBox />
        <NotificationBell />
        <UserMenu />
      </div>
    </header>
  )
}
