import { useRemoteList } from '@/hooks/useRemoteList'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { analyticsService } from '@/services/analyticsService'
import { ChartCard } from './ChartCard'
import { AXIS_TICK, CHART_COLORS, OUTCOME_COLORS } from './chartTheme'
import styles from './Charts.module.css'

const TOOLTIP_STYLE = {
  fontSize: 12,
  borderRadius: 3,
  border: `1px solid ${CHART_COLORS.line}`,
  boxShadow: '0 6px 24px rgba(20,20,28,0.09)',
}

export function StateBarChart() {
  const { data, loading, error, retry } = useRemoteList(analyticsService.getByState)
  if (loading) return <p role="status">Loading chart…</p>
  if (error) return <p role="alert">Could not load chart. <button onClick={retry}>Retry</button></p>
  if (!data.length) return <p>No matching child-marriage records available.</p>

  return (
    <ChartCard
      title="Child-marriage cases by state"
      subtitle="Available cases across the approved child-marriage laws; each case counted once"
      dataTable={{
        caption: 'Child-marriage cases by state',
        columns: ['State', 'Cases'],
        rows: data.map((d) => [d.state, d.value]),
      }}
    >
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={data} layout="vertical" margin={{ left: 8, right: 24 }}>
          <CartesianGrid horizontal={false} stroke={CHART_COLORS.line} />
          <XAxis type="number" tick={AXIS_TICK} axisLine={false} tickLine={false} />
          <YAxis
            type="category"
            dataKey="state"
            width={130}
            tick={AXIS_TICK}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip cursor={{ fill: CHART_COLORS.surfaceSunken }} contentStyle={TOOLTIP_STYLE} />
          <Bar dataKey="value" name="Cases" fill={CHART_COLORS.orange} radius={[0, 20, 20, 0]} barSize={10} />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}

export function SectionsBarChart() {
  const { data, loading, error, retry } = useRemoteList(analyticsService.getBySection)
  if (loading) return <p role="status">Loading chart…</p>
  if (error) return <p role="alert">Could not load chart. <button onClick={retry}>Retry</button></p>
  if (!data.length) return <p>No recorded child-marriage sections available.</p>
  const acts = [...new Set(data.map((d) => d.act))]

  return (
    <ChartCard
      title="Sections cited, by Act"
      subtitle="Sections stay separate for each law. A case can cite several sections; cases without recorded sections are excluded."
      dataTable={{
        caption: 'Child-marriage sections by Act',
        columns: ['Act / section', 'Cases'],
        rows: data.map((d) => [`${d.act} — Section ${d.section}`, d.value]),
      }}
    >
      {acts.map((act) => {
        const sections = data.filter((d) => d.act === act)
        return <div key={act}>
          <h3>{act}</h3>
          <ResponsiveContainer width="100%" height={Math.max(120, sections.length * 36 + 35)}>
            <BarChart data={sections} layout="vertical" margin={{ left: 8, right: 24 }}>
              <CartesianGrid horizontal={false} stroke={CHART_COLORS.line} />
              <XAxis type="number" allowDecimals={false} tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="section" width={104} tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: CHART_COLORS.surfaceSunken }} contentStyle={TOOLTIP_STYLE} />
              <Bar dataKey="value" name="Cases" fill={CHART_COLORS.pink} radius={[0, 20, 20, 0]} barSize={10} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      })}
    </ChartCard>
  )
}

export function YearTrendChart() {
  const { data, loading, error, retry } = useRemoteList(analyticsService.getByYear)
  if (loading) return <p role="status">Loading chart…</p>
  if (error) return <p role="alert">Could not load chart. <button onClick={retry}>Retry</button></p>
  if (!data.length) return <p>No matching child-marriage records available.</p>

  return (
    <ChartCard
      title="Child-marriage cases by registration year"
      subtitle="Available cases by registration year; missing years shown as Unknown"
      dataTable={{
        caption: 'Child-marriage cases by registration year',
        columns: ['Year', 'Cases'],
        rows: data.map((d) => [d.year, d.value]),
      }}
    >
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={data} margin={{ left: 8, right: 24, top: 8 }}>
          <CartesianGrid vertical={false} stroke={CHART_COLORS.line} />
          <XAxis dataKey="year" tick={AXIS_TICK} axisLine={false} tickLine={false} />
          <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} width={44} />
          <Tooltip contentStyle={TOOLTIP_STYLE} />
          <Line
            type="linear"
            dataKey="value"
            name="Cases"
            stroke={CHART_COLORS.orange}
            strokeWidth={2.2}
            dot={{ r: 3, fill: CHART_COLORS.orange, strokeWidth: 0 }}
            activeDot={{ r: 5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}

export function OutcomeDonutChart() {
  const { data, loading, error, retry } = useRemoteList(analyticsService.getOutcomes)
  if (loading) return <p role="status">Loading chart…</p>
  if (error) return <p role="alert">Could not load chart. <button onClick={retry}>Retry</button></p>
  if (!data.length) return <p>No matching child-marriage records available.</p>

  const total = data.reduce((sum, d) => sum + d.value, 0)

  return (
    <ChartCard
      title="Child-marriage case outcomes"
      subtitle="Recorded dispositions across approved child-marriage laws, including pending cases"
      dataTable={{
        caption: 'Child-marriage case outcomes',
        columns: ['Outcome', 'Cases'],
        rows: data.map((d) => [d.label, d.value]),
      }}
    >
      <div className={styles.donutWrap}>
        <ResponsiveContainer width={140} height={140}>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="label"
              innerRadius={38}
              outerRadius={54}
              paddingAngle={0}
              startAngle={90}
              endAngle={-270}
              stroke="none"
            >
              {data.map((d) => (
                <Cell key={d.label} fill={OUTCOME_COLORS[d.label] || CHART_COLORS.line} />
              ))}
            </Pie>
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <text x="50%" y="48%" textAnchor="middle" className={styles.donutTotal}>
              {total}
            </text>
            <text x="50%" y="60%" textAnchor="middle" className={styles.donutCaption}>
              cases
            </text>
          </PieChart>
        </ResponsiveContainer>

        <div className={styles.donutLegend}>
          {data.map((d) => (
            <div className={styles.legendRow} key={d.label}>
              <span
                className={styles.legendSwatch}
                style={{ background: OUTCOME_COLORS[d.label] || CHART_COLORS.line }}
              />
              {d.label}
              <span className={styles.legendValue}>{d.value}</span>
            </div>
          ))}
        </div>
      </div>
    </ChartCard>
  )
}
