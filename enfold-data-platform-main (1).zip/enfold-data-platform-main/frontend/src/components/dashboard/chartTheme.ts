/** Recharts needs concrete colours, so these mirror the CSS tokens in styles/tokens.css. */
export const CHART_COLORS = {
  orange: '#D9600F',
  pink: '#C81E63',
  blue: '#3B6FB0',
  ok: '#2E7D4F',
  neutral: '#8A8C92',
  line: '#ECECEF',
  inkFaint: '#74767E',
  inkMuted: '#6C6E76',
  surfaceSunken: '#F7F7F9',
}

export const OUTCOME_COLORS: Record<string, string> = {
  Pending: CHART_COLORS.orange,
  Acquitted: CHART_COLORS.ok,
  Convicted: CHART_COLORS.pink,
  'Compounded / withdrawn': CHART_COLORS.neutral,
  Other: CHART_COLORS.blue,
}

export const AXIS_TICK = { fontSize: 11, fill: CHART_COLORS.inkMuted }
