import { FiltersContext, type FiltersContextValue, type FiltersState, type MultiGroup } from './filtersState'
import {
  useCallback,
  useMemo,
  useReducer,
  type ReactNode,
} from 'react'
import { makeEmptyFilters } from '@/lib/filters'
import type { CaseFilters } from '@/types'

type Action =
  | { type: 'TOGGLE_SET'; group: MultiGroup; value: string }
  | { type: 'TOGGLE_PINNED_ONLY' }
  | { type: 'SET_PINNED_ONLY'; value: boolean }
  | { type: 'REMOVE_CHIP'; group: MultiGroup; value: string }
  | { type: 'CLEAR_ALL' }
  | { type: 'SET_SEARCH'; value: string }
  | { type: 'SET_SCRAPE'; value: string }
  | { type: 'OPEN_DRAWER' }
  | { type: 'CANCEL_DRAFT' }
  | { type: 'APPLY_DRAFT' }
  | { type: 'TOGGLE_DRAFT_SET'; group: MultiGroup; value: string }
  | { type: 'PATCH_DRAFT'; patch: Partial<CaseFilters> }

const toggle = (list: string[], value: string) =>
  list.includes(value) ? list.filter((v) => v !== value) : [...list, value]

function reducer(state: FiltersState, action: Action): FiltersState {
  switch (action.type) {
    case 'TOGGLE_SET': {
      const next = { ...state.filters, [action.group]: toggle(state.filters[action.group], action.value) }
      return { ...state, filters: next, draft: next }
    }
    case 'TOGGLE_PINNED_ONLY': {
      const next = { ...state.filters, pinnedOnly: !state.filters.pinnedOnly }
      return { ...state, filters: next, draft: next }
    }
    case 'SET_PINNED_ONLY': {
      const next = { ...state.filters, pinnedOnly: action.value }
      return { ...state, filters: next, draft: next }
    }
    case 'REMOVE_CHIP': {
      const next = {
        ...state.filters,
        [action.group]: state.filters[action.group].filter((v) => v !== action.value),
      }
      return { ...state, filters: next, draft: next }
    }
    case 'CLEAR_ALL': {
      const next = makeEmptyFilters()
      return { ...state, filters: next, draft: next, searchQuery: '', scrapeFilter: 'all' }
    }
    case 'SET_SEARCH':
      return { ...state, searchQuery: action.value }
    case 'SET_SCRAPE':
      return { ...state, scrapeFilter: action.value }
    case 'OPEN_DRAWER':
      return { ...state, drawerOpen: true, draft: state.filters }
    case 'CANCEL_DRAFT':
      return { ...state, drawerOpen: false, draft: state.filters }
    case 'APPLY_DRAFT':
      return { ...state, drawerOpen: false, filters: state.draft }
    case 'TOGGLE_DRAFT_SET':
      return {
        ...state,
        draft: { ...state.draft, [action.group]: toggle(state.draft[action.group], action.value) },
      }
    case 'PATCH_DRAFT':
      return { ...state, draft: { ...state.draft, ...action.patch } }
    default:
      return state
  }
}

export function FiltersProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, () => {
    const filters = makeEmptyFilters()
    return { filters, draft: filters, scrapeFilter: 'all', searchQuery: '', drawerOpen: false }
  })

  const toggleFilter = useCallback(
    (group: MultiGroup, value: string) => dispatch({ type: 'TOGGLE_SET', group, value }),
    [],
  )
  const togglePinnedOnly = useCallback(() => dispatch({ type: 'TOGGLE_PINNED_ONLY' }), [])
  const setPinnedOnly = useCallback(
    (value: boolean) => dispatch({ type: 'SET_PINNED_ONLY', value }),
    [],
  )
  const removeChip = useCallback(
    (group: MultiGroup, value: string) => dispatch({ type: 'REMOVE_CHIP', group, value }),
    [],
  )
  const clearAll = useCallback(() => dispatch({ type: 'CLEAR_ALL' }), [])
  const setSearchQuery = useCallback((value: string) => dispatch({ type: 'SET_SEARCH', value }), [])
  const setScrapeFilter = useCallback((value: string) => dispatch({ type: 'SET_SCRAPE', value }), [])
  const openDrawer = useCallback(() => dispatch({ type: 'OPEN_DRAWER' }), [])
  const cancelDraft = useCallback(() => dispatch({ type: 'CANCEL_DRAFT' }), [])
  const applyDraft = useCallback(() => dispatch({ type: 'APPLY_DRAFT' }), [])
  const toggleDraftFilter = useCallback(
    (group: MultiGroup, value: string) => dispatch({ type: 'TOGGLE_DRAFT_SET', group, value }),
    [],
  )
  const patchDraft = useCallback(
    (patch: Partial<CaseFilters>) => dispatch({ type: 'PATCH_DRAFT', patch }),
    [],
  )

  const value = useMemo<FiltersContextValue>(
    () => ({
      ...state,
      toggleFilter,
      togglePinnedOnly,
      setPinnedOnly,
      removeChip,
      clearAll,
      setSearchQuery,
      setScrapeFilter,
      openDrawer,
      cancelDraft,
      applyDraft,
      toggleDraftFilter,
      patchDraft,
    }),
    [
      state,
      toggleFilter,
      togglePinnedOnly,
      setPinnedOnly,
      removeChip,
      clearAll,
      setSearchQuery,
      setScrapeFilter,
      openDrawer,
      cancelDraft,
      applyDraft,
      toggleDraftFilter,
      patchDraft,
    ],
  )

  return <FiltersContext value={value}>{children}</FiltersContext>
}
