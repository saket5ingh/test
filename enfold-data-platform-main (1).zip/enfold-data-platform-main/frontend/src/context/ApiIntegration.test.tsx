import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/renderWithProviders'
import { useAuth } from './authState'
import { useCases } from './casesState'
import { CASES } from '@/services/mock/cases.mock'
import { tokenStore } from '@/services/http'

vi.mock('@/services/config', () => ({ API_BASE_URL: '/api', USE_MOCK: false, delay: (value: unknown) => Promise.resolve(value) }))

const officer = { name: 'Officer', email: 'officer@example.org', role: 'user', roleLabel: 'Officer', initials: 'OF' }
const admin = { ...officer, email: 'admin@example.org', role: 'admin' }
const row = { ...CASES[0], dispositionRaw: null, lastPurpose: null, pinned: false }
let failPin = false
let failCases = false
let currentAccount = officer
let calls: string[] = []

function Harness() {
  const { account, login, logout } = useAuth()
  const { cases, error, togglePin } = useCases()
  return <>
    <p>Account: {account?.email ?? 'anonymous'}</p>
    <p>Cases: {cases.length}</p>
    <p>Pin: {String(cases[0]?.pinned ?? false)}</p>
    <button onClick={() => void login({ userId: 'officer', password: 'password' })}>Login officer</button>
    <button onClick={() => void login({ userId: 'admin', password: 'password' })}>Login admin</button>
    <button onClick={logout}>Logout</button>
    <button onClick={() => togglePin(row.id)}>Toggle pin</button>
    {error ? <p role="alert">{error}</p> : null}
  </>
}

beforeEach(() => {
  sessionStorage.clear()
  tokenStore.set(null)
  failPin = false
  failCases = false
  currentAccount = officer
  calls = []
  vi.stubGlobal('fetch', vi.fn(async (url: string, init: RequestInit) => {
    calls.push(`${init?.method ?? 'GET'} ${url}`)
    if (url === '/api/auth/login') {
      currentAccount = JSON.parse(init.body as string).userId === 'admin' ? admin : officer
      return Response.json({ account: currentAccount, token: currentAccount.email })
    }
    if (url === '/api/auth/me') return Response.json(currentAccount)
    if (url.startsWith('/api/cases?')) return failCases ? Response.json({ detail: 'Expired' }, { status: 401 }) : Response.json({ items: [row], total: 1, page: 1, pageSize: 25 })
    if (url === '/api/options') return Response.json({ totalCases: 1, districts: [], acts: [], caseTypes: [], purposes: [], complexes: [], courts: [] })
    if (url === '/api/cases/updates') return Response.json({ items: [], total: 0, critical: 0 })
    if (url === '/api/scrapes') return Response.json([{ id: '2026-09', label: 'September 2026', short: 'Sep 2026', date: '2026-09-01' }])
    if (url.endsWith('/pin')) return failPin ? Response.json({ detail: 'Save failed' }, { status: 500 }) : new Response(null, { status: 204 })
    throw new Error(`Unexpected request: ${url}`)
  }))
})
afterEach(() => { vi.unstubAllGlobals(); tokenStore.set(null) })

describe('API-mode authentication and cases', () => {
  it('waits for authentication, then loads cases without a page reload', async () => {
    const user = userEvent.setup()
    renderWithProviders(<Harness />)
    expect(calls).toEqual([])
    await user.click(screen.getByText('Login officer'))
    expect(await screen.findByText('Cases: 1')).toBeInTheDocument()
    expect(calls.some((c) => c.startsWith('GET /api/cases?'))).toBe(true)
  })

  it('clears cases on logout and reloads for a different account', async () => {
    const user = userEvent.setup()
    renderWithProviders(<Harness />)
    await user.click(screen.getByText('Login officer'))
    await screen.findByText('Cases: 1')
    await user.click(screen.getByText('Logout'))
    expect(screen.getByText('Cases: 0')).toBeInTheDocument()
    await user.click(screen.getByText('Login admin'))
    await screen.findByText('Account: admin@example.org')
    await screen.findByText('Cases: 1')
    expect(calls.filter((c) => c.startsWith('GET /api/cases?'))).toHaveLength(2)
  })

  it('rolls back a failed pin save and explains the failure', async () => {
    failPin = true
    const user = userEvent.setup()
    renderWithProviders(<Harness />)
    await user.click(screen.getByText('Login officer'))
    await screen.findByText('Cases: 1')
    await user.click(screen.getByText('Toggle pin'))
    expect(await screen.findByRole('alert')).toHaveTextContent('Could not save this pin')
    expect(screen.getByText('Pin: false')).toBeInTheDocument()
  })

  it('clears the session when an authenticated request returns 401', async () => {
    failCases = true
    const user = userEvent.setup()
    renderWithProviders(<Harness />)
    await user.click(screen.getByText('Login officer'))
    await waitFor(() => expect(screen.getByText('Account: anonymous')).toBeInTheDocument())
    expect(sessionStorage.getItem('ecourts.session')).toBeNull()
    expect(tokenStore.get()).toBeNull()
  })
})
