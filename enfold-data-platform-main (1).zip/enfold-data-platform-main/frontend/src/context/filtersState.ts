import { createContext, useContext } from 'react'
import type { CaseFilters, FilterGroup } from '@/types'
export type MultiGroup = FilterGroup | 'complex' | 'court'

export interface FiltersState {
  filters: CaseFilters
  /** Uncommitted drawer edits — discarded unless the user hits Apply. */
  draft: CaseFilters
  searchQuery: string
  scrapeFilter: string
  drawerOpen: boolean
}

export interface FiltersContextValue extends FiltersState {
  toggleFilter: (group: MultiGroup, value: string) => void
  togglePinnedOnly: () => void
  setPinnedOnly: (value: boolean) => void
  removeChip: (group: MultiGroup, value: string) => void
  clearAll: () => void
  setSearchQuery: (value: string) => void
  setScrapeFilter: (value: string) => void
  openDrawer: () => void
  cancelDraft: () => void
  applyDraft: () => void
  toggleDraftFilter: (group: MultiGroup, value: string) => void
  patchDraft: (patch: Partial<CaseFilters>) => void
}

export const FiltersContext = createContext<FiltersContextValue | null>(null)

export function useFilters(): FiltersContextValue {
  const ctx = useContext(FiltersContext)
  if (!ctx) throw new Error('useFilters must be used within FiltersProvider')
  return ctx
}
