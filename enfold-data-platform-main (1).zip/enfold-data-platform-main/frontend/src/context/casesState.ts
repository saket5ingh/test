import { createContext, useContext } from 'react'
import type { Case, Scrape } from '@/types'
import type { CaseOptions, CaseUpdates } from '@/services/caseService'
export interface CasesContextValue {
  cases: Case[]; scrapes: Scrape[]; options: CaseOptions; updates: CaseUpdates
  total: number; page: number; pageSize: number; setPage: (page: number) => void
  loading: boolean; error: string | null; revision: number
  reload: () => void; togglePin: (id: string, target?: Case) => Promise<void>
}
export const CasesContext = createContext<CasesContextValue | null>(null)
export function useCases(): CasesContextValue {
  const ctx = useContext(CasesContext)
  if (!ctx) throw new Error('useCases must be used within CasesProvider')
  return ctx
}
