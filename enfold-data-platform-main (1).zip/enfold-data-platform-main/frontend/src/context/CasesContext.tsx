import { useCallback, useRef, useState, type ReactNode } from 'react'
import { caseService, EMPTY_OPTIONS } from '@/services/caseService'
import { useAuth } from './authState'
import { useFilters } from './filtersState'
import { CasesContext } from './casesState'
import { useResource } from '@/hooks/useResource'
import type { Case } from '@/types'

export function CasesProvider({ children }: { children: ReactNode }) {
  const { account, isAuthenticated, isAdmin } = useAuth()
  const { filters, scrapeFilter, searchQuery } = useFilters()
  const [revision, setRevision] = useState(0)
  const [pinError, setPinError] = useState<{ identity: string; text: string }>()
  const identity = `${account?.email}:${account?.role}`
  const filterKey = JSON.stringify([identity, filters, scrapeFilter, searchQuery])
  const [cursor, setCursor] = useState({ filterKey: '', page: 1 })
  const page = cursor.filterKey === filterKey ? cursor.page : 1
  const pageSize = 25
  const setPage = (next: number) => setCursor({ filterKey, page: Math.max(1, next) })
  const queryKey = JSON.stringify([filterKey, page, revision])
  const loadPage = useCallback(async (signal: AbortSignal) => {
    const data = await caseService.listCases({ ...filters, q: searchQuery, scrape: scrapeFilter, page, pageSize, admin: isAdmin }, signal)
    const lastPage = Math.max(1, Math.ceil(data.total / pageSize))
    // Unpinning the final row of a filtered page may remove that page entirely.
    if (!signal.aborted && page > lastPage) setCursor({ filterKey, page: lastPage })
    return data
  }, [filters, scrapeFilter, searchQuery, page, isAdmin, filterKey, setCursor])
  const list = useResource(queryKey, loadPage, isAuthenticated)
  const loadMetadata = useCallback(async (signal: AbortSignal) => {
    const [scrapes, options, updates] = await Promise.all([caseService.listScrapes(signal), caseService.options(signal), caseService.updates(signal)])
    return { scrapes, options, updates }
  }, [])
  const meta = useResource(`${identity}:${revision}`, loadMetadata, isAuthenticated)
  const reload = useCallback(() => { setPinError(undefined); setRevision((v) => v + 1) }, [])
  const saving = useRef(new Set<string>())
  const togglePin = async (id: string, supplied?: Case) => {
    const target = supplied ?? list.data?.items.find((c) => c.id === id)
    const saveKey = `${identity}:${id}`
    if (!target || !isAuthenticated || saving.current.has(saveKey)) return
    saving.current.add(saveKey)
    setPinError(undefined)
    try { await caseService.setPinned(id, !target.pinned); setRevision((v) => v + 1) }
    catch { setPinError({ identity, text: 'Could not save this pin. Please try again.' }) }
    finally { saving.current.delete(saveKey) }
  }
  return <CasesContext value={{ cases: list.data?.items ?? [], total: list.data?.total ?? 0,
    page, pageSize, setPage, scrapes: meta.data?.scrapes ?? [], options: meta.data?.options ?? EMPTY_OPTIONS,
    updates: meta.data?.updates ?? { items: [], total: 0, critical: 0 },
    loading: list.loading || meta.loading, error: (isAuthenticated && pinError?.identity === identity ? pinError.text : null) ?? list.error ?? meta.error ?? null,
    revision, reload, togglePin }}>{children}</CasesContext>
}
