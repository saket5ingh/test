import { AuthContext, type AuthContextValue } from './authState'
import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react'
import { USE_MOCK } from '@/services/config'
import { onUnauthorized, tokenStore } from '@/services/http'
import { authService } from '@/services/authService'
import { isAdmin as isAdminRole } from '@/lib/rbac'
import type { Account, Credentials } from '@/types'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [account, setAccount] = useState<Account | null>(() => authService.restore()?.account ?? null)

  const [initializing, setInitializing] = useState(() => !USE_MOCK && account !== null)

  useEffect(() => {
    let cancelled = false
    const originalToken = tokenStore.get()
    if (!USE_MOCK && originalToken) {
      authService.currentAccount().then((current) => {
        if (!cancelled && tokenStore.get() === originalToken) setAccount(current)
      }).catch(() => {
        if (!cancelled && tokenStore.get() === originalToken) {
          authService.logout()
          setAccount(null)
        }
      }).finally(() => { if (!cancelled) setInitializing(false) })
    }
    return () => { cancelled = true }
  }, [])

  const login = useCallback(async (credentials: Credentials) => {
    const session = await authService.login(credentials)
    setAccount(session.account)
    setInitializing(false)
  }, [])

  const googleLogin = useCallback(async (credential: string) => {
    const session = await authService.googleLogin(credential)
    setAccount(session.account)
    setInitializing(false)
  }, [])

  const selectAccount = useCallback(async (email: string) => {
    const session = await authService.selectAccount(email)
    setAccount(session.account)
    setInitializing(false)
  }, [])

  const logout = useCallback(() => {
    authService.logout()
    setAccount(null)
    setInitializing(false)
  }, [])

  useEffect(() => onUnauthorized(logout), [logout])

  const value = useMemo<AuthContextValue>(
    () => ({
      account,
      isAuthenticated: account !== null && !initializing,
      initializing,
      isAdmin: isAdminRole(account),
      login,
      googleLogin,
      selectAccount,
      logout,
    }),
    [account, initializing, login, googleLogin, selectAccount, logout],
  )

  return <AuthContext value={value}>{children}</AuthContext>
}
