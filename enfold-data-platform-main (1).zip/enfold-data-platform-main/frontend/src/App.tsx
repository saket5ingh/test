import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from '@/context/AuthContext'
import { useAuth } from '@/context/authState'
import { CasesProvider } from '@/context/CasesContext'
import { FiltersProvider } from '@/context/FiltersContext'
import { AppRoutes } from '@/router'

export function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AccountScope />
      </AuthProvider>
    </BrowserRouter>
  )
}

function AccountScope() {
  const { account } = useAuth()
  const identity = `${account?.email ?? 'anonymous'}:${account?.role ?? ''}`
  return (
    <FiltersProvider key={identity}><CasesProvider><AppRoutes /></CasesProvider></FiltersProvider>
  )
}
