import type { ReactElement } from 'react'
import { render } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { AuthProvider } from '@/context/AuthContext'
import { CasesProvider } from '@/context/CasesContext'
import { FiltersProvider } from '@/context/FiltersContext'
import { ACCOUNTS } from '@/services/mock/accounts.mock'
import type { Role } from '@/types'

export function signIn(role: Role) {
  const account = ACCOUNTS.find((a) => a.role === role)!
  sessionStorage.setItem('ecourts.session', JSON.stringify({ account, token: 'test-token' }))
}

export function renderWithProviders(ui: ReactElement, { route = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <FiltersProvider><CasesProvider>{ui}</CasesProvider></FiltersProvider>
      </AuthProvider>
    </MemoryRouter>,
  )
}
