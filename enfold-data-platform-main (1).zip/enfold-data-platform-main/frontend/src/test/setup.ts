import '@testing-library/jest-dom/vitest'
import { afterEach, expect, vi } from 'vitest'
import { toHaveNoViolations } from 'jest-axe'

expect.extend(toHaveNoViolations)

afterEach(() => sessionStorage.clear())
window.scrollTo = vi.fn()
