import { ACT_OPTIONS } from '@/lib/caseMetadata'
import type { Case, CaseFilters, UpdateSeverity } from '@/types'

export function makeEmptyFilters(): CaseFilters {
  return {
    status: [],
    district: [],
    acts: [],
    caseType: [],
    purpose: [],
    pinnedOnly: false,
    regYearFrom: '',
    regYearTo: '',
    filingFrom: '',
    filingTo: '',
    decisionFrom: '',
    decisionTo: '',
    complex: [],
    court: [],
  }
}

export function caseActKeys(c: Case): string[] {
  return ACT_OPTIONS.filter((o) => c.acts.some((a) => o.match(a.name))).map((o) => o.key)
}

const inRange = (value: string | null, from: string, to: string) => {
  if (!from && !to) return true
  if (!value) return false
  if (from && value < from) return false
  if (to && value > to) return false
  return true
}

export function applyFilters(list: Case[], f: CaseFilters): Case[] {
  return list.filter((c) => {
    if (f.status.length && !f.status.includes(c.status)) return false
    if (f.district.length && !f.district.includes(c.district)) return false
    if (f.caseType.length && !f.caseType.includes(c.caseTypeClass)) return false
    if (f.acts.length) {
      const keys = [...caseActKeys(c), ...c.acts.map((a) => a.name)]
      if (!f.acts.some((k) => keys.includes(k))) return false
    }
    if (f.pinnedOnly && !c.pinned) return false
    if (f.purpose.length && !f.purpose.includes(c.lastPurpose)) return false
    if (f.complex.length && !f.complex.includes(c.complex)) return false
    if (f.court.length && !f.court.includes(c.court)) return false
    if (f.regYearFrom && (c.regYear == null || c.regYear < Number(f.regYearFrom))) return false
    if (f.regYearTo && (c.regYear == null || c.regYear > Number(f.regYearTo))) return false
    if (!inRange(c.filingDate, f.filingFrom, f.filingTo)) return false
    if (!inRange(c.decisionDate, f.decisionFrom, f.decisionTo)) return false
    return true
  })
}

export function getUpdates(cases: Case[]): Case[] {
  const sevRank = (s: UpdateSeverity) => (s === 'critical' ? 0 : 1)
  return cases
    .filter((c) => c.pinned && c.update)
    .sort(
      (a, b) =>
        sevRank(a.update!.severity) - sevRank(b.update!.severity) ||
        b.update!.at.localeCompare(a.update!.at),
    )
}

export function getCriticalUpdates(cases: Case[]): Case[] {
  return getUpdates(cases).filter((c) => c.update!.severity === 'critical')
}

export function sortForAttention(list: Case[]): Case[] {
  const rank = (c: Case) => (c.update ? (c.update.severity === 'critical' ? 0 : 1) : 2)
  return list
    .slice()
    .sort(
      (a, b) =>
        rank(a) - rank(b) ||
        (b.lastScrape ?? '').localeCompare(a.lastScrape ?? '') ||
        (b.regDate ?? '').localeCompare(a.regDate ?? ''),
    )
}

export function rowAccent(c: Case): UpdateSeverity | null {
  return c.update ? c.update.severity : null
}
