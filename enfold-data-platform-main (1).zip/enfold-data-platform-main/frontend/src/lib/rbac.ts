import type { Account } from '@/types'

/** Fields hidden from field officers and shown only to admins. */
export type RestrictedField = 'cnr' | 'caseNo' | 'regNo' | 'complex' | 'court'

export function isAdmin(account: Account | null): boolean {
  return account?.role === 'admin'
}

export function canSee(account: Account | null, _field: RestrictedField): boolean {
  return isAdmin(account)
}
