import { describe, expect, it } from 'vitest'
import { countBy, fmtDate, relTime } from '@/lib/format'
import { freshnessOf, scrapeLabel } from '@/lib/freshness'
import { canSee, isAdmin } from '@/lib/rbac'
import type { Account } from '@/types'

const admin: Account = {
  name: 'Rahul Nair',
  role: 'admin',
  roleLabel: 'Data Operations Admin',
  email: 'rahul.nair@cwc-fieldops.org',
  initials: 'RN',
}
const officer: Account = { ...admin, role: 'user' }

describe('relTime', () => {
  it('formats minutes, hours, days and months', () => {
    expect(relTime('2026-08-20T08:30:00', new Date('2026-08-20T09:00:00'))).toBe('30m ago')
    expect(relTime('2026-08-20T04:00:00', new Date('2026-08-20T09:00:00'))).toBe('5h ago')
    expect(relTime('2026-08-10T09:00:00', new Date('2026-08-20T09:00:00'))).toBe('10d ago')
    expect(relTime('2026-05-20T09:00:00', new Date('2026-08-20T09:00:00'))).toBe('3mo ago')
  })
})

describe('fmtDate', () => {
  it('formats an ISO date', () => {
    expect(fmtDate('2025-08-11')).toBe('11 Aug 2025')
  })

  it('renders an em dash for missing dates', () => {
    expect(fmtDate(null)).toBe('—')
  })
})

describe('countBy', () => {
  it('tallies by the key function', () => {
    expect(countBy(['a', 'b', 'a'], (v) => v)).toEqual({ a: 2, b: 1 })
  })
})

describe('freshnessOf', () => {
  it('classifies the latest scrape as fresh', () => {
    expect(freshnessOf({ lastScrape: '2026-08' }, '2026-08')).toBe('fresh')
  })

  it('classifies one scrape back as aging', () => {
    expect(freshnessOf({ lastScrape: '2026-07' }, '2026-08')).toBe('aging')
  })

  it('classifies two or more scrapes back as stale', () => {
    expect(freshnessOf({ lastScrape: '2026-06' }, '2026-08')).toBe('stale')
    expect(freshnessOf({ lastScrape: '2026-05' }, '2026-08')).toBe('stale')
  })

  it('does not mark an unknown scrape as fresh', () => {
    expect(freshnessOf({ lastScrape: 'nope' }, '2026-08')).toBe('stale')
  })
})

describe('scrape labels', () => {
  it('resolves known ids and falls back to the id', () => {
    expect(scrapeLabel('2026-08')).toBe('August 2026')
    expect(scrapeLabel('unknown')).toBe('unknown')
  })
})

describe('rbac', () => {
  it('only grants admins access to restricted fields', () => {
    expect(isAdmin(admin)).toBe(true)
    expect(isAdmin(officer)).toBe(false)
    expect(isAdmin(null)).toBe(false)
    expect(canSee(admin, 'cnr')).toBe(true)
    expect(canSee(officer, 'cnr')).toBe(false)
  })
})
