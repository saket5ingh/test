import { describe, expect, it } from 'vitest'
import { applyFilters, caseActKeys, makeEmptyFilters, sortForAttention } from '@/lib/filters'
import { CASES } from '@/services/mock/cases.mock'

const withFilters = (patch: Partial<ReturnType<typeof makeEmptyFilters>>) => ({
  ...makeEmptyFilters(),
  ...patch,
})

describe('applyFilters', () => {
  it('returns everything when no filter is set', () => {
    expect(applyFilters(CASES, makeEmptyFilters())).toHaveLength(CASES.length)
  })

  it('filters by status', () => {
    const result = applyFilters(CASES, withFilters({ status: ['pending'] }))
    expect(result.length).toBeGreaterThan(0)
    expect(result.every((c) => c.status === 'pending')).toBe(true)
  })

  it('treats multiple values in one group as OR', () => {
    const result = applyFilters(CASES, withFilters({ status: ['pending', 'rejected'] }))
    expect(result.every((c) => c.status === 'pending' || c.status === 'rejected')).toBe(true)
    expect(result.length).toBeGreaterThan(
      applyFilters(CASES, withFilters({ status: ['pending'] })).length,
    )
  })

  it('treats separate groups as AND', () => {
    const result = applyFilters(CASES, withFilters({ status: ['pending'], district: ['Patna'] }))
    expect(result).toHaveLength(0)
  })

  it('matches acts through the act matchers', () => {
    const result = applyFilters(CASES, withFilters({ acts: ['childmarriage'] }))
    expect(result.every((c) => caseActKeys(c).includes('childmarriage'))).toBe(true)
  })

  it('filters to pinned cases only', () => {
    const result = applyFilters(CASES, withFilters({ pinnedOnly: true }))
    expect(result.every((c) => c.pinned)).toBe(true)
  })

  it('applies the registration year range', () => {
    const result = applyFilters(CASES, withFilters({ regYearFrom: '2025', regYearTo: '2025' }))
    expect(result.every((c) => c.regYear === 2025)).toBe(true)
  })

  it('excludes cases without a decision date when a decision range is set', () => {
    const result = applyFilters(CASES, withFilters({ decisionFrom: '2020-01-01' }))
    expect(result.every((c) => c.decisionDate !== null)).toBe(true)
  })

  it('filters by admin-only court identifiers', () => {
    const result = applyFilters(CASES, withFilters({ court: ['Special POCSO Court'] }))
    expect(result.every((c) => c.court === 'Special POCSO Court')).toBe(true)
  })
})

describe('sortForAttention', () => {
  it('puts critical updates first, then info, then the rest', () => {
    const sorted = sortForAttention(CASES)
    const rank = sorted.map((c) => (c.update ? (c.update.severity === 'critical' ? 0 : 1) : 2))
    expect(rank).toEqual([...rank].sort((a, b) => a - b))
  })

  it('does not mutate the input array', () => {
    const input = CASES.slice(0, 3)
    const snapshot = input.map((c) => c.id)
    sortForAttention(input)
    expect(input.map((c) => c.id)).toEqual(snapshot)
  })
})
