import { describe, expect, it } from 'vitest'
import { getSuggestions, splitHighlight, groupSuggestions, tokenize } from '@/lib/search'
import { CASES } from '@/services/mock/cases.mock'

describe('tokenize', () => {
  it('lowercases and splits on whitespace', () => {
    expect(tokenize('  Patna   POCSO ')).toEqual(['patna', 'pocso'])
  })

  it('returns an empty list for blank input', () => {
    expect(tokenize('   ')).toEqual([])
  })
})

describe('getSuggestions', () => {
  it('returns nothing for an empty query', () => {
    expect(getSuggestions(CASES, '', true)).toEqual([])
  })

  it('finds a case by CNR for admins', () => {
    const results = getSuggestions(CASES, 'BRGA010125162025', true)
    expect(results[0].case.id).toBe('c1')
  })

  it('does not expose CNR matches to field officers', () => {
    expect(getSuggestions(CASES, 'BRGA010125162025', false)).toHaveLength(0)
  })

  it('finds a case by anonymized reference for field officers', () => {
    const results = getSuggestions(CASES, 'PCMA-BR-0001', false)
    expect(results[0].case.id).toBe('c1')
  })

  it('prefers cases matching every token', () => {
    const results = getSuggestions(CASES, 'patna pocso', true)
    expect(results.every((r) => r.allTokensMatched)).toBe(true)
    expect(results[0].case.district).toBe('Patna')
  })

  it('caps results at six', () => {
    expect(getSuggestions(CASES, 'bihar', true).length).toBeLessThanOrEqual(6)
  })
})

describe('splitHighlight', () => {
  it('marks the matched run', () => {
    expect(splitHighlight('Patna', ['pat'])).toEqual([
      { text: 'Pat', match: true },
      { text: 'na', match: false },
    ])
  })

  it('merges overlapping token matches', () => {
    expect(splitHighlight('abcd', ['ab', 'bc'])).toEqual([
      { text: 'abc', match: true },
      { text: 'd', match: false },
    ])
  })

  it('returns the whole value when nothing matches', () => {
    expect(splitHighlight('Patna', ['xyz'])).toEqual([{ text: 'Patna', match: false }])
  })
})

describe('groupSuggestions', () => {
  it('groups by the first matched field category', () => {
    const groups = groupSuggestions(getSuggestions(CASES, 'gaya', true))
    expect(groups.map((g) => g.label)).toContain('District')
  })
})
