import { STATUS_META } from '@/lib/caseMetadata'
import type { Case } from '@/types'

export interface SearchField {
  field: string
  value: string | null
  exact?: boolean
}

export interface SearchResult {
  case: Case
  score: number
  matchedFields: SearchField[]
  allTokensMatched: boolean
  tokensMatched: number
}

export interface SuggestionGroup {
  label: string
  items: SearchResult[]
}

export interface HighlightPart {
  text: string
  match: boolean
}

export function tokenize(query: string): string[] {
  return query.toLowerCase().trim().split(/\s+/).filter(Boolean)
}

/** Field officers search anonymized references; admins search real identifiers. */
export function searchFields(c: Case, admin: boolean): SearchField[] {
  const fields: SearchField[] = []
  if (admin) {
    fields.push({ field: 'CNR Number', value: c.cnr, exact: true })
    fields.push({ field: 'Case Number', value: c.caseNo, exact: true })
    fields.push({ field: 'Registration Number', value: `${c.regNo}/${c.regYear}`, exact: true })
  } else {
    fields.push({ field: 'Reference', value: c.ref, exact: true })
  }
  fields.push({ field: 'District', value: c.district })
  fields.push({ field: 'Case type', value: c.caseType })
  fields.push({ field: 'Disposition', value: c.dispositionRaw })
  fields.push({ field: 'Status', value: STATUS_META[c.status]?.label ?? c.status })
  fields.push({ field: 'Last purpose', value: c.lastPurpose })
  if (admin) {
    fields.push({ field: 'Complex', value: c.complex })
    fields.push({ field: 'Court', value: c.court })
  }
  for (const a of c.acts) {
    fields.push({ field: 'Act', value: a.name })
    fields.push({ field: 'Section', value: a.sections.join(', ') })
  }
  return fields
}

export function getSuggestions(cases: Case[], query: string, admin: boolean): SearchResult[] {
  const tokens = tokenize(query)
  if (!tokens.length) return []

  const results = cases
    .map((c) => {
      const fields = searchFields(c, admin)
      let score = 0
      const matchedFields: SearchField[] = []

      for (const tok of tokens) {
        let tokenMatched = false
        for (const f of fields) {
          const v = (f.value ?? '').toLowerCase()
          if (v.includes(tok)) {
            tokenMatched = true
            if (!matchedFields.some((m) => m.field === f.field && m.value === f.value)) {
              matchedFields.push(f)
            }
            if (f.exact && v === tok) score += 50
          }
        }
        if (tokenMatched) score += 10
      }

      const tokensMatched = tokens.filter((tok) =>
        fields.some((f) => (f.value ?? '').toLowerCase().includes(tok)),
      ).length

      return {
        case: c,
        score,
        matchedFields,
        allTokensMatched: tokensMatched === tokens.length,
        tokensMatched,
      }
    })
    .filter((r) => r.tokensMatched > 0)

  const withAll = results.filter((r) => r.allTokensMatched)
  const pool = withAll.length ? withAll : results
  return pool.sort((a, b) => b.score - a.score).slice(0, 6)
}

/** Splits a value into matched/unmatched runs so React can render <mark> safely. */
export function splitHighlight(value: string, tokens: string[]): HighlightPart[] {
  if (!tokens.length) return [{ text: value, match: false }]

  const lower = value.toLowerCase()
  const ranges: Array<[number, number]> = []
  for (const tok of tokens) {
    let from = 0
    let idx = lower.indexOf(tok, from)
    while (idx >= 0) {
      ranges.push([idx, idx + tok.length])
      from = idx + tok.length
      idx = lower.indexOf(tok, from)
    }
  }
  if (!ranges.length) return [{ text: value, match: false }]

  ranges.sort((a, b) => a[0] - b[0])
  const merged: Array<[number, number]> = [ranges[0]]
  for (const [start, end] of ranges.slice(1)) {
    const last = merged[merged.length - 1]
    if (start <= last[1]) last[1] = Math.max(last[1], end)
    else merged.push([start, end])
  }

  const parts: HighlightPart[] = []
  let cursor = 0
  for (const [start, end] of merged) {
    if (start > cursor) parts.push({ text: value.slice(cursor, start), match: false })
    parts.push({ text: value.slice(start, end), match: true })
    cursor = end
  }
  if (cursor < value.length) parts.push({ text: value.slice(cursor), match: false })
  return parts
}

const CATEGORY_MAP: Record<string, string> = {
  'CNR Number': 'Case identifiers',
  'Case Number': 'Case identifiers',
  'Registration Number': 'Case identifiers',
  Reference: 'Case identifiers',
  Complex: 'Court',
  Court: 'Court',
  District: 'District',
  'Case type': 'Case type',
  Disposition: 'Disposition',
  Status: 'Status',
  'Last purpose': 'Hearing purpose',
  Act: 'Acts & sections',
  Section: 'Acts & sections',
}

export function categoryLabel(field: string): string {
  return CATEGORY_MAP[field] ?? 'Other'
}

/** Groups ranked suggestions by the parameter each case matched on. */
export function groupSuggestions(results: SearchResult[]): SuggestionGroup[] {
  const order: string[] = []
  const map = new Map<string, SearchResult[]>()
  for (const r of results) {
    const primary = r.matchedFields[0]?.field ?? 'Other'
    const label = categoryLabel(primary)
    if (!map.has(label)) {
      map.set(label, [])
      order.push(label)
    }
    map.get(label)!.push(r)
  }
  return order.map((label) => ({ label, items: map.get(label)! }))
}
