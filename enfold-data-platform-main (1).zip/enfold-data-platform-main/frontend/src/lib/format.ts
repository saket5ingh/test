export function relTime(iso: string, now: Date = new Date()): string {
  const d = new Date(iso)
  if (!Number.isFinite(d.getTime())) return 'Unknown date'
  const mins = Math.max(0, Math.round((now.getTime() - d.getTime()) / 60000))
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.round(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.round(hrs / 24)
  if (days < 45) return `${days}d ago`
  const months = Math.round(days / 30)
  return `${months}mo ago`
}

export function fmtDate(iso: string | null | undefined): string {
  if (!iso) return '—'
  const d = new Date(`${iso}T00:00:00`)
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

export function countBy<T>(list: T[], keyFn: (item: T) => string): Record<string, number> {
  const acc: Record<string, number> = {}
  for (const item of list) {
    const key = keyFn(item)
    acc[key] = (acc[key] ?? 0) + 1
  }
  return acc
}
