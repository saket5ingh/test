import type { Case, Freshness } from '@/types'

function monthNumber(id: string): number | null {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(id)) return null
  const [year, month] = id.split('-').map(Number)
  return year * 12 + month
}

export function scrapeLabel(id: string): string {
  return monthNumber(id) === null ? id : new Date(`${id}-01T00:00:00`).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })
}

export function freshnessOf(c: Pick<Case, 'lastScrape'>, latest = new Date().toISOString().slice(0, 7)): Freshness {
  const month = monthNumber(c.lastScrape ?? '')
  const newest = monthNumber(latest)
  if (month === null || newest === null || month > newest) return 'stale'
  const age = newest - month
  return age === 0 ? 'fresh' : age === 1 ? 'aging' : 'stale'
}

export const FRESHNESS_LABEL: Record<Freshness, string> = {
  fresh: 'Fresh', aging: 'Aging', stale: 'Stale',
}
