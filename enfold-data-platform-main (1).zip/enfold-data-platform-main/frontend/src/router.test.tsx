import { afterEach, describe, expect, it } from 'vitest'
import { screen } from '@testing-library/react'
import { AppRoutes } from '@/router'
import { renderWithProviders, signIn } from '@/test/renderWithProviders'

afterEach(() => sessionStorage.clear())

describe('routing', () => {
  it('redirects anonymous visitors to the login screen', async () => {
    renderWithProviders(<AppRoutes />, { route: '/cases' })
    expect(await screen.findByRole('heading', { name: 'Sign in to continue' })).toBeInTheDocument()
  })

  it.each([
    ['/dashboard', 'Child-marriage Dashboard'],
    ['/cases', 'Cases'],
    ['/admin/run', 'Run custom scrape'],
    ['/admin/logs', 'Scrape run logs'],
  ])('renders %s for an admin', async (route, heading) => {
    signIn('admin')
    renderWithProviders(<AppRoutes />, { route })
    // Longer timeout: the dashboard route is lazy-loaded.
    expect(
      await screen.findByRole('heading', { name: heading, level: 1 }, { timeout: 5000 }),
    ).toBeInTheDocument()
  })

  it('renders a case detail page', async () => {
    signIn('admin')
    renderWithProviders(<AppRoutes />, { route: '/cases/c1' })
    expect(await screen.findByRole('heading', { level: 1, name: /Bail\/2623\/2025/ })).toBeInTheDocument()
  })

  it('keeps field officers out of admin routes', async () => {
    signIn('user')
    renderWithProviders(<AppRoutes />, { route: '/admin/run' })
    expect(
      await screen.findByRole('heading', { name: 'Child-marriage Dashboard', level: 1 }, { timeout: 5000 }),
    ).toBeInTheDocument()
    expect(screen.queryByRole('heading', { name: 'Run custom scrape' })).not.toBeInTheDocument()
  })

  it('hides the Scraper menu from field officers', async () => {
    signIn('user')
    renderWithProviders(<AppRoutes />, { route: '/cases' })
    await screen.findByRole('heading', { name: 'Cases', level: 1 })
    expect(screen.queryByRole('button', { name: /scraper/i })).not.toBeInTheDocument()
  })
})
