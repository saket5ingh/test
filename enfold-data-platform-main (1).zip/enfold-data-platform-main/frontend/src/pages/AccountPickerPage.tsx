import { useEffect, useState } from 'react'
import clsx from 'clsx'
import { Navigate, useNavigate } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { Avatar } from '@/components/ui/Avatar'
import { BrandMark } from '@/components/ui/BrandMark'
import { useAuth } from '@/context/authState'
import { authService } from '@/services/authService'
import type { Account } from '@/types'
import styles from './Auth.module.css'
import { USE_MOCK } from '@/services/config'

export function AccountPickerPage() {
  const navigate = useNavigate()
  const { selectAccount } = useAuth()
  const [accounts, setAccounts] = useState<Account[]>([])

  useEffect(() => {
    let cancelled = false
    authService.listAccounts().then((list) => {
      if (!cancelled) setAccounts(list)
    })
    return () => {
      cancelled = true
    }
  }, [])

  const choose = async (email: string) => {
    await selectAccount(email)
    navigate('/dashboard', { replace: true })
  }

  if (!USE_MOCK) return <Navigate to="/login" replace />

  return (
    <div className={styles.wrap}>
      <main className={styles.pickerCard}>
        <button type="button" className={styles.backLink} onClick={() => navigate('/login')}>
          <Icon name="chev" /> Back
        </button>
        <BrandMark />
        <h1>Choose an account</h1>
        <p className={styles.lede} style={{ marginBottom: 24 }}>
          to continue to eCourts Scraper
        </p>

        <div>
          {accounts.map((a) => (
            <button
              type="button"
              key={a.email}
              className={styles.accountRow}
              onClick={() => choose(a.email)}
            >
              <Avatar initials={a.initials} size="lg" />
              <span>
                <span className={styles.accountName} style={{ display: 'block' }}>
                  {a.name}
                </span>
                <span className={styles.accountEmail} style={{ display: 'block' }}>
                  {a.email}
                </span>
              </span>
              <span className={clsx(styles.accountRole, styles[a.role])}>{a.role}</span>
            </button>
          ))}
        </div>

        <div className={styles.divider}>demo only</div>
        <div className={styles.foot}>
          This account picker is for the local demo. The role badge here is
          shown for this prototype so you can preview both the field-officer and admin views.
        </div>
      </main>
    </div>
  )
}
