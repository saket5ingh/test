import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { caseService } from '@/services/caseService'
import { CASES } from '@/services/mock/cases.mock'
import { fmtDate } from '@/lib/format'
import { axe } from 'jest-axe'
import { CasesPage } from '@/pages/CasesPage'
import { renderWithProviders, signIn } from '@/test/renderWithProviders'

afterEach(() => sessionStorage.clear())

describe('CasesPage', () => {
  it('hides admin-only identifiers from field officers', async () => {
    signIn('user')
    renderWithProviders(<CasesPage />, { route: '/cases' })

    await screen.findByText('PCMA-BR-0001')

    expect(screen.queryByText('BRGA010125162025')).not.toBeInTheDocument()
    expect(screen.queryByText('Bail/2623/2025')).not.toBeInTheDocument()
    expect(screen.queryByText('Gaya DJ Division')).not.toBeInTheDocument()
    expect(screen.queryByRole('columnheader', { name: 'CNR' })).not.toBeInTheDocument()
  })

  it('shows real identifiers to admins', async () => {
    signIn('admin')
    renderWithProviders(<CasesPage />, { route: '/cases' })

    expect(await screen.findByText('BRGA010125162025')).toBeInTheDocument()
    expect(screen.getByRole('columnheader', { name: 'CNR' })).toBeInTheDocument()
  })

  it('has no detectable accessibility violations', async () => {
    signIn('admin')
    const { container } = renderWithProviders(<CasesPage />, { route: '/cases' })

    await screen.findByText('BRGA010125162025')
    await waitFor(async () => {
      expect(await axe(container)).toHaveNoViolations()
    })
  }, 20000)
})


describe('case directory interactions', () => {
  const sample = { ...CASES[0], id: 'synthetic-case', status: 'pending' as const, cnr: '', caseNo: '', ref: 'SAFE-REF-001', regNo: null, regYear: null, caseType: '', hearings: [], numHearings: 1, pinned: false, nextHearing: '2099-10-20', acts: [{ name: 'SC/ST (Prevention of Atrocities) Act', sections: [] }] }
  beforeEach(() => {
    vi.spyOn(caseService, 'listCases').mockResolvedValue({ items: [sample], total: 1, page: 1, pageSize: 25 })
    vi.spyOn(caseService, 'options').mockResolvedValue({ totalCases: 1, districts: ['Bihar', 'Gaya', 'Patna', 'Goa', 'Pune', 'Mumbai', 'Delhi', 'Chennai'], acts: [sample.acts[0].name], caseTypes: [], purposes: [], complexes: [], courts: [] })
    vi.spyOn(caseService, 'listScrapes').mockResolvedValue([{ id: '2026-10', short: 'Oct 2026', label: 'October 2026', date: '2026-10-01', count: 1 }])
    vi.spyOn(caseService, 'updates').mockResolvedValue({ items: [], total: 0, critical: 0 })
  })
  afterEach(() => vi.restoreAllMocks())
  it('keeps full act names, a permitted fallback link and summary hearing data when history is omitted', async () => {
    signIn('admin'); renderWithProviders(<CasesPage />, { route: '/cases' })
    expect(await screen.findByRole('link', { name: 'SAFE-REF-001' })).toHaveAttribute('href', '/cases/synthetic-case')
    expect(screen.getByText('SC/ST (Prevention of Atrocities) Act')).toBeVisible()
    expect(screen.getByText(`Next: ${fmtDate(sample.nextHearing)}`)).toBeVisible()
    expect(screen.getByText('1 recorded hearing')).toBeVisible()
    expect(screen.getAllByText('—')).toHaveLength(3)
    expect(screen.getByRole('region', { name: 'Cases matching the current filters' })).toHaveAttribute('tabindex', '0')
    expect(screen.getByRole('region', { name: 'Cases matching the current filters' })).toHaveAccessibleDescription('Scroll horizontally if needed to see all case information.')
  })
  it.each(['admin', 'user'] as const)('does not show an upcoming hearing on a closed case for %s', async (role) => {
    vi.mocked(caseService.listCases).mockResolvedValue({ items: [{ ...sample, status: 'disposed', decisionDate: '2025-07-03', nextHearing: '2025-07-03' }], total: 1, page: 1, pageSize: 25 })
    signIn(role); renderWithProviders(<CasesPage />, { route: '/cases' })
    await screen.findByRole('link', { name: 'SAFE-REF-001' })
    expect(screen.queryByText(/^Next:/)).not.toBeInTheDocument()
    expect(screen.queryByText('Next date not available')).not.toBeInTheDocument()
  })
  it('labels an overdue source date as historical for a pending case', async () => {
    vi.mocked(caseService.listCases).mockResolvedValue({ items: [{ ...sample, status: 'pending', nextHearing: '2020-07-03' }], total: 1, page: 1, pageSize: 25 })
    signIn('admin'); renderWithProviders(<CasesPage />, { route: '/cases' })
    await screen.findByRole('link', { name: 'SAFE-REF-001' })
    expect(screen.getByText(`Last reported hearing date: ${fmtDate('2020-07-03')}`)).toBeVisible()
    expect(screen.queryByText(/^Next:/)).not.toBeInTheDocument()
  })
  it('clears search and last-scraped month even when no other filters are selected', async () => {
    const user = userEvent.setup(); signIn('admin'); renderWithProviders(<CasesPage />, { route: '/cases' })
    await screen.findByRole('link', { name: 'SAFE-REF-001' })
    const search = screen.getByRole('searchbox', { name: 'Search all cases' })
    await user.type(search, 'SC/ST'); await user.keyboard('{Enter}')
    expect(search).toHaveFocus()
    expect(await screen.findByText('Search: SC/ST')).toBeVisible()
    await user.click(screen.getByRole('button', { name: 'Last scraped: All months' }))
    await user.click(screen.getByRole('radio', { name: /Oct 2026/ }))
    expect(await screen.findByRole('button', { name: 'Remove filter Last scraped: October 2026' })).toBeVisible()
    await waitFor(() => expect(caseService.listCases).toHaveBeenLastCalledWith(expect.objectContaining({ q: 'SC/ST', scrape: '2026-10', page: 1 }), expect.any(AbortSignal)))
    await user.click(screen.getByRole('button', { name: 'Clear all' }))
    await waitFor(() => expect(caseService.listCases).toHaveBeenLastCalledWith(expect.objectContaining({ q: '', scrape: 'all', page: 1 }), expect.any(AbortSignal)))
    expect(search).toHaveValue('')
    expect(screen.queryByRole('button', { name: 'Clear all' })).not.toBeInTheDocument()
  })
  it('searches long option lists and closes the panel on Escape while restoring trigger focus', async () => {
    const user = userEvent.setup(); signIn('admin'); renderWithProviders(<CasesPage />, { route: '/cases' })
    await screen.findByRole('link', { name: 'SAFE-REF-001' })
    const trigger = screen.getByRole('button', { name: 'District' })
    await user.click(trigger)
    await user.type(screen.getByRole('searchbox', { name: 'Find district' }), 'gaya')
    expect(screen.getByRole('checkbox', { name: 'Gaya' })).toBeVisible()
    expect(screen.queryByRole('checkbox', { name: 'Goa' })).not.toBeInTheDocument()
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('group', { name: 'District' })).not.toBeInTheDocument()
    expect(trigger).toHaveFocus()
  })
  it('does not show an empty result while loading or after failure, and retries to a genuine empty result', async () => {
    const user = userEvent.setup(); let reject: (error: Error) => void = () => {}
    vi.mocked(caseService.listCases).mockImplementationOnce(() => new Promise((_resolve, rejectPromise) => { reject = rejectPromise }))
    signIn('admin'); renderWithProviders(<CasesPage />, { route: '/cases' })
    expect(screen.getByRole('status')).toHaveTextContent('Loading cases')
    expect(screen.queryByText('No cases match the current scope')).not.toBeInTheDocument()
    await act(async () => { reject(new Error('Case service unavailable.')) })
    expect(await screen.findByRole('alert')).toHaveTextContent('Case service unavailable.')
    expect(screen.queryByText('No cases match the current scope')).not.toBeInTheDocument()
    vi.mocked(caseService.listCases).mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 25 })
    await user.click(within(screen.getByRole('alert')).getByRole('button', { name: 'Retry' }))
    expect(await screen.findByText('No cases match the current scope')).toBeVisible()
  })
  it('shows pending pin feedback and keeps the case visible when saving a pin fails', async () => {
    const user = userEvent.setup(); let reject: (error: Error) => void = () => {}
    vi.spyOn(caseService, 'setPinned').mockImplementationOnce(() => new Promise((_resolve, rejectPromise) => { reject = rejectPromise }))
    signIn('user'); renderWithProviders(<CasesPage />, { route: '/cases' })
    const pin = await screen.findByRole('button', { name: 'Pin case SAFE-REF-001' })
    await user.click(pin)
    expect(pin).toBeDisabled(); expect(pin).toHaveAttribute('aria-busy', 'true')
    await act(async () => { reject(new Error('Pin failed')) })
    expect(await screen.findByRole('alert')).toHaveTextContent('Could not save this pin.')
    expect(screen.getByRole('link', { name: 'SAFE-REF-001' })).toBeVisible()
    expect(pin).toBeEnabled()
    expect(caseService.setPinned).toHaveBeenCalledExactlyOnceWith('synthetic-case', true)
  })
})
