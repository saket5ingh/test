import { useResource } from '@/hooks/useResource'
import { caseService } from '@/services/caseService'
import { useEffect, useId, useCallback, useState } from 'react'
import clsx from 'clsx'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { Icon } from '@/components/icons/Icon'
import { DetailsTab, TimelineTab } from '@/components/case-detail/CaseTabs'
import { Tabs, TabPanel, type TabDef } from '@/components/case-detail/Tabs'
import { RestrictedPill, FreshnessIndicator } from '@/components/ui/Badges'
import { Button } from '@/components/ui/Button'
import { EmptyState } from '@/components/ui/EmptyState'
import { StatusBadge } from '@/components/ui/StatusBadge'
import { useAuth } from '@/context/authState'
import { useCases } from '@/context/casesState'
import { freshnessOf, scrapeLabel } from '@/lib/freshness'
import styles from '@/components/case-detail/CaseDetail.module.css'

const ADMIN_TABS: TabDef[] = [
  { key: 'overview', label: 'Details' },
  { key: 'timeline', label: 'Hearing timeline' },
]

export function CaseDetailPage() {
  const { caseId } = useParams<{ caseId: string }>()
  const [searchParams, setSearchParams] = useSearchParams()
  const navigate = useNavigate()
  const { isAdmin } = useAuth()
  const { scrapes, revision, error: pinError, reload, togglePin } = useCases()
  const loadCase = useCallback((signal: AbortSignal) => caseService.getCase(caseId ?? '', signal), [caseId])
  const { data: caseRecord, loading, error: fetchError } = useResource(`${caseId}:${revision}`, loadCase)
  const error = fetchError ?? pinError
  const tabs = isAdmin ? ADMIN_TABS : ADMIN_TABS.slice(0, 1)
  const tabIdPrefix = useId()

  const requestedTab = searchParams.get('tab') ?? 'overview'
  const activeTab = tabs.some((t) => t.key === requestedTab) ? requestedTab : 'overview'

  const [flash, setFlash] = useState(searchParams.get('flash') === '1')

  useEffect(() => {
    if (!flash) return
    const next = new URLSearchParams(searchParams)
    next.delete('flash')
    setSearchParams(next, { replace: true })
    const timer = setTimeout(() => setFlash(false), 1800)
    return () => clearTimeout(timer)
  }, [flash, searchParams, setSearchParams])

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [caseId])

  if (loading) return <p role="status">Loading case…</p>
  if (error && !caseRecord) return <p role="alert">{error} <button onClick={reload}>Retry</button></p>
  if (!caseRecord) {
    return (
      <EmptyState title="Case not found" description="This case is no longer available." />
    )
  }

  const setTab = (key: string) => {
    const next = new URLSearchParams(searchParams)
    if (key === 'overview') next.delete('tab')
    else next.set('tab', key)
    setSearchParams(next, { replace: true })
  }

  return (
    <>
      {error ? <p role="alert">{error}</p> : null}
      <Button
        variant="subtle"
        style={{ marginBottom: 12, paddingLeft: 4 }}
        onClick={() => navigate('/cases')}
      >
        ← Back to cases
      </Button>

      <div className={clsx(styles.head, flash && styles.flash)}>
        <div className={styles.headTop}>
          <div>
            <h1 className={styles.title}>
              {isAdmin ? (
                <>
                  {caseRecord.caseNo} <span className={styles.subtle}>— {caseRecord.caseType}</span>
                </>
              ) : (
                caseRecord.caseType
              )}
            </h1>

            <dl>
              {isAdmin ? (
                <>
                  <div className={styles.idLine}>
                    <dt>CNR Number</dt>
                    <dd>{caseRecord.cnr}</dd>
                  </div>
                  <div className={styles.idLine}>
                    <dt>Registration Number</dt>
                    <dd>
                      {caseRecord.regNo} / {caseRecord.regYear}
                    </dd>
                  </div>
                </>
              ) : (
                <>
                  <div className={styles.idLine}>
                    <dt>Reference</dt>
                    <dd>{caseRecord.ref}</dd>
                  </div>
                  <div className={styles.idLine}>
                    <dt>CNR Number</dt>
                    <dd>
                      <RestrictedPill />
                    </dd>
                  </div>
                  <div className={styles.idLine}>
                    <dt>Registration Number</dt>
                    <dd>
                      <RestrictedPill />
                    </dd>
                  </div>
                </>
              )}
              <div className={styles.idLine}>
                <dt>District</dt>
                <dd>
                  {caseRecord.district}, {caseRecord.state}
                </dd>
              </div>
            </dl>

            <div className={styles.statusRow}>
              <StatusBadge status={caseRecord.status} prominent />
              <FreshnessIndicator
                freshness={freshnessOf(caseRecord, scrapes[0]?.id)}
                text={`Last refresh: ${scrapeLabel(caseRecord.lastScrape)}`}
              />
            </div>
          </div>

          <Button
            variant={caseRecord.pinned ? 'primary' : 'default'}
            aria-pressed={caseRecord.pinned}
            onClick={() => void togglePin(caseRecord.id, caseRecord)}
          >
            <Icon name={caseRecord.pinned ? 'pin' : 'pinOutline'} />
            {caseRecord.pinned ? 'Pinned' : 'Pin this case'}
          </Button>
        </div>
      </div>

      {tabs.length > 1 ? (
        <Tabs
          idPrefix={tabIdPrefix}
          tabs={tabs}
          active={activeTab}
          onChange={setTab}
          label="Case sections"
        />
      ) : null}

      <TabPanel idPrefix={tabIdPrefix} tabKey="overview" active={activeTab}>
        <DetailsTab caseRecord={caseRecord} />
      </TabPanel>
      <TabPanel idPrefix={tabIdPrefix} tabKey="timeline" active={activeTab}>
        <TimelineTab caseRecord={caseRecord} />
      </TabPanel>
    </>
  )
}
