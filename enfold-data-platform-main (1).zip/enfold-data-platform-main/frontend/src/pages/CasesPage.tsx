import { useState } from 'react'
import { useFilters } from '@/context/filtersState'
import { ActiveFilterChips, FilterBar } from '@/components/cases/FilterBar'
import { AdvancedFilterDrawer } from '@/components/cases/AdvancedFilterDrawer'
import { CaseTable } from '@/components/cases/CaseTable'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/context/authState'
import { useCases } from '@/context/casesState'
import styles from './CasesPage.module.css'

function CaseSearch({ query, onSearch, isAdmin }: { query: string; onSearch: (value: string) => void; isAdmin: boolean }) {
  const [draft, setDraft] = useState(query)
  const [previousQuery, setPreviousQuery] = useState(query)
  // External chip removal or Clear all updates the input without replacing its DOM node.
  if (query !== previousQuery) { setPreviousQuery(query); setDraft(query) }
  return <form className={styles.search} role="search" aria-label="Search cases" onSubmit={(event) => { event.preventDefault(); onSearch(draft.trim()) }}>
    <label>Search all cases<input type="search" value={draft} maxLength={200} placeholder={isAdmin ? 'CNR, case number, district or act…' : 'Reference, district or act…'} aria-describedby="case-search-help" onChange={(event) => setDraft(event.target.value)} /></label>
    <Button type="submit" variant="primary">Search</Button>
    <p id="case-search-help">{isAdmin ? 'Search identifiers, court details, districts and acts across all matching cases.' : 'Search references, districts, case types and acts across the fields available to you.'}</p>
  </form>
}
export function CasesPage() {
  const { searchQuery, setSearchQuery } = useFilters()
  const { isAdmin } = useAuth()
  const { cases, loading, error, reload, total, page, pageSize, setPage } = useCases()
  const pages = Math.max(1, Math.ceil(total / pageSize))
  return <div className={styles.page}>
    <header className={styles.header}><p className={styles.eyebrow}>CASE DIRECTORY</p><h1>Cases</h1><p>Latest case records collected from eCourts through manual and monthly scans.{isAdmin ? '' : ' You are viewing the fields available to field officers.'}</p></header>
    <CaseSearch query={searchQuery} onSearch={setSearchQuery} isAdmin={isAdmin} />
    <FilterBar /><ActiveFilterChips />
    <div className={styles.resultsHead}><div><h2>Case records</h2><p role="status">{loading ? 'Loading cases…' : error && !cases.length ? 'Cases could not be loaded.' : `${total.toLocaleString('en-IN')} case${total === 1 ? '' : 's'}`}</p></div><Button onClick={reload} disabled={loading}>Refresh</Button></div>
    {error ? <div className={styles.error} role="alert"><span>{error}</span><Button onClick={reload}>Retry</Button></div> : null}
    {loading ? <div className={styles.loading} aria-hidden="true"><div /><div /><div /><div /></div> : cases.length || !error ? <CaseTable cases={cases} caption="Cases matching the current filters" emptyTitle="No cases match the current scope" emptyDescription="Try another search or clear the filters and last scraped month. New cases appear after a scrape saves them." /> : null}
    {!loading && (!error || cases.length > 0) ? <nav className={styles.pagination} aria-label="Case pages"><span>{total ? `${((page - 1) * pageSize + 1).toLocaleString('en-IN')}–${Math.min(page * pageSize, total).toLocaleString('en-IN')} of ${total.toLocaleString('en-IN')} cases` : '0 cases'}</span><div><Button disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous page</Button><span>Page {page} of {pages}</span><Button disabled={page >= pages} onClick={() => setPage(page + 1)}>Next page</Button></div></nav> : null}
    <AdvancedFilterDrawer />
  </div>
}
