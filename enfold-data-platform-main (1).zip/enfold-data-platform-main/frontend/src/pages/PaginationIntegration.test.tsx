import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Routes, Route } from 'react-router-dom'
import { renderWithProviders, signIn } from '@/test/renderWithProviders'
import { CasesPage } from './CasesPage'
import { CaseDetailPage } from './CaseDetailPage'
import { CASES } from '@/services/mock/cases.mock'
import { ACCOUNTS } from '@/services/mock/accounts.mock'
import { tokenStore } from '@/services/http'

vi.mock('@/services/config', () => ({ API_BASE_URL: '/api', USE_MOCK: false, delay: (v: unknown) => Promise.resolve(v) }))
let calls: string[]
let pinned = false
beforeEach(() => {
  signIn('user')
  calls = []
  pinned = false
  vi.stubGlobal('fetch', vi.fn(async (url: string, init: RequestInit) => {
    calls.push(url)
    if (url === '/api/auth/me') return Response.json(ACCOUNTS.find((a) => a.role === 'user'))
    if (url === '/api/options') return Response.json({ totalCases: 31, districts: ['Gaya', 'Other district'], acts: [], caseTypes: [], purposes: [], complexes: [], courts: [] })
    if (url === '/api/scrapes') return Response.json([])
    if (url === '/api/cases/updates') return Response.json({ items: [], total: 0, critical: 0 })
    if (url.startsWith('/api/cases?')) {
      const params = new URL(url, 'http://localhost').searchParams
      const page = Number(params.get('page') ?? 1)
      const searched = params.get('q') === 'outside page'
      return Response.json({ items: [{ ...CASES[page === 1 ? 0 : 1], pinned }], total: searched ? 1 : 31, page, pageSize: 25 })
    }
    if (url === '/api/cases/outside-page/pin') {
      pinned = JSON.parse(init.body as string).pinned
      return new Response(null, { status: 204 })
    }
    if (url === '/api/cases/outside-page') return Response.json({ ...CASES[2], id: 'outside-page', pinned })
    throw new Error(`Unexpected request: ${url}`)
  }))
})
afterEach(() => { vi.unstubAllGlobals(); tokenStore.set(null) })

it('paginates on the server and resets to page one for a catalogue search', async () => {
  const user = userEvent.setup()
  renderWithProviders(<CasesPage />)
  await screen.findByText('31 cases')
  await user.click(screen.getByRole('button', { name: 'Next page' }))
  await screen.findByText('Page 2 of 2')
  expect(calls.some((url) => url.includes('page=2'))).toBe(true)
  await user.type(screen.getByRole('searchbox', { name: 'Search all cases' }), 'outside page')
  await user.click(screen.getByRole('button', { name: /^Search$/ }))
  await screen.findByText('1 case')
  expect(screen.getByText('Page 1 of 1')).toBeInTheDocument()
  const last = calls.filter((url) => url.startsWith('/api/cases?')).at(-1)!
  expect(new URL(last, 'http://localhost').searchParams.get('q')).toBe('outside page')
})

it('offers filter values that are not present on the current page', async () => {
  const user = userEvent.setup()
  renderWithProviders(<CasesPage />)
  await screen.findByText('31 cases')
  await user.click(screen.getByRole('button', { name: /^District/ }))
  expect(screen.getByText('Other district')).toBeInTheDocument()
})

it('loads and pins a case opened directly outside the list page, without PDF tabs', async () => {
  const user = userEvent.setup()
  renderWithProviders(<Routes><Route path="/cases/:caseId" element={<CaseDetailPage />} /></Routes>, { route: '/cases/outside-page' })
  await user.click(await screen.findByRole('button', { name: 'Pin this case' }))
  expect(await screen.findByRole('button', { name: 'Pinned' })).toHaveAttribute('aria-pressed', 'true')
  expect(calls).toContain('/api/cases/outside-page/pin')
  expect(screen.queryByRole('tab', { name: /order|pdf/i })).not.toBeInTheDocument()
})
