import clsx from 'clsx'
import {
  OutcomeDonutChart,
  SectionsBarChart,
  StateBarChart,
  YearTrendChart,
} from '@/components/dashboard/PcmaCharts'
import { PageHead } from '@/components/ui/PageHead'
import styles from '@/components/dashboard/Charts.module.css'

export function DashboardPage() {
  return (
    <>
      <PageHead
        title="Child-marriage Dashboard"
        description="Available cases under the Prohibition of Child Marriage Act, the Child Marriage Restraint Act and other approved child-marriage labels."
      />

      <div className={clsx(styles.chartsGrid, styles.single)}>
        <StateBarChart />
      </div>
      <div className={styles.chartsGrid}>
        <OutcomeDonutChart />
        <SectionsBarChart />
      </div>
      <div className={clsx(styles.chartsGrid, styles.single)}>
        <YearTrendChart />
      </div>
    </>
  )
}
