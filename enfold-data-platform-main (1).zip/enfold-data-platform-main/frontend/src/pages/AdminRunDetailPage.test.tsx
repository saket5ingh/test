import { act, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { axe } from 'jest-axe'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { beforeEach, afterEach, expect, it, vi } from 'vitest'
import { scrapeService } from '@/services/scrapeService'
import type { ScraperRun } from '@/types/scraper'
import { AdminRunDetailPage } from './AdminRunDetailPage'
vi.mock('@/services/scrapeService', () => ({ scrapeService: { reviewRetry: vi.fn(), getRun: vi.fn(), results: vi.fn(), tasks: vi.fn(), events: vi.fn(), cancel: vi.fn(), retry: vi.fn(), download: vi.fn() } }))
const run: ScraperRun = {
  id: 'synthetic-run', name: 'Nationwide test scan', trigger: 'manual', triggeredBy: 'opaque-user-id', triggeredByName: 'Test administrator',
  queuedAt: '2026-10-01T12:00:00Z', startedAt: '2026-10-01T12:01:00Z', completedAt: '2026-10-01T13:01:00Z', outcome: 'success',
  criteria: { allStates: true, allActs: false, stateCodes: [], actKeys: ['childmarriage'], sections: [], status: 'all' },
  resolvedScope: { states: [{ code: '1', name: 'Example state' }], actKeys: ['childmarriage'] },
  tasks: { success: 150, failed: 2 }, counts: { new: 12, updated: 4, unchanged: 6 }, total: 22,
  coverage: [{ kind: 'case', status: 'success', count: 150 }], snapshotsAvailable: true, error: null, cancelRequested: false,
  legacyCriteria: { state: null, acts: null, sections: null, status: 'all' },
}
function page() { return render(<MemoryRouter initialEntries={['/admin/runs/synthetic-run']}><Routes><Route path="/admin/runs/:runId" element={<AdminRunDetailPage />} /></Routes></MemoryRouter>) }
beforeEach(() => {
  vi.mocked(scrapeService.getRun).mockResolvedValue(run)
  vi.mocked(scrapeService.results).mockResolvedValue({ items: [], total: 1000, page: 1, pageSize: 25 })
  vi.mocked(scrapeService.tasks).mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 25 })
  vi.mocked(scrapeService.events).mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 50 })
})
afterEach(() => { vi.useRealTimers(); vi.resetAllMocks() })
it('renders the initiator name and only loads the selected section, with keyboard tab navigation', async () => {
  const user = userEvent.setup(); page()
  expect(await screen.findByText('Test administrator')).toBeInTheDocument()
  expect(screen.queryByText('opaque-user-id')).not.toBeInTheDocument()
  expect(screen.getByText('Pending & disposed')).toBeInTheDocument()
  expect(scrapeService.results).not.toHaveBeenCalled(); expect(scrapeService.events).not.toHaveBeenCalled()
  screen.getByRole('tab', { name: 'Overview' }).focus()
  await user.keyboard('{ArrowRight}')
  expect(screen.getByRole('tab', { name: 'Results' })).toHaveFocus()
  await waitFor(() => expect(scrapeService.results).toHaveBeenCalledOnce())
  await user.keyboard('{End}')
  expect(screen.getByRole('tab', { name: 'Audit history' })).toHaveAttribute('aria-selected', 'true')
  await waitFor(() => expect(scrapeService.events).toHaveBeenCalledOnce())
  await user.keyboard('{Home}')
  expect(screen.getByRole('tab', { name: 'Overview' })).toHaveFocus()
})
it('applies search and filters on the server, resets pages and keeps section filters on returning', async () => {
  const user = userEvent.setup(); page()
  await user.click(await screen.findByRole('tab', { name: 'Results' }))
  await user.click(await screen.findByRole('button', { name: 'Next' }))
  await waitFor(() => expect(scrapeService.results).toHaveBeenLastCalledWith('synthetic-run', 2, expect.any(AbortSignal), expect.objectContaining({ page: 2 })))
  expect(screen.getByRole('searchbox')).toHaveAttribute('maxlength', '160')
  await user.type(screen.getByRole('searchbox'), 'CNR% example')
  await user.click(screen.getByRole('button', { name: 'Search' }))
  await waitFor(() => expect(scrapeService.results).toHaveBeenLastCalledWith('synthetic-run', 1, expect.any(AbortSignal), expect.objectContaining({ q: 'CNR% example', page: 1 })))
  await user.selectOptions(screen.getByLabelText('State'), 'Example state')
  await user.selectOptions(screen.getByLabelText('Case status'), 'disposed')
  await user.selectOptions(screen.getByLabelText('Change'), 'updated')
  await user.selectOptions(screen.getByLabelText('Rows per page'), '100')
  await waitFor(() => expect(scrapeService.results).toHaveBeenLastCalledWith('synthetic-run', 1, expect.any(AbortSignal), expect.objectContaining({ state: 'Example state', status: 'disposed', change_kind: 'updated', pageSize: 100 })))
  await user.type(screen.getByLabelText('Go to page'), '3'); await user.click(screen.getByRole('button', { name: 'Go' }))
  await waitFor(() => expect(scrapeService.results).toHaveBeenLastCalledWith('synthetic-run', 3, expect.any(AbortSignal), expect.any(Object)))
  await user.click(screen.getByRole('tab', { name: 'Overview' })); await user.click(screen.getByRole('tab', { name: 'Results' }))
  expect(screen.getByRole('searchbox')).toHaveValue('CNR% example')
  expect(screen.getByLabelText('Case status')).toHaveValue('disposed')
})
it('does not poll terminal run information or results', async () => {
  vi.useFakeTimers(); page()
  await act(async () => { await Promise.resolve() })
  fireEvent.click(screen.getByRole('tab', { name: 'Results' }))
  await act(async () => { await Promise.resolve(); await vi.advanceTimersByTimeAsync(16000) })
  expect(scrapeService.getRun).toHaveBeenCalledOnce(); expect(scrapeService.results).toHaveBeenCalledOnce()
})
it('polls active data, cancels inactive sections and stops after a terminal run response', async () => {
  vi.useFakeTimers(); vi.mocked(scrapeService.getRun).mockResolvedValueOnce({ ...run, outcome: 'running', completedAt: null }).mockResolvedValue(run)
  page(); await act(async () => { await Promise.resolve() })
  fireEvent.click(screen.getByRole('tab', { name: 'Results' }))
  await act(async () => { await Promise.resolve() })
  const signal = vi.mocked(scrapeService.results).mock.calls[0][2]
  fireEvent.click(screen.getByRole('tab', { name: 'Overview' }))
  expect(signal?.aborted).toBe(true)
  await act(async () => { await vi.advanceTimersByTimeAsync(20000) })
  expect(scrapeService.getRun).toHaveBeenCalledTimes(2); expect(scrapeService.results).toHaveBeenCalledOnce()
})
it('explains unavailable CSV and requires an explicit cancellation confirmation', async () => {
  const user = userEvent.setup(); vi.mocked(scrapeService.getRun).mockResolvedValue({ ...run, outcome: 'running', completedAt: null })
  page(); const download = await screen.findByRole('button', { name: 'Download CSV' })
  expect(download).toBeDisabled(); expect(download).toHaveAccessibleDescription('CSV becomes available when this run finishes or is cancelled.')
  await user.click(screen.getByRole('button', { name: 'Cancel run' })); expect(scrapeService.cancel).not.toHaveBeenCalled()
  await user.click(screen.getByRole('button', { name: 'Keep running' })); expect(screen.queryByRole('region', { name: 'Confirm cancellation' })).not.toBeInTheDocument()
  await user.click(screen.getByRole('button', { name: 'Cancel run' })); await user.click(screen.getByRole('button', { name: 'Confirm cancellation' }))
  expect(scrapeService.cancel).toHaveBeenCalledWith('synthetic-run')
})
it('shows retry action errors without removing the run', async () => {
  const user = userEvent.setup(); vi.mocked(scrapeService.getRun).mockResolvedValue({ ...run, outcome: 'partial' }); vi.mocked(scrapeService.retry).mockRejectedValue(new Error('Worker unavailable.'))
  page(); await user.click(await screen.findByRole('button', { name: 'Retry unfinished work' }))
  expect(await screen.findByRole('alert')).toHaveTextContent('Worker unavailable.')
  expect(screen.getByRole('heading', { name: run.name })).toBeInTheDocument()
})
it('renders mapping review details without exposing its config by default and safely handles malformed payloads', async () => {
  const user = userEvent.setup()
  vi.mocked(scrapeService.events).mockResolvedValue({ items: [{ id: 'one', at: run.queuedAt, kind: 'act_mapping_review', message: JSON.stringify({ option: 'childmarriage', label: 'Child Marriage Act', reason: 'ambiguous_law', location: 'Example court', state: 'Example state', district: 'Example district', court: 'Example court name', config: { hash: 'hidden-config-hash' } }), actor_name: null, task_id: null }, { id: 'two', at: run.queuedAt, kind: 'act_mapping_review', message: 'Older plain text', actor_name: 'Test administrator', task_id: null }], total: 2, page: 1, pageSize: 50 })
  page(); await user.click(await screen.findByRole('tab', { name: 'Audit history' }))
  expect(await screen.findByText('Child Marriage Act')).toBeVisible()
  expect(screen.getByText('Ambiguous law')).toBeVisible()
  expect(screen.getByText('Child-marriage acts (PCMA / CMRA)')).toBeVisible()
  expect(screen.getByText('State', { selector: 'dt' })).toBeVisible()
  expect(screen.getByText('District', { selector: 'dt' })).toBeVisible()
  expect(screen.getByText('Court', { selector: 'dt' })).toBeVisible()
  expect(screen.queryByText('District discovery')).not.toBeInTheDocument()
  expect(screen.getByText(/hidden-config-hash/)).not.toBeVisible()
  await user.click(screen.getByText('Act name needs review')); expect(screen.getByText('Older plain text')).toBeVisible()
  await user.selectOptions(screen.getByLabelText('Event category'), 'warnings')
  await waitFor(() => expect(scrapeService.events).toHaveBeenLastCalledWith('synthetic-run', 1, expect.any(AbortSignal), expect.objectContaining({ kind: 'warnings' })))
})
it('shows loading, recoverable failure and empty results', async () => {
  const user = userEvent.setup(); let reject: (reason: Error) => void = () => {}
  vi.mocked(scrapeService.tasks).mockImplementationOnce(() => new Promise((_resolve, rejectPromise) => { reject = rejectPromise }))
  page(); await user.click(await screen.findByRole('tab', { name: /Failures/ }))
  expect(screen.getByRole('status')).toHaveTextContent('Loading work items')
  await act(async () => { reject(new Error('Could not fetch work items.')) })
  expect(await screen.findByRole('alert')).toHaveTextContent('Could not fetch work items.')
  await user.click(within(screen.getByRole('alert')).getByRole('button', { name: 'Try again' }))
  expect(await screen.findByText('No work items match these filters.')).toBeInTheDocument()
})

it('resets narrowed work-item filters when opening the failed-task summary', async () => {
  const user = userEvent.setup(); page()
  await user.click(await screen.findByRole('tab', { name: /Failures/ }))
  await user.type(screen.getByRole('searchbox'), 'Narrow court')
  await user.click(screen.getByRole('button', { name: 'Search' }))
  await user.selectOptions(screen.getByLabelText('Work type'), 'case')
  await user.selectOptions(screen.getByLabelText('Task status'), 'success')
  await user.click(screen.getByRole('button', { name: /Failed tasks/ }))
  await waitFor(() => expect(scrapeService.tasks).toHaveBeenLastCalledWith('synthetic-run', 1, 'failed', expect.any(AbortSignal), { page: 1, pageSize: 25, q: '', status: 'failed' }))
  expect(screen.getByRole('searchbox')).toHaveValue('')
  expect(screen.getByLabelText('Work type')).toHaveValue('all')
})

it('keeps an unsubmitted search draft when pagination changes', async () => {
  const user = userEvent.setup(); page()
  await user.click(await screen.findByRole('tab', { name: 'Results' }))
  await user.type(screen.getByRole('searchbox'), 'Unsubmitted location')
  await user.click(screen.getByRole('button', { name: 'Next' }))
  await waitFor(() => expect(scrapeService.results).toHaveBeenLastCalledWith('synthetic-run', 2, expect.any(AbortSignal), expect.objectContaining({ page: 2, q: '' })))
  expect(screen.getByRole('searchbox')).toHaveValue('Unsubmitted location')
})

const performance: NonNullable<ScraperRun['performance']> = {
  windowMinutes: 60, observedSince: '2026-10-01T12:01:00Z',
  successfulTasksLastHour: 120, failedTasksLastHour: 4, retriedTasksLastHour: 18,
  caseDetailsLastHour: 95, sourceErrorsLastHour: 6, sourceErrorRate: 0.05,
  lastSuccessfulTaskAt: '2026-10-01T12:58:00Z', lastCaseAt: '2026-10-01T12:57:00Z', deferredTasks: 850,
  workerConcurrency: 4, inFlight: 3, workerLastSeen: '2026-10-01T12:59:00Z', workerHealthy: true,
  requestIntervalSeconds: 1.5, observedRequestIntervalSeconds: 2.1,
  sourcePausedUntil: null, sourceFailureStreak: 0, stalled: false,
  etaSeconds: 7200, etaBasis: 'current_case_backlog',
}
function monitoredRun(overrides: Partial<NonNullable<ScraperRun['performance']>> = {}): ScraperRun {
  return { ...run, outcome: 'running', completedAt: null, performance: { ...performance, ...overrides }, coverage: [
    { kind: 'case', status: 'queued', count: 180 }, { kind: 'case', status: 'running', count: 3 },
    { kind: 'search', status: 'queued', count: 25 }, { kind: 'case', status: 'failed', count: 2 },
  ] }
}
it('shows successful throughput separately from retries and bounds the estimate to admitted case work', async () => {
  vi.mocked(scrapeService.getRun).mockResolvedValue(monitoredRun())
  page()
  const panel = await screen.findByRole('region', { name: 'Scraper performance' })
  const throughput = within(panel).getByLabelText('Recent throughput')
  expect(throughput).toHaveTextContent('Case details completed95')
  expect(throughput).toHaveTextContent('Tasks completed120')
  expect(throughput).toHaveTextContent('Retries18Attempts, not progress')
  expect(throughput).toHaveTextContent('Tasks failed4')
  const estimate = within(panel).getByRole('region', { name: 'Admitted case backlog estimate' })
  expect(estimate).toHaveTextContent('2h')
  expect(estimate).toHaveTextContent('183 admitted case tasks queued or running')
  expect(estimate).toHaveTextContent('850 staged child references')
  expect(estimate).toHaveTextContent('may include duplicates')
  expect(estimate).toHaveTextContent('not a whole-run finish time')
  expect(panel).toHaveTextContent('Source failures / task outcomes5%')
  expect(panel).toHaveTextContent('Worker reporting')
  expect(panel).toHaveTextContent('1.5s between admissions')
  expect(panel).toHaveTextContent('2.1s between admissionsIncludes idle time')
  expect(panel.querySelector('time[datetime="2026-10-01T12:58:00Z"]')).toBeInTheDocument()
  expect(screen.getByRole('region', { name: 'Coverage by work type' })).toBeInTheDocument()
  expect(screen.queryByRole('alert')).not.toBeInTheDocument()
})
it('keeps recorded source errors available alongside current stalled and cooldown warnings', async () => {
  vi.mocked(scrapeService.getRun).mockResolvedValue({ ...monitoredRun({ stalled: true, sourcePausedUntil: '2099-10-01T13:05:00Z', sourceFailureStreak: 7, workerHealthy: false }), error: 'Recorded source error for audit' })
  const user = userEvent.setup(); page()
  expect(await screen.findByRole('alert')).toHaveTextContent('No recent successful progress')
  expect(screen.getByRole('status')).toHaveTextContent('Source cooldown is active')
  expect(screen.getByRole('status')).toHaveTextContent('Consecutive source failures: 7')
  expect(screen.getByText('Worker heartbeat stale')).toBeInTheDocument()
  expect(screen.getByText('A source error was recorded')).toBeInTheDocument()
  await user.click(screen.getByText('Technical details'))
  expect(screen.getByText('Recorded source error for audit')).toBeVisible()
})
it('renders missing ETA and runtime samples as unavailable rather than zero', async () => {
  vi.mocked(scrapeService.getRun).mockResolvedValue(monitoredRun({ etaSeconds: null, etaBasis: null, sourceErrorRate: null, workerConcurrency: null, inFlight: null, workerHealthy: false, workerLastSeen: null, requestIntervalSeconds: null, observedRequestIntervalSeconds: null, lastSuccessfulTaskAt: null, lastCaseAt: null }))
  page()
  const panel = await screen.findByRole('region', { name: 'Scraper performance' })
  expect(panel).toHaveTextContent('Insufficient recent successful samples')
  expect(panel).toHaveTextContent('No recent outcomes')
  expect(panel).toHaveTextContent('No worker heartbeat')
  expect(within(panel).getAllByText('Not available')).toHaveLength(4)
  expect(panel).not.toHaveTextContent('Less than 1 minute')
})
it('does not show expired cooldowns as currently active', async () => {
  vi.mocked(scrapeService.getRun).mockResolvedValue(monitoredRun({ sourcePausedUntil: '2000-01-01T00:00:00Z' }))
  page(); await screen.findByRole('region', { name: 'Scraper performance' })
  expect(screen.queryByText('Source cooldown is active')).not.toBeInTheDocument()
})
it('does not attribute live global worker status or cooldown to finished runs', async () => {
  vi.mocked(scrapeService.getRun).mockResolvedValue({ ...run, performance: { ...performance, stalled: true, sourcePausedUntil: '2099-10-01T13:05:00Z' } })
  page()
  const panel = await screen.findByRole('region', { name: 'Scraper performance' })
  expect(panel).toHaveTextContent('Run finished')
  expect(screen.queryByRole('region', { name: 'Global worker & source pacing' })).not.toBeInTheDocument()
  expect(screen.queryByText('Worker reporting')).not.toBeInTheDocument()
  expect(screen.queryByText('Source cooldown is active')).not.toBeInTheDocument()
  expect(screen.queryByRole('alert')).not.toBeInTheDocument()
})
it('supports legacy runs without performance metrics', async () => {
  page()
  expect(await screen.findByText('Performance metrics are not available for this run.')).toBeInTheDocument()
  expect(screen.getByRole('heading', { name: 'Run overview' })).toBeInTheDocument()
})

it('exposes labelled performance sections without accessibility violations', async () => {
  vi.mocked(scrapeService.getRun).mockResolvedValue(monitoredRun({ stalled: true, sourcePausedUntil: '2099-10-01T13:05:00Z' }))
  page()
  const panel = await screen.findByRole('region', { name: 'Scraper performance' })
  expect(await axe(panel)).toHaveNoViolations()
})


it('shows partial recovery without claiming that the source is fully recovered', async () => {
  vi.mocked(scrapeService.getRun).mockResolvedValue(monitoredRun({ sourcePausedUntil: '2099-10-01T13:05:00Z', sourceFailureStreak: 0, sourceRecoverySuccesses: 1, sourceRecoveryRequired: 3 }))
  page()
  await screen.findByRole('region', { name: 'Scraper performance' })
  const status = screen.getByRole('status')
  expect(status).toHaveTextContent('Recovery checks: 1 of 3 successful')
  expect(status).toHaveTextContent('Previous backoff is retained until recovery is confirmed')
  expect(status).not.toHaveTextContent('Consecutive source failures: 0')
})

it('shows incomplete coverage and retries only a reviewed quarantined task', async () => {
  const task = { id: 'quarantined-task', kind: 'court', status: 'failed', attempts: 8, error_message: 'Invalid response', payload: { court: { name: 'Example court', code: '2' } }, review_required: true, review_reason: 'Coverage is incomplete.', review_failures: 5, review_sessions: 3 }
  vi.mocked(scrapeService.getRun).mockResolvedValue({ ...run, outcome: 'partial', tasks: { success: 150, failed: 1 }, quarantined: 1, coverageIncomplete: true })
  vi.mocked(scrapeService.tasks).mockResolvedValue({ items: [task], total: 1, page: 1, pageSize: 25 })
  vi.mocked(scrapeService.reviewRetry).mockResolvedValue({ id: task.id })
  const user = userEvent.setup(); page()
  await user.click(await screen.findByRole('button', { name: 'View quarantined tasks' }))
  await waitFor(() => expect(scrapeService.tasks).toHaveBeenCalledWith('synthetic-run', 1, 'quarantined', expect.any(AbortSignal), expect.objectContaining({ status: 'quarantined' })))
  expect(screen.getByText('Coverage is incomplete')).toBeInTheDocument()
  expect(screen.queryByRole('button', { name: 'Retry unfinished work' })).not.toBeInTheDocument()
  await user.click(await screen.findByRole('button', { name: 'Review and retry task' }))
  const submit = screen.getByRole('button', { name: 'Confirm reviewed retry' })
  expect(submit).toBeDisabled()
  await user.type(screen.getByLabelText('Review reason'), 'Verified court response format')
  await user.click(submit)
  await waitFor(() => expect(scrapeService.reviewRetry).toHaveBeenCalledWith('synthetic-run', task.id, 'Verified court response format'))
  expect(scrapeService.retry).not.toHaveBeenCalled()
})

it('keeps the review reason after a retry error and supports cancelling review', async () => {
  vi.mocked(scrapeService.tasks).mockResolvedValue({ items: [{ id: 'one', kind: 'court', status: 'failed', attempts: 5, error_message: null, payload: {}, review_required: true }], total: 1, page: 1, pageSize: 25 })
  vi.mocked(scrapeService.reviewRetry).mockRejectedValue(new Error('Task is no longer awaiting review'))
  const user = userEvent.setup(); page()
  await user.click(await screen.findByRole('tab', { name: /^Failures/ }))
  await user.click(await screen.findByRole('button', { name: 'Review and retry task' }))
  await user.type(screen.getByLabelText('Review reason'), 'Rechecked source')
  await user.click(screen.getByRole('button', { name: 'Confirm reviewed retry' }))
  expect(await screen.findByRole('alert')).toHaveTextContent('Task is no longer awaiting review')
  expect(screen.getByLabelText('Review reason')).toHaveValue('Rechecked source')
  expect(await axe(screen.getByRole('tabpanel'))).toHaveNoViolations()
  await user.click(screen.getByRole('button', { name: 'Cancel review' }))
  expect(screen.queryByLabelText('Review reason')).not.toBeInTheDocument()
})
