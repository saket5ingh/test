import { afterEach, describe, expect, it, vi } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { LoginPage } from '@/pages/LoginPage'
import { authService } from '@/services/authService'
import { renderWithProviders } from '@/test/renderWithProviders'

afterEach(() => { sessionStorage.clear(); vi.restoreAllMocks() })

describe('LoginPage', () => {
  it('blocks submission and reports a missing password', async () => {
    const user = userEvent.setup()
    renderWithProviders(<LoginPage />, { route: '/login' })

    await user.type(screen.getByLabelText('User ID / email'), 'officer')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))

    expect(await screen.findByRole('alert')).toHaveTextContent('Enter your password.')
    expect(screen.getByLabelText('Password')).toHaveAttribute('aria-invalid', 'true')
  })

  it('accepts a username without imposing email-only validation', async () => {
    const user = userEvent.setup()
    renderWithProviders(<LoginPage />, { route: '/login' })

    const login = vi.spyOn(authService, 'login').mockRejectedValue(new Error('Invalid credentials'))
    const userIdInput = screen.getByLabelText('User ID / email')
    await user.clear(userIdInput)
    await user.type(userIdInput, 'not-an-email')
    await user.type(screen.getByLabelText('Password'), 'secret')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))

    await waitFor(() => expect(login).toHaveBeenCalledWith({ userId: 'not-an-email', password: 'secret' }))
    expect(await screen.findByRole('alert')).toHaveTextContent('Sign-in failed.')
  })

  it('toggles password visibility', async () => {
    const user = userEvent.setup()
    renderWithProviders(<LoginPage />, { route: '/login' })

    const password = screen.getByLabelText('Password')
    expect(password).toHaveAttribute('type', 'password')

    await user.click(screen.getByRole('button', { name: 'Show' }))
    expect(password).toHaveAttribute('type', 'text')
  })
})
