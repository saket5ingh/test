import { useState, type FormEvent } from 'react'
import clsx from 'clsx'
import { Navigate, useNavigate } from 'react-router-dom'
import courthouseArt from '@/assets/courthouse.svg'
import { GoogleIcon, Icon } from '@/components/icons/Icon'
import { BrandMark } from '@/components/ui/BrandMark'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/context/authState'
import styles from './Auth.module.css'
import { GoogleSignIn } from '@/components/auth/GoogleSignIn'
import { USE_MOCK } from '@/services/config'


interface Errors {
  userId?: string
  password?: string
  form?: string
}

export function LoginPage() {
  const navigate = useNavigate()
  const { login, isAuthenticated } = useAuth()

  const [userId, setUserId] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [errors, setErrors] = useState<Errors>({})
  const [submitting, setSubmitting] = useState(false)

  if (isAuthenticated) return <Navigate to="/dashboard" replace />

  const validate = (): Errors => {
    const next: Errors = {}
    if (!userId.trim()) next.userId = 'Enter your user ID or email.'
    
    if (!password) next.password = 'Enter your password.'
    return next
  }

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault()
    const found = validate()
    setErrors(found)
    if (Object.keys(found).length) return

    setSubmitting(true)
    try {
      await login({ userId: userId.trim(), password })
      navigate('/dashboard', { replace: true })
    } catch {
      setErrors({ form: 'Sign-in failed. Check your credentials and try again.' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className={styles.wrap}>
      <div className={styles.split}>
        <div className={styles.illus}>
          <div className={styles.illusBrand}>
            <BrandMark subtitle="Child-protection case monitor" onDark />
          </div>
          <img className={styles.art} src={courthouseArt} alt="" />
          <div className={styles.tag}>
            Track every child-protection case across the districts you cover —{' '}
            <span>one monthly scrape</span>, one place to watch what changed.
          </div>
          <div className={styles.illusFoot}>
            Restricted to authorized Child Welfare Committee and legal-aid personnel. Contact your administrator to request access.
          </div>
        </div>

        <main className={styles.panel}>
          <h1>Sign in to continue</h1>
          <p className={styles.lede}>
            Use your assigned user ID or email and password.
          </p>

          <form onSubmit={onSubmit} noValidate>
            {errors.form ? (
              <div className={styles.error} role="alert" style={{ marginBottom: 12 }}>
                {errors.form}
              </div>
            ) : null}

            <div className={styles.field}>
              <label htmlFor="login-id">User ID / email</label>
              <div className={clsx(styles.inputShell, errors.userId && styles.invalid)}>
                <Icon name="user" />
                <input
                  id="login-id"
                  type="text"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder="name@your-organization.org"
                  autoComplete="username"
                  aria-invalid={Boolean(errors.userId)}
                  aria-describedby={errors.userId ? 'login-id-error' : undefined}
                />
              </div>
              {errors.userId ? (
                <div className={styles.error} id="login-id-error" role="alert">
                  {errors.userId}
                </div>
              ) : null}
            </div>

            <div className={styles.field}>
              <label htmlFor="login-pw">Password</label>
              <div className={clsx(styles.inputShell, errors.password && styles.invalid)}>
                <Icon name="lock" />
                <input
                  id="login-pw"
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  aria-invalid={Boolean(errors.password)}
                  aria-describedby={errors.password ? 'login-pw-error' : undefined}
                />
                <button
                  type="button"
                  className={styles.reveal}
                  aria-pressed={showPw}
                  onClick={() => setShowPw((v) => !v)}
                >
                  {showPw ? 'Hide' : 'Show'}
                </button>
              </div>
              {errors.password ? (
                <div className={styles.error} id="login-pw-error" role="alert">
                  {errors.password}
                </div>
              ) : null}
            </div>

            <div className={styles.formHelp}>
              <span>For password resets, contact your administrator.</span>
            </div>

            <Button type="submit" variant="primary" block disabled={submitting}>
              {submitting ? 'Signing in…' : 'Sign in'}
            </Button>
          </form>

          {!USE_MOCK ? <GoogleSignIn /> : null}
          {USE_MOCK ? (
            <button type="button" className={styles.sso} onClick={() => navigate('/select-account')}>
              <GoogleIcon /> Preview demo accounts
            </button>
          ) : null}

          <div className={styles.foot}>
            Your access level (field user or admin) is set by your organization account — there's
            nothing to choose here. Your session ends when you sign out or the token expires.
          </div>
        </main>
      </div>
    </div>
  )
}
