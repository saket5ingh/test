import { useCallback } from 'react'
import { Link, useParams } from 'react-router-dom'
import { DetailsTab, TimelineTab } from '@/components/case-detail/CaseTabs'
import { useResource } from '@/hooks/useResource'
import { request } from '@/services/http'
import { normalizeCase } from '@/services/caseService'
import type { RunSnapshot } from '@/types/scraper'
export function AdminSnapshotPage() {
  const { runId, caseId } = useParams()
  const load = useCallback((signal: AbortSignal) => request<RunSnapshot>(`/scrapes/runs/${runId}/results/${caseId}`, { signal }), [runId, caseId])
  const { data, error, loading } = useResource(`${runId}:${caseId}`, load)
  if (loading) return <p role="status">Loading snapshot…</p>
  if (error || !data) return <p role="alert">{error ?? 'Snapshot unavailable'}</p>
  const row = normalizeCase(data.snapshot)
  return <>
    <Link to={`/admin/runs/${runId}`}>← Back to run results</Link>
    <h1>Historical snapshot: {row.cnr}</h1>
    <p>Collected {new Date(data.fetched_at).toLocaleString()} · Status then: {row.status}</p>
    <p><Link to={`/cases/${row.id}`}>View the latest case record</Link></p>
    <DetailsTab caseRecord={row} /><h2>Hearing history at collection</h2><TimelineTab caseRecord={row} />
  </>
}
