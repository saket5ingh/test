import { render, screen, within } from '@testing-library/react'
import { expect, it, vi } from 'vitest'
import { DashboardPage } from './DashboardPage'
vi.mock('@/services/config', () => ({ USE_MOCK: false }))
vi.mock('@/services/analyticsService', () => ({ analyticsService: {
  getByState: async () => [{ state: 'Chandigarh', value: 22 }],
  getOutcomes: async () => [{ label: 'Disposed', value: 22 }],
  getByYear: async () => [{ year: '2020', value: 22 }],
  getBySection: async () => [
    { act: 'Prohibition of Child Marriage Act', section: '9', value: 10 },
    { act: 'Child Marriage Restraint Act, 1929', section: '9', value: 12 },
  ],
} }))
vi.mock('recharts', async () => {
  const actual = await vi.importActual<typeof import('recharts')>('recharts')
  return { ...actual, ResponsiveContainer: ({ children }: { children: import('react').ReactNode }) => <div>{children}</div> }
})
it('shows live child-marriage totals with law-specific sections and no illustrative labels', async () => {
  render(<DashboardPage />)
  expect(screen.getByRole('heading', { name: 'Child-marriage Dashboard' })).toBeVisible()
  const states = await screen.findByRole('table', { name: 'Child-marriage cases by state' })
  expect(within(states).getByRole('cell', { name: '22' })).toBeInTheDocument()
  const sections = await screen.findByRole('table', { name: 'Child-marriage sections by Act' })
  expect(within(sections).getByText('Prohibition of Child Marriage Act — Section 9')).toBeInTheDocument()
  expect(within(sections).getByText('Child Marriage Restraint Act, 1929 — Section 9')).toBeInTheDocument()
  expect(screen.queryByText(/illustrative/i)).not.toBeInTheDocument()
})
