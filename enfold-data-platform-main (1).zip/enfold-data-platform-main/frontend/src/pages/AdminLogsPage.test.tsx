import { act, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { beforeEach, afterEach, expect, it, vi } from 'vitest'
import { axe } from 'jest-axe'
import { scrapeService } from '@/services/scrapeService'
import type { ScraperRun } from '@/types/scraper'
import { AdminLogsPage } from './AdminLogsPage'
vi.mock('@/services/scrapeService', () => ({ scrapeService: { listRunPage: vi.fn(), options: vi.fn() } }))
const run: ScraperRun = {
  id: 'test-run', name: 'Monthly child-marriage scan — 2026-10', trigger: 'scheduled', triggeredBy: null,
  queuedAt: '2026-10-11T18:30:00Z', startedAt: '2026-10-11T18:30:04Z', completedAt: null,
  lastActivityAt: '2026-10-11T19:30:00Z', outcome: 'running', criteria: null, resolvedScope: null,
  tasks: { success: 15000, queued: 10, running: 1, failed: 2 }, counts: {}, total: 0,
  coverage: [], snapshotsAvailable: true, error: null, cancelRequested: false,
  legacyCriteria: { state: null, acts: null, sections: null, status: 'all' },
}
const history = { items: [run], total: 51, page: 1, pageSize: 25 }
function page() { return render(<MemoryRouter><AdminLogsPage /></MemoryRouter>) }
beforeEach(() => {
  vi.mocked(scrapeService.listRunPage).mockResolvedValue(history)
  vi.mocked(scrapeService.options).mockResolvedValue({ states: [], acts: [], statesUpdatedAt: null, workerHealthy: true, workerLastSeen: '2026-10-11T19:30:00Z', monthlyEnabled: true, monthlySchedule: { week: 3, weekday: 4, hour: 0, minute: 0, timezone: 'Asia/Kolkata', nextRunAt: '2026-10-15T18:30:00Z' } })
})
afterEach(() => { vi.useRealTimers(); vi.resetAllMocks() })
it('explains zero saved cases with activity and shows backend schedule in its specified timezone', async () => {
  const { container } = page()
  expect(await screen.findByText('15,000 completed')).toBeVisible()
  expect(screen.getByText('Discovery can run before cases are saved.')).toBeVisible()
  expect(screen.getByText(/Every third Friday · 00:00 · Asia\/Kolkata/)).toBeVisible()
  expect(screen.getByText('16 Oct 2026, 00:00')).toBeVisible()
  expect(screen.getByText(/All states · Child-marriage acts only · All sections · Pending & disposed/)).toBeVisible()
  expect(screen.getByText('Reporting normally')).toBeVisible()
  expect(screen.getByRole('link', { name: `Open results for ${run.name}` })).toHaveAttribute('href', '/admin/runs/test-run')
  expect(screen.getByRole('region', { name: 'Scrape run history' })).toHaveAttribute('tabindex', '0')
  expect(screen.getByRole('region', { name: 'Scrape run history' })).toHaveAccessibleDescription('Scroll horizontally if needed to see all run information.')
  const results = await axe(container, { rules: { region: { enabled: false } } })
  expect(results.violations).toEqual([])
})
it('searches and filters on the server, resets pagination, clears filters, and preserves input focus', async () => {
  const user = userEvent.setup(); page()
  await user.click(await screen.findByRole('button', { name: 'Next' }))
  await waitFor(() => expect(scrapeService.listRunPage).toHaveBeenLastCalledWith(2, expect.any(AbortSignal), expect.any(Object)))
  const search = screen.getByRole('searchbox', { name: 'Run name' })
  await user.type(search, 'PCMA %')
  expect(search).toHaveFocus()
  await user.keyboard('{Enter}')
  await waitFor(() => expect(scrapeService.listRunPage).toHaveBeenLastCalledWith(1, expect.any(AbortSignal), expect.objectContaining({ q: 'PCMA %' })))
  expect(search).toHaveFocus()
  await user.selectOptions(screen.getByLabelText('Outcome'), 'failed')
  await user.selectOptions(screen.getByLabelText('Trigger'), 'manual')
  await waitFor(() => expect(scrapeService.listRunPage).toHaveBeenLastCalledWith(1, expect.any(AbortSignal), { pageSize: 25, q: 'PCMA %', outcome: 'failed', trigger: 'manual' }))
  await user.click(screen.getByRole('button', { name: 'Clear filters' }))
  expect(search).toHaveValue('')
  await waitFor(() => expect(scrapeService.listRunPage).toHaveBeenLastCalledWith(1, expect.any(AbortSignal), { pageSize: 25, q: '', outcome: 'all', trigger: 'all' }))
})
it('polls every five seconds and retains rows when a refresh fails', async () => {
  vi.useFakeTimers(); page()
  await act(async () => { await Promise.resolve() })
  vi.mocked(scrapeService.listRunPage).mockRejectedValueOnce(new Error('Temporary API failure.'))
  await act(async () => { await vi.advanceTimersByTimeAsync(5000) })
  expect(screen.getByRole('alert')).toHaveTextContent('Showing the last successful update.')
  expect(screen.getByRole('link', { name: run.name })).toBeVisible()
  expect(scrapeService.listRunPage).toHaveBeenCalledTimes(2)
  await act(async () => { await vi.advanceTimersByTimeAsync(5000) })
  expect(screen.queryByRole('alert')).not.toBeInTheDocument()
})
it('shows loading, recoverable initial errors and a helpful empty filtered state', async () => {
  const user = userEvent.setup()
  let reject: (error: Error) => void = () => {}
  vi.mocked(scrapeService.listRunPage).mockImplementationOnce(() => new Promise((_resolve, rejectPromise) => { reject = rejectPromise }))
  page(); expect(screen.getByRole('status')).toHaveTextContent('Loading run history')
  await act(async () => { reject(new Error('History unavailable.')) })
  expect(await screen.findByRole('alert')).toHaveTextContent('History unavailable.')
  await user.click(within(screen.getByRole('alert')).getByRole('button', { name: 'Retry' }))
  await screen.findByText('15,000 completed')
  vi.mocked(scrapeService.listRunPage).mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 25 })
  await user.selectOptions(screen.getByLabelText('Outcome'), 'cancelled')
  expect(await screen.findByRole('heading', { name: 'No runs match these filters' })).toBeVisible()
  expect(screen.queryByRole('link', { name: run.name })).not.toBeInTheDocument()
})
it('recovers to an existing page when the filtered result count shrinks', async () => {
  const user = userEvent.setup(); page()
  await user.click(await screen.findByRole('button', { name: 'Next' }))
  await waitFor(() => expect(scrapeService.listRunPage).toHaveBeenLastCalledWith(2, expect.any(AbortSignal), expect.any(Object)))
  vi.mocked(scrapeService.listRunPage).mockResolvedValue({ items: [], total: 0, page: 2, pageSize: 25 })
  await user.click(screen.getByRole('button', { name: 'Refresh' }))
  await waitFor(() => expect(scrapeService.listRunPage).toHaveBeenLastCalledWith(1, expect.any(AbortSignal), expect.any(Object)))
  expect(screen.getByText('Page 1 of 1')).toBeVisible()
})
it('does not claim healthy live status after an options refresh fails', async () => {
  page(); await screen.findByText('Reporting normally')
  vi.mocked(scrapeService.options).mockRejectedValue(new Error('Status unavailable.'))
  fireEvent.click(screen.getByRole('button', { name: 'Refresh' }))
  expect(await screen.findByText('Health could not be refreshed')).toBeVisible()
  expect(screen.queryByText('Reporting normally')).not.toBeInTheDocument()
})
