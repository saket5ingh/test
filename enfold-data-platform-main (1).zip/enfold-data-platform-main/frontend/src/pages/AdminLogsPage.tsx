import { useCallback, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/Button'
import { scrapeService, type RunListFilters } from '@/services/scrapeService'
import { usePollingResource } from '@/hooks/usePollingResource'
import type { ScraperRun } from '@/types/scraper'
import styles from './AdminLogsPage.module.css'

const labels: Record<ScraperRun['outcome'], string> = { pending: 'Pending', queued: 'Queued', running: 'Running', success: 'Completed', partial: 'Partially completed', failed: 'Failed', cancelled: 'Cancelled' }
const number = (value: number) => value.toLocaleString('en-IN')
function stamp(value: string | null | undefined, timezone?: string) {
  return value ? new Date(value).toLocaleString('en-IN', { timeZone: timezone, day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }) : 'Not available'
}
function elapsed(run: ScraperRun, now: number) {
  if (!run.startedAt) return 'Not started'
  const minutes = Math.max(0, Math.floor(((run.completedAt ? new Date(run.completedAt).getTime() : now) - new Date(run.startedAt).getTime()) / 60000))
  return minutes < 1 ? 'Less than a minute' : `${Math.floor(minutes / 60) ? `${Math.floor(minutes / 60)}h ` : ''}${minutes % 60}m${run.completedAt ? '' : ' elapsed'}`
}
function recurrence(schedule: NonNullable<Awaited<ReturnType<typeof scrapeService.options>>['monthlySchedule']>) {
  const week = ['first', 'second', 'third', 'fourth', 'fifth'][schedule.week - 1] ?? String(schedule.week)
  const day = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][schedule.weekday] ?? 'day'
  return `Every ${week} ${day} · ${String(schedule.hour).padStart(2, '0')}:${String(schedule.minute).padStart(2, '0')} · ${schedule.timezone}`
}
export function AdminLogsPage() {
  const [page, setPage] = useState(1)
  const [draft, setDraft] = useState('')
  const [filters, setFilters] = useState<RunListFilters>({ q: '', outcome: 'all', trigger: 'all' })
  const load = useCallback(async (signal: AbortSignal) => ({ ...await scrapeService.listRunPage(page, signal, { ...filters, pageSize: 25 }), fetchedAt: Date.now() }), [page, filters])
  const { data, error, loading, refresh } = usePollingResource(`runs:${page}:${JSON.stringify(filters)}`, load)
  const loadOptions = useCallback((signal: AbortSignal) => scrapeService.options(signal), [])
  const options = usePollingResource('scraper-options', loadOptions, 15000)
  const totalPages = Math.max(1, Math.ceil((data?.total ?? 0) / 25))
  if (data && page > totalPages) setPage(totalPages)
  function change(next: Partial<RunListFilters>) { setPage(1); setFilters((old) => ({ ...old, ...next })) }
  const filtered = Boolean(filters.q || filters.outcome !== 'all' || filters.trigger !== 'all')
  const schedule = options.data?.monthlySchedule
  const zone = Intl.DateTimeFormat().resolvedOptions().timeZone
  return <div className={styles.page}>
    <header className={styles.header}><div><p className={styles.eyebrow}>SCRAPER OPERATIONS</p><h1>Scrape run logs</h1><p>Follow live work and explore the history of every manual and monthly scan.</p></div><Link className={styles.createLink} to="/admin/run">Run custom scrape <span aria-hidden="true">↗</span></Link></header>
    <section className={styles.operations} aria-label="Monthly schedule and worker health">
      <div className={styles.schedule}><div className={styles.stripHeading}><h2>Monthly child-marriage scan</h2>{options.data ? <span className={styles.badge} data-status={options.data.monthlyEnabled ? 'success' : 'cancelled'}>{options.data.monthlyEnabled ? 'Enabled' : 'Disabled'}</span> : null}</div>
        {options.loading ? <p>Loading schedule…</p> : options.data ? <><p className={styles.next}>{options.data.monthlyEnabled ? <>Next scheduled time <strong>{schedule?.nextRunAt ? stamp(schedule.nextRunAt, schedule.timezone) : 'Not available'}</strong></> : 'Automatic monthly scans are disabled.'}</p>{schedule && options.data.monthlyEnabled ? <p>{recurrence(schedule)}</p> : null}<p className={styles.small}>All states · Child-marriage acts only · All sections · Pending &amp; disposed. A busy worker may delay processing.</p></> : null}
      </div><div className={styles.worker}><h2>Scraper worker</h2>{options.data ? <><p className={styles.workerStatus} data-healthy={options.data.workerHealthy && !options.error}>{options.error ? 'Health could not be refreshed' : options.data.workerHealthy ? 'Reporting normally' : 'No recent heartbeat'}</p><p className={styles.small}>Last seen: {stamp(options.data.workerLastSeen)} · {zone}</p>{!options.data.workerHealthy ? <p className={styles.small}>Queued work waits until the worker is available.</p> : <p className={styles.small}>A heartbeat confirms availability, not run completion.</p>}</> : !options.loading ? <p>Worker health unavailable</p> : <p>Checking worker…</p>}</div>
    </section>
    {options.error ? <div className={styles.error} role="alert"><span>Schedule and worker information could not be refreshed. {options.error}</span><Button onClick={options.refresh}>Retry status</Button></div> : null}
    <form className={styles.filters} onSubmit={(event) => { event.preventDefault(); change({ q: draft.trim() }) }} role="search" aria-label="Find scrape runs">
      <div className={styles.search}><label>Run name<input type="search" maxLength={160} placeholder="Search run names…" value={draft} onChange={(event) => setDraft(event.target.value)} /></label><Button type="submit">Search</Button></div>
      <label>Outcome<select value={filters.outcome} onChange={(event) => change({ outcome: event.target.value as RunListFilters['outcome'] })}><option value="all">All outcomes</option>{Object.entries(labels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></label>
      <label>Trigger<select value={filters.trigger} onChange={(event) => change({ trigger: event.target.value as RunListFilters['trigger'] })}><option value="all">All triggers</option><option value="manual">Manual</option><option value="scheduled">Scheduled</option></select></label>
      {filtered || draft ? <Button variant="subtle" onClick={() => { setDraft(''); change({ q: '', outcome: 'all', trigger: 'all' }) }}>Clear filters</Button> : null}
    </form>
    <div className={styles.historyHead}><div><h2>Run history {data ? <span>{number(data.total)} {data.total === 1 ? 'run' : 'runs'}{filtered ? ' matching' : ''}</span> : null}</h2><p>Times shown in {zone}. Tasks include court discovery and case collection.</p></div><div className={styles.refresh}><span>{data ? `Updated ${new Date(data.fetchedAt).toLocaleTimeString('en-IN', { hour12: false })}` : 'Refreshes every 5 seconds'}</span><Button onClick={() => { refresh(); options.refresh() }}>Refresh</Button></div></div>
    {loading ? <p role="status" className={styles.empty}>Loading run history…</p> : null}
    {error ? <div role="alert" className={styles.error}><span>{error}{data ? ' Showing the last successful update.' : ''}</span><Button onClick={refresh}>Retry</Button></div> : null}
    {data?.items.length ? <><div className={styles.scrollHint} id="run-scroll-help">Scroll horizontally if needed to see all run information.</div><div className={styles.tableScroll} role="region" aria-label="Scrape run history" aria-describedby="run-scroll-help" tabIndex={0}><table><caption className={styles.srOnly}>Scrape run history</caption><thead><tr><th scope="col">Run / initiated by</th><th scope="col">Outcome</th><th scope="col">Activity</th><th scope="col">Saved cases</th><th scope="col">Timing</th><th scope="col">Results</th></tr></thead><tbody>{data.items.map((run) => <tr key={run.id}>
      <th scope="row" className={styles.runName}><Link to={`/admin/runs/${run.id}`}>{run.name}</Link><small>{run.trigger === 'scheduled' ? 'Scheduled · System' : `Manual · ${run.triggeredByName || 'Administrator'}`}</small></th>
      <td><span className={styles.badge} data-status={run.outcome}>{labels[run.outcome]}</span>{run.cancelRequested ? <small>Cancellation requested</small> : null}{['pending', 'queued'].includes(run.outcome) ? <small>Waiting for worker</small> : null}</td>
      <td className={styles.activity}><strong>{number(run.tasks.success ?? 0)} completed</strong><div className={styles.taskCounts}><span>{number(run.tasks.running ?? 0)} running</span><span>{number(run.tasks.queued ?? 0)} queued</span><span data-failed={Boolean(run.tasks.failed)}>{number(run.tasks.failed ?? 0)} failed</span></div><small>Last activity: {stamp(run.lastActivityAt)}</small></td>
      <td className={styles.saved}><strong>{number(run.total)}</strong>{run.total === 0 && run.outcome === 'running' ? <small>Discovery can run before cases are saved.</small> : <small>Cases in this run</small>}</td>
      <td className={styles.timing}><span>Queued {stamp(run.queuedAt)}</span><small>{run.startedAt ? `Started ${stamp(run.startedAt)}` : 'Not started'}</small>{run.startedAt ? <small>{elapsed(run, data.fetchedAt)}</small> : null}</td>
      <td><Link className={styles.resultLink} aria-label={`Open results for ${run.name}`} to={`/admin/runs/${run.id}`}>Open results <span aria-hidden="true">↗</span></Link></td>
    </tr>)}</tbody></table></div></> : data ? <div className={styles.empty}><h3>{filtered ? 'No runs match these filters' : 'No scrape runs yet'}</h3><p>{filtered ? 'Try another run name or clear the filters.' : 'Start a custom scrape, or wait for the next enabled monthly scan.'}</p></div> : null}
    {data ? <nav className={styles.pagination} aria-label="Run pages"><span>{data.total ? `${number((page - 1) * 25 + 1)}–${number(Math.min(page * 25, data.total))} of ${number(data.total)} runs` : '0 runs'}</span><div><Button disabled={page === 1 || loading} onClick={() => setPage((v) => v - 1)}>Previous</Button><span>Page {page} of {totalPages}</span><Button disabled={page >= totalPages || loading} onClick={() => setPage((v) => v + 1)}>Next</Button></div></nav> : null}
  </div>
}
