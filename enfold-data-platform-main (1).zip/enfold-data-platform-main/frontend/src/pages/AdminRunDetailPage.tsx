import { useCallback, useEffect, useState, type ReactNode, type KeyboardEvent } from 'react'
import { RunPerformancePanel } from '@/components/admin/RunPerformancePanel'
import { Icon } from '@/components/icons/Icon'
import { Link, useParams } from 'react-router-dom'
import { Button } from '@/components/ui/Button'
import { scrapeService, type RunFilters } from '@/services/scrapeService'
import { usePollingResource } from '@/hooks/usePollingResource'
import { ACT_OPTIONS } from '@/lib/caseMetadata'
import type { ScraperRun, RunEvent, RunTask } from '@/types/scraper'
import styles from './AdminRunDetailPage.module.css'

const tabs = ['Overview', 'Results', 'Failures', 'Audit history'] as const
type Tab = typeof tabs[number]
type Query = RunFilters & { page: number; pageSize: number }
const initialQuery = (): Query => ({ page: 1, pageSize: 25, q: '' })
const number = (value: number) => value.toLocaleString()
const date = (value: string | null) => value ? new Date(value).toLocaleString() : '—'
const activeRun = (run: ScraperRun) => ['pending', 'queued', 'running'].includes(run.outcome)
const labels: Record<string, string> = { quarantined: 'Needs review', success: 'Completed', partial: 'Partially completed', pending: 'Pending', queued: 'Queued', running: 'Running', failed: 'Failed', cancelled: 'Cancelled', all: 'All', new: 'New', updated: 'Updated', unchanged: 'Unchanged', disposed: 'Disposed', acquitted: 'Acquitted', allowed: 'Allowed', rejected: 'Rejected', discover: 'State discovery', state: 'District discovery', district: 'Court discovery', court: 'Act discovery', search: 'Case search', case: 'Case details' }
const humanize = (value: string) => value.replaceAll('_', ' ').replace(/^./, (c) => c.toUpperCase())
const label = (value: string) => labels[value] ?? humanize(value)
const mappingFields: Record<string, string> = { option: 'Selected act', label: 'Court act name', code: 'Court act code', name: 'Court act name', reason: 'Review reason', location: 'Location', state: 'State', district: 'District', court: 'Court' }
function mappingValue(key: string, value: unknown) {
  if (typeof value !== 'string') return JSON.stringify(value)
  if (key === 'option') return ACT_OPTIONS.find((act) => act.key === value)?.label ?? humanize(value)
  return key === 'reason' ? humanize(value) : value
}
function Badge({ value }: { value: string }) { return <span className={styles.badge} data-status={value}>{label(value)}</span> }
function Table({ children, name }: { children: ReactNode; name: string }) { return <div className={styles.tableScroll} role="region" aria-label={name} tabIndex={0}><p className={styles.scrollHint}>Scroll horizontally to see all columns.</p><table>{children}</table></div> }
function ErrorMessage({ error, retry }: { error?: string; retry: () => void }) { return error ? <div className={styles.error} role="alert">{error}<Button onClick={retry}>Try again</Button></div> : null }
function Empty({ children }: { children: ReactNode }) { return <div className={styles.empty}>{children}</div> }
function Select({ name, value, options, onChange }: { name: string; value: string; options: [string, string][]; onChange: (value: string) => void }) {
  return <label>{name}<select value={value} onChange={(event) => onChange(event.target.value)}>{options.map(([key, text]) => <option key={key} value={key}>{text}</option>)}</select></label>
}
function Search({ query, setQuery, placeholder }: { query: Query; setQuery: (value: Query) => void; placeholder: string }) {
  const [draft, setDraft] = useState(query.q ?? '')
  return <form className={styles.search} onSubmit={(event) => { event.preventDefault(); setQuery({ ...query, q: draft.trim(), page: 1 }) }}><label>Search<input type="search" value={draft} maxLength={160} placeholder={placeholder} onChange={(event) => setDraft(event.target.value)} /></label><Button type="submit">Search</Button></form>
}
function Pagination({ query, setQuery, total, loading, name }: { query: Query; setQuery: (value: Query) => void; total: number; loading: boolean; name: string }) {
  const pages = Math.max(1, Math.ceil(total / query.pageSize))
  const [jump, setJump] = useState('')
  return <nav className={styles.pagination} aria-label={`${name} pages`}>
    <span>{number(total)} {name.toLowerCase()} · Page {query.page} of {number(pages)}</span>
    <Select name="Rows per page" value={String(query.pageSize)} options={[25, 50, 100].map((n) => [String(n), String(n)])} onChange={(v) => setQuery({ ...query, page: 1, pageSize: Number(v) })} />
    <div className={styles.pageButtons}><Button disabled={query.page <= 1 || loading} onClick={() => setQuery({ ...query, page: query.page - 1 })}>Previous</Button><Button disabled={query.page >= pages || loading} onClick={() => setQuery({ ...query, page: query.page + 1 })}>Next</Button></div>
    <form className={styles.jump} onSubmit={(event) => { event.preventDefault(); const page = Number(jump); if (Number.isInteger(page) && page >= 1 && page <= pages) setQuery({ ...query, page }) }}><label>Go to page<input type="number" min={1} max={pages} value={jump} onChange={(event) => setJump(event.target.value)} /></label><Button type="submit" disabled={loading || !jump}>Go</Button></form>
  </nav>
}
type SectionProps = { id: string; active: boolean; query: Query; setQuery: (value: Query) => void; revision: number }
function Results({ id, active, query, setQuery, revision, states }: SectionProps & { states: { name: string }[] }) {
  const load = useCallback((signal: AbortSignal) => scrapeService.results(id, query.page, signal, query), [id, query])
  const { data, error, loading, refresh } = usePollingResource(`results:${id}:${JSON.stringify(query)}:${revision}`, load, active ? 5000 : 0)
  return <><div className={styles.sectionHead}><div><h2>Collected results</h2><p>Snapshots preserve what this run collected. Later changes to a case do not alter these results.</p></div></div>
    <div className={styles.filters}><Search key={query.q ?? ''} query={query} setQuery={setQuery} placeholder="CNR, reference or location" /><Select name="State" value={query.state ?? ''} options={[[ '', 'All states' ], ...states.map((s): [string, string] => [s.name, s.name])]} onChange={(state) => setQuery({ ...query, state, page: 1 })} /><Select name="Case status" value={query.status ?? 'all'} options={['all', 'pending', 'disposed', 'acquitted', 'allowed', 'rejected'].map((v) => [v, label(v)])} onChange={(status) => setQuery({ ...query, status, page: 1 })} /><Select name="Change" value={query.change_kind ?? 'all'} options={['all', 'new', 'updated', 'unchanged'].map((v) => [v, label(v)])} onChange={(change_kind) => setQuery({ ...query, change_kind, page: 1 })} /></div>
    <ErrorMessage error={error} retry={refresh} />{loading ? <Empty><span role="status">Loading results…</span></Empty> : data?.items.length ? <Table name="Historical case snapshots"><thead><tr><th>Case / CNR</th><th>Location</th><th>Status then</th><th>Change</th><th>Collected</th><th>Details</th></tr></thead><tbody>{data.items.map(({ snapshot, fetched_at, change_kind }) => <tr key={snapshot.id}><td className={styles.mono}>{snapshot.cnr || snapshot.id}</td><td>{snapshot.district}<small>{snapshot.state}</small></td><td><Badge value={snapshot.status} /></td><td><Badge value={change_kind} /></td><td className={styles.nowrap}>{date(fetched_at)}</td><td><Link className={styles.snapshotLink} to={`/admin/runs/${id}/cases/${snapshot.id}`}>View snapshot <Icon name="arrowUpRight" width={14} height={14} /></Link></td></tr>)}</tbody></Table> : data ? <Empty>No case snapshots match these filters.</Empty> : null}
    {data ? <Pagination query={query} setQuery={setQuery} total={data.total} loading={loading} name="Results" /> : null}</>
}
function location(task: RunTask) { return [task.payload.state?.name, task.payload.district?.name, task.payload.court ? `${task.payload.court.name} (${task.payload.court.code})` : null, task.payload.cnr, task.payload.act_code ? `Act code ${task.payload.act_code}` : null, task.payload.section ? `Section ${task.payload.section}` : null, task.payload.status].filter(Boolean).join(' · ') || 'Nationwide discovery' }
function ReviewTask({ id, task, reviewed }: { id: string; task: RunTask; reviewed: () => void }) {
  const [open, setOpen] = useState(false)
  const [reason, setReason] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  if (!task.review_required) return null
  return <div><strong>Needs operator review</strong><p>{task.review_reason}</p><p>{task.review_failures ?? 0} response failures across {task.review_sessions ?? 0} sessions. Quarantined {date(task.review_at ?? null)}.</p>
    <details className={styles.technical}><summary>Recovery evidence</summary><pre>{JSON.stringify(task.review_evidence ?? {}, null, 2)}</pre></details>
    {!open ? <Button onClick={() => setOpen(true)}>Review and retry task</Button> : <form className={styles.reviewForm} onSubmit={async (event) => {
      event.preventDefault(); if (busy || reason.trim().length < 3) return
      setBusy(true); setError('')
      try { await scrapeService.reviewRetry(id, task.id, reason.trim()); setOpen(false); setReason(''); reviewed() }
      catch (failure) { setError(failure instanceof Error ? failure.message : 'Retry failed. Please try again.') }
      finally { setBusy(false) }
    }}><p>Only this task will be requeued. Saved cases and snapshots remain intact.</p>
      <label>Review reason<textarea value={reason} onChange={(event) => setReason(event.target.value)} required minLength={3} maxLength={500} disabled={busy} /></label>
      {error ? <p role="alert" className={styles.error}>{error}</p> : null}
      <Button type="submit" disabled={busy || reason.trim().length < 3}>{busy ? 'Requesting retry…' : 'Confirm reviewed retry'}</Button>
      <Button type="button" disabled={busy} onClick={() => setOpen(false)}>Cancel review</Button></form>}
  </div>
}
function Failures({ id, active, query, setQuery, revision, reviewed }: SectionProps & { reviewed: () => void }) {
  const load = useCallback((signal: AbortSignal) => scrapeService.tasks(id, query.page, query.status ?? 'failed', signal, query), [id, query])
  const { data, error, loading, refresh } = usePollingResource(`tasks:${id}:${JSON.stringify(query)}:${revision}`, load, active ? 5000 : 0)
  return <><div className={styles.sectionHead}><div><h2>Work items & failures</h2><p>Inspect unfinished work here. “Retry unfinished work” excludes quarantined tasks. Review those individually below.</p></div></div>
    <div className={styles.filters}><Search key={query.q ?? ''} query={query} setQuery={setQuery} placeholder="Location, CNR or error" /><Select name="Task status" value={query.status ?? 'failed'} options={['failed', 'quarantined', 'queued', 'running', 'success', 'cancelled', 'all'].map((v) => [v, label(v)])} onChange={(status) => setQuery({ ...query, status, page: 1 })} /><Select name="Work type" value={query.kind ?? 'all'} options={['all', 'discover', 'state', 'district', 'court', 'search', 'case'].map((v) => [v, label(v)])} onChange={(kind) => setQuery({ ...query, kind, page: 1 })} /></div>
    <ErrorMessage error={error} retry={refresh} />{loading ? <Empty><span role="status">Loading work items…</span></Empty> : data?.items.length ? <Table name="Work items"><thead><tr><th>Work type</th><th>Location / criteria</th><th>Status</th><th>Attempts</th><th>Source error</th></tr></thead><tbody>{data.items.map((task) => <tr key={task.id}><td>{label(task.kind)}</td><td className={styles.location}>{location(task)}</td><td><Badge value={task.status} />{task.review_required ? <small>Needs review · coverage incomplete</small> : null}</td><td>{task.attempts}</td><td>{task.error_message ? <details className={styles.technical}><summary>View error details</summary><pre>{task.error_message}</pre></details> : '—'}<ReviewTask id={id} task={task} reviewed={() => { refresh(); reviewed() }} /></td></tr>)}</tbody></Table> : data ? <Empty>No work items match these filters.</Empty> : null}
    {data ? <Pagination query={query} setQuery={setQuery} total={data.total} loading={loading} name="Work items" /> : null}</>
}
function EventMessage({ event }: { event: RunEvent }) {
  let payload: Record<string, unknown> | null = null
  if (event.kind === 'act_mapping_review') {
    try {
      const parsed: unknown = JSON.parse(event.message)
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) payload = parsed as Record<string, unknown>
    } catch { /* Older event messages can be plain text. */ }
  }
  if (payload) {
    const fields = Object.entries(payload).filter(([key, value]) => !/hash|version|config/i.test(key) && value !== null)
    return <><dl className={styles.mapping}>{fields.map(([key, value]) => <div key={key}><dt>{mappingFields[key] ?? humanize(key)}</dt><dd>{mappingValue(key, value)}</dd></div>)}</dl><details className={styles.technical}><summary>Technical payload</summary><pre>{JSON.stringify(payload, null, 2)}</pre></details></>
  }
  return <details className={styles.technical}><summary>{event.kind === 'act_mapping_review' ? 'Act name needs review' : 'View event details'}</summary><pre>{event.message}</pre></details>
}
function Audit({ id, active, query, setQuery, revision }: SectionProps) {
  const load = useCallback((signal: AbortSignal) => scrapeService.events(id, query.page, signal, query), [id, query])
  const { data, error, loading, refresh } = usePollingResource(`events:${id}:${JSON.stringify(query)}:${revision}`, load, active ? 5000 : 0)
  return <><div className={styles.sectionHead}><div><h2>Audit history</h2><p>Newest events first. Filter errors and warnings to find work that needs attention.</p></div></div>
    <div className={styles.filters}><Search key={query.q ?? ''} query={query} setQuery={setQuery} placeholder="Search event messages" /><Select name="Event category" value={query.kind ?? 'all'} options={['all', 'errors', 'warnings', 'activity'].map((v) => [v, label(v)])} onChange={(kind) => setQuery({ ...query, kind, page: 1 })} /></div>
    <ErrorMessage error={error} retry={refresh} />{loading ? <Empty><span role="status">Loading audit history…</span></Empty> : data?.items.length ? <ol className={styles.timeline}>{data.items.map((event) => <li key={event.id}><div className={styles.eventMeta}><time>{date(event.at)}</time><span>{event.actor_name || 'System / worker'}</span></div><div className={styles.eventBody}><strong>{label(event.kind)}</strong><EventMessage event={event} /></div></li>)}</ol> : data ? <Empty>No events match these filters.</Empty> : null}
    {data ? <Pagination query={query} setQuery={setQuery} total={data.total} loading={loading} name="Events" /> : null}</>
}
function Overview({ run }: { run: ScraperRun }) {
  const criteria = run.criteria
  const [now, setNow] = useState(() => Date.now())
  const active = activeRun(run)
  useEffect(() => {
    if (!active) return
    const timer = setInterval(() => setNow(Date.now()), 30000)
    return () => clearInterval(timer)
  }, [active])
  const elapsed = run.startedAt ? Math.max(0, Math.floor(((run.completedAt ? new Date(run.completedAt).getTime() : now) - new Date(run.startedAt).getTime()) / 60000)) : null
  const fields = [['States', criteria?.allStates ? 'All states' : run.resolvedScope?.states.map((s) => s.name).join(', ') || criteria?.stateCodes.join(', ') || run.legacyCriteria?.state || '—'], ['Acts', criteria?.allActs ? 'All eight act options' : criteria?.actKeys.map((key) => ACT_OPTIONS.find((a) => a.key === key)?.label ?? key).join(', ') || run.legacyCriteria?.acts || '—'], ['Sections', criteria ? criteria.sections.join(', ') || 'All sections' : run.legacyCriteria?.sections || '—'], ['Case status', criteria?.status === 'all' ? 'Pending & disposed' : label(criteria?.status ?? run.legacyCriteria?.status ?? 'all')], ['Queued', date(run.queuedAt)], ['Started', run.startedAt ? date(run.startedAt) : 'Waiting for worker'], ['Completed', date(run.completedAt)], ['Elapsed', elapsed === null ? 'Not started' : `${Math.floor(elapsed / 60)}h ${elapsed % 60}m`], ['Initiated by', run.trigger === 'scheduled' ? 'Monthly scheduler' : run.triggeredByName || 'Administrator (name unavailable)']]
  const kinds = [...new Set(run.coverage.map((r) => r.kind))]
  return <><RunPerformancePanel run={run} now={now} /><div className={styles.sectionHead}><div><h2>Run overview</h2><p>Submitted criteria and the work discovered so far.</p></div></div><dl className={styles.detailsGrid}>{fields.map(([key, value]) => <div key={key}><dt>{key}</dt><dd>{value}</dd></div>)}</dl>
    <div className={styles.sectionHead}><div><h2>Coverage by work type</h2><p>Tasks are discovered as courts are scanned, so these counts are not a completion percentage.</p></div></div>
    {kinds.length ? <Table name="Coverage by work type"><thead><tr><th>Work type</th>{['success', 'queued', 'running', 'failed', 'cancelled'].map((s) => <th key={s}>{label(s)}</th>)}</tr></thead><tbody>{kinds.map((kind) => <tr key={kind}><td>{label(kind)}</td>{['success', 'queued', 'running', 'failed', 'cancelled'].map((status) => <td key={status}>{number(run.coverage.filter((r) => r.kind === kind && r.status === status).reduce((n, r) => n + r.count, 0))}</td>)}</tr>)}</tbody></Table> : <Empty>Coverage will appear once the worker discovers tasks.</Empty>}
  </>
}
export function AdminRunDetailPage() { const id = useParams().runId ?? ''; return <RunDetail key={id} id={id} /> }
function RunDetail({ id }: { id: string }) {
  const [tab, setTab] = useState<Tab>('Overview')
  const [queries, setQueries] = useState<Record<string, Query>>({ Results: initialQuery(), Failures: { ...initialQuery(), status: 'failed' }, 'Audit history': { ...initialQuery(), pageSize: 50 } })
  const [revision, setRevision] = useState(0)
  const load = useCallback((signal: AbortSignal) => scrapeService.getRun(id, signal), [id])
  const runData = usePollingResource(`run:${id}`, load, 5000, activeRun)
  const [actionError, setActionError] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [confirmCancel, setConfirmCancel] = useState(false)
  const run = runData.data
  function refresh() { runData.refresh(); setRevision((v) => v + 1) }
  async function action(kind: 'cancel' | 'retry' | 'download') {
    setBusy(kind); setActionError('')
    try { await scrapeService[kind](id); if (kind !== 'download') refresh(); setConfirmCancel(false) }
    catch (error) { setActionError(error instanceof Error ? error.message : 'Action failed. Please try again.') }
    finally { setBusy(null) }
  }
  function tabKey(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    const target = event.key === 'ArrowRight' ? (index + 1) % tabs.length : event.key === 'ArrowLeft' ? (index + tabs.length - 1) % tabs.length : event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : -1
    if (target < 0) return
    event.preventDefault(); setTab(tabs[target]); document.getElementById(`run-tab-${target}`)?.focus()
  }
  if (!run) return <div className={styles.page}><Link to="/admin/logs">← Scrape Run Logs</Link>{runData.error ? <ErrorMessage error={runData.error} retry={runData.refresh} /> : <Empty><span role="status">Loading run…</span></Empty>}</div>
  const active = activeRun(run)
  const canRetry = run.snapshotsAvailable && ['partial', 'failed', 'cancelled'].includes(run.outcome) && ((run.tasks.failed ?? 0) - (run.quarantined ?? 0) + (run.tasks.cancelled ?? 0) > 0)
  const csvReason = !run.snapshotsAvailable ? 'CSV snapshots are not available for this legacy run.' : active ? 'CSV becomes available when this run finishes or is cancelled.' : ''
  return <div className={styles.page}>
    <Link className={styles.back} to="/admin/logs"><Icon name="arrowLeft" width={15} height={15} /> Scrape Run Logs</Link>
    <header className={styles.header}><div><div className={styles.eyebrow}>SCRAPER OPERATIONS · {run.trigger === 'scheduled' ? 'MONTHLY SCHEDULE' : 'MANUAL RUN'}</div><h1>{run.name}</h1><div className={styles.statusLine}><Badge value={run.outcome} /><span>{active ? 'Updates automatically every 5 seconds' : `Finished ${date(run.completedAt)}`}</span></div></div>
      <div className={styles.actions}><Button onClick={refresh} disabled={Boolean(busy)}><Icon name="refresh" width={14} height={14} /> Refresh</Button><Button variant="primary" disabled={Boolean(busy) || Boolean(csvReason)} aria-describedby={csvReason ? 'csv-explanation' : undefined} onClick={() => void action('download')}><Icon name="download" width={14} height={14} /> {busy === 'download' ? 'Preparing CSV…' : 'Download CSV'}</Button>{csvReason ? <small id="csv-explanation">{csvReason}</small> : null}</div>
    </header>
    <ErrorMessage error={runData.error} retry={runData.refresh} />{actionError ? <p className={styles.error} role="alert">{actionError}</p> : null}
    {run.coverageIncomplete || (run.quarantined ?? 0) > 0 ? <aside className={styles.warning} aria-label="Incomplete coverage"><div><strong>Coverage is incomplete</strong><p>Failed work may leave cases or court details uncollected. An inaccessible court is not an empty result.</p>{(run.quarantined ?? 0) > 0 ? <><p>{number(run.quarantined ?? 0)} tasks need operator review. They will not retry automatically.</p><Button onClick={() => { setQueries((q) => ({ ...q, Failures: { ...initialQuery(), status: 'quarantined' } })); setTab('Failures') }}>View quarantined tasks</Button></> : null}</div></aside> : null}
    <div className={styles.metrics}><div className={styles.saved}><span>Saved cases</span><strong>{number(run.total)}</strong><small>In this run</small></div>{['new', 'updated', 'unchanged'].map((kind) => <div key={kind}><span>{label(kind)}</span><strong>{number(run.counts[kind] ?? 0)}</strong><small>Case records</small></div>)}<button className={styles.failedMetric} onClick={() => { setQueries((q) => ({ ...q, Failures: { ...initialQuery(), status: 'failed' } })); setTab('Failures') }}><span>Failed tasks <Icon name="arrowUpRight" width={15} height={15} /></span><strong>{number(run.tasks.failed ?? 0)}</strong><small>Inspect work items</small></button></div>
    <div className={styles.workStrip}><span><strong>{number(run.tasks.success ?? 0)}</strong> tasks completed</span><span><strong>{number(run.tasks.running ?? 0)}</strong> running</span><span><strong>{number(run.tasks.queued ?? 0)}</strong> queued</span><span><strong>{number(run.tasks.cancelled ?? 0)}</strong> cancelled</span><div className={styles.runActions}>{active ? <Button disabled={Boolean(busy) || run.cancelRequested} onClick={() => setConfirmCancel(true)}>{run.cancelRequested ? 'Cancellation requested' : 'Cancel run'}</Button> : null}{canRetry ? <Button disabled={Boolean(busy) || Boolean(run.tasks.running)} onClick={() => void action('retry')}>{busy === 'retry' ? 'Requesting retry…' : 'Retry unfinished work'}</Button> : null}</div></div>
    {canRetry && Boolean(run.tasks.running) ? <p className={styles.note}>Retry is available after the current worker finishes its task.</p> : null}
    {confirmCancel ? <section className={styles.confirm} role="region" aria-label="Confirm cancellation"><h2>Stop this run?</h2><p>Queued work will stop and in-progress work will finish stopping. Cases and snapshots already saved will remain available.</p><div><Button onClick={() => setConfirmCancel(false)} disabled={Boolean(busy)}>Keep running</Button><Button onClick={() => void action('cancel')} disabled={Boolean(busy)}>{busy === 'cancel' ? 'Requesting cancellation…' : 'Confirm cancellation'}</Button></div></section> : null}
    {run.error ? <aside className={styles.warning}><Icon name="alert" width={17} height={17} /><div><strong>A source error was recorded</strong><p>This is the latest recorded error; it does not necessarily describe the run’s current state.</p><details className={styles.technical}><summary>Technical details</summary><pre>{run.error}</pre></details></div></aside> : null}
    <div className={styles.tabs} role="tablist" aria-label="Run sections">{tabs.map((name, i) => <button key={name} id={`run-tab-${i}`} role="tab" aria-selected={tab === name} aria-controls={`run-panel-${i}`} tabIndex={tab === name ? 0 : -1} onKeyDown={(event) => tabKey(event, i)} onClick={() => setTab(name)}>{name}{name === 'Failures' && run.tasks.failed ? <span>{number(run.tasks.failed)}</span> : null}</button>)}</div>
    <section className={styles.panel} role="tabpanel" id={`run-panel-${tabs.indexOf(tab)}`} aria-labelledby={`run-tab-${tabs.indexOf(tab)}`} tabIndex={0}>
      {tab === 'Overview' ? <Overview run={run} /> : tab !== 'Audit history' && !run.snapshotsAvailable ? <Empty>Historical snapshots and work items were not recorded for this legacy run.</Empty> : (() => { const props: SectionProps = { id, active, query: queries[tab], setQuery: (query) => setQueries((all) => ({ ...all, [tab]: query })), revision }; return tab === 'Results' ? <Results {...props} states={run.resolvedScope?.states ?? []} /> : tab === 'Failures' ? <Failures {...props} reviewed={refresh} /> : <Audit {...props} /> })()}
    </section>
  </div>
}
