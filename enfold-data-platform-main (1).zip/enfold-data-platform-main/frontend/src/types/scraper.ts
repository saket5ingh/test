import type { Case } from './case'
export interface RunCriteria {
  allStates: boolean; stateCodes: string[]; allActs: boolean; actKeys: string[]
  sections: string[]; status: 'all' | 'pending' | 'disposed'
}
export interface RunPerformance {
  windowMinutes: number; observedSince: string
  successfulTasksLastHour: number; failedTasksLastHour: number; retriedTasksLastHour: number
  caseDetailsLastHour: number; sourceErrorsLastHour: number; sourceErrorRate: number | null
  lastSuccessfulTaskAt: string | null; lastCaseAt: string | null; deferredTasks: number
  workerConcurrency: number | null; inFlight: number | null; workerLastSeen: string | null; workerHealthy: boolean
  requestIntervalSeconds: number | null; observedRequestIntervalSeconds: number | null
  sourcePausedUntil: string | null; sourceFailureStreak: number; sourceRecoverySuccesses?: number; sourceRecoveryRequired?: number; stalled: boolean
  etaSeconds: number | null; etaBasis: 'current_case_backlog' | null
}
export interface ScraperRun {
  id: string; name: string; criteria: RunCriteria | null
  resolvedScope: { states: { code: string; name: string }[]; actKeys: string[] } | null
  trigger: 'manual' | 'scheduled'; triggeredBy: string | null; triggeredByName?: string | null
  performance?: RunPerformance
  lastActivityAt?: string | null
  queuedAt: string; startedAt: string | null; completedAt: string | null
  outcome: 'pending' | 'queued' | 'running' | 'success' | 'partial' | 'failed' | 'cancelled'
  tasks: Record<string, number>; counts: Record<string, number>; total: number
  coverage: { kind: string; status: string; count: number }[]
  quarantined?: number; coverageIncomplete?: boolean
  snapshotsAvailable: boolean; error: string | null; cancelRequested: boolean
  legacyCriteria: { state: string | null; acts: string | null; sections: string | null; status: string }
}
export interface Page<T> { items: T[]; total: number; page: number; pageSize: number }
export interface RunSnapshot { snapshot: Case; fetched_at: string; change_kind: string }
export interface RunEvent { id: string; at: string; kind: string; message: string; actor_name: string | null; task_id: string | null }
export interface RunTask {
  id: string; kind: string; status: string; attempts: number; error_message: string | null
  review_required?: boolean; review_reason?: string | null; review_at?: string | null; review_evidence?: Record<string, unknown> | null; review_failures?: number; review_sessions?: number
  payload: { state?: { name: string }; district?: { name: string }; court?: { name: string; code: string }; cnr?: string; act_code?: string; section?: string; status?: string }
}
export interface ScraperOptions {
  states: { code: string; name: string }[]; acts: { key: string; label: string }[]
  monthlySchedule?: { week: number; weekday: number; hour: number; minute: number; timezone: string; nextRunAt: string | null }
  statesUpdatedAt: string | null; workerLastSeen: string | null; workerHealthy: boolean; monthlyEnabled: boolean
}
