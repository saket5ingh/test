export type FilterGroup = 'status' | 'district' | 'acts' | 'caseType' | 'purpose'

export interface CaseFilters {
  status: string[]
  district: string[]
  acts: string[]
  caseType: string[]
  purpose: string[]
  pinnedOnly: boolean
  /** Advanced filters, committed from the drawer. */
  regYearFrom: string
  regYearTo: string
  filingFrom: string
  filingTo: string
  decisionFrom: string
  decisionTo: string
  complex: string[]
  court: string[]
}

export interface FilterOption {
  key: string
  label: string
}

export interface ActOption extends FilterOption {
  flag: boolean
  match: (actName: string) => boolean
}
