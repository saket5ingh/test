export type Role = 'user' | 'admin'

export interface Account {
  name: string
  role: Role
  roleLabel: string
  email: string
  initials: string
}

export interface Credentials {
  userId: string
  password: string
}
