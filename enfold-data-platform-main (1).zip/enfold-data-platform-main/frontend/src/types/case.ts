export type CaseStatus = 'pending' | 'disposed' | 'acquitted' | 'allowed' | 'rejected'

export type UpdateSeverity = 'critical' | 'info'

export type Freshness = 'fresh' | 'aging' | 'stale'

export interface Act {
  name: string
  sections: string[]
  /** Statute is child-protection related and highlighted in the UI. */
  flag?: boolean
}

export interface Hearing {
  date: string
  purpose: string
}

export interface CaseUpdate {
  text: string
  at: string
  severity: UpdateSeverity
}

export interface Case {
  id: string
  /** Anonymized reference shown to field officers. */
  ref: string
  cnr: string
  caseNo: string
  regNo: number | null
  regYear: number | null
  caseType: string
  caseTypeClass: string
  state: string
  district: string
  complex: string
  court: string
  regDate: string
  filingDate: string
  decisionDate: string | null
  dispositionRaw: string
  status: CaseStatus
  numHearings: number | null
  duration: number | null
  lastPurpose: string
  acts: Act[]
  hearings: Hearing[]
  pinned: boolean
  lastScrape: string
  nextHearing: string | null
  update: CaseUpdate | null
}
