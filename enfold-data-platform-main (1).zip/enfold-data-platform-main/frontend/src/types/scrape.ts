export interface Scrape {
  id: string
  label: string
  short: string
  count?: number
  date: string
}

export type ScrapeOutcome = 'success' | 'failed' | 'partial'

export interface CustomScrape {
  id: string
  name: string
  state: string
  acts: string
  status: string
  sections: string
  ranAt: string
  triggeredBy: string
  outcome: ScrapeOutcome
  count: number
}

export type ScrapeStatusFilter = 'all' | 'pending' | 'disposed'

export interface ScrapeFormValues {
  name: string
  state: string
  acts: string
  status: ScrapeStatusFilter
  sections: string
}

export interface ScrapeRunResult {
  total: number
  pending: number
  disposed: number
  flagged: number
  trend: number[]
}
