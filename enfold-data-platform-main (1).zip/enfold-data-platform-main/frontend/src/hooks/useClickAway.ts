import { useEffect, type RefObject } from 'react'

/** Closes a popover when the user clicks or focuses outside of it. */
export function useClickAway<T extends HTMLElement>(
  ref: RefObject<T | null>,
  active: boolean,
  onAway: () => void,
) {
  useEffect(() => {
    if (!active) return

    const handle = (event: MouseEvent | FocusEvent) => {
      const target = event.target as Node | null
      if (target && ref.current && !ref.current.contains(target)) onAway()
    }

    document.addEventListener('mousedown', handle)
    document.addEventListener('focusin', handle)
    return () => {
      document.removeEventListener('mousedown', handle)
      document.removeEventListener('focusin', handle)
    }
  }, [ref, active, onAway])
}
