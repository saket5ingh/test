import { useEffect, useState } from 'react'

/** Keyed results never expose data from a previous query or account. Loaders must be stable. */
export function useResource<T>(key: string, load: (signal: AbortSignal) => Promise<T>, enabled = true) {
  const [result, setResult] = useState<{ key: string; data?: T; error?: string }>()
  useEffect(() => {
    if (!enabled) return
    const controller = new AbortController()
    load(controller.signal).then((data) => {
      if (!controller.signal.aborted) setResult({ key, data })
    }).catch((error: unknown) => {
      if (!controller.signal.aborted) setResult({ key, error: error instanceof Error ? error.message : 'Could not load data.' })
    })
    return () => controller.abort()
  }, [key, load, enabled])
  const current = enabled && result?.key === key ? result : undefined
  return { data: current?.data, error: current?.error, loading: enabled && !current }
}
