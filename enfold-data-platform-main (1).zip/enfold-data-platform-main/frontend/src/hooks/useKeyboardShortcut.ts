import { useEffect } from 'react'

const EDITABLE = /^(input|textarea|select)$/i

/** Global single-key shortcut that stays out of the way while typing. */
export function useKeyboardShortcut(key: string, handler: () => void, enabled = true) {
  useEffect(() => {
    if (!enabled) return

    const onKeydown = (event: KeyboardEvent) => {
      if (event.key !== key) return
      const active = document.activeElement
      if (active && (EDITABLE.test(active.tagName) || (active as HTMLElement).isContentEditable)) {
        return
      }
      event.preventDefault()
      handler()
    }

    document.addEventListener('keydown', onKeydown)
    return () => document.removeEventListener('keydown', onKeydown)
  }, [key, handler, enabled])
}
