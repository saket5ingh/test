import { useCallback, useEffect, useState } from 'react'

/** Discards late responses after retry/unmount and distinguishes errors from empty data. */
export function useRemoteList<T>(load: () => Promise<T[]>) {
  const [revision, setRevision] = useState(0)
  const [result, setResult] = useState({ revision: -1, data: [] as T[], error: false })
  useEffect(() => {
    let cancelled = false
    load().then((data) => {
      if (!cancelled) setResult({ revision, data, error: false })
    }).catch(() => {
      if (!cancelled) setResult({ revision, data: [], error: true })
    })
    return () => { cancelled = true }
  }, [load, revision])
  const retry = useCallback(() => setRevision((value) => value + 1), [])
  return { data: result.data, loading: result.revision !== revision,
    error: result.revision === revision && result.error, retry }
}
