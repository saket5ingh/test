import { useCallback, useEffect, useState } from 'react'

/** Keep the last successful result while polling; query changes hide stale data. */
export function usePollingResource<T>(key: string, load: (signal: AbortSignal) => Promise<T>, interval = 5000, shouldPoll?: (data: T) => boolean) {
  const [result, setResult] = useState<{ key: string; data?: T; error?: string }>()
  const [revision, setRevision] = useState(0)
  const refresh = useCallback(() => setRevision((n) => n + 1), [])
  useEffect(() => {
    const controller = new AbortController()
    let timer: ReturnType<typeof setTimeout>
    async function poll() {
      let keepPolling = true
      try {
        const data = await load(controller.signal)
        keepPolling = shouldPoll ? shouldPoll(data) : true
        if (!controller.signal.aborted) setResult({ key, data })
      } catch (error) {
        if (!controller.signal.aborted) setResult((old) => ({ key, data: old?.key === key ? old.data : undefined,
          error: error instanceof Error ? error.message : 'Could not load run information.' }))
      } finally {
        if (!controller.signal.aborted && interval > 0 && keepPolling) timer = setTimeout(() => { void poll() }, interval)
      }
    }
    void poll()
    return () => { controller.abort(); clearTimeout(timer) }
  }, [key, load, interval, revision, shouldPoll])
  const current = result?.key === key ? result : undefined
  return { data: current?.data, error: current?.error, loading: !current, refresh }
}
