import { AdminRunDetailPage } from '@/pages/AdminRunDetailPage'
import { AdminSnapshotPage } from '@/pages/AdminSnapshotPage'
import { lazy, Suspense } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { AppShell } from '@/components/layout/AppShell'
import { AdminRoute, ProtectedRoute } from '@/components/layout/RouteGuards'
import { AccountPickerPage } from '@/pages/AccountPickerPage'
import { AdminLogsPage } from '@/pages/AdminLogsPage'
import { AdminRunPage } from '@/pages/AdminRunPage'
import { CaseDetailPage } from '@/pages/CaseDetailPage'
import { CasesPage } from '@/pages/CasesPage'
import { LoginPage } from '@/pages/LoginPage'

// Split out so Recharts stays off the initial bundle.
const DashboardPage = lazy(() =>
  import('@/pages/DashboardPage').then((m) => ({ default: m.DashboardPage })),
)

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/select-account" element={<AccountPickerPage />} />

      <Route element={<ProtectedRoute />}>
        <Route element={<AppShell />}>
          <Route
            path="/dashboard"
            element={
              <Suspense fallback={<p role="status">Loading dashboard…</p>}>
                <DashboardPage />
              </Suspense>
            }
          />
          <Route path="/cases" element={<CasesPage />} />
          <Route path="/cases/:caseId" element={<CaseDetailPage />} />
          <Route element={<AdminRoute />}>
            <Route path="/admin/run" element={<AdminRunPage />} />
            <Route path="/admin/runs/:runId" element={<AdminRunDetailPage />} />
            <Route path="/admin/runs/:runId/cases/:caseId" element={<AdminSnapshotPage />} />
            <Route path="/admin/logs" element={<AdminLogsPage />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
