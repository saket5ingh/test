# Local validation and performance results

Date: 14 October 2026. Active repository: `enfold-data-platform`.
Branch: `feature/scraper-performance`, based on `0e03ac7`.
No production deployment or eCourts traffic was performed for these changes.

## Phase status

| Phase | Implemented and locally verified | Remaining boundary |
|---|---|---|
| 1 Reliability | Endpoint validation, classified errors, invalid-session/connection reset, shared durable cooldown and single recovery probe | Exact upstream cause and live effectiveness remain unverified |
| 2 Scheduling | Persisted weighted rotation, producer fairness under pressure, strict oldest-run ordering | No live throughput claim |
| 3 Database | Bulk admission, transactional counters, indexes, bounded progress queries, hearing-write avoidance, reconciliation | Production migration time/storage must be measured |
| 4 Worker | Bounded pool, shared durable pacing, leases/claim fencing, recovery, cancellation, graceful shutdown, retained advisory lock | Default concurrency 1; live tuning/canary requires approval; replicas unsupported |
| 5 Workload | Durable chunk checkpoints and admission backpressure; existing workload retained | Cohort refresh policies designed only; client approved child-marriage-only scans, third Friday midnight IST on 15 October; live activation pending |
| 6 Monitoring | Throughput, source-error share, last success, stale/stalled/cooldown warnings, concurrency/pacing, admitted-case-only estimate | Metrics start with this schema; historical hourly rates unavailable |
| 7 Safety | Synthetic integration, migration/rollback/reconciliation rehearsal, benchmarks, frontend tests and operator plan | Docker smoke/CI and approved production rollout still required |

## Reproducible benchmark

Environment: local macOS ARM64, Python 3.12.14, PostgreSQL 16.15; localhost connection,
not the EC2 server. Queue contains synthetic case tasks with realistic JSON payload
shape, distinct keys and repeated readiness timestamps. No case data was copied
from production. Seven warmed query measurements; median reported. Three insertion
measurements; rolled-back transactions to avoid changing the benchmark queue.
Times include local client/database round trips and do not include upstream calls.

| Operation | Before migration | Optimized | Interpretation |
|---|---:|---:|---|
| Group counts over 2,500,000 task rows vs counter read | 115.934 ms | 0.081 ms | One small counter query replaces the scan |
| Status aggregation used by old finalization | 94.616 ms | Uses small counters | No separate full-finalization timing claimed |
| Ready task lookup | 0.151 ms | 0.111 ms | Lookup only, not the complete transactional claim |
| Insert 5,000 children: old individual inserts vs new 500-row batches | 370.111 ms | 93.489 ms | Includes new trigger overhead in optimized schema |

The old count query also improved to **49.306 ms** after migration/cache/index
changes. Even against that same-schema comparison, the counter read was 0.081 ms.
Do not attribute all before/after differences to one change: cache state and added
indexes differ. On the optimized schema alone, individual insertion took
934.550 ms versus 93.489 ms for batches; transactional counter triggers make row-
at-a-time operations more expensive, reinforcing why bulk admission matters.

The task fingerprint was **identical** before and after the 2.5-million-row upgrade:
`833320b8182b2c651912d8454bd7b536`. It includes the original IDs, keys, payloads,
statuses, attempts/retry bases and timing fields. A separate migration test compares
all pre-existing task/run/case/user/pin/snapshot fields, including old errors, and
forces a failure after DDL to verify atomic rollback.

Raw measurements: `large-baseline.json`, `large-optimized.json`. Earlier 250,000-row
checkpoints are in `baseline.json`, `optimized.json`; do not mix the two sample sizes.

To reproduce, use a newly created, isolated UTF-8 localhost database ending in
`_test`. Apply schema/migrations through version 6 from baseline `0e03ac7`, then:

```sh
python backend/tools/benchmark_scraper.py \
  --url postgresql://OWNER@127.0.0.1:PORT/ffg_benchmark_test \
  --seed --rows 2500000 --phase baseline --inserts 5000 > before.json

psql -X -v ON_ERROR_STOP=1 --single-transaction \
  -h 127.0.0.1 -p PORT -U OWNER -d ffg_benchmark_test -f db/migrate.sql

python backend/tools/benchmark_scraper.py \
  --url postgresql://OWNER@127.0.0.1:PORT/ffg_benchmark_test \
  --phase optimized --inserts 5000 > after.json
```

Use the same database for both measurements; compare `rows` and
`task_fingerprint`. Never run the integration suite on this benchmark database:
its synthetic pipeline test deliberately advances ready times for queued tasks.
The benchmark rejects non-local hosts and database names not ending in `_test`.

## Validation evidence

Final backend, PostgreSQL and deployment run: **233 tests passed**, one existing
Starlette/AnyIO deprecation warning. Frontend: **107 tests passed** in 17 files.

- Existing pipeline regression passed with least-privilege API/worker roles:
  login, authorization, case ingestion, snapshots, pins, notifications, judgments,
  duplicate prevention, retry/cancel/recovery and the monthly schedule.
- New real-PostgreSQL tests cover normal/pressure fairness, simultaneous distinct
  claims, source cooldown across clients/restarts, exclusive recovery probes,
  stale-owner fencing, checkpoint restart without refetch, counter rollback,
  expired leases, cancellation, same-CNR concurrent ingestion, bounded concurrent
  execution with global pacing, retry-budget deferral, shutdown recovery, strict
  run ordering and producer-only backpressure deadlock prevention.
- A separate disposable database rehearses version-6 upgrade, failure rollback,
  repeated migration, preservation of existing records, reconciliation reruns and
  cascading deletion of an empty synthetic run.
- Existing and new SQL/ORM columns/types/nullability match. API/worker grants are
  exercised rather than assumed from SQL text.
- Frontend typecheck, lint, production build and 107 tests across 17 files passed,
  including accessibility and legacy/finished/stalled/cooldown/ETA scenarios.
- Desktop, tablet and 375-pixel mobile visual review passed using synthetic local
  API data. The evaluator used screenshots/source because its separate browser
  sign-in was unavailable; parent verified the rendered local page. No other-
  provider evaluator model was available. No required design fixes remained.
- Deployment scripts passed shell syntax checks and ShellCheck. Production config
  validation rejects extra coordinators, invalid pool/queue/shutdown bounds and
  reduced production pacing. There is no Docker executable in this local
  environment; container builds/smoke checks remain for the existing CI workflow.
- The existing Starlette/AnyIO deprecation warning remains; no new test failures
  or frontend lint warnings were observed.

## Operational limits

A faster query does not imply a comparable improvement in full scrape duration.
At the unchanged three-second spacing, the previously observed case backlog alone
has an ideal floor of about 85.3 days; bootstrap, other tasks, latency and retries
add time. The small EC2 instance's memory, CPU credits, disk and source behavior
were not re-tested. No claim is made that comprehensive monthly completion is now
feasible or that the external intermittent connection problem is permanently fixed.

See `../../deploy/SCRAPER_PERFORMANCE.md` for the maintenance/rollback plan and the
six proposed refresh cohorts requiring product decisions. No code was committed,
pushed or deployed as part of this implementation request.

## Child-marriage scope and calendar follow-up — 14 October 2026

The client approved all-state monthly coverage for the `childmarriage` option
only, all sections and both statuses. The calendar is now the third Friday at
00:00 Asia/Kolkata, with 16 October 2026 as the next matching date. All four
requested names have independent regression examples; the 1929 Act and the
generic yearless label retain separate mapping identities. Manual all-eight-act
coverage remains available.

Validation after this change: 212 backend/database tests, 26 deployment tests,
107 frontend tests, typecheck, lint, build, ShellCheck and diff whitespace checks
passed. The calendar tests cover all months in 2026, a year rollover and leap-year
February; the database test verifies single monthly creation, no overlapping
scheduled runs and the exact child-marriage criteria. Reset rehearsals passed on
both schema versions 6 and 7, checking complete account and migration-state
preservation.

The user-authorized staging reset cleared ten scraping tables and preserved both
accounts exactly. The old worker is stopped, automatic scheduling is disabled,
and the previously prepared Thursday settings are written to the runtime file.
On 15 October the client approved deployment and changed the permanent schedule
to the third Friday; the runtime file must be updated during deployment. The old release
does not forward all calendar variables to the API. New-release publication and
deployment are required before enabling the schedule; source performance under
the new scope has not yet been measured. No new application release was deployed
as part of the reset.
