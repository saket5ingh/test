# Scraper optimization implementation record

Branch: feature/scraper-performance; baseline 0e03ac7 (includes the pushed Logs/Cases changes, not yet on main at fetch time).

## Constraints

The original performance implementation used local PostgreSQL and fake HTTP/source clients, preserving existing run identifiers and data. The later client instruction on 14 October explicitly authorized stopping staging and clearing all scraping data while retaining accounts; this supersedes the original no-reset constraint for that maintenance operation only. The client approved deployment on 15 October and finalized the permanent calendar as the third Friday at midnight IST. The original performance work preserved nationwide all-eight-act coverage. The client approved monthly child-marriage-only scope on 14 October, retaining all sections and both statuses; the third-Friday calendar was finalized on 15 October. Manual all-eight-act coverage stays available. Skipping known cases or changing refresh frequency requires product approval.

## Established diagnosis

The preceding read-only investigation observed 2,455,506 queued case tasks, 120,226 queued searches and no case completions. In one hour there were 1,185 retries and no successful tasks. Production request spacing was 3 seconds. A fresh-session search and a three-request comparison returned valid empty lists, so the exact upstream/session cause remains unproven. The code logs HTTP/decryption success before endpoint-schema validation, does not reset the session on that later validation failure, and has no cross-task source circuit breaker. FIFO discovery/search delays cases, every completion recounts the run, and children are inserted individually. A sampled queue was 87% IPC/BNS-originated; this is consistent with broad scope, not evidence of duplicates or permission to narrow it.

At unchanged spacing, existing case tasks alone require an ideal 85.3 days. Better scheduling/SQL cannot make this comprehensive workload fit a month at the same rate.

## Intended phased changes and validation

1. Baseline: existing suite; isolated synthetic queue benchmark and preserved-row fingerprint.
2. Reliability: typed errors, endpoint validation inside session lifecycle, reset invalid sessions/transports, bounded shared circuit breaker. Never convert unknown response shapes to empty success.
3. Persistence: additive migration for task leases/expansion checkpoints; statement-level transactional counters and minute metrics; queue indexes; bulk inserts; result counters. Test reruns, permissions, rollback, reconciliation and existing-row preservation.
4. Scheduling/worker: weighted task-kind selection, oldest eligible run first; bounded concurrency under retained coordinator advisory lock; durable shared pacing and source cooldown; leases/claim fencing; graceful shutdown. Single coordinator only, not arbitrary replicas.
5. Backpressure: cap newly queued case work, checkpoint child expansions in bounded chunks; drain the existing queue without deleting/resetting it. Full-history vs recurring refresh policies documented only, pending approval.
6. API/frontend: additive cheap progress/throughput/cooldown/ETA fields and operational UI. ETA is conditional remaining-work estimate, not a promise while discovery continues.
7. Full regression/integration suite and before/after benchmarks. Safe quiesced migration and rollback plan; do not execute against live deployment.

Checkpoints and measured results will be appended as phases complete. No performance percentage is claimed before measurement.

## Completed checkpoints

The reliability, worker, queue, monitoring and schema changes are implemented.
Detailed benchmark and test evidence is in [RESULTS.md](RESULTS.md). The operator
plan and product-policy boundaries are in
[SCRAPER_PERFORMANCE.md](../../deploy/SCRAPER_PERFORMANCE.md).

The earlier baseline suite was 208 passing tests plus one skipped PostgreSQL test.
The full suite now enables isolated PostgreSQL tests, including migration rehearsals;
final totals are 233 backend/database/deployment tests and 107 frontend tests passing. UI rendering uses synthetic
localhost data only. Production and the active nationwide run remain untouched.
