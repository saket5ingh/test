# Deployment reuse assessment — 4 October 2026

## Decision

Reuse the **release process**, adapting it for FFG. Do not merge the CI/CD branch
wholesale or run its Django deployment against FFG.

The user confirmed that only FFG will run on the new EC2 instance, and that the
contents of this directory will become the root of a separate repository.
All implementation changes therefore stay inside `ffg/`, including
`.github/workflows/ffg.yml`. The workflow becomes active in the standalone repo;
it is intentionally not active as a nested workflow in this parent repo.

## What was inspected

- `origin/feature/CI-CD` and upstream PR #4's Git head both resolved to
  `607dedf04ffed59b27125c3caa1cbaa9b4864f0b`; their trees match exactly.
- The GitHub connector returned 404 for the private PR, but Git SSH access
  successfully fetched `refs/pull/4/head`. The code was reviewed; PR discussion,
  review status and remote workflow results were not verified.
- Abhishek's October 1–2 changes: `f314a43` introduced the release workflow,
  production Compose, deployment script/docs and lazy Django state cache;
  `b063501` adjusted workflow triggers; `48eda68` merged CI corrections;
  `607dedf` defaulted manual image publishing to true. Related Copilot commits
  fixed Python typing and workflow permissions.
- The branch's common ancestor with the current FFG branch is `a018587`.
  It does not contain the current integration, scraper and diagnosis fixes
  (`ca056bd`, `e5c01f9`, `1131b40`). Preserve the current FFG code.

## Compatibility and findings

| Finding | Evidence in reviewed branch | Impact / FFG decision |
| --- | --- | --- |
| Workflow verifies Django, not FFG | `.github/workflows/ci.yml:24–104` installs root requirements, checks Django migrations/Pyright, builds root Dockerfile | Replace verification with FFG backend/PostgreSQL tests, frontend checks and both image builds. |
| FFG is excluded from the image | `.dockerignore:10`, root `Dockerfile:1–12`, `deploy/README.md:3–8` | A successful upstream build cannot deploy FFG. Build `backend/` and `frontend/` separately. |
| Production stack is a different architecture | `docker-compose.prod.yml:5–74` starts Django, Celery, Flower, Redis and PostgreSQL 15 | FFG uses FastAPI, its own durable worker and PostgreSQL 16. No Redis, Celery or Flower is needed. |
| No application tests in existing verify job | `.github/workflows/ci.yml:64–104`; README explicitly excludes tests | Compilation and migration checks do not establish functional correctness. Use the existing FFG test suites, including real DB roles. |
| Default-branch assumptions differ | `.github/workflows/ci.yml:7,110` uses `main`; inspected fork's default is `master` | A push to this fork's default branch would not trigger that push/publish path. New workflow verifies pushes without hardcoding a branch and publishes only on explicit dispatch. |
| Existing deployment has no automatic EC2 delivery | `deploy/README.md:44–50`; workflow produces a downloadable bundle | Keep controlled operator deployment for staging. AWS credentials are not needed by this CI workflow. |
| Existing deploy stops web before pulling images | `deploy/pull-and-up.sh:216–222` | Registry failure can leave the app unavailable. FFG pulls all images before pausing services. |
| Existing backup can skip a stopped DB | `deploy/pull-and-up.sh:200–207` | FFG starts/health-checks the DB, backs up any existing application DB, and fails if an established deployment's DB is missing. |
| Existing script offers forced/no-backup deployment | `deploy/pull-and-up.sh:20–21,187–190` | Omit these shortcuts in the initial FFG operator script. |
| Existing script has a fixed Flower password | `docker-compose.prod.yml:31` | Do not import Flower or its credentials. FFG requires independent runtime secrets. |
| Source state-cache changes are Django-specific | `x/states_cache.py`, `x/models/scrape_task.py`, `x/views/scrape.py` | Valuable fix for Django boot, but FFG already has lazy source access and PostgreSQL metadata caching. No port is necessary. |

Reviewed source:
[workflow](https://github.com/saket5ingh/enfold-web/blob/607dedf04ffed59b27125c3caa1cbaa9b4864f0b/.github/workflows/ci.yml),
[deployment script](https://github.com/saket5ingh/enfold-web/blob/607dedf04ffed59b27125c3caa1cbaa9b4864f0b/deploy/pull-and-up.sh),
[production stack](https://github.com/saket5ingh/enfold-web/blob/607dedf04ffed59b27125c3caa1cbaa9b4864f0b/docker-compose.prod.yml).

## Reused design and FFG implementation

- Verification gates publication. GHCR is the registry; application image digests
  and matching SQL/deployment files form a release bundle.
- Unlike rebuilding after verification, publishing transfers the exact images
  tested by the verify job. Initial releases target Linux AMD64 only.
- One EC2 runs Caddy → frontend/Nginx → API, plus the worker and PostgreSQL.
  Only Caddy publishes ports 80/443; app and DB traffic use the Compose network.
- Persistent PostgreSQL and Caddy volumes survive application replacement.
  API/worker DB roles remain separate. Source history, snapshots, pins and
  notifications stay in PostgreSQL; there are no Django `/data` artifacts.
- A deployment lock prevents concurrent operator scripts. Update sequence:
  validate → pull → start/check DB → pause writers → backup → migrate → recreate
  services → health/HTTPS checks → record successful release.
- Worker tasks interrupted by deployment are recovered from the durable queue.
  No Celery drain or twelve-hour deployment wait is needed.
- Backup and isolated restore-drill scripts are supplied. A code rollback does
  not reverse a database migration; keep the matching old release bundle and
  confirm schema compatibility before using it.
- Monthly scraping is hard-disabled in the staging production configuration.

## Verification and remaining work

The local test results and operational instructions are in
[`../deploy/README.md`](../deploy/README.md). No EC2, domain, cloud credentials,
remote workflow execution or live deployment was configured during this change.
Docker container startup and HTTPS must still be verified on a Docker-capable
host. The intermittent eCourts transport failures remain an independent issue.

Before public production use: configure off-host scheduled backups and prove
restoration, monitoring/alerts, login throttling and security audit logging;
configure Google OAuth; validate representative data and broader scrape coverage.
Single-EC2 deployment is a staging baseline with downtime during updates and
no high availability, not a solution to those outstanding operational tasks.
