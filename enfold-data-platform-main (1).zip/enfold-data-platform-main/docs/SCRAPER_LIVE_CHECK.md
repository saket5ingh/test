# Bounded live scraper diagnostic

This check investigated the `RemoteProtocolError` observed during initial local
scraper attempts. It used the existing FFG client, worker functions, authenticated
FastAPI routes and an isolated local PostgreSQL database. Production data and
the separate Django application were not modified.

## Connection diagnosis

- DNS resolution and verified TLS 1.3 handshakes succeeded.
- HTTPX and Requests each received HTTP 200 from the session endpoint and
  decrypted a response containing a token.
- Authenticated state requests returned 36 states both immediately and after a
  short wait. No consistent token-activation problem was reproduced.
- An unrestricted act search in the bounded worker pilot repeatedly lost its
  connection before a response. That pilot was cancelled at its time limit.
- Narrow IPC section-302 searches timed out with a deliberately short 35-second
  diagnostic timeout in both Python libraries.
- Curl, using HTTP/2 and a 120-second timeout, retrieved a valid encrypted search
  response in 57.3 seconds: 650,420 bytes containing 1,143 case references.
- The normal FFG HTTPX client then completed the narrow search and case ingestion
  with its existing 120-second timeout. No HTTP/2 setting or code patch was needed.

These results establish intermittent request failures and a slow successful
search. They do not establish the exact cause of the earlier disconnects, prove
an IP block, or prove that HTTP/2 is required. The error occurs before a usable
HTTP response, rather than during database storage or response decryption.

## Successful pilot

| Measure | Result |
| --- | --- |
| Run ID | `53967807-f0e0-450e-bfa7-cf14308d687c` |
| Geography | Bihar → Gaya → first returned court establishment |
| Criteria | IPC/BNS option, section 302, pending cases |
| Diagnostic cap | Five minutes, at most three case histories |
| Outcome | Success |
| Elapsed | 81.1 seconds |
| Live HTTP requests | 10 |
| Search results | 1,143 IPC references; the corresponding BNS search returned zero |
| Cases saved | 3 |
| Historical snapshots | 3 |
| Successful work items | 9 |
| Snapshots containing a next-hearing date | 3 |
| Hearing entries saved | 0 |
| CSV endpoint | HTTP 200; 1,549 bytes |
| Latest-case endpoints | HTTP 200 for each saved case |

The temporary diagnostic harness limited returned districts, establishments and
case references before passing them to the real worker. It recorded these limits
in the run name and audit history. It did not simulate the upstream responses.
The run's success applies only to this explicitly bounded sample, not to all
cases in Bihar or to a nationwide run.

The administrator test account was disabled after verification. The temporary
PostgreSQL server was stopped; its database files retain the pilot for inspection.
No tokens, case identifiers, litigant names or response bodies are included here.

## Further reliability diagnosis

The follow-up used the same isolated database, restricted API/worker roles and
bounded harness. No production schema or data was changed. Each run was capped
at five minutes and three case histories, with one court establishment selected.

### Confirmed hearing parser defect

Assam → Bajali → first establishment → POCSO → disposed cases returned
`historyOfCaseHearing` as a JSON list. The parser only accepted HTML, so all
three case tasks failed with `Invalid hearing history`. This is a confirmed
application defect, separate from the transport disconnects.

`normalize.py` now accepts JSON rows and legacy HTML. JSON hearing dates come
from `todays_date` / `todays_date1`, not the future `nextdate`. A separate
`last_business_date` entry is merged and deduplicated by date/purpose. Invalid
rows or mismatched CNRs fail explicitly; existing case data is preserved. Only
date and purpose are retained from hearing rows.

| Check | Result |
| --- | --- |
| Original run | `d3121a48-1948-49c2-baab-d7dbf41d421e` |
| Retry after parser correction | Success; 12.7 seconds, 5 live HTTP requests |
| Saved data | 3 cases, 3 snapshots, 6 hearing entries |
| Case API / CSV | Verified; CSV 2,421 bytes |
| Repeat run | `b6ceafbe-7ee3-4fd9-b7b9-849e34651258` |
| Repeat outcome | Success; 51.7 seconds, 10 live HTTP requests |
| Change classification | All 3 unchanged |
| Identity / deduplication | Same case IDs; one database record per CNR |
| Personal pin | Preserved |
| Earlier snapshots | Same saved contents and collection timestamps |
| Repeat CSV / hearings | 2,421 bytes / 6 entries |

The repeat deliberately raised one `UpstreamError` before a case request and
cleared its session token. The normal worker renewed the session and retried the
case after its 30-second backoff; every saved response came from the real source.
This validates recovery from a **controlled failure**, not reproduction of the
remote server's internal failure conditions. A last-recorded error may remain in
the run audit even after recovery; final outcome and task status show success.

### Connection reliability

A subsequent Bihar/Gaya/Dowry probe again observed `RemoteProtocolError`: session
creation succeeded in 7.14 seconds, then the state endpoint disconnected in
0.318 seconds without an HTTP response. It saved no data and did not queue a run.
The short failure duration rules out the configured 120-second timeout for that
specific request. It does not establish whether eCourts or an intermediary
terminated the connection, nor whether throttling caused it.

A second probe reached the second returned establishment. Its act catalogue
request failed with `ReadError`, then recovered through the normal 30-second
worker backoff and a fresh session. Run
`84c39aa5-f1d8-4b3d-ada3-9d15199d4461` completed in 135.1 seconds with seven
HTTP requests and four successful tasks. The catalogue did not offer the Dowry
Prohibition Act; the run recorded `act_unavailable`, saved zero cases and made no
case search/history requests. This confirms recovery from a **real network
failure** and the unavailable-act audit path, not Dowry case ingestion.

The final attempted repeat of the Bihar IPC sample failed during session
creation after 76.45 seconds, before a job was queued. HTTPX trace events showed
a new TCP connection, successful TLS negotiation, then failure while receiving
HTTP/1.1 response headers. This instance did not reuse an idle pooled connection
and did not reach the 120-second timeout. Changing only keep-alive reuse or
extending that timeout would not explain or resolve this observed disconnect.
The earlier Bihar sample remains saved, but its repeat with the corrected parser
was not verified. No further live requests were made after this failure.

The client now emits redacted request timing/outcome telemetry, and the worker
suppresses HTTPX INFO logs containing full request URLs. No timeout, encryption,
HTTP version or retry-policy change was justified by the available evidence.

## Regression verification

- 73 backend tests passed without the opt-in PostgreSQL test.
- The PostgreSQL integration test also passed against the isolated database with
  separate API/worker roles: **74 tests passed in total**. Its source double now
  includes JSON hearing rows and a duplicate latest-business entry, with explicit
  snapshot and case-API assertions. It also checks restricted responses,
  notifications, retries, cancellation and immutable history.
- One existing Starlette/AnyIO deprecation warning was emitted.
- No frontend code or SQL schema changed in this diagnosis. Frontend checks were
  not rerun for these backend-only changes. Docker/browser deployment checks
  remain outstanding; the Docker executable was unavailable on this host.

## Still unverified

- Other regional hearing formats beyond the sampled JSON and tested legacy HTML.
- Independent comparison of every saved field with the source display.
- All eight act mappings across regions and complete search coverage.
- Large exports, sustained reliability and nationwide completion time.
- The same workflow through the browser and deployed Docker stack.

Monthly scheduling remains disabled. The parser correction and sampled recovery
checks support moving to deployment preparation and a limited staging pilot.
They do not establish production readiness or reliable nationwide completion.
