-- Run with psql --single-transaction -v ON_ERROR_STOP=1.
SELECT pg_advisory_xact_lock(772639104);
SELECT to_regclass('pcma.users') IS NOT NULL AS initialized \gset
\if :initialized
\else
\ir 01_schema.sql
\endif
CREATE TABLE IF NOT EXISTS pcma.schema_migrations (
    version INTEGER PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO pcma.schema_migrations(version) VALUES (1) ON CONFLICT DO NOTHING;
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 3) AS apply_pins \gset
\if :apply_pins
\ir migrations/003_personal_pins.sql
INSERT INTO pcma.schema_migrations(version) VALUES (3);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 4) AS apply_contracts \gset
\if :apply_contracts
\ir migrations/004_contracts_and_auth.sql
INSERT INTO pcma.schema_migrations(version) VALUES (4);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 5) AS apply_scraper \gset
\if :apply_scraper
\ir migrations/005_scraper.sql
INSERT INTO pcma.schema_migrations(version) VALUES (5);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 6) AS apply_documents \gset
\if :apply_documents
\ir migrations/006_final_judgments.sql
INSERT INTO pcma.schema_migrations(version) VALUES (6);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 7) AS apply_performance \gset
\if :apply_performance
\ir migrations/007_scraper_performance.sql
INSERT INTO pcma.schema_migrations(version) VALUES (7);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 8) AS apply_source_reliability \gset
\if :apply_source_reliability
\ir migrations/008_source_reliability.sql
INSERT INTO pcma.schema_migrations(version) VALUES (8);
\endif
SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 9) AS apply_operator_review \gset
\if :apply_operator_review
\ir migrations/009_operator_review.sql
INSERT INTO pcma.schema_migrations(version) VALUES (9);
\endif
