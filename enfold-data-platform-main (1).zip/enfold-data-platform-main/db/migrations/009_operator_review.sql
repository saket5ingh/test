-- Additive, transactional migration. Stop writers; no existing task is requeued
-- or quarantined, and no historical evidence is inferred from old messages.
ALTER TABLE pcma.scrape_tasks
 ADD COLUMN source_validated_at TIMESTAMPTZ,
 ADD COLUMN review_failures INTEGER NOT NULL DEFAULT 0 CHECK(review_failures>=0),
 ADD COLUMN review_sessions INTEGER NOT NULL DEFAULT 0 CHECK(review_sessions>=0),
 ADD COLUMN review_started_at TIMESTAMPTZ,
 ADD COLUMN review_last_session UUID,
 ADD COLUMN review_required BOOLEAN NOT NULL DEFAULT FALSE,
 ADD COLUMN review_reason TEXT,
 ADD COLUMN review_at TIMESTAMPTZ,
 ADD COLUMN review_evidence JSONB,
 ADD CONSTRAINT task_review_state CHECK(NOT review_required OR
   (status='failed' AND review_reason IS NOT NULL AND review_at IS NOT NULL AND review_evidence IS NOT NULL));
CREATE INDEX idx_tasks_review ON pcma.scrape_tasks(run_id,id) WHERE review_required;
CREATE INDEX idx_tasks_recovery_evidence ON pcma.scrape_tasks(run_id,kind,source_validated_at DESC) WHERE status='success';
