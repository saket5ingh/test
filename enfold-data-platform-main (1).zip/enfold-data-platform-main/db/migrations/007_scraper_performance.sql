-- Additive migration. Stop all app writers for rollout; preserve task identities,
-- retry state, payloads, snapshots and run criteria. Atomic with migrate.sql.
LOCK TABLE pcma.scrape_tasks, pcma.scrape_run_cases IN SHARE ROW EXCLUSIVE MODE;
ALTER TABLE pcma.scrape_tasks
    ADD COLUMN lease_owner UUID,
    ADD COLUMN lease_until TIMESTAMPTZ,
    ADD COLUMN claim_version BIGINT NOT NULL DEFAULT 0 CHECK (claim_version >= 0),
    ADD COLUMN expanding BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN error_kind VARCHAR(30);
ALTER TABLE pcma.scrape_runs ADD COLUMN dispatch_cursor INTEGER NOT NULL DEFAULT 0;
CREATE INDEX idx_tasks_claim_kind ON pcma.scrape_tasks(run_id,kind,available_at,id) WHERE status='queued';
CREATE INDEX idx_tasks_expired ON pcma.scrape_tasks(lease_until,run_id) WHERE status='running';
CREATE INDEX idx_tasks_run_kind_status ON pcma.scrape_tasks(run_id,kind,status);

CREATE TABLE pcma.scrape_task_counts (
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id) ON DELETE CASCADE,
    kind VARCHAR(20) NOT NULL, status VARCHAR(20) NOT NULL,
    total BIGINT NOT NULL CHECK(total >= 0), PRIMARY KEY(run_id,kind,status)
);
CREATE TABLE pcma.scrape_result_counts (
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id) ON DELETE CASCADE,
    change_kind VARCHAR(20) NOT NULL, total BIGINT NOT NULL CHECK(total >= 0),
    PRIMARY KEY(run_id,change_kind)
);
CREATE TABLE pcma.scrape_run_progress (
    run_id UUID PRIMARY KEY REFERENCES pcma.scrape_runs(id) ON DELETE CASCADE,
    last_activity_at TIMESTAMPTZ, last_success_at TIMESTAMPTZ, last_case_at TIMESTAMPTZ,
    metrics_since TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deferred_tasks BIGINT NOT NULL DEFAULT 0 CHECK(deferred_tasks>=0)
);
CREATE TABLE pcma.scrape_metrics (
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id) ON DELETE CASCADE,
    bucket TIMESTAMPTZ NOT NULL,
    succeeded BIGINT NOT NULL DEFAULT 0, case_succeeded BIGINT NOT NULL DEFAULT 0,
    retried BIGINT NOT NULL DEFAULT 0, failed BIGINT NOT NULL DEFAULT 0,
    source_errors BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY(run_id,bucket)
);
CREATE TABLE pcma.scrape_expansions (
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id) ON DELETE CASCADE,
    task_id UUID NOT NULL REFERENCES pcma.scrape_tasks(id) ON DELETE CASCADE,
    chunk INTEGER NOT NULL CHECK(chunk>=0), children JSONB NOT NULL CHECK(jsonb_typeof(children)='array'),
    PRIMARY KEY(task_id,chunk)
);
-- One coordinator owns this row. Request admission and circuit state survive
-- process restarts. Multiple coordinator replicas remain intentionally forbidden.
CREATE TABLE pcma.scraper_control (
    id BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK(id), owner UUID,
    next_request_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paused_until TIMESTAMPTZ, failure_streak INTEGER NOT NULL DEFAULT 0,
    cooldown_level INTEGER NOT NULL DEFAULT 0, probe_owner UUID,
    probe_until TIMESTAMPTZ, last_error_kind VARCHAR(30),
    requests BIGINT NOT NULL DEFAULT 0, last_request_at TIMESTAMPTZ
);
INSERT INTO pcma.scraper_control(id) VALUES(TRUE);

-- Invoked only by statement triggers. Definer rights let least-privilege API
-- writes update derived state without granting direct counter mutation.
CREATE FUNCTION pcma.apply_task_deltas(deltas JSONB) RETURNS void
LANGUAGE sql SECURITY DEFINER SET search_path=pg_catalog AS $$
    INSERT INTO pcma.scrape_task_counts(run_id,kind,status,total)
    SELECT d.run_id,kind,status,0 FROM jsonb_to_recordset(deltas)
        AS d(run_id UUID,kind VARCHAR(20),status VARCHAR(20),n BIGINT)
    JOIN pcma.scrape_runs r ON r.id=d.run_id
    WHERE n<>0 ORDER BY d.run_id,kind,status ON CONFLICT DO NOTHING;
    UPDATE pcma.scrape_task_counts c SET total=c.total+d.n
    FROM jsonb_to_recordset(deltas) AS d(run_id UUID,kind VARCHAR(20),status VARCHAR(20),n BIGINT)
    WHERE c.run_id=d.run_id AND c.kind=d.kind AND c.status=d.status AND d.n<>0;
$$;
REVOKE ALL ON FUNCTION pcma.apply_task_deltas(JSONB) FROM PUBLIC;

CREATE FUNCTION pcma.track_scrape_tasks() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE deltas JSONB;
BEGIN
    IF TG_OP='INSERT' THEN
        SELECT jsonb_agg(to_jsonb(d)) INTO deltas FROM
            (SELECT run_id,kind,status,count(*) AS n FROM new_tasks GROUP BY run_id,kind,status) d;
    ELSIF TG_OP='DELETE' THEN
        SELECT jsonb_agg(to_jsonb(d)) INTO deltas FROM
            (SELECT run_id,kind,status,-count(*) AS n FROM old_tasks GROUP BY run_id,kind,status) d;
    ELSE
        SELECT jsonb_agg(to_jsonb(d)) INTO deltas FROM
            (SELECT run_id,kind,status,sum(n)::bigint AS n FROM
                (SELECT run_id,kind,status,count(*) AS n FROM new_tasks GROUP BY run_id,kind,status
                 UNION ALL SELECT run_id,kind,status,-count(*) FROM old_tasks GROUP BY run_id,kind,status) x
             GROUP BY run_id,kind,status HAVING sum(n)<>0) d;
    END IF;
    PERFORM pcma.apply_task_deltas(COALESCE(deltas,'[]'::jsonb));
    IF TG_OP='UPDATE' THEN
        INSERT INTO pcma.scrape_run_progress(run_id,last_activity_at,last_success_at,last_case_at)
        SELECT n.run_id, max(COALESCE(n.completed_at,n.started_at)),
            max(n.completed_at) FILTER(WHERE n.status='success' AND o.status<>'success'),
            max(n.completed_at) FILTER(WHERE n.status='success' AND o.status<>'success' AND n.kind='case')
        FROM new_tasks n JOIN old_tasks o USING(id)
        WHERE n.status IS DISTINCT FROM o.status
        GROUP BY n.run_id ORDER BY n.run_id
        ON CONFLICT(run_id) DO UPDATE SET
            last_activity_at=GREATEST(pcma.scrape_run_progress.last_activity_at,EXCLUDED.last_activity_at),
            last_success_at=GREATEST(pcma.scrape_run_progress.last_success_at,EXCLUDED.last_success_at),
            last_case_at=GREATEST(pcma.scrape_run_progress.last_case_at,EXCLUDED.last_case_at);
        INSERT INTO pcma.scrape_metrics(run_id,bucket,succeeded,case_succeeded,retried,failed,source_errors)
        SELECT n.run_id,date_trunc('minute',clock_timestamp()),
            count(*) FILTER(WHERE n.status='success'),
            count(*) FILTER(WHERE n.status='success' AND n.kind='case'),
            count(*) FILTER(WHERE n.status='queued' AND n.error_message IS NOT NULL AND NOT n.expanding),
            count(*) FILTER(WHERE n.status='failed'),
            count(*) FILTER(WHERE n.status IN ('queued','failed') AND n.error_kind IN ('response','network','throttle','http','rejected'))
        FROM new_tasks n JOIN old_tasks o USING(id)
        WHERE o.status='running' AND n.status<>o.status
        GROUP BY n.run_id ORDER BY n.run_id
        ON CONFLICT(run_id,bucket) DO UPDATE SET
            succeeded=pcma.scrape_metrics.succeeded+EXCLUDED.succeeded,
            case_succeeded=pcma.scrape_metrics.case_succeeded+EXCLUDED.case_succeeded,
            retried=pcma.scrape_metrics.retried+EXCLUDED.retried,
            failed=pcma.scrape_metrics.failed+EXCLUDED.failed,
            source_errors=pcma.scrape_metrics.source_errors+EXCLUDED.source_errors;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER scrape_tasks_insert AFTER INSERT ON pcma.scrape_tasks REFERENCING NEW TABLE AS new_tasks FOR EACH STATEMENT EXECUTE FUNCTION pcma.track_scrape_tasks();
CREATE TRIGGER scrape_tasks_update AFTER UPDATE ON pcma.scrape_tasks REFERENCING NEW TABLE AS new_tasks OLD TABLE AS old_tasks FOR EACH STATEMENT EXECUTE FUNCTION pcma.track_scrape_tasks();
CREATE TRIGGER scrape_tasks_delete AFTER DELETE ON pcma.scrape_tasks REFERENCING OLD TABLE AS old_tasks FOR EACH STATEMENT EXECUTE FUNCTION pcma.track_scrape_tasks();

CREATE FUNCTION pcma.track_scrape_results() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
    INSERT INTO pcma.scrape_result_counts(run_id,change_kind,total)
    SELECT run_id,change_kind,count(*) FROM new_results GROUP BY run_id,change_kind ORDER BY run_id,change_kind
    ON CONFLICT(run_id,change_kind) DO UPDATE SET total=pcma.scrape_result_counts.total+EXCLUDED.total;
    RETURN NULL;
END $$;
CREATE TRIGGER scrape_results_insert AFTER INSERT ON pcma.scrape_run_cases REFERENCING NEW TABLE AS new_results FOR EACH STATEMENT EXECUTE FUNCTION pcma.track_scrape_results();

INSERT INTO pcma.scrape_task_counts SELECT run_id,kind,status,count(*) FROM pcma.scrape_tasks GROUP BY run_id,kind,status;
INSERT INTO pcma.scrape_result_counts SELECT run_id,change_kind,count(*) FROM pcma.scrape_run_cases GROUP BY run_id,change_kind;
INSERT INTO pcma.scrape_run_progress(run_id,last_activity_at,last_success_at,last_case_at)
SELECT run_id,max(GREATEST(started_at,completed_at)),max(completed_at) FILTER(WHERE status='success'),
    max(completed_at) FILTER(WHERE status='success' AND kind='case') FROM pcma.scrape_tasks GROUP BY run_id;
CREATE FUNCTION pcma.track_scrape_expansions() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE deltas JSONB;
BEGIN
    IF TG_OP='INSERT' THEN
        SELECT jsonb_agg(to_jsonb(d)) INTO deltas FROM (SELECT run_id,sum(jsonb_array_length(children))::bigint AS n FROM new_chunks GROUP BY run_id) d;
    ELSIF TG_OP='DELETE' THEN
        SELECT jsonb_agg(to_jsonb(d)) INTO deltas FROM (SELECT run_id,-sum(jsonb_array_length(children))::bigint AS n FROM old_chunks GROUP BY run_id) d;
    ELSE
        SELECT jsonb_agg(to_jsonb(d)) INTO deltas FROM (SELECT run_id,sum(n)::bigint AS n FROM
            (SELECT run_id,jsonb_array_length(children) AS n FROM new_chunks UNION ALL
             SELECT run_id,-jsonb_array_length(children) FROM old_chunks) x GROUP BY run_id) d;
    END IF;
    INSERT INTO pcma.scrape_run_progress(run_id)
    SELECT d.run_id FROM jsonb_to_recordset(COALESCE(deltas,'[]'::jsonb)) AS d(run_id UUID,n BIGINT)
    JOIN pcma.scrape_runs r ON r.id=d.run_id ORDER BY d.run_id ON CONFLICT DO NOTHING;
    UPDATE pcma.scrape_run_progress p SET deferred_tasks=p.deferred_tasks+d.n
    FROM jsonb_to_recordset(COALESCE(deltas,'[]'::jsonb)) AS d(run_id UUID,n BIGINT) WHERE p.run_id=d.run_id;
    RETURN NULL;
END $$;
CREATE TRIGGER expansions_insert AFTER INSERT ON pcma.scrape_expansions REFERENCING NEW TABLE AS new_chunks FOR EACH STATEMENT EXECUTE FUNCTION pcma.track_scrape_expansions();
CREATE TRIGGER expansions_update AFTER UPDATE ON pcma.scrape_expansions REFERENCING NEW TABLE AS new_chunks OLD TABLE AS old_chunks FOR EACH STATEMENT EXECUTE FUNCTION pcma.track_scrape_expansions();
CREATE TRIGGER expansions_delete AFTER DELETE ON pcma.scrape_expansions REFERENCING OLD TABLE AS old_chunks FOR EACH STATEMENT EXECUTE FUNCTION pcma.track_scrape_expansions();
