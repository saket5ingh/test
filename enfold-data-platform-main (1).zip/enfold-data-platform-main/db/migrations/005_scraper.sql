-- Legacy runs have no snapshots. Do not backfill them from today's case data.
ALTER TABLE pcma.scrape_runs
    ADD COLUMN criteria JSONB,
    ADD COLUMN resolved_scope JSONB,
    ADD COLUMN trigger_type VARCHAR(20) NOT NULL DEFAULT 'manual',
    ADD COLUMN queued_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ADD COLUMN cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN schedule_key VARCHAR(40) UNIQUE,
    ADD COLUMN request_key UUID UNIQUE,
    ADD COLUMN snapshot_version INTEGER;
ALTER TABLE pcma.scrape_runs ALTER COLUMN started_at DROP DEFAULT;
ALTER TABLE pcma.scrape_runs DROP CONSTRAINT scrape_outcome_check;
ALTER TABLE pcma.scrape_runs ADD CONSTRAINT scrape_outcome_check
    CHECK (outcome IN ('pending', 'queued', 'running', 'success', 'partial', 'failed', 'cancelled'));
ALTER TABLE pcma.scrape_runs ADD CONSTRAINT scrape_trigger_check CHECK (trigger_type IN ('manual', 'scheduled'));
ALTER TABLE pcma.scrape_runs ADD CONSTRAINT scrape_criteria_check CHECK (jsonb_typeof(criteria) = 'object');
CREATE INDEX idx_runs_queued ON pcma.scrape_runs(queued_at DESC, id);

CREATE TABLE pcma.scrape_tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id) ON DELETE CASCADE,
    task_key TEXT NOT NULL,
    kind VARCHAR(20) NOT NULL CHECK (kind IN ('discover', 'state', 'district', 'court', 'search', 'case')),
    payload JSONB NOT NULL CHECK (jsonb_typeof(payload) = 'object'),
    status VARCHAR(20) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'running', 'success', 'failed', 'cancelled')),
    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    available_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error_message TEXT,
    UNIQUE(run_id, task_key)
);
CREATE INDEX idx_tasks_ready ON pcma.scrape_tasks(status, available_at);
CREATE INDEX idx_tasks_run_status ON pcma.scrape_tasks(run_id, status);
CREATE TABLE pcma.scrape_run_cases (
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id) ON DELETE RESTRICT,
    case_id UUID NOT NULL REFERENCES pcma.cases(id) ON DELETE RESTRICT,
    fetched_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    snapshot JSONB NOT NULL CHECK (jsonb_typeof(snapshot) = 'object'),
    change_kind VARCHAR(20) NOT NULL CHECK (change_kind IN ('new', 'updated', 'unchanged')),
    PRIMARY KEY(run_id, case_id)
);
CREATE INDEX idx_run_cases_case ON pcma.scrape_run_cases(case_id);
CREATE TABLE pcma.scrape_run_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id) ON DELETE CASCADE,
    task_id UUID REFERENCES pcma.scrape_tasks(id) ON DELETE SET NULL,
    at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    kind VARCHAR(40) NOT NULL,
    message TEXT NOT NULL,
    actor_id UUID REFERENCES pcma.users(id) ON DELETE SET NULL
);
CREATE INDEX idx_run_events ON pcma.scrape_run_events(run_id, at, id);
CREATE TABLE pcma.scraper_metadata (
    key VARCHAR(40) PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
-- One current notification per pinned case/user. New pins do not inherit old alerts.
CREATE TABLE pcma.case_notifications (
    user_id UUID NOT NULL,
    case_id UUID NOT NULL,
    run_id UUID NOT NULL REFERENCES pcma.scrape_runs(id),
    payload JSONB NOT NULL CHECK (pcma.valid_update(payload)),
    PRIMARY KEY(user_id, case_id),
    FOREIGN KEY(user_id, case_id) REFERENCES pcma.case_pins(user_id, case_id) ON DELETE CASCADE
);
-- Rebuild the legacy read view in the same transaction around its column-type change.
DROP VIEW pcma.v_frontline_cases;
ALTER TABLE pcma.cases ALTER COLUMN last_purpose TYPE TEXT;
CREATE VIEW pcma.v_frontline_cases AS
SELECT id, case_ref, case_type, case_type_class, state, district,
       registration_date, filing_date, decision_date, disposition_raw,
       status, duration_days, hearings_count, last_purpose, next_hearing,
       acts, last_scrape, pinned, update_info, created_at, updated_at
FROM pcma.cases;
UPDATE pcma.scrape_runs SET queued_at=started_at WHERE snapshot_version IS NULL AND started_at IS NOT NULL;
ALTER TABLE pcma.scrape_tasks ADD COLUMN retry_base INTEGER NOT NULL DEFAULT 0 CHECK (retry_base >= 0);
