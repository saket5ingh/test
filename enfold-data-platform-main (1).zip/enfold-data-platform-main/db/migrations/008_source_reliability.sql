-- Additive and transactional. Roll out with writers stopped via the deployment
-- procedure. Do not requeue terminal tasks, replace IDs, or rewrite audit rows.
ALTER TABLE pcma.scrape_tasks ADD COLUMN source_attempts INTEGER NOT NULL DEFAULT 0 CHECK(source_attempts>=0);
ALTER TABLE pcma.scraper_control ADD COLUMN recovery_successes INTEGER NOT NULL DEFAULT 0 CHECK(recovery_successes>=0);

-- Credit only verifiable historical transport/availability failures in the
-- current explicit retry cycle. Unknown errors keep their existing budget.
-- SourceDeferred already credits retry_base; it has no task_retry error event.
WITH last_retry AS (
    SELECT run_id,max(at) AS at FROM pcma.scrape_run_events
    WHERE kind='retry_requested' GROUP BY run_id
), failures AS (
    SELECT e.task_id,count(*)::integer AS total,
        count(*) FILTER(WHERE r.at IS NULL OR e.at>r.at)::integer AS current_cycle
    FROM pcma.scrape_run_events e LEFT JOIN last_retry r USING(run_id)
    WHERE e.task_id IS NOT NULL AND e.kind IN ('task_retry','task_failed')
      AND e.message ~ '^[A-Za-z]+WebService[.]php: (network failure [(][A-Za-z]+[)]|HTTP (5[0-9][0-9]|405|429); retry later)$'
    GROUP BY e.task_id
)
UPDATE pcma.scrape_tasks t SET source_attempts=f.total,
    retry_base=t.retry_base+CASE WHEN t.status IN ('queued','running')
        THEN LEAST(f.current_cycle,GREATEST(0,t.attempts-t.retry_base)) ELSE 0 END
FROM failures f WHERE t.id=f.task_id;
-- Existing completed/failed/cancelled status, payloads, snapshots, attempts,
-- source cooldown/ownership and old events remain intact. The new field counts
-- lifetime source failures; retry_base only changes for queued/in-flight work.
