-- Global legacy pins have no attributable owner. Preserve the old column, but
-- start personal pins empty rather than assigning another person's preferences.
CREATE TABLE IF NOT EXISTS pcma.case_pins (
    user_id UUID NOT NULL REFERENCES pcma.users(id) ON DELETE CASCADE,
    case_id UUID NOT NULL REFERENCES pcma.cases(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, case_id)
);
CREATE INDEX IF NOT EXISTS idx_case_pins_case_id ON pcma.case_pins(case_id);
