-- Existing placeholder/legacy documents remain untouched. Only new, validated
-- final-order references are exposed by the document API.
ALTER TABLE pcma.case_documents ADD COLUMN source_reference JSONB;
ALTER TABLE pcma.case_documents ADD COLUMN source_key VARCHAR(64);
ALTER TABLE pcma.case_documents ADD CONSTRAINT document_reference_check CHECK (
    (source_reference IS NULL AND source_key IS NULL) OR
    (source_reference IS NOT NULL AND source_key IS NOT NULL
     AND document_type = 'final' AND jsonb_typeof(source_reference) = 'object'
     AND source_key ~ '^[0-9a-f]{64}$'
     AND source_reference ?& ARRAY['filename','state_cd','dist_cd','court_code'])
);
CREATE UNIQUE INDEX idx_case_docs_source ON pcma.case_documents(case_id, source_key);
-- Records when document discovery was attempted, including an empty source list.
ALTER TABLE pcma.cases ADD COLUMN documents_checked_at TIMESTAMPTZ;

-- Bounded backfill finds the latest successful scope without repeated table scans.
CREATE INDEX idx_case_task_document_scope ON pcma.scrape_tasks ((payload->>'cnr'), completed_at DESC)
    WHERE kind = 'case' AND status = 'success';
