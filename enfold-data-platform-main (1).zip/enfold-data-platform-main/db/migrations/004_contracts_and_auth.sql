-- Run through migrate.sql in one transaction. Invalid legacy data stops the
-- migration with its constraint name; no records are silently deleted/coerced.
ALTER TABLE pcma.users ADD COLUMN google_sub VARCHAR(255) UNIQUE;
ALTER TABLE pcma.users ADD COLUMN auth_version INTEGER NOT NULL DEFAULT 0;
ALTER TABLE pcma.users ADD CONSTRAINT users_role_check CHECK (role IN ('user', 'admin'));
ALTER TABLE pcma.users ADD CONSTRAINT users_auth_version_check CHECK (auth_version >= 0);
CREATE UNIQUE INDEX users_email_lower_unique ON pcma.users (lower(email));

-- Existing display labels become canonical filter keys without changing meaning.
UPDATE pcma.scrape_runs SET status_filter = lower(status_filter)
WHERE status_filter IN ('All', 'Pending', 'Disposed');

CREATE FUNCTION pcma.valid_acts(value JSONB) RETURNS BOOLEAN
LANGUAGE plpgsql IMMUTABLE STRICT AS $$
DECLARE act JSONB; section JSONB;
BEGIN
    IF jsonb_typeof(value) <> 'array' THEN RETURN FALSE; END IF;
    FOR act IN SELECT * FROM jsonb_array_elements(value) LOOP
        IF jsonb_typeof(act) <> 'object'
           OR jsonb_typeof(act->'name') IS DISTINCT FROM 'string'
           OR length(btrim(act->>'name')) = 0
           OR jsonb_typeof(act->'sections') IS DISTINCT FROM 'array'
           OR (act ? 'flag' AND jsonb_typeof(act->'flag') NOT IN ('boolean', 'null'))
        THEN RETURN FALSE; END IF;
        FOR section IN SELECT * FROM jsonb_array_elements(act->'sections') LOOP
            IF jsonb_typeof(section) <> 'string' THEN RETURN FALSE; END IF;
        END LOOP;
    END LOOP;
    RETURN TRUE;
END; $$;
CREATE FUNCTION pcma.valid_update(value JSONB) RETURNS BOOLEAN
LANGUAGE SQL IMMUTABLE STRICT AS $$
    SELECT jsonb_typeof(value) = 'object'
       AND jsonb_typeof(value->'text') IS NOT DISTINCT FROM 'string'
       AND jsonb_typeof(value->'at') IS NOT DISTINCT FROM 'string'
       AND COALESCE(value->>'severity' IN ('info', 'critical'), FALSE);
$$;
ALTER TABLE pcma.cases ADD CONSTRAINT cases_status_check
    CHECK (status IN ('pending', 'disposed', 'acquitted', 'allowed', 'rejected'));
ALTER TABLE pcma.cases ADD CONSTRAINT cases_registration_year_check CHECK (registration_year BETWEEN 1 AND 9999);
ALTER TABLE pcma.cases ADD CONSTRAINT cases_registration_number_check CHECK (registration_number >= 0);
ALTER TABLE pcma.cases ADD CONSTRAINT cases_duration_check CHECK (duration_days >= 0);
ALTER TABLE pcma.cases ADD CONSTRAINT cases_hearings_count_check CHECK (hearings_count >= 0);
ALTER TABLE pcma.cases ADD CONSTRAINT cases_acts_check CHECK (pcma.valid_acts(acts));
ALTER TABLE pcma.cases ADD CONSTRAINT cases_update_check CHECK (pcma.valid_update(update_info));
ALTER TABLE pcma.cases ADD CONSTRAINT cases_last_scrape_check CHECK (last_scrape ~ '^[0-9]{4}-(0[1-9]|1[0-2])$');
ALTER TABLE pcma.case_hearings ADD CONSTRAINT hearings_sequence_check CHECK (sequence_order >= 0);
ALTER TABLE pcma.scrape_runs ADD CONSTRAINT scrape_status_check CHECK (status_filter IN ('all', 'pending', 'disposed'));
ALTER TABLE pcma.scrape_runs ADD CONSTRAINT scrape_outcome_check CHECK (outcome IN ('pending', 'running', 'success', 'partial', 'failed'));
ALTER TABLE pcma.scrape_runs ADD CONSTRAINT scrape_count_check CHECK (total_cases_found >= 0);
ALTER TABLE pcma.scrape_runs ADD CONSTRAINT scrape_dates_check CHECK (completed_at >= started_at);
CREATE INDEX idx_cases_last_scrape ON pcma.cases(last_scrape);
CREATE INDEX idx_cases_registration_year ON pcma.cases(registration_year);
