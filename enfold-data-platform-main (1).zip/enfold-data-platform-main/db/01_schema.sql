CREATE SCHEMA IF NOT EXISTS pcma;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

CREATE TABLE pcma.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    role_label VARCHAR(255),
    initials VARCHAR(10),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pcma.scrape_runs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    state VARCHAR(100),
    acts VARCHAR(500),
    sections VARCHAR(255),
    status_filter VARCHAR(20) DEFAULT 'all',
    outcome VARCHAR(20) DEFAULT 'pending',
    total_cases_found INTEGER DEFAULT 0,
    error_message TEXT,
    triggered_by UUID REFERENCES pcma.users(id) ON DELETE SET NULL,
    started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ
);

CREATE TABLE pcma.cases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scrape_run_id UUID REFERENCES pcma.scrape_runs(id) ON DELETE SET NULL,
    cnr_number VARCHAR(32) UNIQUE NOT NULL,
    case_number VARCHAR(64),
    case_ref VARCHAR(64),
    case_type VARCHAR(128),
    case_type_class VARCHAR(64),
    registration_number INTEGER,
    registration_year INTEGER,
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    complex_name VARCHAR(255),
    court_name VARCHAR(255),
    registration_date DATE,
    filing_date DATE,
    decision_date DATE,
    disposition_raw VARCHAR(255),
    status VARCHAR(32) NOT NULL DEFAULT 'pending',
    duration_days INTEGER,
    hearings_count INTEGER DEFAULT 0,
    last_purpose VARCHAR(255),
    next_hearing DATE,
    acts JSONB NOT NULL DEFAULT '[]'::jsonb,
    last_scrape VARCHAR(20),
    pinned BOOLEAN NOT NULL DEFAULT FALSE,
    update_info JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pcma.case_hearings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID NOT NULL REFERENCES pcma.cases(id) ON DELETE CASCADE,
    hearing_date DATE NOT NULL,
    purpose TEXT NOT NULL,
    sequence_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pcma.case_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID NOT NULL REFERENCES pcma.cases(id) ON DELETE CASCADE,
    document_type VARCHAR(20) NOT NULL,
    label VARCHAR(500) NOT NULL,
    document_date DATE,
    s3_key VARCHAR(500),
    external_link TEXT,
    params_blob TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX idx_case_docs_unique_s3 ON pcma.case_documents(case_id, s3_key) WHERE s3_key IS NOT NULL;

CREATE OR REPLACE FUNCTION pcma.update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER tr_cases_updated_at
BEFORE UPDATE ON pcma.cases
FOR EACH ROW
EXECUTE PROCEDURE pcma.update_timestamp();

CREATE INDEX idx_cases_state_district ON pcma.cases(state, district);
CREATE INDEX idx_cases_decision_date ON pcma.cases(decision_date);
CREATE INDEX idx_cases_status ON pcma.cases(status);
CREATE INDEX idx_cases_disposition_raw ON pcma.cases(disposition_raw);
CREATE INDEX idx_cases_acts_gin ON pcma.cases USING GIN (acts jsonb_path_ops);
CREATE INDEX idx_cases_court_name_trgm ON pcma.cases USING GIN (court_name gin_trgm_ops);
CREATE INDEX idx_cases_complex_name_trgm ON pcma.cases USING GIN (complex_name gin_trgm_ops);
CREATE INDEX idx_case_hearings_case_id ON pcma.case_hearings(case_id);
CREATE INDEX idx_case_documents_case_id ON pcma.case_documents(case_id);

CREATE OR REPLACE VIEW pcma.v_frontline_cases AS
SELECT id, case_ref, case_type, case_type_class, state, district,
       registration_date, filing_date, decision_date, disposition_raw,
       status, duration_days, hearings_count, last_purpose, next_hearing,
       acts, last_scrape, pinned, update_info, created_at, updated_at
FROM pcma.cases;
