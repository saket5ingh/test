-- Owner-only maintenance, with all API/worker writers stopped. No source HTTP.
-- psql -X -v ON_ERROR_STOP=1 --single-transaction -d pcma_db -f db/reconcile_scraper.sql
-- Rebuild derived counters only. Never delete tasks, snapshots or metric history.
LOCK TABLE pcma.scrape_tasks,pcma.scrape_run_cases,pcma.scrape_expansions IN SHARE ROW EXCLUSIVE MODE;
DELETE FROM pcma.scrape_task_counts;
INSERT INTO pcma.scrape_task_counts SELECT run_id,kind,status,count(*) FROM pcma.scrape_tasks GROUP BY run_id,kind,status;
DELETE FROM pcma.scrape_result_counts;
INSERT INTO pcma.scrape_result_counts SELECT run_id,change_kind,count(*) FROM pcma.scrape_run_cases GROUP BY run_id,change_kind;
INSERT INTO pcma.scrape_run_progress(run_id,last_activity_at,last_success_at,last_case_at)
SELECT run_id,max(GREATEST(started_at,completed_at)),max(completed_at) FILTER(WHERE status='success'),
    max(completed_at) FILTER(WHERE status='success' AND kind='case') FROM pcma.scrape_tasks GROUP BY run_id
ON CONFLICT(run_id) DO UPDATE SET last_activity_at=EXCLUDED.last_activity_at,
    last_success_at=EXCLUDED.last_success_at,last_case_at=EXCLUDED.last_case_at;
UPDATE pcma.scrape_run_progress SET deferred_tasks=0;
UPDATE pcma.scrape_run_progress p SET deferred_tasks=x.total FROM (
    SELECT run_id,sum(jsonb_array_length(children)) AS total FROM pcma.scrape_expansions GROUP BY run_id
) x WHERE p.run_id=x.run_id;
