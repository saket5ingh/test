"""Reproducible synthetic SQL benchmark. Local *_test databases only; no HTTP.

Seed once before migration, rerun with --phase optimized after migration.
Outputs JSON timings and a fingerprint of pre-existing task fields.
"""
import argparse
import asyncio
import json
import statistics
import time
from urllib.parse import urlsplit
from uuid import UUID, uuid4
import asyncpg

RUN = UUID('00000000-0000-4000-8000-000000000707')

async def main(args):
    url = urlsplit(args.url)
    if url.hostname not in ('localhost', '127.0.0.1') or not url.path.endswith('_test'):
        raise SystemExit('Only an isolated localhost database ending in _test is allowed')
    db = await asyncpg.connect(args.url)
    try:
        await db.execute("SET statement_timeout='120s'")
        if args.seed:
            async with db.transaction():
                await db.execute("INSERT INTO pcma.scrape_runs(id,name,outcome) VALUES($1,'Synthetic SQL benchmark','success') ON CONFLICT DO NOTHING", RUN)
                await db.execute("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,available_at)
                    SELECT $1,'case:benchmark-'||i,'case',jsonb_build_object('cnr','SYNTHETIC-'||i),'queued',
                    '2026-01-01'::timestamptz + (i/500)*interval '1 second'
                    FROM generate_series(1,$2::int) i ON CONFLICT DO NOTHING""", RUN, args.rows)
            await db.execute('ANALYZE pcma.scrape_tasks')
        count = await db.fetchval('SELECT count(*) FROM pcma.scrape_tasks WHERE run_id=$1', RUN)
        fingerprint = await db.fetchval("""SELECT md5(string_agg(md5(concat_ws('|',id,task_key,kind,payload,status,attempts,retry_base,available_at,started_at,completed_at)),'' ORDER BY id)) FROM pcma.scrape_tasks WHERE run_id=$1""", RUN)
        queries = {
            'legacy_counts': 'SELECT kind,status,count(*) FROM pcma.scrape_tasks WHERE run_id=$1 GROUP BY kind,status',
            'legacy_finalize': 'SELECT status,count(*) FROM pcma.scrape_tasks WHERE run_id=$1 GROUP BY status',
            'legacy_claim': "SELECT id FROM pcma.scrape_tasks WHERE run_id=$1 AND status='queued' AND available_at<=CURRENT_TIMESTAMP ORDER BY available_at,id LIMIT 1",
        }
        if args.phase == 'optimized':
            queries.update(counters='SELECT kind,status,total FROM pcma.scrape_task_counts WHERE run_id=$1',
                indexed_claim="SELECT id FROM pcma.scrape_tasks WHERE run_id=$1 AND kind='case' AND status='queued' AND available_at<=CURRENT_TIMESTAMP ORDER BY available_at,id LIMIT 1")
        results = {}
        for name, query in queries.items():
            await db.fetch(query, RUN)
            durations=[]
            for _ in range(7):
                start=time.perf_counter(); await db.fetch(query,RUN); durations.append((time.perf_counter()-start)*1000)
            results[name]={'median_ms':round(statistics.median(durations),3),'max_ms':round(max(durations),3)}
        if args.inserts:
            insert_times={}
            payload=json.dumps({'cnr':'SYNTHETIC-BENCH','state':{'code':'5','name':'Synthetic state'},'court':{'code':'1','name':'Synthetic court'}})
            for mode in ('individual','bulk_500'):
                durations=[]
                for repetition in range(3):
                    transaction=db.transaction(); await transaction.start()
                    try:
                        rid=uuid4()
                        await db.execute("INSERT INTO pcma.scrape_runs(id,name,outcome) VALUES($1,'Synthetic insertion benchmark','success')",rid)
                        start=time.perf_counter()
                        if mode=='individual':
                            for i in range(args.inserts):
                                await db.execute("INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload) VALUES($1,$2,'case',$3::jsonb) ON CONFLICT DO NOTHING",rid,str(i),payload)
                        else:
                            for start_at in range(0,args.inserts,500):
                                rows=json.dumps([{'key':str(i),'payload':json.loads(payload)} for i in range(start_at,min(start_at+500,args.inserts))])
                                await db.execute("INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload) SELECT $1,key,'case',payload FROM jsonb_to_recordset($2::jsonb) AS x(key TEXT,payload JSONB) ON CONFLICT DO NOTHING",rid,rows)
                        durations.append((time.perf_counter()-start)*1000)
                        assert await db.fetchval('SELECT count(*) FROM pcma.scrape_tasks WHERE run_id=$1',rid)==args.inserts
                    finally: await transaction.rollback()
                insert_times[mode]={'rows':args.inserts,'median_ms':round(statistics.median(durations),3),'max_ms':round(max(durations),3)}
            results['insert_comparison_same_schema']=insert_times
        print(json.dumps({'phase':args.phase,'rows':count,'task_fingerprint':fingerprint,'timings':results},indent=2))
    finally:
        await db.close()

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url',required=True)
    parser.add_argument('--phase',choices=['baseline','optimized'],default='baseline')
    parser.add_argument('--seed',action='store_true')
    parser.add_argument('--inserts',type=int,default=0,help='Compare individual and 500-row insertion batches in rolled-back transactions')
    parser.add_argument('--rows',type=int,default=250000)
    asyncio.run(main(parser.parse_args()))
