"""Isolated PostgreSQL tests. Synthetic clients only; never contact eCourts."""
import asyncio
import os
from contextlib import asynccontextmanager
from uuid import uuid4
import pytest
from sqlalchemy import text
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from app.scraper import worker
from app.scraper.control import SourceGate, SourceDeferred, OwnershipLost
from app.scraper.client import UpstreamError
from app.scraper.store import enqueue_many, stage_children, expand_batch, ingest
from app.scraper.normalize import normalize
from app.scraper.monitor import summaries, performance
from test_scraper import history

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URL not supplied')


@asynccontextmanager
async def database(monkeypatch):
    url=make_url(os.environ['FFG_TEST_PG_OWNER'])
    assert url.host in ('localhost','127.0.0.1') and url.database.endswith('_test')
    engine=create_async_engine(url)
    sessions=async_sessionmaker(engine,expire_on_commit=False)
    monkeypatch.setattr(worker,'async_session_maker',sessions)
    monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_ENABLED',False)
    ids=[]; owner=uuid4()
    async with sessions() as db,db.begin():
        await db.execute(text('''UPDATE pcma.scraper_control SET owner=:owner,paused_until=NULL,
            failure_streak=0,cooldown_level=0,recovery_successes=0,probe_owner=NULL,probe_until=NULL,
            next_request_at=clock_timestamp() WHERE id=TRUE'''),{'owner':owner})
    async def queue(children):
        run=uuid4(); ids.append(run)
        async with sessions() as db,db.begin():
            await db.execute(text('''INSERT INTO pcma.scrape_runs(id,name,outcome,status_filter,criteria,
                trigger_type,queued_at,started_at,snapshot_version)
                VALUES(:id,'Synthetic performance test','queued','all',
                '{"allStates": true,"stateCodes":[],"allActs": true,"actKeys":[],"sections":[],"status":"all"}',
                'manual','1900-01-01',NULL,1)'''),{'id':run})
            await enqueue_many(db,run,children)
        return run
    try: yield sessions,queue,owner,engine
    finally:
        async with sessions() as db,db.begin():
            await db.execute(text("UPDATE pcma.scrape_runs SET outcome='cancelled',cancel_requested=TRUE WHERE id=ANY(:ids)"),{'ids':ids})
            await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled',lease_owner=NULL,lease_until=NULL WHERE run_id=ANY(:ids) AND status IN ('queued','running')"),{'ids':ids})
        await engine.dispose()


@pytest.mark.parametrize('pressure',[False,True])
def test_fairness_under_pressure_and_distinct_concurrent_claims(monkeypatch,pressure):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            monkeypatch.setattr(worker.settings,'SCRAPER_QUEUE_HIGH_WATER',10 if pressure else 10000)
            run_id=await queue([(kind,{'n':i},f'{kind}-{i}') for kind in ('case','search','court','district','state','discover') for i in range(45)])
            kinds=[]; ids=[]
            # One complete pressure rotation must still serve every producer kind.
            for _ in range(len(worker.PRESSURE_KINDS if pressure else worker.FAIR_KINDS)):
                async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                assert task['run_id']==run_id
                kinds.append(task['kind']); ids.append(task['id'])
            assert set(kinds)=={'case','search','court','district','state','discover'}
            assert kinds.count('case')==(32 if pressure else 4)
            async def claim():
                async with sessions() as db,db.begin(): return await worker.claim(db,owner)
            claimed=await asyncio.gather(*[claim() for _ in range(6)])
            ids += [t['id'] for t in claimed if t]
            assert len(ids)==len(set(ids))
    asyncio.run(run())


def test_global_limiter_cooldown_single_probe_and_owner_fencing(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            gates=[SourceGate(sessions,owner,interval=0.025) for _ in range(3)]
            stamps=[]
            async def admit(gate):
                stamps.append(await gate.wait())
            await asyncio.gather(*[admit(g) for g in gates])
            # Compare PostgreSQL reservations, not delayed Python resumption times.
            stamps.sort(); assert all((b-a).total_seconds()>=0.025 for a,b in zip(stamps,stamps[1:])),stamps
            monkeypatch.setattr(worker.settings,'SCRAPER_SOURCE_FAILURE_THRESHOLD',2)
            async with sessions() as db,db.begin():
                assert not await gates[0].report(db,UpstreamError('Synthetic bad response'))
                assert await gates[0].report(db,UpstreamError('Synthetic bad response'))
            with pytest.raises(SourceDeferred): await gates[1].wait()
            # Recreating the client cannot reset persisted source backoff.
            with pytest.raises(SourceDeferred): await SourceGate(sessions,owner,interval=0).wait()
            async with sessions() as db,db.begin():
                await db.execute(text("UPDATE pcma.scraper_control SET paused_until=clock_timestamp()-INTERVAL '1 second',next_request_at=clock_timestamp()"))
            await gates[0].wait()
            with pytest.raises(SourceDeferred): await gates[1].wait()
            async with sessions() as db,db.begin():
                await gates[1].report(db)  # stale in-flight success cannot close another probe
            with pytest.raises(SourceDeferred): await gates[1].wait()
            for i in range(worker.settings.SCRAPER_RECOVERY_SUCCESSES):
                async with sessions() as db,db.begin(): await gates[0].report(db)
                if i+1<worker.settings.SCRAPER_RECOVERY_SUCCESSES:
                    with pytest.raises(SourceDeferred): await gates[1].wait()
                    async with sessions() as db,db.begin():
                        await db.execute(text("UPDATE pcma.scraper_control SET paused_until=clock_timestamp()-INTERVAL '1 second',next_request_at=clock_timestamp()"))
                    await gates[0].wait()
            await gates[1].wait()
            async with sessions() as db,db.begin(): await db.execute(text('UPDATE pcma.scraper_control SET owner=:owner'),{'owner':uuid4()})
            with pytest.raises(OwnershipLost): await gates[0].wait()
    asyncio.run(run())


def test_checkpoint_backpressure_resume_without_refetch_or_attempt_reset(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            monkeypatch.setattr(worker.settings,'SCRAPER_QUEUE_HIGH_WATER',10)
            monkeypatch.setattr(worker.settings,'SCRAPER_INSERT_BATCH',4)
            run_id=await queue([('search',{},'parent')])
            calls=0
            async def perform(*args):
                nonlocal calls
                calls+=1
                return [('case',{'cnr':f'SYN{i}'},f'SYN{i}') for i in range(23)],[],None,None
            monkeypatch.setattr(worker,'perform',perform)
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            await worker.execute_task(object(),task)
            async with sessions() as db:
                assert (await db.execute(text('SELECT deferred_tasks FROM pcma.scrape_run_progress WHERE run_id=:run'),{'run':run_id})).scalar_one()==19
                validated_at=(await db.execute(text('SELECT source_validated_at FROM pcma.scrape_tasks WHERE id=:id'),task)).scalar_one()
                assert validated_at is not None
            # Restart: leave a claimed expansion in flight, recover it, then resume.
            async with sessions() as db,db.begin():
                await db.execute(text("UPDATE pcma.scrape_runs SET dispatch_cursor=1 WHERE id=:run"),{'run':run_id})
                abandoned=await worker.claim(db,owner)
                assert abandoned['expanding']
            async with sessions() as db,db.begin(): await worker.recover(db,owner)
            complete=0
            for _ in range(100):
                async with sessions() as db,db.begin(): current=await worker.claim(db,owner)
                if not current: break
                if current['kind']=='case':
                    # Synthetic drain, no source request or case-record access.
                    async with sessions() as db,db.begin():
                        await db.execute(text("UPDATE pcma.scrape_tasks SET status='success',completed_at=clock_timestamp(),lease_owner=NULL,lease_until=NULL WHERE id=:id"),current)
                        await worker.finalize(db,run_id)
                    complete+=1
                else: await worker.execute_task(object(),current)
                async with sessions() as db:
                    pending=(await db.execute(text("SELECT sum(total) FROM pcma.scrape_task_counts WHERE run_id=:run AND status IN ('queued','running')"),{'run':run_id})).scalar_one()
                    assert pending<=10
            assert complete==23 and calls==1
            async with sessions() as db:
                parent=(await db.execute(text("SELECT attempts,expanding,status FROM pcma.scrape_tasks WHERE run_id=:run AND kind='search'"),{'run':run_id})).one()
                assert tuple(parent)==(1,False,'success')
                assert (await db.execute(text('SELECT source_validated_at FROM pcma.scrape_tasks WHERE id=:id'),task)).scalar_one()==validated_at
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_expansions WHERE run_id=:run'),{'run':run_id})).scalar_one()==0
                assert (await db.execute(text('SELECT deferred_tasks FROM pcma.scrape_run_progress WHERE run_id=:run'),{'run':run_id})).scalar_one()==0
    asyncio.run(run())


def test_transaction_rollback_counters_dedupe_and_expired_lease_fencing(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id=await queue([('search',{},'one')])
            async with sessions() as db:
                async with db.begin():
                    assert await enqueue_many(db,run_id,[('case',{'cnr':'A'},'A')]*4)==1
                    await db.rollback()
            async with sessions() as db:
                assert (await db.execute(text('SELECT sum(total) FROM pcma.scrape_task_counts WHERE run_id=:run'),{'run':run_id})).scalar_one()==1
            async with sessions() as db,db.begin(): old=await worker.claim(db,owner)
            async with sessions() as db,db.begin():
                await db.execute(text("UPDATE pcma.scrape_tasks SET lease_until=clock_timestamp()-INTERVAL '1 second' WHERE id=:id"),old)
                await worker.recover(db,owner,expired_only=True)
                new=await worker.claim(db,owner)
            assert old['id']==new['id'] and new['claim_version']>old['claim_version']
            async with sessions() as db:
                assert not await worker.owns_task(db,old)
                assert await worker.owns_task(db,new)
            # A cancelled in-flight response cannot produce queued children.
            async with sessions() as db,db.begin(): await db.execute(text('UPDATE pcma.scrape_runs SET cancel_requested=TRUE WHERE id=:run'),{'run':run_id})
            async def perform(*args): return [('case',{'cnr':'A'},'A')],[],None,None
            monkeypatch.setattr(worker,'perform',perform)
            await worker.execute_task(object(),new)
            async with sessions() as db:
                actual=(await db.execute(text('SELECT status,count(*) FROM pcma.scrape_tasks WHERE run_id=:run GROUP BY status'),{'run':run_id})).all()
                cached=(await db.execute(text('SELECT status,sum(total) FROM pcma.scrape_task_counts WHERE run_id=:run AND total>0 GROUP BY status'),{'run':run_id})).all()
                assert dict(actual)==dict(cached)=={'cancelled':1}
    asyncio.run(run())


def test_concurrent_ingestion_of_same_cnr_retains_one_case_and_two_snapshots(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            runs=[await queue([]),await queue([])]
            cnr='SYN'+uuid4().hex[:12].upper()
            record=normalize(history(),{'cnr':cnr,'status':'Pending','state':{'name':'Bihar','code':'5'},'district':{'name':'Gaya','code':'1'},'court':{'name':'Court','code':'1'}})
            async def save(run_id):
                async with sessions() as db,db.begin(): await ingest(db,run_id,dict(record))
            await asyncio.gather(*[save(r) for r in runs])
            async with sessions() as db:
                assert (await db.execute(text('SELECT count(*) FROM pcma.cases WHERE cnr_number=:cnr'),{'cnr':cnr})).scalar_one()==1
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=ANY(:ids)'),{'ids':runs})).scalar_one()==2
                assert (await db.execute(text('SELECT sum(total) FROM pcma.scrape_result_counts WHERE run_id=ANY(:ids)'),{'ids':runs})).scalar_one()==2
    asyncio.run(run())


def test_pool_overlaps_tasks_but_preserves_lock_and_global_pacing(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,engine):
            monkeypatch.setattr(worker.settings,'SCRAPER_CONCURRENCY',3)
            monkeypatch.setattr(worker.settings,'SCRAPER_REQUEST_INTERVAL',0.03)
            run_id=await queue([('case',{'n':i},str(i)) for i in range(6)])
            stop=asyncio.Event(); in_flight=0; peak=0; starts=[]; closed=[]
            class Client:
                def __init__(self,interval,limiter): self.limiter=limiter
                async def states(self): return [{'code':'5','name':'Bihar'}]
                async def close(self): closed.append(self)
            async def perform(client,task,criteria):
                nonlocal in_flight,peak
                starts.append(await client.limiter.wait())
                in_flight+=1; peak=max(peak,in_flight)
                await asyncio.sleep(0.12)
                in_flight-=1
                if len(starts)==6 and not in_flight: stop.set()
                return [],[],None,None
            monkeypatch.setattr(worker,'perform',perform)
            async with engine.connect() as guard:
                assert (await guard.execute(text('SELECT pg_try_advisory_lock(:key)'),{'key':worker.LOCK_ID})).scalar_one()
                await guard.commit()
                try: await asyncio.wait_for(worker.run_pool(guard,owner,stop,Client),10)
                finally:
                    await guard.execute(text('SELECT pg_advisory_unlock(:key)'),{'key':worker.LOCK_ID}); await guard.commit()
            assert peak==3 and len(closed)==3 and len(starts)==6
            starts.sort()
            assert all((b-a).total_seconds()>=0.03 for a,b in zip(starts,starts[1:])),starts
            async with sessions() as db:
                summary=(await summaries(db,[run_id]))[run_id]
                assert summary['tasks']=={'success':6}
                assert summary['metrics']['cases']==6
    asyncio.run(run())


def test_source_deferral_preserves_attempt_budget_and_circuit_prevents_claims(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id=await queue([('search',{},'one')])
            gate=SourceGate(sessions,owner,interval=0)
            class Client: limiter=gate
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            async def deferred(*args): raise SourceDeferred(30)
            monkeypatch.setattr(worker,'perform',deferred)
            await worker.execute_task(Client(),task)
            async with sessions() as db,db.begin():
                row=(await db.execute(text('SELECT attempts,retry_base,status FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert tuple(row)==(1,1,'queued')
                await db.execute(text('UPDATE pcma.scrape_tasks SET available_at=CURRENT_TIMESTAMP WHERE id=:id'),task)
                await gate.report(db,UpstreamError('Synthetic throttle',kind='throttle'))
                assert await worker.claim(db,owner) is None
                await db.execute(text('UPDATE pcma.scraper_control SET paused_until=NULL,failure_streak=0,probe_owner=NULL'))
                task=await worker.claim(db,owner)
            assert task['attempts']-task['retry_base']==1
            async def fail(*args): raise UpstreamError('Synthetic rejected search',kind='validation')
            monkeypatch.setattr(worker,'perform',fail)
            monkeypatch.setattr(worker.settings,'SCRAPER_MAX_ATTEMPTS',1)
            await worker.execute_task(Client(),task)
            async with sessions() as db:
                stats=(await summaries(db,[run_id]))[run_id]
                assert stats['tasks']=={'failed':1}
                assert stats['metrics']['failed']==1 and stats['metrics']['source_errors']==0
                assert stats['metrics']['retried']==0
    asyncio.run(run())


def test_shutdown_cancels_hung_synthetic_request_and_recovers_durable_task(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,engine):
            monkeypatch.setattr(worker.settings,'SCRAPER_CONCURRENCY',1)
            monkeypatch.setattr(worker.settings,'SCRAPER_SHUTDOWN_SECONDS',1)
            run_id=await queue([('case',{},'hung')]); stop=asyncio.Event(); closed=[]
            class Client:
                def __init__(self,interval,limiter): self.limiter=limiter
                async def states(self): return [{'code':'5','name':'Bihar'}]
                async def close(self): closed.append(True)
            async def hang(*args):
                stop.set()
                await asyncio.Event().wait()
            monkeypatch.setattr(worker,'perform',hang)
            async with engine.connect() as guard:
                assert (await guard.execute(text('SELECT pg_try_advisory_lock(:key)'),{'key':worker.LOCK_ID})).scalar_one()
                await guard.commit()
                try: await asyncio.wait_for(worker.run_pool(guard,owner,stop,Client),5)
                finally:
                    await guard.execute(text('SELECT pg_advisory_unlock(:key)'),{'key':worker.LOCK_ID}); await guard.commit()
            async with sessions() as db:
                row=(await db.execute(text('SELECT status,attempts,retry_base,lease_owner,lease_until FROM pcma.scrape_tasks WHERE run_id=:run'),{'run':run_id})).one()
                assert tuple(row)==('queued',1,1,None,None)
            assert closed==[True]
    asyncio.run(run())


def test_later_run_cannot_overtake_old_run_waiting_for_retry(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            old=await queue([('case',{},'first')]); new=await queue([('case',{},'second')])
            async with sessions() as db,db.begin():
                await db.execute(text("UPDATE pcma.scrape_runs SET queued_at='1900-01-02' WHERE id=:id"),{'id':new})
                await db.execute(text("UPDATE pcma.scrape_tasks SET available_at=clock_timestamp()+INTERVAL '1 hour' WHERE run_id=:id"),{'id':old})
                assert await worker.claim(db,owner) is None
                await db.execute(text("UPDATE pcma.scrape_tasks SET status='success',completed_at=clock_timestamp() WHERE run_id=:id"),{'id':old})
                await worker.finalize(db,old)
                assert (await worker.claim(db,owner))['run_id']==new
    asyncio.run(run())


def test_producer_only_queue_makes_bounded_progress_without_deadlock(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            monkeypatch.setattr(worker.settings,'SCRAPER_QUEUE_HIGH_WATER',10)
            run_id=await queue([('search',{'n':i},str(i)) for i in range(10)])
            calls=0
            async def produce(client,task,criteria):
                nonlocal calls
                if task['kind']=='search':
                    calls+=1
                    return [('case',{'n':task['payload']['n']},str(task['payload']['n']))],[],None,None
                return [],[],None,None
            monkeypatch.setattr(worker,'perform',produce)
            for _ in range(60):
                async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                if task is None: break
                await worker.execute_task(object(),task)
                async with sessions() as db:
                    pending=(await db.execute(text("SELECT COALESCE(sum(total),0) FROM pcma.scrape_task_counts WHERE run_id=:id AND status IN ('queued','running')"),{'id':run_id})).scalar_one()
                    assert pending<=11  # Only one deadlock-breaking admission above capacity.
            async with sessions() as db:
                assert (await db.execute(text('SELECT outcome FROM pcma.scrape_runs WHERE id=:id'),{'id':run_id})).scalar_one()=='success'
                assert (await db.execute(text('SELECT deferred_tasks FROM pcma.scrape_run_progress WHERE run_id=:id'),{'id':run_id})).scalar_one()==0
            assert calls==10
    asyncio.run(run())
