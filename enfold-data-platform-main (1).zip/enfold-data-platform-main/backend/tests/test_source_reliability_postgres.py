"""Real localhost PostgreSQL; synthetic source clients, never eCourts."""
import asyncio
import copy
import os
from uuid import uuid4
import pytest
from sqlalchemy import text
from app.scraper import worker
from app.scraper.client import UpstreamError
from app.scraper.control import SourceGate, SourceDeferred
from app.scraper.normalize import normalize
from app.scraper.store import ingest, save_documents
from test_scraper import history, scope
from test_scraper_performance_postgres import database

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URL not supplied')


async def ready(sessions, task_id=None):
    """Advance only synthetic database clocks, never the actual source gate."""
    async with sessions() as db,db.begin():
        await db.execute(text("UPDATE pcma.scraper_control SET next_request_at=clock_timestamp(),paused_until=CASE WHEN paused_until IS NULL THEN NULL ELSE clock_timestamp()-INTERVAL '1 second' END"))
        if task_id:
            await db.execute(text('UPDATE pcma.scrape_tasks SET available_at=clock_timestamp() WHERE id=:id'),{'id':task_id})


async def state(sessions):
    async with sessions() as db:
        return dict((await db.execute(text('SELECT *,clock_timestamp() observed FROM pcma.scraper_control'))).mappings().one())


@pytest.mark.parametrize('kind',['network','http','throttle'])
def test_source_retries_preserve_record_budget_backoff_and_audit(monkeypatch,kind):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id=await queue([('case',scope(),'synthetic')]);gate=SourceGate(sessions,owner,interval=0)
            class Client: limiter=gate
            async def fail(client,*args):
                await gate.wait();raise UpstreamError('Synthetic source outage',kind=kind)
            monkeypatch.setattr(worker,'perform',fail)
            task_id=None
            for attempt in range(1,13):
                await ready(sessions,task_id)
                async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                task_id=task['id'];await worker.execute_task(Client(),task)
                async with sessions() as db:
                    row=(await db.execute(text('SELECT *,extract(epoch from available_at-clock_timestamp()) delay FROM pcma.scrape_tasks WHERE id=:id'),{'id':task_id})).mappings().one()
                    assert row['status']=='queued' and row['attempts']==row['retry_base']==row['source_attempts']==attempt
                    expected=min(1800,30*2**min(10,attempt-1))
                    assert expected-3 <= row['delay'] <= expected
                    assert row['lease_owner'] is None and row['completed_at'] is None
                if (await state(sessions))['paused_until']:
                    async with sessions() as db,db.begin(): assert await worker.claim(db,owner) is None
            # Twelve real source failures still leave all three record attempts.
            async def bad_record(client,*args):
                await gate.wait();raise ValueError('Incomplete JSON hearing entry')
            monkeypatch.setattr(worker,'perform',bad_record)
            for record_attempt in range(1,4):
                await ready(sessions,task_id)
                async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                await worker.execute_task(Client(),task)
                async with sessions() as db:
                    row=(await db.execute(text('SELECT * FROM pcma.scrape_tasks WHERE id=:id'),{'id':task_id})).mappings().one()
                    assert row['attempts']==12+record_attempt and row['retry_base']==12 and row['source_attempts']==12
                    assert row['status']==('failed' if record_attempt==3 else 'queued')
            async with sessions() as db:
                events=(await db.execute(text('SELECT kind,count(*) FROM pcma.scrape_run_events WHERE run_id=:id GROUP BY kind'),{'id':run_id})).all()
                assert dict(events)['task_retry']==14 and dict(events)['task_failed']==1
                assert dict(events)['source_retry_alert']==1
                from app.routes.scrapes import events as list_events
                alerts=await list_events(run_id,page=1,pageSize=100,q='',kind='errors',db=db)
                assert any(e['kind']=='source_retry_alert' for e in alerts['items'])
                assert (await db.execute(text('SELECT sum(source_errors) FROM pcma.scrape_metrics WHERE run_id=:id'),{'id':run_id})).scalar_one()==12
    asyncio.run(run())


def test_spaced_recovery_retains_backoff_across_clients_and_requires_three_successes(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            gate=SourceGate(sessions,owner,interval=0);other=SourceGate(sessions,owner,interval=0)
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('503',kind='throttle'))
            await ready(sessions);await gate.wait()
            async with sessions() as db,db.begin(): await gate.report(db)
            row=await state(sessions)
            assert row['cooldown_level']==1 and row['recovery_successes']==1 and row['failure_streak']==0
            assert 57 < (row['paused_until']-row['observed']).total_seconds() <= 60
            with pytest.raises(SourceDeferred): await other.wait()
            # A replacement client reads durable partial recovery, it cannot clear it.
            gate=SourceGate(sessions,owner,interval=0)
            await ready(sessions);await gate.wait()
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('network',kind='network'))
            row=await state(sessions)
            assert row['cooldown_level']==2 and row['recovery_successes']==0
            assert 117 < (row['paused_until']-row['observed']).total_seconds() <= 120
            for i in range(3):
                await ready(sessions);await gate.wait()
                # Another client's in-flight success cannot count as this probe.
                async with sessions() as db,db.begin(): await other.report(db)
                assert (await state(sessions))['recovery_successes']==i
                async with sessions() as db,db.begin(): await gate.report(db)
                row=await state(sessions)
                assert row['recovery_successes']==(i+1 if i<2 else 0)
                assert row['cooldown_level']==(2 if i<2 else 0)
            assert row['paused_until'] is None and row['probe_owner'] is None
    asyncio.run(run())


def test_validation_and_catalogue_success_cannot_open_or_close_source_circuit(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            gate=SourceGate(sessions,owner,interval=0)
            for _ in range(7):
                async with sessions() as db,db.begin(): assert not await gate.report(db,UpstreamError('Invalid court act list',kind='validation'))
            row=await state(sessions);assert row['failure_streak']==0 and row['paused_until'] is None
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('503',kind='throttle'))
            for error,representative in [(None,False),(UpstreamError('hearing',kind='validation'),True)]:
                await ready(sessions);await gate.wait()
                async with sessions() as db,db.begin(): await gate.report(db,error,representative=representative)
                row=await state(sessions)
                assert row['cooldown_level']==1 and row['failure_streak']==1
                assert row['recovery_successes']==0 and row['probe_owner'] is None
            # Once open, unrelated in-flight failures must not repeatedly extend it.
            await gate.wait()
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('network',kind='network'))
            before=await state(sessions)
            async with sessions() as db,db.begin(): await SourceGate(sessions,owner).report(db,UpstreamError('late',kind='network'))
            after=await state(sessions)
            assert after['paused_until']==before['paused_until'] and after['cooldown_level']==before['cooldown_level']
    asyncio.run(run())


@pytest.mark.parametrize('cancel_after_request',[False,True])
def test_cancellation_during_cooldown_or_request_preserves_budget_and_audit(monkeypatch,cancel_after_request):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id=await queue([('case',scope(),'cancel')]);gate=SourceGate(sessions,owner,interval=0)
            class Client: limiter=gate
            async def fail(client,*args):
                await gate.wait()
                if cancel_after_request:
                    async with sessions() as db,db.begin(): await db.execute(text('UPDATE pcma.scrape_runs SET cancel_requested=TRUE WHERE id=:id'),{'id':run_id})
                raise UpstreamError('503',kind='throttle')
            monkeypatch.setattr(worker,'perform',fail)
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            await worker.execute_task(Client(),task)
            if not cancel_after_request:
                async with sessions() as db,db.begin():
                    await db.execute(text('UPDATE pcma.scrape_runs SET cancel_requested=TRUE WHERE id=:id'),{'id':run_id})
                    await worker.recover(db,owner)
            async with sessions() as db:
                row=(await db.execute(text('SELECT status,attempts,retry_base,source_attempts FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert tuple(row)==('cancelled',1,0 if cancel_after_request else 1,0 if cancel_after_request else 1)
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=:id'),{'id':run_id})).scalar_one()==0
                assert (await db.execute(text('SELECT outcome FROM pcma.scrape_runs WHERE id=:id'),{'id':run_id})).scalar_one()=='cancelled'
    asyncio.run(run())


@pytest.mark.parametrize('bad_history',[['bad-row'],[{'todays_date':'','purpose':'Evidence'}]])
def test_bad_hearings_preserve_existing_case_hearings_documents_and_snapshot(monkeypatch,bad_history):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            cnr='SYN'+uuid4().hex[:12].upper();payload={**scope(),'cnr':cnr}
            old_run=await queue([]);new_run=await queue([('case',payload,cnr)])
            record=normalize(history(),payload)
            async with sessions() as db,db.begin():
                await ingest(db,old_run,record)
                case_id=(await db.execute(text('SELECT id FROM pcma.cases WHERE cnr_number=:cnr'),{'cnr':cnr})).scalar_one()
                await save_documents(db,case_id,[{'date':'2026-10-01','reference':{'filename':'/orders/synthetic.pdf','state_cd':'5','dist_cd':'1','court_code':'1'}}])
                uid=uuid4()
                await db.execute(text("INSERT INTO pcma.users(id,user_id,email,name,password_hash,role) VALUES(:id,:user_id,:email,'Synthetic','disabled','user')"),{'id':uid,'user_id':str(uid),'email':f'{uid}@example.test'})
                await db.execute(text('INSERT INTO pcma.case_pins(user_id,case_id) VALUES(:user,:case)'),{'user':uid,'case':case_id})
                await worker.finalize(db,old_run)
            async def snapshot():
                async with sessions() as db:
                    case_id=(await db.execute(text('SELECT id FROM pcma.cases WHERE cnr_number=:cnr'),{'cnr':cnr})).scalar_one()
                    result={}
                    for table,predicate,params in [('cases','id=:id',{'id':case_id}),('case_hearings','case_id=:id',{'id':case_id}),('case_documents','case_id=:id',{'id':case_id}),('case_pins','case_id=:id',{'id':case_id}),('scrape_run_cases','run_id=:id',{'id':old_run})]:
                        result[table]=[r[0] for r in (await db.execute(text(f'SELECT to_jsonb(t) FROM pcma.{table} t WHERE {predicate} ORDER BY 1'),params)).all()]
                    return result
            before=await snapshot();gate=SourceGate(sessions,owner,interval=0)
            class Client:
                limiter=gate
                async def history(self,scope):
                    await gate.wait()
                    data=copy.deepcopy(history());data['historyOfCaseHearing']=bad_history;return data
            task_id=None
            for _ in range(3):
                await ready(sessions,task_id)
                async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                task_id=task['id'];await worker.execute_task(Client(),task)
            assert await snapshot()==before
            assert (await state(sessions))['failure_streak']==0
            async with sessions() as db:
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=:id'),{'id':new_run})).scalar_one()==0
                assert (await db.execute(text('SELECT error_kind FROM pcma.scrape_tasks WHERE id=:id'),{'id':task_id})).scalar_one()=='validation'
    asyncio.run(run())



def test_outage_deferral_and_recovery_save_exactly_one_case_and_snapshot(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            cnr='SYN'+uuid4().hex[:12].upper();payload={**scope(),'cnr':cnr}
            run_id=await queue([('case',payload,cnr)]);gate=SourceGate(sessions,owner,interval=0)
            class Client:
                limiter=gate
                count=0
                async def history(self,scope):
                    await gate.wait();self.count+=1
                    if self.count==1: raise UpstreamError('Synthetic network error',kind='network')
                    return history()
            client=Client()
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            await worker.execute_task(client,task)
            await ready(sessions,task['id'])
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            # A different in-flight task opens the gate after this claim.
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('503',kind='throttle'))
            await worker.execute_task(client,task)
            assert client.count==1  # Deferral made no source request.
            await ready(sessions,task['id'])
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            await worker.execute_task(client,task)
            await worker.execute_task(client,task)  # A stale completion cannot write twice.
            async with sessions() as db:
                row=(await db.execute(text('SELECT status,attempts,retry_base,source_attempts FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert tuple(row)==('success',3,2,1)
                assert (await db.execute(text('SELECT count(*) FROM pcma.cases WHERE cnr_number=:cnr'),{'cnr':cnr})).scalar_one()==1
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=:id'),{'id':run_id})).scalar_one()==1
                assert (await db.execute(text("SELECT count(*) FROM pcma.scrape_run_events WHERE run_id=:id AND kind='task_retry'"),{'id':run_id})).scalar_one()==1
                transitions=(await db.execute(text("SELECT message FROM pcma.scrape_run_events WHERE run_id=:id AND kind='source_transition'"),{'id':run_id})).scalars().all()
                assert any('recovering' in m for m in transitions)
    asyncio.run(run())


@pytest.mark.parametrize('acts',[None,'1~Approved#2~'])
def test_invalid_court_catalogue_never_creates_partial_search_work(monkeypatch,acts):
    from app.scraper.client import ECourtsClient
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id=await queue([('court',scope(),'court')]);gate=SourceGate(sessions,owner,interval=0)
            client=ECourtsClient(interval=0,limiter=gate)
            async def decoded(*args,**kwargs):
                await gate.wait();return {'actsList':[{'acts':acts}]}
            monkeypatch.setattr(client,'get',decoded)
            task_id=None
            try:
                for _ in range(3):
                    await ready(sessions,task_id)
                    async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                    task_id=task['id'];await worker.execute_task(client,task)
                async with sessions() as db:
                    assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_tasks WHERE run_id=:id'),{'id':run_id})).scalar_one()==1
                    assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_expansions WHERE run_id=:id'),{'id':run_id})).scalar_one()==0
                    row=(await db.execute(text('SELECT status,error_kind,source_attempts FROM pcma.scrape_tasks WHERE id=:id'),{'id':task_id})).one()
                    assert tuple(row)==('failed','validation',0)
                    assert (await db.execute(text('SELECT sum(source_errors) FROM pcma.scrape_metrics WHERE run_id=:id'),{'id':run_id})).scalar_one()==0
                assert (await state(sessions))['paused_until'] is None
            finally: await client.close()
    asyncio.run(run())
