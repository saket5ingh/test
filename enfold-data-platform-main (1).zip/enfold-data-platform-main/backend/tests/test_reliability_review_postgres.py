"""Review reproductions on isolated localhost PostgreSQL; no upstream traffic."""
import asyncio
import os
from uuid import uuid4
import pytest
from sqlalchemy import text
from app.scraper import worker
from app.scraper.client import UpstreamError
from app.scraper.control import SourceGate, OwnershipLost
from test_scraper_performance_postgres import database
from test_source_reliability_postgres import ready, state

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URL not supplied')


@pytest.mark.parametrize('mode',['shutdown','expired','replacement'])
def test_interrupted_claims_preserve_validation_budget_and_fencing(monkeypatch,mode):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id=await queue([('case',{},'interrupted')])
            for attempt in range(1,4):
                async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                async with sessions() as db,db.begin():
                    if mode=='expired':
                        await worker.recover(db,owner,expired_only=True)
                        assert await worker.owns_task(db,task)  # Fresh lease must remain owned.
                        await db.execute(text("UPDATE pcma.scrape_tasks SET lease_until=clock_timestamp()-interval '1 second' WHERE id=:id"),task)
                    if mode=='replacement':
                        owner=uuid4()
                        await db.execute(text('UPDATE pcma.scraper_control SET owner=:owner'),{'owner':owner})
                    await worker.recover(db,owner,expired_only=mode=='expired')
                    await worker.recover(db,owner,expired_only=mode=='expired')  # No double refund.
                    row=(await db.execute(text('SELECT attempts,retry_base,source_attempts,claim_version FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                    assert tuple(row)==(attempt,attempt,0,attempt)
                    assert not await worker.owns_task(db,task)
            async def invalid(*args): raise UpstreamError('Synthetic invalid hearing',kind='validation')
            monkeypatch.setattr(worker,'perform',invalid)
            if mode=='replacement':
                with pytest.raises(OwnershipLost): await worker.execute_task(object(),task)
            for failed in range(1,4):
                await ready(sessions,task['id'])
                async with sessions() as db,db.begin(): current=await worker.claim(db,owner)
                assert current['claim_version']>task['claim_version']
                if mode!='replacement': await worker.execute_task(object(),task)
                await worker.execute_task(object(),current)
                async with sessions() as db:
                    row=(await db.execute(text('SELECT status,attempts,retry_base FROM pcma.scrape_tasks WHERE id=:id'),current)).one()
                    assert tuple(row)==('failed' if failed==3 else 'queued',3+failed,3)
            async with sessions() as db:
                assert (await db.execute(text("SELECT count(*) FROM pcma.scrape_run_events WHERE run_id=:id AND kind='task_recovered'"),{'id':run_id})).scalar_one()==3
    asyncio.run(run())


def test_interrupted_expansion_does_not_refund_already_validated_attempt(monkeypatch):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            await queue([('search',{},'staged')])
            async with sessions() as db,db.begin():
                task=await worker.claim(db,owner)
                await db.execute(text("UPDATE pcma.scrape_tasks SET status='queued',expanding=TRUE WHERE id=:id"),task)
                expanding=await worker.claim(db,owner)
                assert expanding['attempts']==1
                await worker.recover(db,owner)
                row=(await db.execute(text('SELECT attempts,retry_base,expanding FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert tuple(row)==(1,0,True)
    asyncio.run(run())


@pytest.mark.parametrize('kind',['validation','request'])
def test_validation_during_partial_recovery_is_inconclusive_and_retains_level(monkeypatch,kind):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            gate=SourceGate(sessions,owner,interval=0)
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('503',kind='throttle'))
            await ready(sessions);await gate.wait()
            async with sessions() as db,db.begin(): await gate.report(db)
            await ready(sessions);await gate.wait()
            before=await state(sessions)
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('Synthetic content error',kind=kind))
            after=await state(sessions)
            assert after['cooldown_level']==before['cooldown_level']==1
            assert after['failure_streak']==before['failure_streak']==0
            assert before['recovery_successes']==1 and after['recovery_successes']==0
            assert after['paused_until']==before['paused_until'] and after['probe_owner'] is None
            # Another business task can try without claiming the source recovered.
            other=SourceGate(sessions,owner,interval=0);await other.wait()
            async with sessions() as db,db.begin(): await other.report(db)
            assert (await state(sessions))['recovery_successes']==1
    asyncio.run(run())


@pytest.mark.parametrize('kind',['throttle','http','request'])
def test_retry_after_sets_shared_minimum_even_for_inflight_errors(monkeypatch,kind):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            gate=SourceGate(sessions,owner,interval=3)
            async with sessions() as db,db.begin(): await gate.report(db,UpstreamError('503',kind='throttle'))
            await ready(sessions);await gate.wait()
            other=SourceGate(sessions,owner,interval=3)
            async with sessions() as db,db.begin(): await other.report(db,UpstreamError('Synthetic HTTP error',kind=kind,retry_after=3600))
            before=await state(sessions)
            assert 3597<(before['paused_until']-before['observed']).total_seconds()<=3600
            async with sessions() as db,db.begin(): await gate.report(db)
            assert (await state(sessions))['paused_until']==before['paused_until']
            from app.scraper.control import SourceDeferred
            for g in (gate,other,SourceGate(sessions,owner,interval=3)):
                with pytest.raises(SourceDeferred): await g.wait()
            async with sessions() as db,db.begin():
                await other.report(db,UpstreamError('Shorter hint',kind=kind,retry_after=120))
                assert (await db.execute(text('SELECT paused_until FROM pcma.scraper_control'))).scalar_one()==before['paused_until']
    asyncio.run(run())


@pytest.mark.parametrize('kind',['request','throttle'])
def test_retry_after_preserves_task_deadline_and_normal_error_budget(monkeypatch,kind):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            await queue([('case',{},'hint')]);gate=SourceGate(sessions,owner,interval=3)
            class Client: limiter=gate
            async def fail(*args): raise UpstreamError('Synthetic HTTP error',kind=kind,retry_after=3600)
            monkeypatch.setattr(worker,'perform',fail)
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            await worker.execute_task(Client(),task)
            async with sessions() as db:
                row=(await db.execute(text('SELECT retry_base,source_attempts,extract(epoch from available_at-clock_timestamp()) delay FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert row.retry_base==row.source_attempts==(1 if kind=='throttle' else 0)
                assert 3597<row.delay<=3600
    asyncio.run(run())


@pytest.mark.parametrize('kind',['response','rejected'])
def test_documented_indefinite_response_policy_can_block_a_later_run(monkeypatch,kind):
    """Risk reproduction, not a claim that quarantine has been implemented."""
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            old=await queue([('court',{},'persistent')]);later=await queue([('court',{},'later')])
            async with sessions() as db,db.begin():
                await db.execute(text("UPDATE pcma.scrape_runs SET queued_at='1900-01-02' WHERE id=:id"),{'id':later})
            gate=SourceGate(sessions,owner,interval=0)
            class Client: limiter=gate
            async def fail(*args): raise UpstreamError('Synthetic persistent response error',kind=kind)
            monkeypatch.setattr(worker,'perform',fail)
            task_id=None
            for _ in range(10):
                await ready(sessions,task_id)
                async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
                assert task['run_id']==old
                task_id=task['id'];await worker.execute_task(Client(),task)
            await ready(sessions)  # Exclude global pause; old task's delay still blocks the later run.
            async with sessions() as db,db.begin():
                assert await worker.claim(db,owner) is None
                row=(await db.execute(text('SELECT status,attempts,retry_base FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert tuple(row)==('queued',10,10)
                assert (await db.execute(text('SELECT outcome FROM pcma.scrape_runs WHERE id=:id'),{'id':old})).scalar_one()=='running'
                assert (await db.execute(text("SELECT count(*) FROM pcma.scrape_run_events WHERE run_id=:id AND kind='source_retry_alert'"),{'id':old})).scalar_one()==1
    asyncio.run(run())
