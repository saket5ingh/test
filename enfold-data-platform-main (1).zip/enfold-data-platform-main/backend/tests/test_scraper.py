import asyncio
import base64
import json
from datetime import datetime, timezone
from uuid import uuid4
import httpx
import pytest
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7
from pydantic import ValidationError
from app.scraper.client import ECourtsClient, UpstreamError, REQUEST_KEY, RESPONSE_KEY, encrypt, decrypt
from app.scraper.catalog import act_codes
from app.scraper.contracts import RunRequest
from app.scraper.normalize import normalize, change_notice
from app.scraper.export import csv_line
from app.scraper.worker import due_month, perform
from app.config import settings


def scope():
    return {'state': {'code':'5','name':'Bihar'}, 'district':{'code':'1','name':'Gaya'},
            'court':{'code':'1','name':'District Court'}, 'cnr':'TEST123456789012', 'status':'Pending'}


def history():
    return {'type_name':'Criminal', 'reg_no':'100', 'reg_year':'2024', 'date_of_filing':'02-01-2024',
        'dt_regis':'03-01-2024','date_of_decision':'','disp_name':'','date_next_list':'20-10-2026',
        'act':[{'actCodeName':'The Prohibition of Child Marriage Act, 2006','actSectionName':'9,10'}],
        'historyOfCaseHearing':'<table class="tbl-result"><tbody><tr><td>1</td><td>01-08-2026</td><td>Judge</td><td>Evidence</td></tr></tbody></table>'}


def encrypted_response(data):
    iv = b'x' * 16
    padder = PKCS7(128).padder()
    raw = padder.update(json.dumps(data).encode()) + padder.finalize()
    cipher = Cipher(algorithms.AES(RESPONSE_KEY), modes.CBC(iv)).encryptor()
    return iv.hex() + base64.b64encode(cipher.update(raw) + cipher.finalize()).decode()


def test_protocol_encrypts_fresh_iv_and_decrypts_response():
    first, second = encrypt({'a': 1}), encrypt({'a': 1})
    assert first != second
    iv = bytes.fromhex('556A586E32723575' + first[:16])
    decryptor = Cipher(algorithms.AES(REQUEST_KEY), modes.CBC(iv)).decryptor()
    plain = decryptor.update(base64.b64decode(first[17:])) + decryptor.finalize()
    unpadder = PKCS7(128).unpadder()
    assert json.loads(unpadder.update(plain) + unpadder.finalize()) == {'a':1}
    assert decrypt(encrypted_response({'states':[]})) == {'states':[]}


def test_client_lazy_token_and_refresh_after_failure():
    calls=[]
    def respond(request):
        calls.append(request.url.path)
        if request.url.path.endswith('appReleaseWebService.php'):
            return httpx.Response(200,text=encrypted_response({'token':'test-token'}))
        return httpx.Response(405,text='throttled')
    async def run():
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        assert calls == []
        for _ in range(2):
            with pytest.raises(UpstreamError, match='HTTP 405'): await client.states()
        await client.close()
    asyncio.run(run())
    assert len([c for c in calls if c.endswith('appReleaseWebService.php')]) == 2


def test_request_telemetry_excludes_private_payloads_and_exception_text(caplog):
    import logging
    caplog.set_level(logging.INFO,logger='app.scraper.client')
    async def run():
        def failure(request):
            raise httpx.RemoteProtocolError('private-case-value secret-token',request=request)
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(failure))
        with pytest.raises(UpstreamError):
            await client._request('caseHistoryWebService.php',{'cino':'private-case-value'},'secret-token')
        await client.close()
    asyncio.run(run())
    messages='\n'.join(record.getMessage() for record in caplog.records if record.name=='app.scraper.client')
    assert 'endpoint=caseHistoryWebService.php' in messages
    assert 'error_type=RemoteProtocolError' in messages and 'elapsed_s=' in messages
    assert 'private-case-value' not in messages and 'secret-token' not in messages and 'params=' not in messages


def test_missing_payload_is_failure_but_explicit_empty_search_is_valid():
    assert ECourtsClient.rows({'caseNos':[]},'caseNos') == []
    with pytest.raises(UpstreamError): ECourtsClient.rows({},'caseNos')
    with pytest.raises(UpstreamError): ECourtsClient.rows({'states':[]},'states',empty_ok=False)
    with pytest.raises(UpstreamError): ECourtsClient.rows({'caseNos':['unexpected']},'caseNos')


def test_malformed_catalogues_never_become_successful_empty_scans():
    async def run():
        client=ECourtsClient(interval=0)
        async def bad_acts(*args): return {'actsList':[{'acts':'unrecognized format'}]}
        client.get=bad_acts
        with pytest.raises(UpstreamError,match='malformed'): await client.acts(scope())
        async def bad_courts(*args): return {'courtComplex':[{'court_complex_name':'Court','njdg_est_code':''}]}
        client.get=bad_courts
        with pytest.raises(UpstreamError,match='establishment'): await client.courts('5','1')
        await client.close()
    asyncio.run(run())


def test_sections_are_union_searches_for_both_laws_and_statuses():
    class Client:
        async def acts(self,scope): return [('10','Indian Penal Code'),('20','Bharatiya Nyaya Sanhita')]
    criteria=RunRequest(name='Sections',allStates=True,actKeys=['ipc'],sections=['9','10','11'],status='all',requestId=uuid4()).criteria()
    children,notes,_,_=asyncio.run(perform(Client(),{'kind':'court','payload':scope()},criteria))
    assert not notes and len(children)==12
    assert {(payload['act_code'],payload['status'],payload['section']) for _,payload,_ in children} == {
        (code,status,section) for code in ['10','20'] for status in ['Pending','Disposed'] for section in ['9','10','11']}


def test_mapping_selects_both_ipc_bns_and_excludes_rules():
    rows=[('1','Indian Penal Code 1860'),('2','Bharatiya Nyaya Sanhita 2023'),('3','Prohibition of Child Marriage Rules')]
    assert act_codes(rows,'ipc') == ['1','2']
    assert act_codes(rows,'childmarriage') == []
    assert act_codes([('1','Protection of Children'),('2','Protection of Children')],'pocso') == []


def test_normalization_canonicalizes_act_and_omits_sensitive_unused_data():
    raw=history(); raw.update(petitioner='Private name', finalOrder=[{'order_details':'Private order description'}])
    data=normalize(raw,scope())
    assert data['acts'][0] == {'name':'Prohibition of Child Marriage Act','sections':['10','9'],'flag':None}
    assert data['numHearings']==1 and data['hearings'][0]['date']=='2026-08-01'
    assert 'Private name' not in json.dumps(data) and 'secret.pdf' not in json.dumps(data)
    del raw['historyOfCaseHearing']
    with pytest.raises(ValueError,match='Incomplete'): normalize(raw,scope())


def test_json_hearings_use_actual_date_merge_latest_and_discard_private_fields():
    raw=history()
    early={'todays_date':'01-08-2026','nextdate':'20261020','purpose':'Evidence','judge_name':'Private judge','cino':scope()['cnr']}
    latest={'todays_date':'10-09-2026','purpose':'Arguments','case_number':'Private number'}
    raw['historyOfCaseHearing']=[latest,early,early]
    raw['last_business_date']=latest
    data=normalize(raw,scope())
    assert data['hearings']==[{'date':'2026-08-01','purpose':'Evidence'},{'date':'2026-09-10','purpose':'Arguments'}]
    assert data['numHearings']==2 and data['duration']==40 and data['lastPurpose']=='Arguments'
    assert 'Private' not in json.dumps(data)
    raw['historyOfCaseHearing']=[]
    assert normalize(raw,scope())['hearings']==[{'date':'2026-09-10','purpose':'Arguments'}]
    raw['historyOfCaseHearing']=[{'purpose':'Evidence','nextdate':'20261020'}]
    with pytest.raises(ValueError,match='Incomplete JSON hearing'): normalize(raw,scope())
    raw['historyOfCaseHearing']=[{**early,'cino':'DIFFERENTCASE'}]
    with pytest.raises(ValueError,match='Hearing CNR'): normalize(raw,scope())


def test_notice_rules_and_baseline():
    before=normalize(history(),scope())
    assert change_notice(None,before,'now') is None
    assert change_notice(before,before,'now') is None
    assert change_notice(before,{**before,'status':'disposed'},'now')['severity']=='critical'
    assert change_notice(before,{**before,'nextHearing':'2026-10-10'},'now')['severity']=='critical'
    assert change_notice(before,{**before,'nextHearing':'2026-11-10'},'now')['severity']=='info'
    assert change_notice(before,{**before,'hearings':before['hearings']+[{'date':'2026-09-01','purpose':'Arguments'}]},'now')['severity']=='info'


def test_csv_neutralizes_formulas_and_escapes_newlines():
    import csv,io
    values=['=HYPERLINK("bad")',' +1','@cmd','normal','a,b','a\nb',None]
    parsed=next(csv.reader(io.StringIO(csv_line(values))))
    assert parsed == ["'"+values[0],"' +1","'@cmd",'normal','a,b','a\nb','']


@pytest.mark.parametrize('patch',[{'allStates':False},{'allStates':True,'stateCodes':['5']},{'actKeys':['bad'],'allActs':False},{'sections':['']},{'name':' '}])
def test_invalid_run_criteria(patch):
    data={'name':'Scan','allStates':True,'allActs':True,'requestId':str(uuid4()),**patch}
    with pytest.raises(ValidationError): RunRequest(**data)


@pytest.fixture
def monthly_settings(monkeypatch):
    for name, value in {'ENABLED': True, 'WEEK': 3, 'WEEKDAY': 4, 'HOUR': 0, 'MINUTE': 0}.items():
        monkeypatch.setattr(settings, 'SCRAPER_MONTHLY_' + name, value)
    monkeypatch.setattr(settings, 'SCRAPER_TIMEZONE', 'Asia/Kolkata')


def test_schedule_disabled(monthly_settings, monkeypatch):
    monkeypatch.setattr(settings, 'SCRAPER_MONTHLY_ENABLED', False)
    assert due_month(datetime(2026, 10, 31, tzinfo=timezone.utc)) is None


@pytest.mark.parametrize('year,month,day', [
    (2026, 1, 16), (2026, 2, 20), (2026, 3, 20), (2026, 4, 17),
    (2026, 5, 15), (2026, 6, 19), (2026, 7, 17), (2026, 8, 21),
    (2026, 9, 18), (2026, 10, 16), (2026, 11, 20), (2026, 12, 18),
    (2027, 1, 15), (2028, 2, 18),
])
def test_third_friday_midnight_ist_boundary(monthly_settings, year, month, day):
    from datetime import timedelta
    from zoneinfo import ZoneInfo
    boundary = datetime(year, month, day, tzinfo=ZoneInfo('Asia/Kolkata')).astimezone(timezone.utc)
    assert boundary.hour == 18 and boundary.minute == 30
    assert due_month(boundary - timedelta(microseconds=1)) is None
    assert due_month(boundary) == f'{year}-{month:02}'
    assert due_month(boundary + timedelta(days=1)) == f'{year}-{month:02}'


def test_new_month_does_not_backfill_previous_month(monthly_settings):
    assert due_month(datetime(2026, 11, 1, tzinfo=timezone.utc)) is None


def test_configurable_schedule_time_and_timezone(monthly_settings, monkeypatch):
    monkeypatch.setattr(settings, 'SCRAPER_TIMEZONE', 'UTC')
    monkeypatch.setattr(settings, 'SCRAPER_MONTHLY_WEEK', 1)
    monkeypatch.setattr(settings, 'SCRAPER_MONTHLY_WEEKDAY', 4)  # Friday
    monkeypatch.setattr(settings, 'SCRAPER_MONTHLY_HOUR', 9)
    monkeypatch.setattr(settings, 'SCRAPER_MONTHLY_MINUTE', 15)
    assert due_month(datetime(2026, 10, 2, 9, 14, tzinfo=timezone.utc)) is None
    assert due_month(datetime(2026, 10, 2, 9, 15, tzinfo=timezone.utc)) == '2026-10'


@pytest.mark.parametrize('values', [
    {'SCRAPER_MONTHLY_WEEK': 0}, {'SCRAPER_MONTHLY_WEEK': 5},
    {'SCRAPER_MONTHLY_WEEKDAY': -1}, {'SCRAPER_MONTHLY_WEEKDAY': 7},
    {'SCRAPER_MONTHLY_HOUR': 24}, {'SCRAPER_MONTHLY_MINUTE': 60},
    {'SCRAPER_TIMEZONE': 'not/a-timezone'},
])
def test_invalid_schedule_settings(values):
    from app.config import Settings
    with pytest.raises(ValidationError):
        Settings(_env_file=None, DATABASE_URL='postgresql://test', JWT_SECRET='x' * 32, **values)


@pytest.mark.parametrize('instant,expected', [
    ('2026-10-15T18:29:59+00:00', '2026-10-16T00:00:00+05:30'),
    ('2026-10-15T18:30:00+00:00', '2026-11-20T00:00:00+05:30'),
    ('2026-12-31T23:00:00+00:00', '2027-01-15T00:00:00+05:30'),
])
def test_schedule_metadata_next_calendar_slot(monthly_settings, instant, expected):
    from app.scraper.schedule import schedule_info
    info = schedule_info(datetime.fromisoformat(instant))
    assert info['nextRunAt'].isoformat() == expected
    assert info['timezone'] == 'Asia/Kolkata'
    assert info['week'] == 3 and info['weekday'] == 4


def test_disabled_schedule_has_no_next_slot(monthly_settings, monkeypatch):
    from app.scraper.schedule import schedule_info
    monkeypatch.setattr(settings, 'SCRAPER_MONTHLY_ENABLED', False)
    assert schedule_info(datetime(2026, 10, 1, tzinfo=timezone.utc))['nextRunAt'] is None


def test_invalid_search_resets_session_and_never_becomes_empty_success():
    calls=[]
    searches=0
    def respond(request):
        nonlocal searches
        calls.append(request.url.path)
        if request.url.path.endswith('appReleaseWebService.php'):
            return httpx.Response(200,text=encrypted_response({'token':'synthetic-token'}))
        searches += 1
        data={'token':'replacement','no_of_establishments':0} if searches==1 else {'0':{'caseNos':[]}}
        return httpx.Response(200,text=encrypted_response(data))
    async def run():
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        params={**scope(),'act_code':'1','section':''}
        with pytest.raises(UpstreamError,match='Invalid case search') as exc:
            await client.search(params)
        assert exc.value.kind=='response' and client.token is None and client.reset_transport
        assert await client.search(params)==[]
        await client.close()
    asyncio.run(run())
    assert sum(path.endswith('appReleaseWebService.php') for path in calls)==2


def test_shared_limiter_is_used_for_bootstrap_and_search():
    class Limiter:
        calls=0
        async def wait(self): self.calls+=1
    limiter=Limiter()
    def respond(request):
        data={'token':'synthetic'} if request.url.path.endswith('appReleaseWebService.php') else {'0':{'caseNos':[]}}
        return httpx.Response(200,text=encrypted_response(data))
    async def run():
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond),limiter=limiter)
        await client.search({**scope(),'act_code':'1','section':''})
        await client.close()
    asyncio.run(run())
    assert limiter.calls==2


def test_default_monthly_calendar_is_third_friday():
    from app.config import Settings
    configured = Settings(_env_file=None, DATABASE_URL='postgresql://test', JWT_SECRET='x' * 32)
    assert (configured.SCRAPER_MONTHLY_WEEK, configured.SCRAPER_MONTHLY_WEEKDAY) == (3, 4)
    assert (configured.SCRAPER_MONTHLY_HOUR, configured.SCRAPER_MONTHLY_MINUTE) == (0, 0)
    assert configured.SCRAPER_TIMEZONE == 'Asia/Kolkata'
