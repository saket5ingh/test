"""Regression for the live 22 saved / 10 displayed mismatch; synthetic data only."""
import asyncio
import os
from types import SimpleNamespace
from uuid import uuid4
import httpx
import pytest
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from app.main import app
from app.auth import get_current_user
from app.database import get_db
from app.models.case import Case
from app.scraper.catalog import CATALOG


def test_child_marriage_reporting_names_follow_config():
    assert set(CATALOG.canonical_names('childmarriage')) == {
        'Prohibition of Child Marriage Act', 'Child Marriage Restraint Act',
        'Child Marriage Restraint Act, 1929', 'Child Marriage Act'}


@pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'), reason='Isolated PostgreSQL URL not supplied')
def test_analytics_count_family_once_and_keep_law_sections_separate():
    async def run():
        url=os.environ['FFG_TEST_PG_OWNER']
        assert make_url(url).database.endswith('_test')
        engine=create_async_engine(url)
        session=async_sessionmaker(engine,expire_on_commit=False)
        try:
            async with session() as db:
                async def connection(): yield db
                app.dependency_overrides[get_db]=connection
                app.dependency_overrides[get_current_user]=lambda: SimpleNamespace(role='admin')
                async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as client:
                    async def charts():
                        result={}
                        for path in ['by-state','outcomes','by-section','by-year']:
                            response=await client.get('/api/analytics/'+path)
                            assert response.status_code==200,response.text
                            result[path]=response.json()
                        return result
                    before=await charts()
                    state='Synthetic-'+uuid4().hex
                    pcma='Prohibition of Child Marriage Act'; cmra='Child Marriage Restraint Act, 1929'
                    # 10 PCMA + 12 CMRA + 1 generic, with one shared case = 22.
                    laws=[[pcma]]*9+[[cmra]]*11+[[pcma,cmra]]+[['Child Marriage Act']]
                    for names in laws:
                        db.add(Case(cnr_number=uuid4().hex.upper(),state=state,district='Synthetic',
                            status='pending',disposition_raw=None,registration_year=None,
                            acts=[{'name':name,'sections':['9','9']} for name in names]))
                    # An unrelated act must not inflate the child-marriage charts.
                    db.add(Case(cnr_number=uuid4().hex.upper(),state=state,district='Synthetic',
                        status='pending',acts=[{'name':'IPC','sections':['9']}]))
                    await db.flush()
                    after=await charts()
                    assert next(row['value'] for row in after['by-state'] if row['state']==state)==22
                    for path in ['by-state','outcomes','by-year']:
                        assert sum(row['value'] for row in after[path])-sum(row['value'] for row in before[path])==22
                    def count(rows, **fields):
                        return sum(row['value'] for row in rows if all(row[k]==v for k,v in fields.items()))
                    assert count(after['outcomes'],label='Pending')-count(before['outcomes'],label='Pending')==22
                    assert count(after['by-year'],year='Unknown')-count(before['by-year'],year='Unknown')==22
                    for act,expected in [(pcma,10),(cmra,12),('Child Marriage Act',1)]:
                        assert count(after['by-section'],act=act,section='9')-count(before['by-section'],act=act,section='9')==expected
                await db.rollback()
        finally:
            app.dependency_overrides.clear()
            await engine.dispose()
    asyncio.run(run())
