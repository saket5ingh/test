"""Migration 008 rehearsal: legacy retry budgets, rollback and immutable data."""
import asyncio
import os
from pathlib import Path
import re
import subprocess
from uuid import uuid4
import asyncpg
import pytest
from sqlalchemy.engine import make_url

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URL not supplied')
ROOT=Path(__file__).resolve().parents[2]


def test_source_upgrade_credits_only_verified_active_attempts_and_preserves_history(tmp_path):
    async def run():
        source=make_url(os.environ['FFG_TEST_PG_OWNER']).set(drivername='postgresql')
        assert source.host in ('localhost','127.0.0.1') and source.database.endswith('_test')
        name='ffg_source_upgrade_'+uuid4().hex[:10]+'_test'
        url=source.set(database=name)
        admin=await asyncpg.connect(source.render_as_string(hide_password=False))
        await admin.execute(f'CREATE DATABASE "{name}" TEMPLATE template0 ENCODING \'UTF8\'')
        env={**os.environ,'PGHOST':url.host,'PGPORT':str(url.port or 5432),'PGUSER':url.username,'PGPASSWORD':url.password or ''}
        def apply(path,check=True):
            return subprocess.run(['psql','-X','-q','-v','ON_ERROR_STOP=1','--single-transaction','-d',name,'-f',str(path)],env=env,check=check,capture_output=True,text=True)
        db=None
        try:
            sql=(ROOT/'db/migrate.sql').read_text()
            old=sql[:sql.index('SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 8)')]
            path=tmp_path/'before.sql'
            path.write_text(re.sub(r'\\ir (.+)',lambda m:'\\ir '+str(ROOT/'db'/m[1]),old));apply(path)
            db=await asyncpg.connect(url.render_as_string(hide_password=False))
            run_id,uid,cid=uuid4(),uuid4(),uuid4()
            await db.execute("INSERT INTO pcma.users(id,user_id,email,name,password_hash,role) VALUES($1,'source-upgrade','source@example.test','Synthetic','disabled','admin')",uid)
            await db.execute("INSERT INTO pcma.scrape_runs(id,name,outcome,triggered_by,snapshot_version) VALUES($1,'Source upgrade','running',$2,1)",run_id,uid)
            await db.execute("INSERT INTO pcma.cases(id,cnr_number,case_ref,state,district,status) VALUES($1,'SYNTHETIC-SOURCE','SYNTHETIC','Bihar','Gaya','pending')",cid)
            await db.execute('INSERT INTO pcma.case_pins(user_id,case_id) VALUES($1,$2)',uid,cid)
            await db.execute("INSERT INTO pcma.case_hearings(case_id,hearing_date,purpose) VALUES($1,'2026-10-01','Synthetic hearing')",cid)
            await db.execute("INSERT INTO pcma.case_documents(case_id,document_type,label) VALUES($1,'final','Synthetic document')",cid)
            await db.execute("INSERT INTO pcma.scrape_run_cases(run_id,case_id,snapshot,change_kind) VALUES($1,$2,'{\"synthetic\":true}','new')",run_id,cid)
            await db.execute("UPDATE pcma.scraper_control SET owner=$1,probe_owner=$2,probe_until=now()+interval '10 minutes',paused_until=now()+interval '5 minutes',failure_streak=11,cooldown_level=6",uuid4(),uuid4())
            ids={}
            # active task credit is bounded by attempts minus existing retry_base.
            for key,status,attempts,base in [('queued','queued',3,0),('running','running',4,1),('failed','failed',3,0),('success','success',3,0),('cancelled','cancelled',3,0),('validation','queued',2,0),('capped','queued',3,2),('manual-cycle','queued',5,3)]:
                ids[key]=await db.fetchval("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,attempts,retry_base,claim_version,error_message,error_kind)
                    VALUES($1,$2,'case','{"cnr":"SYNTHETIC-SOURCE"}',$3,$4,$5,9,'Legacy error','network') RETURNING id""",run_id,key,status,attempts,base)
            async def event(key,message,at='2026-10-16 02:00+00',kind='task_retry'):
                await db.execute('INSERT INTO pcma.scrape_run_events(run_id,task_id,kind,message,at) VALUES($1,$2,$3,$4,$5::text::timestamptz)',run_id,ids[key],kind,message,at)
            network='caseHistoryWebService.php: network failure (RemoteProtocolError)'
            for key in ('queued','running','failed','success','cancelled','capped'):
                await event(key,network)
                await event(key,'caseHistoryWebService.php: HTTP 503; retry later',kind='task_failed' if key=='failed' else 'task_retry')
            await event('validation','Incomplete JSON hearing entry')
            await event('validation','Unrecognized eCourts response; possible throttling or protocol change')
            await event('manual-cycle',network,'2026-10-16 00:00+00')
            await db.execute("INSERT INTO pcma.scrape_run_events(run_id,kind,message,at) VALUES($1,'retry_requested','Explicit historical retry','2026-10-16 01:00+00')",run_id)
            await event('manual-cycle',network)
            # Representative synthetic volume: 13,000 additional tasks, 820
            # saved cases/snapshots, and a producer with 1,000 staged references.
            # No production dump or source data is used.
            await db.execute("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,attempts)
                SELECT $1,'bulk-'||n,'case',jsonb_build_object('cnr','SYNTHETIC-'||n),
                    CASE WHEN n<=4000 THEN 'success' ELSE 'queued' END,
                    CASE WHEN n<=4000 THEN 1 ELSE 0 END FROM generate_series(1,13000) n""",run_id)
            await db.execute("""WITH inserted AS (
                INSERT INTO pcma.cases(cnr_number,case_ref,state,district,status)
                SELECT 'SYNTHETIC-BULK-'||n,'SYNTHETIC','Bihar','Gaya','pending'
                FROM generate_series(1,820) n RETURNING id
            ) INSERT INTO pcma.scrape_run_cases(run_id,case_id,snapshot,change_kind)
                SELECT $1,id,'{"synthetic":true}','new' FROM inserted""",run_id)
            parent=await db.fetchval("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,attempts,expanding)
                VALUES($1,'checkpoint','search','{}','queued',1,TRUE) RETURNING id""",run_id)
            await db.execute("""INSERT INTO pcma.scrape_expansions(run_id,task_id,chunk,children)
                SELECT $1,$2,0,jsonb_agg(jsonb_build_array('case',jsonb_build_object('cnr','STAGED-'||n),'STAGED-'||n))
                FROM generate_series(1,1000) n""",run_id,parent)
            tables=('users','cases','case_hearings','case_documents','case_pins','scrape_run_cases','scrape_runs','scrape_run_events','scrape_task_counts','scrape_result_counts','scrape_metrics','scrape_run_progress','scrape_expansions')
            async def snapshot():
                return {t:[r['row'] for r in await db.fetch(f'SELECT to_jsonb(t)::text AS row FROM pcma.{t} t ORDER BY 1')] for t in tables}
            before=await snapshot()
            tasks_before={r['task_key']:dict(r) for r in await db.fetch('SELECT * FROM pcma.scrape_tasks')}
            control_before=dict(await db.fetchrow('SELECT * FROM pcma.scraper_control'))
            # Even an ordinary reader blocks ALTER TABLE's ACCESS EXCLUSIVE
            # lock. Fail fast in the rehearsal instead of hanging on a writer.
            await db.execute('BEGIN')
            await db.fetchval('SELECT count(*) FROM pcma.scrape_tasks')
            locked=tmp_path/'locked.sql'
            locked.write_text("SET LOCAL lock_timeout='100ms';\n\\ir "+str(ROOT/'db/migrate.sql')+'\n')
            result=apply(locked,check=False)
            assert result.returncode!=0 and 'lock timeout' in result.stderr
            await db.execute('ROLLBACK')
            assert await snapshot()==before
            # Conversely, uncommitted migration DDL blocks reads and writes.
            await db.execute('BEGIN')
            await db.execute((ROOT/'db/migrations/008_source_reliability.sql').read_text())
            observer=await asyncpg.connect(url.render_as_string(hide_password=False))
            try:
                await observer.execute("SET lock_timeout='100ms'")
                for statement in ('SELECT count(*) FROM pcma.scrape_tasks',
                                  "UPDATE pcma.scrape_tasks SET available_at=available_at WHERE task_key='queued'"):
                    with pytest.raises(asyncpg.LockNotAvailableError): await observer.execute(statement)
            finally:
                await observer.close()
                await db.execute('ROLLBACK')
            assert await snapshot()==before
            failed=tmp_path/'failed.sql';failed.write_text((ROOT/'db/migrations/008_source_reliability.sql').read_text()+'\nSELECT 1/0;\n')
            result=apply(failed,check=False)
            assert result.returncode!=0 and 'division by zero' in result.stderr
            assert await db.fetchval("SELECT count(*) FROM information_schema.columns WHERE table_schema='pcma' AND table_name='scrape_tasks' AND column_name='source_attempts'")==0
            assert {r['task_key']:dict(r) for r in await db.fetch('SELECT * FROM pcma.scrape_tasks')}==tasks_before
            assert await snapshot()==before
            apply(ROOT/'db/migrate.sql')
            rows={r['task_key']:dict(r) for r in await db.fetch('SELECT * FROM pcma.scrape_tasks')}
            expected_bases={'queued':2,'running':3,'failed':0,'success':0,'cancelled':0,'validation':0,'capped':3,'manual-cycle':4}
            for key,row in rows.items():
                for field in ('review_failures','review_sessions','review_started_at','review_last_session','review_required','review_reason','review_at','review_evidence','source_validated_at'): row.pop(field)
                assert row.pop('source_attempts')==(2 if key in ids and key!='validation' else 0)
                assert row['retry_base']==expected_bases.get(key,tasks_before[key]['retry_base'])
                row['retry_base']=tasks_before[key]['retry_base']
                assert row==tasks_before[key]
            control=dict(await db.fetchrow('SELECT * FROM pcma.scraper_control'))
            assert control.pop('recovery_successes')==0 and control==control_before
            assert await snapshot()==before
            after=await db.fetch('SELECT * FROM pcma.scrape_tasks ORDER BY id')
            apply(ROOT/'db/migrate.sql')
            assert await db.fetch('SELECT * FROM pcma.scrape_tasks ORDER BY id')==after
            assert await snapshot()==before
            assert await db.fetchval('SELECT count(*) FROM pcma.schema_migrations WHERE version=8')==1
            # Invalid budget metadata must remain rejected by database constraints.
            with pytest.raises(asyncpg.CheckViolationError):
                await db.execute('UPDATE pcma.scrape_tasks SET source_attempts=-1')
            with pytest.raises(asyncpg.CheckViolationError):
                await db.execute('UPDATE pcma.scraper_control SET recovery_successes=-1')
        finally:
            if db: await db.close()
            await admin.execute(f'DROP DATABASE "{name}"')
            await admin.close()
    asyncio.run(run())
