"""Durable quarantine and actual authenticated API tests; localhost only."""
import asyncio
import json
import os
from uuid import uuid4
import httpx
import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine,async_sessionmaker
from app.scraper import worker
from app.scraper.client import UpstreamError
from app.scraper.control import SourceGate
from app.scraper.store import ingest
from app.scraper.normalize import normalize
from test_scraper import scope,history
from test_scraper_performance_postgres import database

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URL not supplied')


async def prepare(sessions,queue,monkeypatch,task_kind="court"):
    monkeypatch.setattr(worker.settings,'SCRAPER_QUARANTINE_FAILURES',2)
    monkeypatch.setattr(worker.settings,'SCRAPER_QUARANTINE_MIN_SECONDS',60)
    run=await queue([(task_kind,scope(),'bad-court')])
    async with sessions() as db,db.begin():
        task=(await db.execute(text('SELECT * FROM pcma.scrape_tasks WHERE run_id=:id'),{'id':run})).mappings().one()
        await db.execute(text("""UPDATE pcma.scrape_tasks SET review_failures=1,review_sessions=1,
            review_last_session=:session,review_started_at=clock_timestamp()-interval '120 seconds' WHERE id=:id"""),{'id':task['id'],'session':uuid4()})
    return run,dict(task)


async def evidence(sessions,run,mode='valid',task_kind='court'):
    payload=scope();payload['court']={'code':'2','name':'Synthetic other court'}
    if mode=='same_court': payload=scope()
    async with sessions() as db,db.begin():
        return (await db.execute(text("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,attempts,completed_at,source_validated_at)
            VALUES(:run,:key,:kind,CAST(:payload AS jsonb),'success',1,clock_timestamp(),
              clock_timestamp()-make_interval(secs=>:age)) RETURNING id"""),
            {'run':run,'key':str(uuid4()),'kind':'search' if mode=='wrong_endpoint' else task_kind,
             'payload':json.dumps(payload),'age':1000 if mode=='stale' else 180 if mode=='before_cycle' else 0})).scalar_one()


async def fail(sessions,owner,monkeypatch,*,kind='response',session=None,endpoint='actWebService.php',retry_after=None):
    async def perform(*args): raise UpstreamError('Synthetic invalid court envelope',kind=kind,
        endpoint=endpoint,session_generation=session or str(uuid4()),retry_after=retry_after)
    monkeypatch.setattr(worker,'perform',perform)
    gate=SourceGate(sessions,owner,interval=0)
    class Client: limiter=gate
    async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
    await worker.execute_task(Client(),task)
    return task


@pytest.mark.parametrize('kind',['response','rejected'])
@pytest.mark.parametrize('task_kind,endpoint',[('court','actWebService.php'),('search','searchByActWebService.php'),('case','caseHistoryWebService.php')])
def test_qualified_quarantine_is_failed_coverage_and_unblocks_later_work(monkeypatch,kind,task_kind,endpoint):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id,original=await prepare(sessions,queue,monkeypatch,task_kind)
            successful=await evidence(sessions,run_id,task_kind=task_kind)
            async with sessions() as db,db.begin():
                record=normalize(history(),{**scope(),'cnr':'SYN'+uuid4().hex[:12].upper()})
                await ingest(db,run_id,record)
            later=await queue([('discover',{},'later')])
            async with sessions() as db,db.begin(): await db.execute(text("UPDATE pcma.scrape_runs SET queued_at='1900-01-02' WHERE id=:id"),{'id':later})
            task=await fail(sessions,owner,monkeypatch,kind=kind,endpoint=endpoint)
            async with sessions() as db,db.begin():
                row=(await db.execute(text('SELECT * FROM pcma.scrape_tasks WHERE id=:id'),task)).mappings().one()
                assert row['id']==original['id'] and row['status']=='failed' and row['review_required']
                assert row['review_failures']==2 and row['review_sessions']==2 and row['source_attempts']==1
                assert row['review_evidence']['successfulTask']==str(successful)
                assert (await db.execute(text('SELECT outcome FROM pcma.scrape_runs WHERE id=:id'),{'id':run_id})).scalar_one()=='partial'
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=:id'),{'id':run_id})).scalar_one()==1
                assert (await db.execute(text("SELECT count(*) FROM pcma.scrape_run_events WHERE task_id=:id AND kind='operator_review_required'"),task)).scalar_one()==1
                assert (await worker.claim(db,owner))['run_id']==later
                # Scheduling a later month is no longer blocked by this old run.
                monkeypatch.setattr(worker,'due_month',lambda now:'2099-'+uuid4().hex[:6])
                await worker.schedule(db,None)
                assert (await db.execute(text("SELECT count(*) FROM pcma.scrape_runs WHERE trigger_type='scheduled' AND outcome='queued'"))).scalar_one()>=1
                await db.execute(text("UPDATE pcma.scrape_runs SET outcome='cancelled',cancel_requested=TRUE WHERE schedule_key LIKE '2099-%'"))
    asyncio.run(run())


@pytest.mark.parametrize('mode',['no_evidence','same_court','wrong_endpoint','stale','before_cycle','young',
                                  'same_session','bootstrap','network','http','throttle','recovering','retry_after','checkpoint_only','legacy_success','other_run','missing_court','unknown_session'])
def test_unsafe_or_insufficient_evidence_never_quarantines(monkeypatch,mode):
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id,original=await prepare(sessions,queue,monkeypatch)
            if mode!='no_evidence':
                success_id=await evidence(sessions,await queue([]) if mode=='other_run' else run_id,mode)
                if mode in ('checkpoint_only','legacy_success'):
                    async with sessions() as db,db.begin():
                        await db.execute(text('UPDATE pcma.scrape_tasks SET source_validated_at=:at WHERE id=:id'),{'id':success_id,'at':None})
                if mode=='other_run':
                    async with sessions() as db,db.begin():
                        await db.execute(text("UPDATE pcma.scrape_runs SET outcome='success' WHERE id=(SELECT run_id FROM pcma.scrape_tasks WHERE id=:id)"),{'id':success_id})
            kwargs={}
            async with sessions() as db,db.begin():
                if mode=='checkpoint_only': await db.execute(text("UPDATE pcma.scrape_tasks SET source_validated_at=clock_timestamp()-interval '2 hours' WHERE id=:id"),{'id':success_id})
                if mode=='missing_court': await db.execute(text("UPDATE pcma.scrape_tasks SET payload=payload-'court' WHERE id=:id"),original)
                if mode=='unknown_session': kwargs['session']='not-a-session'
                if mode=='young': await db.execute(text('UPDATE pcma.scrape_tasks SET review_started_at=clock_timestamp() WHERE id=:id'),original)
                if mode=='same_session': kwargs['session']=str((await db.execute(text('SELECT review_last_session FROM pcma.scrape_tasks WHERE id=:id'),original)).scalar_one())
                if mode=='recovering': await db.execute(text("UPDATE pcma.scraper_control SET paused_until=clock_timestamp()-interval '1 second',recovery_successes=1"))
            if mode=='bootstrap': kwargs['endpoint']='appReleaseWebService.php'
            if mode in ('network','http','throttle'): kwargs['kind']=mode
            if mode=='retry_after': kwargs['retry_after']=3600
            task=await fail(sessions,owner,monkeypatch,**kwargs)
            async with sessions() as db:
                row=(await db.execute(text('SELECT status,review_required,review_failures FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert row.status=='queued' and not row.review_required
                if mode in ('network','http','throttle','bootstrap','retry_after'): assert row.review_failures==1
    asyncio.run(run())


def test_authenticated_review_retry_is_selected_audited_and_preserves_snapshots(monkeypatch):
    from app.main import app
    from app.database import get_db
    from app.auth import create_access_token
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id,original=await prepare(sessions,queue,monkeypatch,'case');await evidence(sessions,run_id,task_kind='case')
            record=normalize(history(),{**scope(),'cnr':'SYN'+uuid4().hex[:12].upper()})
            async with sessions() as db,db.begin(): await ingest(db,run_id,record)
            task=await fail(sessions,owner,monkeypatch,endpoint='caseHistoryWebService.php')
            ids={role:uuid4() for role in ('admin','user')}
            async with sessions() as db,db.begin():
                for role,uid in ids.items():
                    await db.execute(text("INSERT INTO pcma.users(id,user_id,email,name,password_hash,role) VALUES(:id,:uid,:email,'Synthetic','disabled',:role)"),{'id':uid,'uid':str(uid),'email':f'{uid}@example.test','role':role})
                before=(await db.execute(text('SELECT snapshot FROM pcma.scrape_run_cases WHERE run_id=:id'),{'id':run_id})).scalar_one()
            api_engine=create_async_engine(os.environ.get('FFG_TEST_PG_API',os.environ['FFG_TEST_PG_OWNER']))
            api=async_sessionmaker(api_engine)
            async def connection():
                async with api() as db: yield db
            app.dependency_overrides[get_db]=connection
            headers={role:{'Authorization':'Bearer '+create_access_token({'sub':str(uid),'ver':0})} for role,uid in ids.items()}
            path=f'/api/scrapes/runs/{run_id}/tasks/{task["id"]}/review-retry'
            try:
                async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as client:
                    assert (await client.post(path,json={'reason':'Reviewed source'},headers=headers['user'])).status_code==403
                    assert (await client.post(path,json={'reason':'Reviewed source'})).status_code==401
                    assert (await client.get(f'/api/scrapes/runs/{run_id}/tasks?status=quarantined',headers=headers['user'])).status_code==403
                    listed=await client.get(f'/api/scrapes/runs/{run_id}/tasks?status=quarantined',headers=headers['admin'])
                    assert listed.status_code==200 and listed.json()['total']==1
                    detail=(await client.get(f'/api/scrapes/runs/{run_id}',headers=headers['admin'])).json()
                    assert detail['quarantined']==1 and detail['coverageIncomplete']
                    assert (await client.post(f'/api/scrapes/runs/{run_id}/retry',headers=headers['admin'])).status_code==409
                    assert (await client.post(path,json={'reason':'  '},headers=headers['admin'])).status_code==422
                    wrong=path.replace(str(run_id),str(uuid4()))
                    assert (await client.post(wrong,json={'reason':'Reviewed source'},headers=headers['admin'])).status_code==404
                    assert (await client.post(path,json={'reason':'Verified court format; retry selected task'},headers=headers['admin'])).status_code==202
                    assert (await client.post(path,json={'reason':'Duplicate retry'},headers=headers['admin'])).status_code==409
                async with sessions() as db:
                    row=(await db.execute(text('SELECT * FROM pcma.scrape_tasks WHERE id=:id'),task)).mappings().one()
                    assert row['status']=='queued' and not row['review_required']
                    assert row['attempts']==task['attempts'] and row['retry_base']==task['attempts'] and row['source_attempts']==1
                    assert row['review_failures']==row['review_sessions']==0 and row['review_started_at'] is None
                    audit=(await db.execute(text("SELECT actor_id,message FROM pcma.scrape_run_events WHERE task_id=:id AND kind='operator_review_retry'"),task)).one()
                    assert audit.actor_id==ids['admin'] and json.loads(audit.message)['previousEvidence']
                # Replay after review uses the same CNR and preserves the old snapshot.
                async def success(client,current,criteria): return [],[],None,record
                monkeypatch.setattr(worker,'perform',success)
                async with sessions() as db,db.begin(): current=await worker.claim(db,owner)
                await worker.execute_task(object(),current)
                async with sessions() as db:
                    assert (await db.execute(text('SELECT snapshot FROM pcma.scrape_run_cases WHERE run_id=:id'),{'id':run_id})).scalar_one()==before
                    assert (await db.execute(text('SELECT count(*) FROM pcma.cases WHERE cnr_number=:cnr'),record)).scalar_one()==1
                    assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE run_id=:id'),{'id':run_id})).scalar_one()==1
            finally:
                app.dependency_overrides.clear();await api_engine.dispose()
    asyncio.run(run())


def test_bulk_retry_cancellation_and_concurrent_review_do_not_bypass_quarantine(monkeypatch):
    from app.main import app
    from app.database import get_db
    from app.auth import create_access_token
    from app.scraper.store import enqueue_many
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id,original=await prepare(sessions,queue,monkeypatch);await evidence(sessions,run_id)
            task=await fail(sessions,owner,monkeypatch)
            uid=uuid4()
            async with sessions() as db,db.begin():
                await db.execute(text("INSERT INTO pcma.users(id,user_id,email,name,password_hash,role) VALUES(:id,:uid,:email,'Synthetic','disabled','admin')"),{'id':uid,'uid':str(uid),'email':f'{uid}@example.test'})
                await enqueue_many(db,run_id,[('case',scope(),'ordinary')])
                ordinary=(await db.execute(text("SELECT id FROM pcma.scrape_tasks WHERE run_id=:id AND kind='case'"),{'id':run_id})).scalar_one()
                await db.execute(text("UPDATE pcma.scrape_tasks SET status='failed',attempts=3 WHERE id=:id"),{'id':ordinary})
            api_engine=create_async_engine(os.environ.get('FFG_TEST_PG_API',os.environ['FFG_TEST_PG_OWNER']))
            api=async_sessionmaker(api_engine)
            async def connection():
                async with api() as db: yield db
            app.dependency_overrides[get_db]=connection
            headers={'Authorization':'Bearer '+create_access_token({'sub':str(uid),'ver':0})}
            path=f'/api/scrapes/runs/{run_id}'
            review=path+f'/tasks/{task["id"]}/review-retry'
            try:
                async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test',headers=headers) as client:
                    assert (await client.post(path+'/retry')).status_code==202
                    async with sessions() as db,db.begin():
                        row=(await db.execute(text('SELECT status,review_required FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                        assert row.status=='failed' and row.review_required
                        running=await worker.claim(db,owner)
                        assert running['id']==ordinary
                    assert (await client.post(path+'/cancel')).status_code==202
                    assert (await client.post(review,json={'reason':'Reviewed during cancellation'})).status_code==409
                    # A late response after cancellation is discarded, including its review evidence.
                    await worker.execute_task(object(),running)
                    async with sessions() as db:
                        cancelled=(await db.execute(text('SELECT status,review_required FROM pcma.scrape_tasks WHERE id=:id'),running)).one()
                        assert cancelled.status=='cancelled' and not cancelled.review_required
                    responses=await asyncio.gather(*[client.post(review,json={'reason':'Reviewed court response'}) for _ in range(2)])
                    assert sorted(r.status_code for r in responses)==[202,409]
                    async with sessions() as db:
                        assert (await db.execute(text("SELECT count(*) FROM pcma.scrape_run_events WHERE task_id=:id AND kind='operator_review_retry'"),task)).scalar_one()==1
                        assert (await db.execute(text('SELECT status FROM pcma.scrape_tasks WHERE id=:id'),running)).scalar_one()=='cancelled'
                        assert (await db.execute(text('SELECT attempts FROM pcma.scrape_tasks WHERE id=:id'),task)).scalar_one()==task['attempts']
                        assert not (await db.execute(text('SELECT cancel_requested FROM pcma.scrape_runs WHERE id=:id'),{'id':run_id})).scalar_one()
            finally:
                app.dependency_overrides.clear();await api_engine.dispose()
    asyncio.run(run())


def test_real_worker_role_can_quarantine_and_api_cannot_rewrite_evidence(monkeypatch):
    from sqlalchemy.exc import DBAPIError
    if not os.getenv('FFG_TEST_PG_WORKER') or not os.getenv('FFG_TEST_PG_API'): pytest.skip('Worker and API role URLs required')
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id,original=await prepare(sessions,queue,monkeypatch);await evidence(sessions,run_id)
            engine=create_async_engine(os.environ['FFG_TEST_PG_WORKER'])
            api_engine=create_async_engine(os.environ['FFG_TEST_PG_API'])
            try:
                monkeypatch.setattr(worker,'async_session_maker',async_sessionmaker(engine))
                task=await fail(sessions,owner,monkeypatch)
                async with sessions() as db:
                    assert (await db.execute(text('SELECT review_required FROM pcma.scrape_tasks WHERE id=:id'),task)).scalar_one()
                    assert (await db.execute(text('SELECT outcome FROM pcma.scrape_runs WHERE id=:id'),{'id':run_id})).scalar_one()=='failed'
                async with api_engine.connect() as db:
                    with pytest.raises(DBAPIError,match='permission denied'):
                        await db.execute(text("UPDATE pcma.scrape_tasks SET review_evidence='{}' WHERE id=:id"),task)
                    await db.rollback()
                    with pytest.raises(DBAPIError,match='permission denied'):
                        await db.execute(text('DELETE FROM pcma.scrape_tasks WHERE id=:id'),task)
            finally: await engine.dispose();await api_engine.dispose()
    asyncio.run(run())


@pytest.mark.parametrize('mode',['cancelled','expired','replaced','interrupted'])
def test_uncommitted_or_stale_failure_cannot_create_review_evidence(monkeypatch,mode):
    from app.scraper.control import OwnershipLost
    async def run():
        async with database(monkeypatch) as (sessions,queue,owner,_):
            run_id,original=await prepare(sessions,queue,monkeypatch);await evidence(sessions,run_id)
            async with sessions() as db,db.begin(): task=await worker.claim(db,owner)
            async def perform(*args):
                if mode=='interrupted': raise asyncio.CancelledError()
                raise UpstreamError('Synthetic invalid envelope',kind='response',endpoint='actWebService.php',session_generation=str(uuid4()))
            monkeypatch.setattr(worker,'perform',perform)
            async with sessions() as db,db.begin():
                if mode=='cancelled': await db.execute(text('UPDATE pcma.scrape_runs SET cancel_requested=TRUE WHERE id=:id'),{'id':run_id})
                if mode=='expired': await db.execute(text("UPDATE pcma.scrape_tasks SET lease_until=clock_timestamp()-interval '1 second' WHERE id=:id"),task)
                if mode=='replaced': await db.execute(text('UPDATE pcma.scraper_control SET owner=:owner'),{'owner':uuid4()})
            if mode=='interrupted':
                with pytest.raises(asyncio.CancelledError): await worker.execute_task(object(),task)
            elif mode=='replaced':
                with pytest.raises(OwnershipLost): await worker.execute_task(object(),task)
            else: await worker.execute_task(object(),task)
            async with sessions() as db:
                row=(await db.execute(text('SELECT review_failures,review_required FROM pcma.scrape_tasks WHERE id=:id'),task)).one()
                assert row.review_failures==1 and not row.review_required
                assert (await db.execute(text("SELECT count(*) FROM pcma.scrape_run_events WHERE task_id=:id AND kind='operator_review_required'"),task)).scalar_one()==0
    asyncio.run(run())
