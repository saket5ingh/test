"""Protocol review against synthetic responses and trace callbacks only."""
import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
import httpx
import pytest
from app.scraper.client import ECourtsClient, UpstreamError, retry_after_seconds
from app.scraper.diagnostics import RequestDiagnostics
from test_scraper import encrypted_response


@pytest.mark.parametrize('status',[401,403])
def test_auth_status_refreshes_on_next_durable_attempt_without_hidden_retry(status):
    async def run():
        calls=[]
        def respond(request):
            calls.append(request.url.path)
            if 'appRelease' in request.url.path: return httpx.Response(200,text=encrypted_response({'token':'synthetic-token'}))
            return httpx.Response(status)
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        try:
            for attempt in range(2):
                with pytest.raises(UpstreamError) as e: await client.states()
                assert e.value.kind=='request' and not e.value.source_failure
                assert len(calls)==2*(attempt+1)
                assert client.token is None and client.reset_transport
        finally: await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('header,expected',[
    ('3600',3600),('0',0),(' Fri, 16 Oct 2026 06:00:00 GMT ',3600),
    ('Fri, 16 Oct 2026 04:00:00 GMT',0),('-5',None),('1.5',None),
    ('garbage PRIVATE',None),('9'*129,None),('9'*12,None),
    (None,None),('Fri, 16 Oct 2026 06:00:00',None),
])
def test_retry_after_parser(header,expected):
    now=datetime(2026,10,16,5,tzinfo=timezone.utc)
    assert retry_after_seconds(header,now)==expected


@pytest.mark.parametrize('status',[429,503,401,403])
def test_http_errors_carry_retry_after_without_an_extra_request(status):
    async def run():
        calls=[]
        def respond(request):
            calls.append(request)
            return httpx.Response(status,headers={'Retry-After':'3600'})
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        try:
            with pytest.raises(UpstreamError) as e: await client.states()
            assert e.value.retry_after==3600 and len(calls)==1
        finally: await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('failure_phase',['connection.connect_tcp','connection.start_tls'])
def test_failed_connection_attempt_never_becomes_reuse_candidate(failure_phase):
    async def run():
        client=SimpleNamespace(context={},client_generation='synthetic',session_generation=None,
                               last_connection={'id':'previous','created':1,'finished':2})
        d=RequestDiagnostics(client)
        await d.trace('connection.connect_tcp.started',{'host':'PRIVATE'})
        assert d.data['connection_id'] is None and not d.data['tcp_established']
        assert d.data['connection_evidence']=='tcp_attempt'
        if failure_phase=='connection.start_tls':
            await d.trace('connection.connect_tcp.complete',{})
            assert d.data['tcp_established'] and d.data['connection_evidence']=='tcp_connected'
            await d.trace('connection.start_tls.started',{})
        await d.trace(failure_phase+'.failed',{'exception':httpx.ConnectError('PRIVATE')})
        d.finish(httpx.ConnectError('PRIVATE'))
        assert client.last_connection is None
        later=RequestDiagnostics(client)
        await later.trace('http11.send_request_headers.started',{})
        assert later.data['connection_id'] is None and later.data['connection_evidence']=='unknown'
        assert 'PRIVATE' not in str(d.data)
    asyncio.run(run())


def test_retry_after_survives_an_incomplete_error_response_body():
    async def run():
        class BrokenBody(httpx.AsyncByteStream):
            async def __aiter__(self):
                yield b'PRIVATE'
                raise httpx.RemoteProtocolError('incomplete message body PRIVATE')
        def respond(request):
            return httpx.Response(503,headers={'Retry-After':'3600'},stream=BrokenBody())
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        try:
            with pytest.raises(UpstreamError) as error: await client.states()
            assert error.value.kind=='network' and error.value.retry_after==3600
            assert 'PRIVATE' not in str(error.value)
        finally: await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('mode',['rejected','decoded_shape','encoding','bootstrap'])
def test_quarantine_error_provenance_survives_session_invalidation(mode):
    from uuid import UUID
    from test_scraper import scope
    async def run():
        calls=[]
        def respond(request):
            calls.append(request.url.path)
            if 'appRelease' in request.url.path:
                return httpx.Response(200,text=encrypted_response({'status':'N'} if mode=='bootstrap' else {'token':'PRIVATE-token'}))
            if mode=='encoding': return httpx.Response(200,text='not encrypted PRIVATE')
            return httpx.Response(200,text=encrypted_response({'status':'N'} if mode=='rejected' else {'unexpected':True}))
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        generations=[]
        try:
            for _ in range(2):
                with pytest.raises(UpstreamError) as error: await client.history(scope())
                e=error.value
                assert e.kind in ('response','rejected')
                assert 'PRIVATE' not in str(e)
                assert client.token is None and client.session_generation is None
                if mode=='bootstrap':
                    assert e.endpoint=='appReleaseWebService.php' and e.session_generation is None
                else:
                    assert e.endpoint=='caseHistoryWebService.php'
                    generations.append(UUID(e.session_generation))
            assert len(calls)==(2 if mode=='bootstrap' else 4)
            if generations: assert generations[0]!=generations[1]
        finally: await client.close()
    asyncio.run(run())
