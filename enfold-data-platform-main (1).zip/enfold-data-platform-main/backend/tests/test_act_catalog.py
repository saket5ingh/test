"""Regression examples are independent of the editable alias configuration."""
import asyncio
import copy
import json
from uuid import uuid4
import pytest
from pydantic import ValidationError
from app.scraper.catalog import CATALOG, CONFIG_PATH, AliasConfig, Catalog, act_codes, canonical_act, load_config
from app.scraper.contracts import RunRequest
from app.scraper.worker import perform


@pytest.mark.parametrize('key,title', [
    ('pocso','The Protection of Children from Sexual Offences Act, 2012'),
    ('pocso','POCSO Act2012'),
    ('pocso','ＰＯＣＳＯ Act 2012'),
    ('childmarriage','THE PROHIBITION OF CHILD MARRIAGE ACT, 2006'),
    ('childmarriage','Child Marriage Restraint Act 1929'),
    ('childmarriage','Child Marriage Act'),
    ('childmarriage','Prohibition of Child Marraige Act'),
    ('it','The Information Technology Act2000'),
    ('jj','Juvenile Justice Act'),
    ('jj','Juvenile Justice (Care and Protection of Children) Act, 2000'),
    ('jj','Juvenile Justice (Care &amp; Protection of Children) Act, 2015'),
    ('ita','Immoral Traffic Act'),
    ('ita','The Immoral Traffic (Prevention) Act, 1956'),
    ('ipc','INDIAN PENAL CODE, 1860'),
    ('ipc','Bharatiya Nyaya Sanhita2023'),
    ('scst','Scheduled Castes and the Scheduled Tribes (Prevention of Atrocities) Act, 1989'),
    ('scst','Scheduled Castes and Scheduled Tribes (Prevention of Atrocities) Act'),
    ('scst','SC/ST (Prevention of Atrocities) Act'),
    ('scst','Prevention of Atrocities SC ST Act'),
    ('scst','Prevention of Atrocities (S.C/S.T Act )'),
    ('scst','(S.C/S.T Act ) Prevention of Atrocities'),
    ('dowry','The Dowry Prohibition Act, 1961'),
])
def test_approved_names_and_typography(key,title):
    assert act_codes([('court-local-code',title)],key)==['court-local-code']
    for other in CATALOG.config.options:
        if other!=key: assert act_codes([('court-local-code',title)],other)==[]


@pytest.mark.parametrize('key,title', [
    ('pocso','POSCO'), ('pocso','POCSO'), ('pocso','Protection of Children'),
    ('pocso','Protection of Children from Sexual Offences Rules'),
    ('pocso','Protection of Children from Sexual Offences Act 2000'),
    ('childmarriage','Prevention of Child Marriage Act'), ('childmarriage','PCMA'),
    ('childmarriage','Prohibition of Child Marriage Act 2007'),
    ('childmarriage','Child Marriage Act 2006'),
    ('childmarriage','Child Marriage Restraint Act 2006'),
    ('childmarriage','Prohibition of Child Marraige Act 1929'),
    ('childmarriage','Prohibition of Child Marriage Amendment Act'),
    ('it','IT Act'), ('it','Information Technology Amendment Act 2008'),
    ('jj','Juvenile Justice Act 1986'), ('jj','Children Act'), ('jj','JJ Act'),
    ('ita','ITPA Act'), ('ita','Suppression of Immoral Traffic in Women and Girls Act'),
    ('ipc','IPC'), ('ipc','BNS'), ('ipc','Bharatiya Nagarik Suraksha Sanhita'),
    ('ipc','Indian Penal Code 2023'), ('ipc','Bharatiya Nyaya Sanhita 1860'),
    ('scst','POA Act'), ('scst','Scheduled Castes and Scheduled Tribes Orders Amendment Act'),
    ('dowry','DP Act'), ('dowry','Dowry Prohibition Rules'),
    # Public act labels observed in Gaya's live catalogue on 2026-10-10.
    # These require a separate alias decision, not silent scope expansion.
    ('pocso','pocso'), ('it','IT Act 2000'), ('scst','SCST Act'),
    ('dowry','Dowry Prohibition DP Act'), ('dowry','Prevention Of Dowry Act'),
])
def test_unapproved_names_years_and_separate_instruments_are_not_collected(key,title):
    assert act_codes([('1',title)],key)==[]


def test_all_court_codes_matched_and_original_labels_audited():
    rows=[('1','The Prohibition of Child Marriage Act, 2006'),('2','PROHIBITION OF CHILD MARRIAGE ACT'),
          ('1','The Prohibition of Child Marriage Act, 2006'),('3',None)]
    matches,review=CATALOG.resolve(rows,'childmarriage')
    assert not review
    assert [m['code'] for m in matches]==['1','2']
    assert matches[0]['sourceLabels']==[rows[0][1]]
    assert matches[0]['law']=='pcma' and matches[0]['year']==2006
    assert matches[0]['config']==CATALOG.identity
    assert act_codes([('99',rows[0][1])],'childmarriage')==['99']


def test_law_identities_and_explicit_jj_years_remain_distinct():
    assert canonical_act('Juvenile Justice (Care and Protection of Children) Act, 2000')=='Juvenile Justice Act, 2000'
    assert canonical_act('Juvenile Justice (Care and Protection of Children) Act, 2015')=='Juvenile Justice Act, 2015'
    assert canonical_act('Juvenile Justice Act')=='Juvenile Justice Act'
    assert canonical_act('Indian Penal Code 1860')=='Indian Penal Code, 1860'
    assert canonical_act('Bharatiya Nyaya Sanhita 2023')=='Bharatiya Nyaya Sanhita, 2023'
    assert canonical_act('Child Marriage Restraint Act 1929')=='Child Marriage Restraint Act, 1929'
    assert canonical_act('Child Marriage Act')=='Child Marriage Act'
    assert canonical_act('Prohibition of Child Marraige Act')=='Prohibition of Child Marriage Act'


def test_worker_records_unapproved_names_and_queues_only_approved_codes():
    class Client:
        async def acts(self,scope):
            return [('10','Child Marriage Act'),('20','Prohibition of Child Marriage Act 2006'),
                    ('30','Child Marriage Restraint Act 1929'), ('40','Prohibition of Child Marraige Act'),
                    ('50','Prevention of Child Marriage Act')]
    scope={'state':{'code':'1'},'district':{'code':'2'},'court':{'code':'3'}}
    criteria=RunRequest(name='Mapping',allStates=True,actKeys=['childmarriage'],status='all',requestId=uuid4()).criteria()
    children,notes,_,_=asyncio.run(perform(Client(),{'kind':'court','payload':scope},criteria))
    assert len(children)==8 and {c[1]['act_code'] for c in children}=={'10','20','30','40'}
    assert {c[1]['status'] for c in children}=={'Pending','Disposed'}
    assert {c[1]['act_mapping']['law'] for c in children}=={'pcma','cmra','childmarriage_unspecified'}
    assert {json.loads(note)['label'] for kind,note in notes if kind=='act_mapping_review'}=={'Prevention of Child Marriage Act'}
    for _,payload,identity in children:
        assert len(payload['act_mapping']['sourceLabels'])==1
        assert payload['act_mapping']['config']==CATALOG.identity
        assert 'act_mapping' not in json.loads(identity)
        assert json.loads(identity)['act_code']==payload['act_code']


def test_invalid_config_is_rejected_and_duplicate_json_keys_are_not_silent(tmp_path):
    bad=tmp_path/'aliases.json'
    bad.write_text('{"version":"one","version":"two"}')
    with pytest.raises(ValueError,match='Duplicate JSON key'): load_config(bad)
    data=json.loads(CONFIG_PATH.read_text())
    data['options']['pocso']['laws'][0]['aliases'].append('Dowry Prohibition Act')
    with pytest.raises(ValidationError,match='Conflicting alias'): AliasConfig.model_validate(data)


@pytest.mark.parametrize('mutation', ['unknown_key','unknown_field','empty_alias','year_in_alias','bad_year','excluded_alias','duplicate_alias','missing_option'])
def test_configuration_errors_fail_before_any_scrape(mutation):
    data=json.loads(CONFIG_PATH.read_text())
    law=data['options']['pocso']['laws'][0]
    if mutation=='unknown_key': data['options']['pcma']=data['options'].pop('childmarriage')
    if mutation=='unknown_field': law['aliasess']=['Misspelling']
    if mutation=='empty_alias': law['aliases']=[' ']
    if mutation=='year_in_alias': law['aliases']=['POCSO Act 2012']
    if mutation=='bad_year': law['years']=['2012']
    if mutation=='excluded_alias': law['aliases']=['Protection of Children Rules']
    if mutation=='duplicate_alias': law['aliases']+=['THE POCSO ACT']
    if mutation=='missing_option': del data['options']['it']
    with pytest.raises(ValidationError): AliasConfig.model_validate(data)


def test_editing_config_alone_can_add_an_alias_and_changes_audit_hash():
    data=copy.deepcopy(CATALOG.config.model_dump())
    # Synthetic isolated example, deliberately not installed in the real config.
    data['version']='2026-10-10.2'
    data['options']['childmarriage']['laws'][0]['aliases'].append('Synthetic verified child marriage title')
    changed=Catalog(AliasConfig.model_validate(data))
    matches,_=changed.resolve([('7','Synthetic verified child marriage title')],'childmarriage')
    assert matches[0]['law']=='pcma'
    assert changed.hash!=CATALOG.hash
    assert act_codes([('7','Synthetic verified child marriage title')],'childmarriage')==[]
