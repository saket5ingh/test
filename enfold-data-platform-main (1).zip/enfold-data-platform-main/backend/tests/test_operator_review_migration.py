"""Migration 009 rehearsal against synthetic schema-008 data, never production."""
import asyncio
import os
from pathlib import Path
import re
import subprocess
from uuid import uuid4
import asyncpg
import pytest
from sqlalchemy.engine import make_url

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URL not supplied')
ROOT=Path(__file__).resolve().parents[2]
FIELDS=('review_failures','review_sessions','review_started_at','review_last_session',
        'review_required','review_reason','review_at','review_evidence','source_validated_at')


def test_operator_review_upgrade_rollback_locks_preservation_and_rerun(tmp_path):
    async def run():
        source=make_url(os.environ['FFG_TEST_PG_OWNER']).set(drivername='postgresql')
        assert source.host in ('localhost','127.0.0.1') and source.database.endswith('_test')
        name='ffg_review_upgrade_'+uuid4().hex[:10]+'_test'
        url=source.set(database=name)
        admin=await asyncpg.connect(source.render_as_string(hide_password=False))
        await admin.execute(f'CREATE DATABASE "{name}" TEMPLATE template0 ENCODING \'UTF8\'')
        env={**os.environ,'PGHOST':url.host,'PGPORT':str(url.port or 5432),'PGUSER':url.username,'PGPASSWORD':url.password or ''}
        def apply(path,check=True):
            return subprocess.run(['psql','-X','-q','-v','ON_ERROR_STOP=1','--single-transaction','-d',name,'-f',str(path)],env=env,check=check,capture_output=True,text=True)
        db=None
        try:
            sql=(ROOT/'db/migrate.sql').read_text()
            old=sql[:sql.index('SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 9)')]
            path=tmp_path/'before.sql';path.write_text(re.sub(r'\\ir (.+)',lambda m:'\\ir '+str(ROOT/'db'/m[1]),old));apply(path)
            db=await asyncpg.connect(url.render_as_string(hide_password=False))
            rid,uid,cid=uuid4(),uuid4(),uuid4()
            await db.execute("INSERT INTO pcma.users(id,user_id,email,name,password_hash,role) VALUES($1,'review-upgrade','review@example.test','Synthetic','disabled','admin')",uid)
            await db.execute("INSERT INTO pcma.scrape_runs(id,name,outcome,triggered_by,snapshot_version) VALUES($1,'Review upgrade','running',$2,1)",rid,uid)
            await db.execute("INSERT INTO pcma.cases(id,cnr_number,case_ref,state,district,status) VALUES($1,'SYNTHETIC-REVIEW','SYNTHETIC','Bihar','Gaya','pending')",cid)
            await db.execute('INSERT INTO pcma.case_pins(user_id,case_id) VALUES($1,$2)',uid,cid)
            await db.execute("INSERT INTO pcma.case_hearings(case_id,hearing_date,purpose) VALUES($1,'2026-10-01','Synthetic hearing')",cid)
            await db.execute("INSERT INTO pcma.case_documents(case_id,document_type,label) VALUES($1,'final','Synthetic document')",cid)
            await db.execute("INSERT INTO pcma.scrape_run_cases(run_id,case_id,snapshot,change_kind) VALUES($1,$2,'{\"synthetic\":true}','new')",rid,cid)
            await db.execute("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,attempts,retry_base,source_attempts,claim_version,error_kind)
                SELECT $1,'task-'||n,'case',jsonb_build_object('cnr','SYNTHETIC-'||n),
                    (ARRAY['queued','running','failed','success','cancelled'])[1+n%5],12,9,7,13,'response'
                FROM generate_series(1,13000) n""",rid)
            parent=await db.fetchval("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,attempts,expanding)
                VALUES($1,'checkpoint','search','{}','queued',1,TRUE) RETURNING id""",rid)
            await db.execute("""INSERT INTO pcma.scrape_expansions(run_id,task_id,chunk,children)
                SELECT $1,$2,0,jsonb_agg(jsonb_build_array('case',jsonb_build_object('cnr','STAGED-'||n),'STAGED-'||n))
                FROM generate_series(1,1000) n""",rid,parent)
            await db.execute("INSERT INTO pcma.scrape_run_events(run_id,task_id,kind,message) VALUES($1,$2,'task_retry','Historical response failure')",rid,parent)
            await db.execute("UPDATE pcma.scraper_control SET owner=$1,paused_until=now()+interval '5 minutes',failure_streak=11,cooldown_level=6,recovery_successes=1",uuid4())
            tables=('users','cases','case_hearings','case_documents','case_pins','scrape_run_cases','scrape_runs','scrape_run_events',
                    'scrape_task_counts','scrape_result_counts','scrape_metrics','scrape_run_progress','scrape_expansions','scraper_control')
            async def snapshot():
                return {t:[r['row'] for r in await db.fetch(f'SELECT to_jsonb(t)::text AS row FROM pcma.{t} t ORDER BY 1')] for t in tables}
            before=await snapshot()
            tasks=await db.fetch('SELECT * FROM pcma.scrape_tasks ORDER BY id')
            ddl=(ROOT/'db/migrations/009_operator_review.sql').read_text()
            # Live readers delay this additive migration too; fail safely on a lock timeout.
            await db.execute('BEGIN');await db.fetchval('SELECT count(*) FROM pcma.scrape_tasks')
            locked=tmp_path/'locked.sql';locked.write_text("SET LOCAL lock_timeout='100ms';\n"+ddl)
            result=apply(locked,False)
            assert result.returncode!=0 and 'lock timeout' in result.stderr
            await db.execute('ROLLBACK')
            # A later SQL failure must roll back both columns and indexes.
            failed=tmp_path/'failed.sql';failed.write_text(ddl+'\nSELECT 1/0;\n')
            result=apply(failed,False)
            assert result.returncode!=0 and 'division by zero' in result.stderr
            assert await db.fetchval("SELECT count(*) FROM information_schema.columns WHERE table_schema='pcma' AND table_name='scrape_tasks' AND column_name='review_required'")==0
            assert await db.fetchval("SELECT to_regclass('pcma.idx_tasks_review')") is None
            assert await snapshot()==before and await db.fetch('SELECT * FROM pcma.scrape_tasks ORDER BY id')==tasks
            apply(ROOT/'db/migrate.sql')
            upgraded=await db.fetch('SELECT * FROM pcma.scrape_tasks ORDER BY id')
            for previous,current in zip(tasks,upgraded):
                row=dict(current)
                assert row['review_failures']==row['review_sessions']==0 and not row['review_required']
                assert all(row[field] is None for field in FIELDS if field not in ('review_failures','review_sessions','review_required'))
                for field in FIELDS: row.pop(field)
                assert row==dict(previous)
            assert await snapshot()==before
            indexes=dict(await db.fetch("SELECT indexname,indexdef FROM pg_indexes WHERE schemaname='pcma' AND indexname LIKE 'idx_tasks_%'"))
            assert '(run_id, kind, source_validated_at DESC)' in indexes['idx_tasks_recovery_evidence']
            assert 'WHERE review_required' in indexes['idx_tasks_review']
            apply(ROOT/'db/migrate.sql')
            assert await snapshot()==before and await db.fetch('SELECT * FROM pcma.scrape_tasks ORDER BY id')==upgraded
            assert await db.fetchval('SELECT count(*) FROM pcma.schema_migrations WHERE version=9')==1
            for change in ('review_required=TRUE','review_failures=-1','review_sessions=-1'):
                with pytest.raises(asyncpg.CheckViolationError): await db.execute('UPDATE pcma.scrape_tasks SET '+change+' WHERE id=$1',parent)
            with pytest.raises(asyncpg.CheckViolationError):
                await db.execute("UPDATE pcma.scrape_tasks SET review_required=TRUE,review_reason='Review',review_at=now(),review_evidence='{}' WHERE id=$1",parent)
            await db.execute("UPDATE pcma.scrape_tasks SET status='failed',review_required=TRUE,review_reason='Review',review_at=now(),review_evidence='{}' WHERE id=$1",parent)
            await db.execute("UPDATE pcma.scrape_tasks SET status='queued',review_required=FALSE WHERE id=$1",parent)
            assert await db.fetchval('SELECT count(*) FROM pcma.scrape_expansions WHERE task_id=$1',parent)==1
        finally:
            if db: await db.close()
            await admin.execute(f'DROP DATABASE "{name}"')
            await admin.close()
    asyncio.run(run())
