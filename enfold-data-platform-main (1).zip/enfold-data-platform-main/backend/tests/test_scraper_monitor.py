from datetime import datetime, timezone, timedelta
from app.scraper.monitor import performance

NOW=datetime(2026,10,14,12,tzinfo=timezone.utc)


def sample():
    row={'outcome':'running','started_at':NOW-timedelta(hours=2)}
    stats={'progress':{'metrics_since':NOW-timedelta(hours=1),'last_success_at':NOW,'deferred_tasks':400},
        'metrics':{'succeeded':200,'cases':100,'retried':20,'failed':5,'source_errors':20},
        'worker':{'updated_at':NOW,'value':{'concurrency':3,'requestIntervalSeconds':3}},
        'coverage':[{'kind':'case','status':'queued','count':1000},{'kind':'search','status':'queued','count':99999}]}
    return row,stats


def test_eta_is_only_existing_case_backlog_and_error_rate_is_task_outcomes():
    row,stats=sample(); view=performance(row,stats,NOW)
    assert view['etaSeconds']==36000 and view['etaBasis']=='current_case_backlog'
    assert view['sourceErrorRate']==round(20/225,4)
    assert view['deferredTasks']==400 and not view['stalled']


def test_stall_and_pause_and_stale_worker_suppress_estimates():
    for reason in ('stalled','cooldown','stale','terminal'):
        row,stats=sample()
        if reason=='stalled': stats['progress']['last_success_at']=NOW-timedelta(hours=1)
        if reason=='cooldown': stats['worker']['value']['sourcePausedUntil']=(NOW+timedelta(minutes=1)).isoformat()
        if reason=='stale': stats['worker']['updated_at']=NOW-timedelta(minutes=10)
        if reason=='terminal': row['outcome']='success'
        view=performance(row,stats,NOW)
        assert view['etaSeconds'] is None
        assert view['stalled']==(reason=='stalled')


def test_short_observation_or_few_completions_cannot_create_false_eta():
    row,stats=sample(); stats['progress']['metrics_since']=NOW-timedelta(seconds=30)
    assert performance(row,stats,NOW)['etaSeconds'] is None
    row,stats=sample(); stats['metrics']['cases']=9
    assert performance(row,stats,NOW)['etaSeconds'] is None


def test_legacy_missing_metrics_are_not_historical_zero_rate_or_live_eta():
    row={'outcome':'success','started_at':None}
    view=performance(row,{'progress':{},'metrics':{},'worker':{},'coverage':[]},NOW)
    assert view['sourceErrorRate'] is None and view['etaSeconds'] is None
    assert not view['stalled'] and not view['workerHealthy']
