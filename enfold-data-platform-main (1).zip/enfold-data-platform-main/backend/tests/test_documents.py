import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock
from uuid import uuid4
import httpx
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.auth import get_current_user
from app.database import get_db
from app.scraper.client import ECourtsClient, UpstreamError
from app.scraper.normalize import final_documents
from app.scraper import documents
from app.document_refs import reference_key

REF = {'filename':'/orders/2026/synthetic.pdf','state_cd':'5','dist_cd':'1','court_code':'2'}


def test_final_references_deduplicate_without_capturing_parties_or_interim_orders():
    source={'finalOrder':[{**REF,'order_date1f':'08-10-2026','order_details':'Sensitive text'},
                          {**REF,'order_date1f':'08-10-2026'}, {'filename':''}],
            'interimOrder':[{**REF,'filename':'interim.pdf'}]}
    result=final_documents(source)
    assert len(result)==1 and result[0]['date']=='2026-10-08'
    assert 'Sensitive' not in str(result) and 'interim.pdf' not in str(result)
    assert reference_key({**REF,'caseno':'changed'})==reference_key(REF)
    assert final_documents({})==[]
    with pytest.raises(ValueError): final_documents({'finalOrder':{'filename':'bad'}})
    with pytest.raises(ValueError): final_documents({'finalOrder':[{'filename':'bad'}]})


@pytest.mark.parametrize('url', ['http://app.ecourts.gov.in/a','https://evil.example/a',
    'https://app.ecourts.gov.in.evil.example/a','https://user@app.ecourts.gov.in/a',
    'https://app.ecourts.gov.in:8443/a','https://127.0.0.1/a','https://app.ecourts.gov.in/a\n'])
def test_document_urls_cannot_escape_allowlist(url):
    with pytest.raises(UpstreamError): documents.safe_pdf_url(url)


@pytest.mark.parametrize('status,body,expected', [(200,b'%PDF-1.7\nsynthetic',True),
    (200,b'{"error":"expired"}',False),(302,b'',False),(500,b'',False)])
def test_download_validates_bytes_and_closes_connection(monkeypatch,status,body,expected):
    async def run():
        requests=[]
        def transport(request):
            requests.append(request)
            assert 'authorization' not in request.headers
            return httpx.Response(status,content=body,headers={'location':'http://127.0.0.1/'})
        http=httpx.AsyncClient(transport=httpx.MockTransport(transport))
        fake=SimpleNamespace(http=http,get=AsyncMock(return_value={'pdf_url':'https://app.ecourts.gov.in/synthetic.pdf'}),close=http.aclose)
        monkeypatch.setattr(documents,'ECourtsClient',lambda **_:fake)
        if expected: assert await documents.fetch_pdf(REF)==body
        else:
            with pytest.raises(UpstreamError): await documents.fetch_pdf(REF)
        assert http.is_closed and len(requests)==1
        assert fake.get.call_args.kwargs['method']=='POST'
    asyncio.run(run())


def test_document_download_size_limit(monkeypatch):
    monkeypatch.setattr(documents,'MAX_PDF_BYTES',8)
    test_download_validates_bytes_and_closes_connection(monkeypatch,200,b'%PDF-1.7 too large',False)


def db_result(value):
    result=Mock(); result.scalar_one_or_none.return_value=value; result.all.return_value=value
    return result


@pytest.mark.parametrize('role',['admin','user'])
def test_both_roles_can_list_and_download_without_exposing_references(monkeypatch,role):
    import app.routes.documents as routes
    case_id,doc_id=uuid4(),uuid4()
    db=SimpleNamespace(execute=AsyncMock(side_effect=[db_result(case_id),
        db_result([SimpleNamespace(id=doc_id,document_date=None)]),db_result(REF)]),rollback=AsyncMock())
    app.dependency_overrides[get_db]=lambda:db
    app.dependency_overrides[get_current_user]=lambda:SimpleNamespace(role=role)
    fetch=AsyncMock(return_value=b'%PDF-1.7\nsynthetic')
    monkeypatch.setattr(routes,'fetch_pdf',fetch)
    try:
        with TestClient(app) as client:
            listed=client.get(f'/api/cases/{case_id}/final-judgments')
            assert listed.json()==[{'id':str(doc_id),'date':None}]
            response=client.get(f'/api/cases/{case_id}/final-judgments/{doc_id}/download')
            assert response.status_code==200 and response.content.startswith(b'%PDF-')
            assert response.headers['cache-control']=='private, no-store'
            assert 'attachment;' in response.headers['content-disposition']
            statement=db.execute.call_args.args[0].compile()
            assert case_id in statement.params.values() and doc_id in statement.params.values()
            db.rollback.assert_awaited_once()
    finally: app.dependency_overrides.clear()


def test_document_routes_require_login():
    with TestClient(app) as client:
        base=f'/api/cases/{uuid4()}/final-judgments'
        assert client.get(base).status_code==401
        assert client.get(base+f'/{uuid4()}/download').status_code==401


@pytest.mark.parametrize('missing', [True,False])
def test_missing_or_unavailable_document_has_safe_error(monkeypatch,missing):
    import app.routes.documents as routes
    db=SimpleNamespace(execute=AsyncMock(return_value=db_result(None if missing else REF)),rollback=AsyncMock())
    app.dependency_overrides[get_db]=lambda:db
    app.dependency_overrides[get_current_user]=lambda:SimpleNamespace(role='user')
    fetch=AsyncMock(side_effect=UpstreamError('SECRET URL TOKEN'))
    monkeypatch.setattr(routes,'fetch_pdf',fetch)
    try:
        with TestClient(app) as client:
            response=client.get(f'/api/cases/{uuid4()}/final-judgments/{uuid4()}/download')
            assert response.status_code==(404 if missing else 502)
            assert 'SECRET' not in response.text
            if missing: fetch.assert_not_called()
    finally: app.dependency_overrides.clear()


def test_ecourts_resolver_uses_post_with_encrypted_query(monkeypatch):
    async def run():
        seen=[]
        def transport(request):
            seen.append(request)
            return httpx.Response(200,text='encrypted')
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(transport))
        import app.scraper.client as module
        monkeypatch.setattr(module,'decrypt',lambda _: {'token':'session'} if len(seen)==1 else {'pdf_url':'https://app.ecourts.gov.in/example'})
        try:
            await client.get('display_pdf_new.php',REF,method='POST')
            assert seen[0].method=='GET' and seen[1].method=='POST'
            assert seen[1].url.params.get('params') and seen[1].content==b''
        finally: await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('orders', ['Source returned an unexpected message', {'unexpected': 'shape'},
                                    [{'filename': '/orders/incomplete.pdf'}]])
def test_optional_order_errors_preserve_valid_case_and_do_not_expose_source(orders):
    from app.scraper.normalize import normalize
    from test_scraper import history, scope
    source = history(); source['finalOrder'] = orders
    record = normalize(source, scope())
    assert record['cnr'] == scope()['cnr'] and record['acts'] and record['hearings']
    assert record['finalDocuments'] is None
    assert record['documentWarning'] == ('Final-judgment references could not be verified; '
        'case details saved, existing references preserved. A later scrape will recheck.')
    # Core data validation must still reject a corrupted case.
    source['act'] = None
    with pytest.raises(ValueError, match='Incomplete case history'):
        normalize(source, scope())


@pytest.mark.parametrize('message', ['Order not uploaded by concerned court',
    '  ORDER  NOT UPLOADED BY CONCERNED COURT.  '])
def test_observed_missing_order_message_saves_case_without_a_document_warning(message):
    from app.scraper.normalize import normalize
    from test_scraper import history, scope
    source=history(); source['finalOrder']=message
    record=normalize(source, scope())
    assert record['finalDocuments']==[]
    assert 'documentWarning' not in record
    assert record['cnr']==scope()['cnr'] and record['hearings']
