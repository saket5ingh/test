"""Opt-in tests against an isolated, migrated database (never production).

FFG_TEST_PG_OWNER, FFG_TEST_PG_API, FFG_TEST_PG_WORKER are asyncpg URLs.
Records use unique synthetic identifiers. The test does not drop/truncate tables.
"""
import asyncio
import os
from datetime import datetime, timezone
from uuid import uuid4, UUID
import bcrypt
import httpx
import pytest
from sqlalchemy import text, inspect
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from app.main import app
from app.database import Base, get_db
from app.scraper import worker
from app.scraper.client import UpstreamError
from test_scraper import history

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URLs not supplied')


class FakeECourts:
    def __init__(self,cnr):
        self.cnr=cnr; self.disposed=False; self.fail=False; self.extra_cnr=None; self.bad_cnr=None; self.invalid_record=False; self.invalid_orders=False
    async def close(self): pass
    async def states(self): return [{'code':'5','name':'Bihar'}]
    async def districts(self,state): return [{'code':'1','name':'Gaya'}]
    async def courts(self,state,district): return [{'code':'1','name':'District court'}]
    async def acts(self,scope): return [('1','Prohibition of Child Marriage Act'),('2','Prevention of Child Marriage Act')]
    async def search(self,scope):
        return [{'cino':cnr,'case_no':'100/2024'} for cnr in [self.cnr,self.extra_cnr] if cnr] if scope['status']==('Disposed' if self.disposed else 'Pending') else []
    async def history(self,scope):
        if self.fail or scope['cnr']==self.bad_cnr: raise UpstreamError('Synthetic record validation failure',kind='validation')
        row=history()
        # Exercise the JSON hearing format observed in live v4 responses through
        # normalization, database storage, snapshots and the restricted API.
        hearing={'todays_date':'01-08-2026','nextdate':'20261020','purpose':'Evidence','cino':scope['cnr']}
        row['historyOfCaseHearing']=[hearing]
        row['last_business_date']=hearing
        if self.invalid_record: row['reg_no']='99999999999999999999'
        if self.disposed: row.update(date_of_decision='20-09-2026',disp_name='Disposed', finalOrder=[{'filename':'/orders/synthetic.pdf','state_cd':'5','dist_cd':'1','court_code':'1','order_date1f':'20-09-2026'}])
        if self.invalid_orders: row['finalOrder']=self.invalid_orders if isinstance(self.invalid_orders,str) else 'Unexpected final-order source response'
        return row


def test_real_postgres_pipeline_permissions_snapshots_notifications_and_retry(monkeypatch):
    async def run():
        assert all(make_url(os.environ[key]).database.endswith('_test') for key in ['FFG_TEST_PG_OWNER','FFG_TEST_PG_API','FFG_TEST_PG_WORKER']), 'Use an isolated database ending in _test'
        assert len({(make_url(os.environ[key]).host,make_url(os.environ[key]).port,make_url(os.environ[key]).database) for key in ['FFG_TEST_PG_OWNER','FFG_TEST_PG_API','FFG_TEST_PG_WORKER']})==1
        engines=[create_async_engine(os.environ[key]) for key in ['FFG_TEST_PG_OWNER','FFG_TEST_PG_API','FFG_TEST_PG_WORKER']]
        owner,api,work=[async_sessionmaker(engine,expire_on_commit=False) for engine in engines]
        monkeypatch.setattr(worker,'async_session_maker',work)
        import app.routes.scrapes as routes
        monkeypatch.setattr(routes,'async_session_maker',api)
        async def connection():
            async with api() as db: yield db
        app.dependency_overrides[get_db]=connection
        suffix=uuid4().hex[:12]
        ids={role:uuid4() for role in ['admin','user','other']}
        async with owner() as db,db.begin():
            for role,uid in ids.items():
                await db.execute(text('''INSERT INTO pcma.users(id,user_id,email,name,password_hash,role)
                    VALUES (:id,:uid,:email,:name,:password,:role)'''),dict(id=uid,uid=role+suffix,email=role+suffix+'@example.org',name=role,
                    password=bcrypt.hashpw(b'test-long-password',bcrypt.gensalt(rounds=4)).decode(),role='admin' if role=='admin' else 'user'))
        client=httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test')
        async def login(role):
            response=await client.post('/api/auth/login',json={'userId':role+suffix,'password':'test-long-password'})
            assert response.status_code==200,response.text
            return {'Authorization':'Bearer '+response.json()['token']}
        admin,user,other=[await login(r) for r in ['admin','user','other']]
        fake=FakeECourts('TEST'+suffix.upper())
        guard=await engines[2].connect()
        assert (await guard.execute(text('SELECT pg_try_advisory_lock(:key)'),{'key':worker.LOCK_ID})).scalar_one()
        await guard.commit()
        async def queue():
            body={'name':'Synthetic '+suffix,'allStates':True,'allActs':True,'status':'all','requestId':str(uuid4())}
            first=await client.post('/api/scrapes/run',json=body,headers=admin)
            assert first.status_code==202,first.text
            second=await client.post('/api/scrapes/run',json=body,headers=admin)
            assert second.json()==first.json()
            conflict=await client.post('/api/scrapes/run',json={**body,'name':'Different criteria'},headers=admin)
            assert conflict.status_code==409
            return first.json()['id']
        async def drain():
            for _ in range(100):
                async with work(bind=guard) as db,db.begin():
                    await db.execute(text("UPDATE pcma.scrape_tasks SET available_at=CURRENT_TIMESTAMP WHERE status='queued'"))
                    task=await worker.claim(db)
                if not task: return
                await worker.process_task(fake,task,guard)
            raise AssertionError('Pipeline did not finish')
        try:
            # New SQL definitions and ORM mappings agree on column types/nullability.
            async with engines[0].connect() as connection:
                def check_schema(sync):
                    inspector=inspect(sync)
                    for name in ['scrape_tasks','scrape_runs','scrape_run_cases','scrape_run_events','scraper_metadata','case_notifications','case_documents','cases','scrape_task_counts','scrape_result_counts','scrape_run_progress','scrape_metrics','scrape_expansions','scraper_control']:
                        actual={c['name']:c for c in inspector.get_columns(name,schema='pcma')}
                        model=Base.metadata.tables['pcma.'+name]
                        assert set(actual)==set(model.columns.keys())
                        for column in model.columns:
                            assert actual[column.name]['type'].compile(dialect=sync.dialect)==column.type.compile(dialect=sync.dialect), (name,column.name)
                            assert actual[column.name]['nullable']==column.nullable, (name,column.name)
                await connection.run_sync(check_schema)
            # API role cannot write case data; worker cannot reset passwords or mutate snapshots.
            async with owner() as db:
                permissions=(await db.execute(text("SELECT has_table_privilege(:api,'pcma.cases','INSERT'), has_column_privilege(:worker,'pcma.users','password_hash','UPDATE'),has_table_privilege(:worker,'pcma.scrape_run_cases','UPDATE')"), {"api":make_url(os.environ["FFG_TEST_PG_API"]).username,"worker":make_url(os.environ["FFG_TEST_PG_WORKER"]).username})).one()
                assert tuple(permissions)==(False,False,False)
            fake.invalid_orders='Order not uploaded by concerned court'
            first=await queue(); await drain()
            fake.invalid_orders=False
            detail=(await client.get(f'/api/scrapes/runs/{first}',headers=admin)).json()
            assert detail['outcome']=='success' and detail['counts']=={'new':1},detail
            assert detail['triggeredByName']=='admin'
            listed=(await client.get('/api/scrapes/runs',headers=admin)).json()
            assert next(r for r in listed['items'] if r['id']==first)['triggeredByName']=='admin'
            assert detail['lastActivityAt'] is not None
            filtered=(await client.get('/api/scrapes/runs', params={'q':suffix,'outcome':'success','trigger':'manual','pageSize':1},headers=admin)).json()
            assert filtered['total']==1 and filtered['items'][0]['id']==first
            assert filtered['items'][0]['tasks']['success'] > 0
            second_page=(await client.get('/api/scrapes/runs',params={'q':suffix,'page':2,'pageSize':1},headers=admin)).json()
            assert second_page['total']==1 and second_page['items']==[]
            for params in [{'q':suffix,'trigger':'scheduled'}, {'q':suffix,'outcome':'failed'}, {'q':suffix+'%'}]:
                empty=(await client.get('/api/scrapes/runs',params=params,headers=admin)).json()
                assert empty['total']==0 and empty['items']==[]
            options=(await client.get('/api/scrapes/options',headers=admin)).json()
            assert options['monthlySchedule']['timezone']==worker.settings.SCRAPER_TIMEZONE

            async with owner() as db:
                from app.scraper.catalog import CATALOG
                payloads=(await db.execute(text("SELECT payload FROM pcma.scrape_tasks WHERE run_id=:id AND kind='search'"),{'id':first})).scalars().all()
                assert payloads and all(p['act_code']=='1' for p in payloads)
                assert all(p['act_mapping']['config']==CATALOG.identity for p in payloads)
                assert payloads[0]['act_mapping']['sourceLabels']==['Prohibition of Child Marriage Act']
            audit=(await client.get(f'/api/scrapes/runs/{first}/events',headers=admin)).json()
            assert any(e['kind']=='act_mapping_review' and 'Prevention of Child Marriage' in e['message'] for e in audit['items'])
            audit_warnings=(await client.get(f'/api/scrapes/runs/{first}/events',params={'kind':'warnings','q':'child marriage','pageSize':1},headers=admin)).json()
            assert audit_warnings['total']>=1 and len(audit_warnings['items'])==1 and audit_warnings['pageSize']==1
            assert audit_warnings['items'][0]['kind'] in ('act_unavailable','act_mapping_review')
            activity=(await client.get(f'/api/scrapes/runs/{first}/events',params={'kind':'activity','pageSize':100},headers=admin)).json()
            assert activity['items'] and all(e['kind'] not in ('act_unavailable','act_mapping_review','task_retry','task_failed','failed','partial','data_rejected') for e in activity['items'])
            case_tasks=(await client.get(f'/api/scrapes/runs/{first}/tasks',params={'status':'success','kind':'case','q':'gAyA','pageSize':1},headers=admin)).json()
            assert case_tasks['total']==1 and len(case_tasks['items'])==1 and case_tasks['pageSize']==1
            assert case_tasks['items'][0]['payload']['cnr']==fake.cnr
            for route in ('results','tasks','events'):
                for params in ({'q':'%'},{'q':'_'},{'q':"' OR 1=1 --"}):
                    filtered=await client.get(f'/api/scrapes/runs/{first}/{route}',params=params,headers=admin)
                    assert filtered.status_code==200 and filtered.json()['total']==0
                for params in ({'pageSize':101},{'page':0},{'q':'x'*161}):
                    assert (await client.get(f'/api/scrapes/runs/{first}/{route}',params=params,headers=admin)).status_code==422
            snapshot=(await client.get(f'/api/scrapes/runs/{first}/results',headers=admin)).json()['items'][0]['snapshot']
            case_id=snapshot['id']; assert snapshot['status']=='pending'
            assert snapshot['numHearings']==1
            assert snapshot['hearings']==[{'date':'2026-08-01','purpose':'Evidence'}]
            assert (await client.get('/api/cases/'+case_id,headers=admin)).json()['hearings']==snapshot['hearings']
            assert (await client.get(f'/api/scrapes/runs/{first}/csv',headers=user)).status_code==403
            for route in ['','/results','/events','/tasks']:
                assert (await client.get(f'/api/scrapes/runs/{first}'+route,headers=user)).status_code==403
            officer_case=(await client.get('/api/cases/'+case_id,headers=user)).json()
            assert officer_case['cnr'] is None and officer_case['hearings']==[]
            assert (await client.put('/api/cases/'+case_id+'/pin',json={'pinned':True},headers=user)).status_code==204
            assert (await client.get('/api/cases/updates',headers=user)).json()['total']==0
            fake.disposed=True
            second=await queue(); await drain()
            assert (await client.get('/api/cases/'+case_id,headers=admin)).json()['status']=='disposed'
            old=(await client.get(f'/api/scrapes/runs/{first}/results',headers=admin)).json()['items'][0]['snapshot']
            assert old['status']=='pending'
            # Filters operate on historical snapshots even after the shared case changes.
            matching=(await client.get(f'/api/scrapes/runs/{first}/results',params={'q':fake.cnr.lower(),'state':'Bihar','status':'pending','change_kind':'new','pageSize':1},headers=admin)).json()
            assert matching['total']==1 and matching['pageSize']==1 and matching['items'][0]['snapshot']['id']==case_id
            for params in ({'status':'disposed'},{'change_kind':'updated'},{'state':'Goa'}):
                assert (await client.get(f'/api/scrapes/runs/{first}/results',params=params,headers=admin)).json()['total']==0
            updates=(await client.get('/api/cases/updates',headers=user)).json()
            assert updates['total']==1 and updates['critical']==1,updates
            assert (await client.get('/api/cases/updates',headers=other)).json()['total']==0
            csv=await client.get(f'/api/scrapes/runs/{first}/csv',headers=admin)
            assert csv.status_code==200 and 'pending' in csv.text and fake.cnr in csv.text
            third=await queue(); await drain()
            assert (await client.get(f'/api/scrapes/runs/{third}',headers=admin)).json()['counts']=={'unchanged':1}
            # Final-document persistence, duplicate prevention, both role permissions,
            # and missing-reference preservation use the real migrated database.
            from app.scraper.store import save_documents
            import app.routes.documents as document_routes
            async def fake_pdf(reference):
                assert reference['filename']=='/orders/synthetic.pdf'
                return b'%PDF-1.7\nsynthetic'
            monkeypatch.setattr(document_routes,'fetch_pdf',fake_pdf)
            for headers in (admin,user):
                listed=await client.get(f'/api/cases/{case_id}/final-judgments',headers=headers)
                assert listed.status_code==200 and len(listed.json())==1
                assert 'filename' not in listed.text
                document_id=listed.json()[0]['id']
                pdf=await client.get(f'/api/cases/{case_id}/final-judgments/{document_id}/download',headers=headers)
                assert pdf.status_code==200 and pdf.content.startswith(b'%PDF-')
                assert (await client.get(f'/api/cases/{uuid4()}/final-judgments/{document_id}/download',headers=headers)).status_code==404
            async with work() as db,db.begin():
                await save_documents(db,case_id,[])
            async with owner() as db:
                assert (await db.execute(text('SELECT count(*) FROM pcma.case_documents WHERE case_id=:id'),{'id':case_id})).scalar_one()==1
                assert (await db.execute(text('SELECT documents_checked_at IS NOT NULL FROM pcma.cases WHERE id=:id'),{'id':case_id})).scalar_one()
            latest=(await client.get(f'/api/scrapes/runs/{third}/results',headers=admin)).json()
            assert 'finalDocuments' not in str(latest) and '/orders/' not in str(latest)
            # Optional document errors cannot discard a valid case or mark stale
            # references as freshly checked. The warning remains visible in audit.
            async with owner() as db:
                checked_before=(await db.execute(text('SELECT documents_checked_at FROM pcma.cases WHERE id=:id'),{'id':case_id})).scalar_one()
            fake.invalid_orders=True
            warning_run=await queue(); await drain()
            warning_detail=(await client.get(f'/api/scrapes/runs/{warning_run}',headers=admin)).json()
            assert warning_detail['outcome']=='success' and warning_detail['total']==1
            warnings=(await client.get(f'/api/scrapes/runs/{warning_run}/events',params={'kind':'warnings','pageSize':100},headers=admin)).json()
            assert any(e['kind']=='document_warning' for e in warnings['items'])
            latest=(await client.get(f'/api/scrapes/runs/{warning_run}/results',headers=admin)).json()
            assert 'documentWarning' not in str(latest) and 'finalDocuments' not in str(latest)
            async with owner() as db:
                assert (await db.execute(text('SELECT documents_checked_at FROM pcma.cases WHERE id=:id'),{'id':case_id})).scalar_one()==checked_before
                assert (await db.execute(text('SELECT count(*) FROM pcma.case_documents WHERE case_id=:id'),{'id':case_id})).scalar_one()==1
            fake.invalid_orders=False
            fake.fail=True
            failed=await queue(); await drain()
            detail=(await client.get(f'/api/scrapes/runs/{failed}',headers=admin)).json()
            assert detail['outcome']=='failed' and detail['tasks']['failed']==1,detail
            failures=(await client.get(f'/api/scrapes/runs/{failed}/tasks?status=failed',headers=admin)).json()
            errors=(await client.get(f'/api/scrapes/runs/{failed}/events',params={'kind':'errors','q':'Synthetic','pageSize':100},headers=admin)).json()
            assert errors['total']>0 and all(e['kind'] in ('task_failed','task_retry','data_rejected','failed','partial') for e in errors['items'])
            assert failures['total']==1 and failures['items'][0]['payload']['court']['name']=='District court'
            fake.fail=False
            assert (await client.post(f'/api/scrapes/runs/{failed}/retry',headers=admin)).status_code==202
            await drain()
            assert (await client.get(f'/api/scrapes/runs/{failed}',headers=admin)).json()['outcome']=='success'
            cancelled=await queue()
            assert (await client.post(f'/api/scrapes/runs/{cancelled}/cancel',headers=admin)).status_code==202
            await drain()
            assert (await client.get(f'/api/scrapes/runs/{cancelled}',headers=admin)).json()['total']==0
            # A stale task from before a restart cannot commit after a new claim.
            recovered=await queue()
            async with work() as db,db.begin(): abandoned=await worker.claim(db)
            async with work() as db,db.begin(): await worker.recover(db)
            async with work() as db,db.begin(): replacement=await worker.claim(db)
            assert replacement['id']==abandoned['id'] and replacement['attempts']>abandoned['attempts']
            await worker.execute_task(fake,abandoned)
            async with owner() as db:
                assert (await db.execute(text('SELECT count(*) FROM pcma.scrape_tasks WHERE run_id=:id'),{'id':recovered})).scalar_one()==1
            await worker.execute_task(fake,replacement); await drain()
            assert (await client.get(f'/api/scrapes/runs/{recovered}',headers=admin)).json()['outcome']=='success'
            # Cancellation while a request is in flight discards its result.
            inflight=await queue()
            for _ in range(20):
                async with work() as db,db.begin(): task=await worker.claim(db)
                assert task
                if task['kind']=='case': break
                await worker.execute_task(fake,task)
            assert task['kind']=='case'
            assert (await client.post(f'/api/scrapes/runs/{inflight}/cancel',headers=admin)).status_code==202
            assert (await client.post(f'/api/scrapes/runs/{inflight}/retry',headers=admin)).status_code==409
            await worker.execute_task(fake,task)
            assert (await client.get(f'/api/scrapes/runs/{inflight}',headers=admin)).json()['total']==0
            assert (await client.post(f'/api/scrapes/runs/{inflight}/retry',headers=admin)).status_code==202
            await drain()
            # One bad case cannot discard good siblings or mutate their snapshots on retry.
            fake.extra_cnr='EXTRA'+suffix.upper(); fake.bad_cnr=fake.extra_cnr
            partial=await queue(); await drain()
            assert (await client.get(f'/api/scrapes/runs/{partial}',headers=admin)).json()['outcome']=='partial'
            saved=(await client.get(f'/api/scrapes/runs/{partial}/results/{case_id}',headers=admin)).json()
            fake.bad_cnr=None
            assert (await client.post(f'/api/scrapes/runs/{partial}/retry',headers=admin)).status_code==202
            await drain()
            assert (await client.get(f'/api/scrapes/runs/{partial}',headers=admin)).json()['total']==2
            page_one=(await client.get(f'/api/scrapes/runs/{partial}/results',params={'pageSize':1,'page':1},headers=admin)).json()
            page_two=(await client.get(f'/api/scrapes/runs/{partial}/results',params={'pageSize':1,'page':2},headers=admin)).json()
            assert page_one['total']==page_two['total']==2
            assert page_one['items'][0]['snapshot']['id']!=page_two['items'][0]['snapshot']['id']
            assert (await client.get(f'/api/scrapes/runs/{partial}/results/{case_id}',headers=admin)).json()==saved
            fake.extra_cnr=None
            # SQL rejection rolls back the record, records failure and releases the queue.
            fake.invalid_record=True
            rejected=await queue(); await drain()
            assert (await client.get(f'/api/scrapes/runs/{rejected}',headers=admin)).json()['outcome']=='failed'
            assert (await client.get('/api/cases/'+case_id,headers=admin)).json()['regNo']==100
            fake.invalid_record=False
            # Monthly scheduling is idempotent and does not overlap a prior scheduled run.
            monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_ENABLED',True)
            monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_WEEK',3)
            monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_WEEKDAY',4)
            monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_HOUR',0)
            monkeypatch.setattr(worker.settings,'SCRAPER_MONTHLY_MINUTE',0)
            monkeypatch.setattr(worker.settings,'SCRAPER_TIMEZONE','Asia/Kolkata')
            year=3000+int(suffix[:8],16)%5000
            async with work() as db,db.begin():
                await worker.schedule(db,datetime(year,1,1,tzinfo=timezone.utc))
                assert not (await db.execute(text('SELECT 1 FROM pcma.scrape_runs WHERE schedule_key=:key'), {'key': f'{year}-01'})).scalar_one_or_none()
            async with work() as db,db.begin():
                await worker.schedule(db,datetime(year,1,25,tzinfo=timezone.utc))
                await worker.schedule(db,datetime(year,1,25,tzinfo=timezone.utc))
                await worker.schedule(db,datetime(year,2,25,tzinfo=timezone.utc))
            async with owner() as db:
                scheduled=(await db.execute(text('SELECT id,criteria FROM pcma.scrape_runs WHERE schedule_key IN (:first,:second)'),{'first':f'{year}-01','second':f'{year}-02'})).mappings().all()
                assert len(scheduled)==1 and scheduled[0]['criteria']['allStates'] and not scheduled[0]['criteria']['allActs']
                assert scheduled[0]['criteria']['actKeys']==['childmarriage']
                assert scheduled[0]['criteria']['sections']==[] and scheduled[0]['criteria']['status']=='all'
            await client.post(f"/api/scrapes/runs/{scheduled[0]['id']}/cancel",headers=admin)
            # Replayed completed case task cannot duplicate snapshots/hearings.
            async with owner() as db:
                count=(await db.execute(text('SELECT count(*) FROM pcma.case_hearings WHERE case_id=:id'),{'id':case_id})).scalar_one()
                assert count==1
            # The operator backfill uses the worker role, is repeatable and does
            # not overwrite case status or snapshots.
            from app.scraper import backfill_documents
            monkeypatch.setattr(backfill_documents,'async_session_maker',work)
            monkeypatch.setattr(backfill_documents,'ECourtsClient',lambda **_:fake)
            fake.disposed=True
            # Clear the stored date so a no-op backfill cannot pass this check.
            async with owner() as db,db.begin():
                await db.execute(text('UPDATE pcma.case_documents SET document_date=NULL WHERE case_id=:id'),{'id':case_id})
            assert await backfill_documents.run(1,UUID(case_id))==0
            assert await backfill_documents.run(1,UUID(case_id))==0
            async with owner() as db:
                assert (await db.execute(text('SELECT count(*) FROM pcma.case_documents WHERE case_id=:id'),{'id':case_id})).scalar_one()==1
                assert str((await db.execute(text('SELECT document_date FROM pcma.case_documents WHERE case_id=:id'),{'id':case_id})).scalar_one())=='2026-09-20'
            assert (await client.get(f'/api/scrapes/runs/{first}/results',headers=admin)).json()['items'][0]['snapshot']==old
        finally:
            # Keep a failed test from leaving work that contaminates a later run.
            async with owner() as db,db.begin():
                await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled' WHERE status IN ('queued','running') AND run_id IN (SELECT id FROM pcma.scrape_runs WHERE name=:name)"),{'name':'Synthetic '+suffix})
                await db.execute(text("UPDATE pcma.scrape_runs SET outcome='cancelled',cancel_requested=TRUE,completed_at=CURRENT_TIMESTAMP WHERE outcome IN ('queued','running') AND name=:name"),{'name':'Synthetic '+suffix})
            await client.aclose()
            await guard.close()
            app.dependency_overrides.clear()
            for engine in engines: await engine.dispose()
    asyncio.run(run())
