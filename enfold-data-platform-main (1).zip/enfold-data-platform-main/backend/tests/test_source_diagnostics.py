"""Synthetic HTTP only: transport instrumentation never probes eCourts."""
import asyncio
import json
import logging
from uuid import uuid4
import httpx
import pytest
from app.scraper import client as source
from app.scraper.client import ECourtsClient, UpstreamError
from app.scraper.diagnostics import exception_details, safe_context
from test_scraper import encrypted_response, scope


def diagnostics(caplog):
    return [json.loads(r.getMessage().split(' diagnostics=',1)[1]) for r in caplog.records
            if r.name=='app.scraper.client' and ' diagnostics=' in r.getMessage()]


@pytest.mark.parametrize('mode,category,phase',[
    ('eof','eof_before_response','http11.receive_response_headers'),
    ('status','invalid_status_line','http11.receive_response_headers'),
    ('body','incomplete_body','http11.receive_response_body'),
])
def test_real_local_transport_phases_partial_bytes_and_privacy(monkeypatch,caplog,mode,category,phase):
    caplog.set_level(logging.INFO,logger='app.scraper.client')
    async def run():
        calls=[]; connections=[]; writers=set()
        async def serve(reader,writer):
            connections.append(1); writers.add(writer)
            try:
                while True:
                    request=await reader.readuntil(b'\r\n\r\n');calls.append(request)
                    if len(calls)==1:
                        body=encrypted_response({'token':'DO_NOT_LOG_TOKEN'}).encode()
                        writer.write(b'HTTP/1.1 200 OK\r\nContent-Length: '+str(len(body)).encode()+
                                     b'\r\nSet-Cookie: DO_NOT_LOG_COOKIE\r\nX-Private: DO_NOT_LOG_HEADER\r\n\r\n'+body)
                        await writer.drain()
                    else:
                        if mode=='status': writer.write(b'DO_NOT_LOG_BAD_STATUS\r\n\r\n')
                        if mode=='body': writer.write(b'HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\nDO_NOT_LOG_BODY')
                        await writer.drain();break
            except asyncio.IncompleteReadError: pass
            finally:
                writer.close();await writer.wait_closed();writers.discard(writer)
        server=await asyncio.start_server(serve,'127.0.0.1',0)
        monkeypatch.setattr(source,'BASE_URL',f'http://127.0.0.1:{server.sockets[0].getsockname()[1]}')
        client=ECourtsClient(interval=0)
        task={'id':uuid4(),'run_id':uuid4(),'kind':'case','attempts':2,
              'payload':{**scope(),'cnr':'DO_NOT_LOG_CNR','case_no':'DO_NOT_LOG_CASE'}}
        client.set_context(task)
        try:
            with pytest.raises(UpstreamError) as error: await client.history(task['payload'])
            assert error.value.kind=='network'
            assert len(calls)==2 and len(connections)==1
            rows=diagnostics(caplog);assert len(rows)==2
            first,last=rows
            assert first['connection_evidence']=='tcp_connected'
            assert last['connection_id']==first['connection_id']
            assert last['connection_reused'] and last['connection_evidence'].startswith('inferred_')
            assert last['failure_phase']==phase and category in last['failure_categories']
            assert last['context']['task_id']==str(task['id'])
            assert last['context']['court_code']=='1' and last['session_age_s']>=0
            assert first['response_headers']['content-length']>0
            if mode=='body':
                assert last['response_status']==200
                assert any('bytes=15 ' in r.getMessage() for r in caplog.records if 'diagnostics=' in r.getMessage())
        finally:
            await client.close();server.close();await server.wait_closed()
            for writer in list(writers): writer.close()
    asyncio.run(run())
    messages='\n'.join(r.getMessage() for r in caplog.records if r.name=='app.scraper.client')
    assert 'DO_NOT_LOG' not in messages and 'params=' not in messages and 'Bearer' not in messages


def test_http503_classification_headers_and_new_client_after_network_error(caplog):
    caplog.set_level(logging.INFO,logger='app.scraper.client')
    async def run():
        n=0
        async def respond(request):
            nonlocal n
            n+=1
            if n==1: raise httpx.RemoteProtocolError('Server disconnected without sending a response. PRIVATE',request=request)
            return httpx.Response(503,headers={'Retry-After':'120','Set-Cookie':'PRIVATE','Connection':'close'})
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        try:
            for kind in ['network','throttle']:
                with pytest.raises(UpstreamError) as e: await client.states()
                assert e.value.kind==kind and e.value.source_failure
            a,b=diagnostics(caplog)
            assert a['client_generation']!=b['client_generation']
            assert b['response_headers']=={'retry-after':120,'connection':'close'}
            assert b['bootstrap'] and b['session_age_s'] is None
        finally: await client.close()
    asyncio.run(run())
    assert 'PRIVATE' not in '\n'.join(r.getMessage() for r in caplog.records if r.name=='app.scraper.client')


@pytest.mark.parametrize('acts,message',[(None,'Invalid court act list'),('1~Valid Act#2~','Incomplete court act catalogue entry')])
def test_verified_act_failures_remain_explicit_and_do_not_invalidate_session(acts,message):
    async def run():
        calls=[]
        def respond(request):
            calls.append(request.url.path)
            data={'token':'synthetic'} if 'appRelease' in request.url.path else {'actsList':[{'acts':acts}]}
            return httpx.Response(200,text=encrypted_response(data))
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(respond))
        try:
            for _ in range(2):
                with pytest.raises(UpstreamError,match=message) as e: await client.acts(scope())
                assert e.value.kind=='validation' and not e.value.source_failure
                assert client.token=='synthetic' and not client.reset_transport
            assert len(calls)==3  # Session once; no extra diagnostic/source requests.
        finally: await client.close()
    asyncio.run(run())


def test_trace_and_context_allowlists_do_not_serialize_untrusted_objects():
    assert safe_context({'id':'SECRET','kind':'SECRET','payload':{'state':{'code':'SECRET'},'cnr':'SECRET'}})=={}
    error=httpx.RemoteProtocolError('illegal header line SECRET params=SECRET')
    assert exception_details(error)=={'exception_chain':['RemoteProtocolError'],'failure_categories':['invalid_header_line']}


def test_cancelled_local_request_remains_cancelled(caplog):
    caplog.set_level(logging.INFO,logger='app.scraper.client')
    async def run():
        started=asyncio.Event()
        async def hang(request):
            started.set();await asyncio.Event().wait()
        client=ECourtsClient(interval=0,transport=httpx.MockTransport(hang))
        task=asyncio.create_task(client.states())
        await started.wait();task.cancel()
        with pytest.raises(asyncio.CancelledError): await task
        await client.close()
        assert len(diagnostics(caplog))==1
    asyncio.run(run())
    assert any('outcome=cancelled' in r.getMessage() for r in caplog.records)


@pytest.mark.parametrize('task',[None,[],{'payload':None},{'payload':{'state':None,'court':[]}}])
def test_malformed_context_does_not_interrupt_requests(task):
    assert safe_context(task)=={}
