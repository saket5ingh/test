import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ['DATABASE_URL'] = 'postgresql+asyncpg://test:test@127.0.0.1:1/ffg_test'
os.environ['JWT_SECRET'] = 'test-only-key-with-at-least-32-characters'
