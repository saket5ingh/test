"""Upgrade/rollback/reconciliation rehearsal in a newly-created localhost database."""
import asyncio
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from uuid import uuid4
import asyncpg
import pytest
from sqlalchemy.engine import make_url

pytestmark=pytest.mark.skipif(not os.getenv('FFG_TEST_PG_OWNER'),reason='Isolated PostgreSQL URL not supplied')
ROOT=Path(__file__).resolve().parents[2]


def test_additive_upgrade_preserves_old_rows_reruns_and_reconciles(tmp_path):
    async def run():
        source=make_url(os.environ['FFG_TEST_PG_OWNER'])
        assert source.host in ('localhost','127.0.0.1') and source.database.endswith('_test')
        assert shutil.which('psql'), 'Install the PostgreSQL client for migration tests'
        name='ffg_upgrade_'+uuid4().hex[:12]+'_test'
        url=source.set(drivername='postgresql',database=name)
        admin=await asyncpg.connect(source.set(drivername='postgresql').render_as_string(hide_password=False))
        await admin.execute(f'CREATE DATABASE "{name}" TEMPLATE template0 ENCODING \'UTF8\'')
        env={**os.environ,'PGHOST':url.host,'PGPORT':str(url.port or 5432),'PGUSER':url.username,'PGPASSWORD':url.password or ''}
        def apply(path,check=True):
            return subprocess.run(['psql','-X','-q','-v','ON_ERROR_STOP=1','--single-transaction','-d',name,'-f',str(path)],env=env,check=check,capture_output=True,text=True)
        db=None
        try:
            sql=(ROOT/'db/migrate.sql').read_text()
            old=sql[:sql.index('SELECT NOT EXISTS (SELECT 1 FROM pcma.schema_migrations WHERE version = 7)')]
            old=re.sub(r'\\ir (.+)',lambda m:'\\ir '+str(ROOT/'db'/m[1]),old)
            path=tmp_path/'before.sql';path.write_text(old);apply(path)
            db=await asyncpg.connect(url.render_as_string(hide_password=False))
            run_id,uid,cid=uuid4(),uuid4(),uuid4()
            await db.execute("INSERT INTO pcma.users(id,user_id,email,name,password_hash,role) VALUES($1,'synthetic-upgrade','synthetic@example.test','Synthetic','disabled','admin')",uid)
            await db.execute("INSERT INTO pcma.scrape_runs(id,name,outcome,triggered_by,snapshot_version) VALUES($1,'Synthetic upgrade','running',$2,1)",run_id,uid)
            await db.execute("INSERT INTO pcma.cases(id,cnr_number,case_ref,state,district,status) VALUES($1,'SYNTHETIC-UPGRADE','SYNTHETIC','Bihar','Gaya','pending')",cid)
            await db.execute('INSERT INTO pcma.case_pins(user_id,case_id) VALUES($1,$2)',uid,cid)
            await db.execute("INSERT INTO pcma.scrape_run_cases(run_id,case_id,snapshot,change_kind) VALUES($1,$2,'{\"synthetic\":true}','new')",run_id,cid)
            for state in ('queued','running','failed','success','cancelled'):
                await db.execute("""INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload,status,attempts,retry_base,started_at,completed_at,error_message)
                    VALUES($1,$2::text,'case','{"cnr":"SYNTHETIC-UPGRADE"}',$2,3,1,now(),CASE WHEN $2 IN ('failed','success','cancelled') THEN now() END,'Synthetic old error')""",run_id,state)
            tables=('users','cases','case_pins','scrape_run_cases','scrape_runs','scrape_tasks')
            async def snapshot():
                out={}
                for table in tables:
                    rows=await db.fetch(f"SELECT (to_jsonb(t)-'dispatch_cursor'-'lease_owner'-'lease_until'-'claim_version'-'expanding'-'error_kind'-'source_attempts'-'review_failures'-'review_sessions'-'review_started_at'-'review_last_session'-'review_required'-'review_reason'-'review_at'-'review_evidence'-'source_validated_at')::text AS row FROM pcma.{table} t ORDER BY 1")
                    out[table]=[r['row'] for r in rows]
                return out
            before=await snapshot()
            # Failure after DDL must roll back the whole upgrade and derived state.
            failed=tmp_path/'failed.sql';failed.write_text((ROOT/'db/migrations/007_scraper_performance.sql').read_text()+'\nSELECT 1/0;\n')
            result=apply(failed,check=False)
            assert result.returncode!=0 and 'division by zero' in result.stderr
            assert await db.fetchval("SELECT to_regclass('pcma.scraper_control')") is None
            assert await snapshot()==before
            apply(ROOT/'db/migrate.sql'); apply(ROOT/'db/migrate.sql')
            assert await snapshot()==before
            assert await db.fetchval('SELECT count(*) FROM pcma.schema_migrations WHERE version=7')==1
            assert await db.fetchval('SELECT sum(total) FROM pcma.scrape_task_counts')==5
            assert await db.fetchval('SELECT sum(total) FROM pcma.scrape_result_counts')==1
            await db.execute('UPDATE pcma.scrape_task_counts SET total=total+7')
            apply(ROOT/'db/reconcile_scraper.sql');apply(ROOT/'db/reconcile_scraper.sql')
            assert await db.fetchval('SELECT sum(total) FROM pcma.scrape_task_counts')==5
            assert await snapshot()==before
            # Cascading deletion of an empty synthetic run must not resurrect counters.
            empty=uuid4()
            await db.execute("INSERT INTO pcma.scrape_runs(id,name,outcome) VALUES($1,'Disposable cascade','queued')",empty)
            await db.execute("INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload) VALUES($1,'cascade','discover','{}')",empty)
            await db.execute('DELETE FROM pcma.scrape_runs WHERE id=$1',empty)
            assert await db.fetchval('SELECT count(*) FROM pcma.scrape_task_counts WHERE run_id=$1',empty)==0
        finally:
            if db: await db.close()
            await admin.execute(f'DROP DATABASE "{name}"')
            await admin.close()
    asyncio.run(run())
