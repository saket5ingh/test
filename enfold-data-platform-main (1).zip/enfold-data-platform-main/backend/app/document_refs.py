"""Stable eCourts references, never session tokens or generated download URLs."""
import hashlib
import json

REFERENCE_FIELDS = ('filename', 'caseno', 'cCode', 'appFlag', 'state_cd', 'dist_cd', 'court_code')


def clean_reference(value):
    if not isinstance(value, dict):
        raise ValueError('Invalid document reference')
    result = {}
    for key in REFERENCE_FIELDS:
        field = value.get(key, '')
        if not isinstance(field, (str, int)) or isinstance(field, bool):
            raise ValueError('Invalid document reference field')
        field = str(field).strip()
        if len(field) > 4096 or any(ord(c) < 32 for c in field):
            raise ValueError('Invalid document reference field')
        result[key] = field
    if not all(result[k] for k in ('filename', 'state_cd', 'dist_cd', 'court_code')):
        raise ValueError('Incomplete document reference')
    return result


def reference_key(reference):
    # Filename is scoped by court; optional display fields may change on refresh.
    identity = {k: reference[k] for k in ('filename', 'state_cd', 'dist_cd', 'court_code')}
    return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
