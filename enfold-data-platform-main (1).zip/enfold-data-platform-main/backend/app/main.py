from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError
from app.database import get_db
from app.config import settings
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth, cases, analytics, scrapes, options, google_auth, documents

app = FastAPI(title="Enfold eCourts API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(google_auth.router, prefix="/api")
app.include_router(cases.router, prefix="/api")
app.include_router(documents.router, prefix="/api")
app.include_router(analytics.router, prefix="/api")
app.include_router(scrapes.router, prefix="/api")
app.include_router(options.router, prefix="/api")

@app.get("/api/health")
def health_check():
    return {"status": "ok"}


@app.get("/api/ready")
async def readiness(db: AsyncSession = Depends(get_db)):
    try:
        # Verify schema access and the latest required migration, not just connectivity.
        await db.execute(text("SELECT user_id, case_id FROM pcma.case_pins LIMIT 0"))
        await db.execute(text("SELECT source_reference, source_key FROM pcma.case_documents LIMIT 0"))
        await db.execute(text("SELECT run_id FROM pcma.scrape_run_cases LIMIT 0"))
        await db.execute(text("SELECT total FROM pcma.scrape_task_counts LIMIT 0"))
        await db.execute(text("SELECT deferred_tasks FROM pcma.scrape_run_progress LIMIT 0"))
        await db.execute(text("SELECT claim_version,expanding,source_attempts,review_required,source_validated_at FROM pcma.scrape_tasks LIMIT 0"))
        await db.execute(text("SELECT auth_version, google_sub FROM pcma.users LIMIT 0"))
    except (SQLAlchemyError, OSError, TimeoutError):
        raise HTTPException(status_code=503, detail="Database is not ready")
    return {"status": "ok"}
