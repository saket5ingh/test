"""Provision/update an account using a database-owner DATABASE_URL, never the API role."""
import asyncio
import getpass
import bcrypt
from sqlalchemy import select
from app.database import async_session_maker
from app.models.user import User


async def main():
    user_id = input("User ID: ").strip()
    email = input("Email: ").strip().lower()
    name = input("Name: ").strip()
    role = input("Role (user/admin): ").strip()
    password = getpass.getpass("New password: ")
    if not all((user_id, email, name)) or role not in ('user', 'admin'):
        raise SystemExit("User ID, email, name and a valid role are required.")
    if not 12 <= len(password.encode('utf-8')) <= 72:
        raise SystemExit("Use a password of 12–72 UTF-8 bytes.")
    if password != getpass.getpass("Confirm password: "):
        raise SystemExit("Passwords do not match.")
    async with async_session_maker() as db:
        user = (await db.execute(select(User).where(User.user_id == user_id))).scalar_one_or_none()
        if user is None:
            user = User(user_id=user_id, auth_version=0)
            db.add(user)
        else:
            user.auth_version += 1
            if user.email.lower() != email:
                user.google_sub = None
        user.email, user.name, user.role = email, name, role
        user.role_label = 'Administrator' if role == 'admin' else 'Field Officer'
        user.initials = ''.join(part[0] for part in name.split())[:2].upper()
        user.password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        user.is_active = True
        await db.commit()
    print("Account saved.")


if __name__ == '__main__':
    asyncio.run(main())
