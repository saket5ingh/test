"""Run with python -m app.scraper.worker using the dedicated worker DB role.

One advisory-locked coordinator runs a bounded pool behind durable global pacing. PostgreSQL persists
all task checkpoints. No request handler performs scraping or starts a thread.
"""
import asyncio
from collections import deque
import json
import logging
import signal
from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from pydantic import ValidationError
from app.config import settings
from app.scraper.schedule import due_month
from app.scraper import quarantine
from app.database import engine, async_session_maker
from app.scraper.catalog import ACTS, CATALOG
from app.scraper.client import ECourtsClient, UpstreamError
from app.scraper.contracts import RunRequest
from app.scraper.normalize import normalize
from app.scraper.store import event, create_run, ingest, stage_children, expand_batch
from app.scraper.control import SourceGate, SourceDeferred, OwnershipLost, control_row

log = logging.getLogger(__name__)
LOCK_ID = 772639105


async def metadata(db, key, value):
    await db.execute(text('''INSERT INTO pcma.scraper_metadata(key,value) VALUES (:key, CAST(:value AS jsonb))
        ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, updated_at=CURRENT_TIMESTAMP'''),
        dict(key=key, value=json.dumps(value)))


async def schedule(db, now):
    month = due_month(now)
    if not month: return
    # At most one monthly run for each month, including restarts. Never overlap
    # another scheduled scan that has not finished; check again on later ticks.
    exists = (await db.execute(text("SELECT 1 FROM pcma.scrape_runs WHERE schedule_key=:key OR (trigger_type='scheduled' AND outcome IN ('queued','running')) LIMIT 1"), dict(key=month))).scalar_one_or_none()
    if exists: return
    request = RunRequest(name=f'Monthly child-marriage scan — {month}', allStates=True,
                         actKeys=['childmarriage'],
                         status='all', requestId=uuid4())
    await create_run(db, request, schedule_key=month)


async def perform(client, task, criteria):
    """Network-only phase. Return work to commit atomically after cancellation check."""
    kind, scope = task['kind'], task['payload']
    children = []
    notes = []
    resolved = None
    record = None
    if kind == 'discover':
        states = await client.states()
        chosen = states if criteria['allStates'] else [s for s in states if s['code'] in criteria['stateCodes']]
        if not chosen or (not criteria['allStates'] and len(chosen) != len(criteria['stateCodes'])):
            raise ValueError('One or more requested states are unavailable')
        resolved = {'states': chosen, 'actKeys': list(ACTS) if criteria['allActs'] else criteria['actKeys'],
                    'actMapping': CATALOG.identity}
        children = [('state', {'state': state}, None) for state in chosen]
    elif kind == 'state':
        children = [('district', {**scope, 'district': district}, None)
                    for district in await client.districts(scope['state']['code'])]
    elif kind == 'district':
        children = [('court', {**scope, 'court': court}, None)
                    for court in await client.courts(scope['state']['code'], scope['district']['code'])]
    elif kind == 'court':
        rows = await client.acts(scope)
        keys = list(ACTS) if criteria['allActs'] else criteria['actKeys']
        statuses = ['Pending', 'Disposed'] if criteria['status'] == 'all' else [criteria['status'].title()]
        for key in keys:
            matches, review = CATALOG.resolve(rows, key)
            location = f"state {scope['state']['code']}, district {scope['district']['code']}, court {scope['court']['code']}"
            for candidate in review:
                notes.append(('act_mapping_review', json.dumps({'option': key, **candidate,
                    'location': location, 'config': CATALOG.identity}, ensure_ascii=True)))
            if not matches:
                notes.append(('act_unavailable', f"No approved act-name match: {ACTS[key][0]}; {location}"))
            for match in matches:
                for status in statuses:
                    for section in criteria['sections'] or ['']:
                        payload = {**scope, 'act_code': match['code'], 'act_mapping': match,
                                   'status': status, 'section': section}
                        # Mapping metadata must not change the identity of a search
                        # already queued by an older release or another option.
                        identity = json.dumps({k: v for k, v in payload.items() if k != 'act_mapping'}, sort_keys=True)
                        children.append(('search', payload, identity))
    elif kind == 'search':
        for row in await client.search(scope):
            cnr = str(row.get('cino') or '').strip().upper()
            if not cnr: raise ValueError('Search returned a case without a CNR')
            children.append(('case', {**scope, 'cnr': cnr, 'case_no': row.get('case_no')}, cnr))
    elif kind == 'case':
        record = normalize(await client.history(scope), scope)
        warning = record.pop('documentWarning', None)
        if warning: notes.append(('document_warning', warning))
    return children, notes, resolved, record


async def finalize(db, run_id):
    counts = dict((await db.execute(text('SELECT status,sum(total) FROM pcma.scrape_task_counts WHERE run_id=:run GROUP BY status'), dict(run=run_id))).all())
    if counts.get('queued', 0) or counts.get('running', 0): return
    row = (await db.execute(text('SELECT outcome,cancel_requested FROM pcma.scrape_runs WHERE id=:run FOR UPDATE'), dict(run=run_id))).mappings().one()
    found = (await db.execute(text('SELECT COALESCE(sum(total),0) FROM pcma.scrape_result_counts WHERE run_id=:run'), dict(run=run_id))).scalar_one()
    outcome = 'cancelled' if row['cancel_requested'] else ('partial' if found else 'failed') if counts.get('failed', 0) else 'success'
    await db.execute(text('UPDATE pcma.scrape_runs SET total_cases_found=:found WHERE id=:run'), dict(run=run_id, found=found))
    if row['outcome'] != outcome:
        await db.execute(text('UPDATE pcma.scrape_runs SET outcome=:outcome,completed_at=CURRENT_TIMESTAMP,total_cases_found=:found WHERE id=:run'), dict(run=run_id,outcome=outcome,found=found))
        await event(db, run_id, outcome, f'Run {outcome}; {found} case snapshots, {counts.get("failed", 0)} failed tasks')


# Persisted weighted round-robin: case details get four slots while every
# producer kind gets a turn. Under backpressure, cases get 32 of 37 slots;
# every producer still gets a turn, without expanding checkpoints at capacity.
FAIR_KINDS = ('case','search','case','court','case','district','case','state','discover')
PRESSURE_KINDS = ('case',)*8+('search',)+('case',)*8+('court',)+('case',)*8+('district',)+('case',)*8+('state','discover')


async def claim(db, owner=None):
    if owner is not None:
        control=await control_row(db,owner)
        if control['paused_until'] and control['paused_until']>control['now']: return None
    run=(await db.execute(text('''SELECT r.id,r.dispatch_cursor FROM pcma.scrape_runs r
        WHERE NOT r.cancel_requested AND r.outcome IN ('queued','running')
        ORDER BY r.queued_at,r.id FOR UPDATE OF r SKIP LOCKED LIMIT 1'''))).mappings().first()
    if run is None: return None
    pending=(await db.execute(text("SELECT COALESCE(sum(total),0) FROM pcma.scrape_task_counts WHERE run_id=:run AND status IN ('queued','running')"),{'run':run['id']})).scalar_one()
    pressure=pending>=settings.SCRAPER_QUEUE_HIGH_WATER
    rotation=PRESSURE_KINDS if pressure else FAIR_KINDS
    start=run['dispatch_cursor']%len(rotation)
    order=[((start+i)%len(rotation),rotation[(start+i)%len(rotation)],False) for i in range(len(rotation))]
    # At capacity, admit each producer's source response once into a durable
    # checkpoint, but defer checkpoint expansion while drainable work exists.
    # If only checkpoints remain, allow one child to break producer-only deadlock.
    if pressure: order += [(0,kind,True) for kind in dict.fromkeys(rotation)]
    seen=set()
    for position,kind,drain_checkpoint in order:
        if (kind,drain_checkpoint) in seen: continue
        seen.add((kind,drain_checkpoint))
        task=(await db.execute(text('''SELECT * FROM pcma.scrape_tasks WHERE run_id=:run AND kind=:kind
            AND status='queued' AND available_at<=CURRENT_TIMESTAMP
            AND (NOT :pressure OR NOT expanding OR :drain)
            ORDER BY available_at,id FOR UPDATE SKIP LOCKED LIMIT 1'''),{'run':run['id'],'kind':kind,'pressure':pressure,'drain':drain_checkpoint})).mappings().first()
        if task is None: continue
        task=dict(task)
        task['_drain_checkpoint']=drain_checkpoint
        task['attempts']+=0 if task['expanding'] else 1
        task['claim_version']+=1
        task['lease_owner']=owner
        await db.execute(text('''UPDATE pcma.scrape_tasks SET status='running',attempts=:attempts,
            claim_version=:claim_version,lease_owner=:lease_owner,
            lease_until=clock_timestamp()+make_interval(secs=>:lease),started_at=CURRENT_TIMESTAMP
            WHERE id=:id'''),{**task,'lease':settings.SCRAPER_LEASE_SECONDS})
        await db.execute(text("UPDATE pcma.scrape_runs SET dispatch_cursor=:cursor,outcome='running',started_at=COALESCE(started_at,CURRENT_TIMESTAMP) WHERE id=:run"),
                         {'run':run['id'],'cursor':(position+1)%len(rotation)})
        if not task['expanding'] and (kind!='case' or task['attempts']>1):
            await event(db,run['id'],'task_started',f"{kind} task, attempt {task['attempts']}",task['id'])
        return task
    return None


async def owns_task(db,task):
    return (await db.execute(text('''SELECT 1 FROM pcma.scrape_tasks WHERE id=:id AND status='running'
        AND attempts=:attempts AND claim_version=:claim_version
        AND lease_owner IS NOT DISTINCT FROM :lease_owner
        AND lease_until>clock_timestamp() FOR UPDATE'''),task)).scalar_one_or_none()


async def execute_task(client, task, guard=None):
    async with async_session_maker() as db:
        criteria=(await db.execute(text('SELECT criteria FROM pcma.scrape_runs WHERE id=:run'),dict(run=task['run_id']))).scalar_one()
    failure=deferred=None
    children,notes,resolved,record=[],[],None,None
    if hasattr(client,'set_context'): client.set_context(task)
    if not task['expanding']:
        try:
            children,notes,resolved,record=await perform(client,task,criteria)
        except SourceDeferred as error:
            deferred=error
        except (UpstreamError,ValueError,KeyError,TypeError) as error:
            failure=error if isinstance(error,UpstreamError) else UpstreamError(
                str(error) if isinstance(error,ValueError) else f'Unexpected upstream structure ({type(error).__name__})', kind='validation')
    if guard is not None:
        await guard.execute(text('SELECT 1')); await guard.commit()
    gate=getattr(client,'limiter',None)
    async with async_session_maker() as db,db.begin():
        # Uniform lock order: control -> run -> task -> CNR. A coordinator that
        # lost ownership cannot commit a late result after its replacement starts.
        if task['lease_owner'] is not None: await control_row(db,task['lease_owner'])
        run=(await db.execute(text('SELECT cancel_requested FROM pcma.scrape_runs WHERE id=:run FOR UPDATE'),dict(run=task['run_id']))).mappings().one()
        if not await owns_task(db,task): return
        if run['cancel_requested']:
            await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled',completed_at=CURRENT_TIMESTAMP,lease_owner=NULL,lease_until=NULL WHERE id=:id"),task)
        elif deferred:
            # No request was admitted: keep attempts monotonic but restore budget.
            await db.execute(text('''UPDATE pcma.scrape_tasks SET status='queued',retry_base=retry_base+1,
                available_at=clock_timestamp()+make_interval(secs=>:delay),error_message=NULL,error_kind=NULL,
                lease_owner=NULL,lease_until=NULL WHERE id=:id'''),{**task,'delay':deferred.seconds})
        elif failure:
            evidence=await quarantine.assess(db,task,failure)
            circuit_error=UpstreamError('Court response isolated for operator review',kind='validation') if evidence else failure
            opened=await gate.report(db,circuit_error,task=task) if isinstance(gate,SourceGate) else False
            source=failure.source_failure
            source_attempts=task.get('source_attempts',0)+int(source)
            # Source outages do not spend the record-validation budget. Attempts
            # stay monotonic for fencing/audit; every actual source failure counts.
            terminal=bool(evidence) or (not source and task['attempts']-task['retry_base']>=settings.SCRAPER_MAX_ATTEMPTS)
            exponent=source_attempts-1 if source else task['attempts']-task['retry_base']-1
            delay=max(min(1800,30*2**min(10,max(0,exponent))),failure.retry_after or 0)
            await db.execute(text('''UPDATE pcma.scrape_tasks SET status=:status,error_message=:error,error_kind=:kind,
                retry_base=retry_base+:credit,source_attempts=:source_attempts,
                available_at=clock_timestamp()+make_interval(secs=>:delay),lease_owner=NULL,lease_until=NULL,
                completed_at=CASE WHEN :terminal THEN CURRENT_TIMESTAMP ELSE NULL END WHERE id=:id'''),
                dict(id=task['id'],status='failed' if terminal else 'queued',error=str(failure)[:1000],kind=failure.kind,delay=delay,terminal=terminal,credit=int(source),source_attempts=source_attempts))
            await event(db,task['run_id'],'task_failed' if terminal else 'task_retry',str(failure)[:1000],task['id'])
            if evidence:
                reason=await quarantine.mark(db,task,evidence)
                await event(db,task['run_id'],'operator_review_required',json.dumps({'reason':reason,'evidence':evidence}),task['id'])
            if source and not evidence and (source_attempts==settings.SCRAPER_SOURCE_RETRY_ALERT_AFTER or
                           source_attempts>settings.SCRAPER_SOURCE_RETRY_ALERT_AFTER and source_attempts%20==0):
                message=f'Source unavailable after {source_attempts} attempts; task retained for delayed retry (local backoff up to 1800 seconds; upstream Retry-After may require longer); saved data preserved. Operator attention required.'
                await event(db,task['run_id'],'source_retry_alert',message,task['id'])
                log.warning('source_retry_alert run=%s task=%s source_attempts=%s',task['run_id'],task['id'],source_attempts)
            if opened: await event(db,task['run_id'],'source_paused','Repeated source failures; shared cooldown before one recovery probe',task['id'])
            await db.execute(text('UPDATE pcma.scrape_runs SET error_message=:message WHERE id=:run'),dict(run=task['run_id'],message=str(failure)[:1000]))
        else:
            if not task['expanding']:
                if isinstance(gate,SourceGate): await gate.report(db,task=task)
                await stage_children(db,task,children,settings.SCRAPER_INSERT_BATCH)
                for kind,note in notes: await event(db,task['run_id'],kind,note,task['id'])
                if resolved:
                    await db.execute(text('UPDATE pcma.scrape_runs SET resolved_scope=CAST(:scope AS jsonb) WHERE id=:run'),dict(run=task['run_id'],scope=json.dumps(resolved)))
                if record: await ingest(db,task['run_id'],record)
            more=await expand_batch(db,task,settings.SCRAPER_QUEUE_HIGH_WATER,settings.SCRAPER_INSERT_BATCH)
            await db.execute(text('''UPDATE pcma.scrape_tasks SET status=:status,expanding=:more,
                source_validated_at=CASE WHEN :validated THEN clock_timestamp() ELSE source_validated_at END,
                error_message=NULL,error_kind=NULL,lease_owner=NULL,lease_until=NULL,
                available_at=CURRENT_TIMESTAMP,completed_at=CASE WHEN :more THEN NULL ELSE CURRENT_TIMESTAMP END WHERE id=:id'''),
                {**task,'more':more,'validated':not task['expanding'],'status':'queued' if more else 'success'})
            if not more and task['kind']!='case': await event(db,task['run_id'],'task_completed',f"{task['kind']} task completed",task['id'])
        await finalize(db,task['run_id'])


async def reject_data(task, error_type):
    # A malformed record must not crash/restart forever and block every later case.
    # execute_task's transaction has rolled back before this independent audit write.
    async with async_session_maker() as db, db.begin():
        if task.get('lease_owner') is not None: await control_row(db,task['lease_owner'])
        run = (await db.execute(text('SELECT cancel_requested FROM pcma.scrape_runs WHERE id=:run FOR UPDATE'), {'run':task['run_id']})).mappings().one()
        if not await owns_task(db,task): return
        result = await db.execute(text("UPDATE pcma.scrape_tasks SET status=:status,error_kind='data',error_message=:error,completed_at=CURRENT_TIMESTAMP,lease_owner=NULL,lease_until=NULL WHERE id=:id AND status='running' AND attempts=:attempts"),
            {'id':task['id'],'attempts':task['attempts'],'status':'cancelled' if run['cancel_requested'] else 'failed',
             'error':f'Record rejected by database validation ({error_type}); existing data preserved'})
        if result.rowcount:
            await db.execute(text('UPDATE pcma.scrape_runs SET error_message=:error WHERE id=:run'),
                {'run':task['run_id'],'error':f'Record rejected by database validation ({error_type}); existing data preserved'})
            await event(db,task['run_id'],'data_rejected',f'Database validation rejected task ({error_type}); inspect the source mapping',task['id'])
            await finalize(db,task['run_id'])


async def process_task(client, task, guard=None):
    try:
        await execute_task(client, task, guard)
    except ValidationError:
        await reject_data(task, 'ValidationError')
    except DBAPIError as error:
        # asyncpg can wrap data errors in DBAPIError rather than DataError.
        # SQLSTATE classes 22/23 identify data/constraint rejection; connection
        # and server errors must still stop the worker for safe recovery.
        code = getattr(error.orig, 'sqlstate', '') or ''
        if code[:2] not in ('22', '23'): raise
        await reject_data(task, code)


async def recover(db, owner=None, expired_only=False):
    if owner is not None: await control_row(db,owner)
    runs=(await db.execute(text("""SELECT r.id,r.cancel_requested FROM pcma.scrape_runs r
        WHERE r.snapshot_version=1 AND (r.outcome IN ('queued','running') OR
          (r.outcome='cancelled' AND EXISTS (SELECT 1 FROM pcma.scrape_tasks t
            WHERE t.run_id=r.id AND t.status IN ('queued','running'))))
        ORDER BY r.id FOR UPDATE OF r"""))).mappings().all()
    for run in runs:
        params={'run':run['id'],'expired':expired_only}
        rows=(await db.execute(text("""UPDATE pcma.scrape_tasks SET status='queued',available_at=CURRENT_TIMESTAMP,
            retry_base=retry_base+CASE WHEN NOT expanding AND attempts>retry_base THEN 1 ELSE 0 END,
            lease_owner=NULL,lease_until=NULL,error_message=NULL,error_kind=NULL
            WHERE run_id=:run AND status='running' AND (NOT :expired OR lease_until<clock_timestamp()) RETURNING id"""),params)).scalars().all()
        for task_id in rows: await event(db,run['id'],'task_recovered','Interrupted task requeued; uncompleted request budget restored, checkpoint work not credited; attempts and claim version preserved',task_id)
        if run['cancel_requested']:
            await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled',completed_at=CURRENT_TIMESTAMP WHERE run_id=:run AND status='queued'"),params)
        await finalize(db,run['id'])


async def refresh_catalog(client, owner):
    if hasattr(client,'set_context'): client.set_context(None)
    # A catalogue refresh is a cancellable pool operation, so a slow bootstrap
    # cannot block heartbeat, lease renewal or shutdown in the coordinator.
    try:
        states=await client.states()
        async with async_session_maker() as db,db.begin():
            await control_row(db,owner)
            await metadata(db,'states',states)
            await client.limiter.report(db,representative=False)
    except UpstreamError as error:
        async with async_session_maker() as db,db.begin(): await client.limiter.report(db,error)
        log.warning('State catalogue refresh failed; existing catalogue preserved')
    except SourceDeferred:
        log.warning('State catalogue refresh deferred; existing catalogue preserved')


async def run_pool(guard, owner, stop, client_factory=ECourtsClient):
    """Bounded task pool. Only this loop uses the advisory-lock connection."""
    clients=[client_factory(interval=settings.SCRAPER_REQUEST_INTERVAL,
        limiter=SourceGate(async_session_maker,owner)) for _ in range(settings.SCRAPER_CONCURRENCY)]
    idle=list(clients); active={}; heartbeat_at=0.0; refresh_at=0.0; request_samples=deque(maxlen=60)
    try:
        while not stop.is_set():
            now=asyncio.get_running_loop().time()
            if now>=heartbeat_at:
                held=(await guard.execute(text("SELECT EXISTS(SELECT 1 FROM pg_locks WHERE locktype='advisory' AND pid=pg_backend_pid() AND objid=:key AND granted)"),{'key':LOCK_ID})).scalar_one()
                await guard.commit()
                if not held: raise OwnershipLost('Coordinator advisory lock lost')
                async with async_session_maker() as db,db.begin():
                    control=await control_row(db,owner)
                    await recover(db,owner,expired_only=True)
                    if control['last_request_at']:
                        request_samples.append((control['requests'],control['last_request_at']))
                    observed_interval=None
                    if len(request_samples)>1:
                        count=control['requests']-request_samples[0][0]
                        if count>0: observed_interval=round((control['last_request_at']-request_samples[0][1]).total_seconds()/count,3)
                    await db.execute(text("UPDATE pcma.scrape_tasks SET lease_until=clock_timestamp()+make_interval(secs=>:lease) WHERE lease_owner=:owner AND status='running' AND lease_until>clock_timestamp()"),{'owner':owner,'lease':settings.SCRAPER_LEASE_SECONDS})
                    await metadata(db,'worker',{'status':'running','concurrency':len(clients),'inFlight':sum(task is not None for _,task in active.values()),
                        'requestIntervalSeconds':settings.SCRAPER_REQUEST_INTERVAL,'observedRequestIntervalSeconds':observed_interval,'sourcePausedUntil':control['paused_until'].isoformat() if control['paused_until'] else None,
                        'sourceFailureStreak':control['failure_streak'],'sourceErrorKind':control['last_error_kind'],
                        'sourceRecoverySuccesses':control['recovery_successes'],'sourceRecoveryRequired':settings.SCRAPER_RECOVERY_SUCCESSES,
                        'requests':control['requests'],'lastRequestAt':control['last_request_at'].isoformat() if control['last_request_at'] else None})
                    await schedule(db,datetime.now(timezone.utc))
                heartbeat_at=now+5
            # Catalogue refresh shares one pool slot and the global admission gate.
            if now>=refresh_at and idle and not active:
                client=idle.pop()
                active[asyncio.create_task(refresh_catalog(client,owner))]=(client,None)
                refresh_at=now+3600
            while idle and not stop.is_set():
                async with async_session_maker() as db,db.begin(): task=await claim(db,owner)
                if task is None: break
                client=idle.pop()
                future=asyncio.create_task(process_task(client,task))
                active[future]=(client,task)
            if active:
                done,_=await asyncio.wait(active,timeout=1,return_when=asyncio.FIRST_COMPLETED)
                for future in done:
                    client,_=active.pop(future); idle.append(client); future.result()
            else:
                try: await asyncio.wait_for(stop.wait(),timeout=1)
                except asyncio.TimeoutError: pass
    finally:
        if active:
            _,pending=await asyncio.wait(active,timeout=settings.SCRAPER_SHUTDOWN_SECONDS)
            for future in pending: future.cancel()
            await asyncio.gather(*active,return_exceptions=True)
        for client in clients: await client.close()
        # Shutdown/checkpoint recovery remains fenced by ownership. A replacement
        # coordinator, never a stale process, owns recovery after connection loss.
        try:
            async with async_session_maker() as db,db.begin(): await recover(db,owner)
        except Exception:
            log.warning('Shutdown left durable leases for coordinator recovery')


async def main():
    stop=asyncio.Event(); loop=asyncio.get_running_loop()
    for sig in (signal.SIGINT,signal.SIGTERM): loop.add_signal_handler(sig,stop.set)
    owner=uuid4()
    try:
        async with engine.connect() as guard:
            locked=(await guard.execute(text('SELECT pg_try_advisory_lock(:key)'),{'key':LOCK_ID})).scalar_one()
            if not locked: raise RuntimeError('Another scraper coordinator already owns the global lock')
            await guard.commit()
            async with async_session_maker() as db,db.begin():
                await db.execute(text('UPDATE pcma.scraper_control SET owner=:owner,probe_owner=NULL,probe_until=NULL WHERE id=TRUE'),{'owner':owner})
                await recover(db,owner)
            await run_pool(guard,owner,stop)
    except Exception as error:
        # Driver exceptions may contain bound case records or database URLs.
        # Stop for durable recovery without printing the original traceback.
        log.error('Worker stopped after %s; durable work retained',type(error).__name__)
        raise RuntimeError(f'Worker stopped after {type(error).__name__}; durable work retained') from None
    finally:
        for sig in (signal.SIGINT,signal.SIGTERM): loop.remove_signal_handler(sig)
        await engine.dispose()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('httpcore').setLevel(logging.WARNING)
    asyncio.run(main())
