import asyncio
from sqlalchemy import text
from app.database import engine

async def check():
    async with engine.connect() as connection:
        fresh = (await connection.execute(text("SELECT EXISTS (SELECT 1 FROM pcma.scraper_metadata WHERE key='worker' AND updated_at > CURRENT_TIMESTAMP - INTERVAL '10 minutes')"))).scalar_one()
    await engine.dispose()
    if not fresh: raise SystemExit('Scraper heartbeat is stale')

if __name__ == '__main__': asyncio.run(check())
