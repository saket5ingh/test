"""Parameterized persistence for durable jobs, snapshots and notifications."""
import hashlib
import json
from datetime import datetime, timezone, date
from uuid import uuid4
from sqlalchemy import text, select
from sqlalchemy.orm import noload, selectinload
from app.models.case import Case
from app.models.hearing import CaseHearing
from app.schemas.case import CaseSchema
from app.scraper.normalize import change_notice


def utcnow(): return datetime.now(timezone.utc)


async def event(db, run_id, kind, message, task_id=None, actor_id=None):
    await db.execute(text('''INSERT INTO pcma.scrape_run_events(run_id, task_id, kind, message, actor_id)
        VALUES (:run, :task, :kind, :message, :actor)'''),
        dict(run=run_id, task=task_id, kind=kind, message=message, actor=actor_id))


def child_row(run_id, kind, payload, identity=None):
    identity = identity or json.dumps(payload, sort_keys=True)
    return {'run_id':str(run_id), 'task_key':kind + ':' + hashlib.sha256(identity.encode()).hexdigest(),
            'kind':kind, 'payload':payload}


async def enqueue_many(db, run_id, children, batch_size=500):
    """One statement per bounded batch; uniqueness and counters apply to inserted rows only."""
    inserted = 0
    for offset in range(0, len(children), batch_size):
        rows = [child_row(run_id,*child) for child in children[offset:offset+batch_size]]
        result = await db.execute(text('''INSERT INTO pcma.scrape_tasks(run_id,task_key,kind,payload)
            SELECT run_id,task_key,kind,payload FROM jsonb_to_recordset(CAST(:rows AS jsonb))
                AS x(run_id UUID,task_key TEXT,kind VARCHAR(20),payload JSONB)
            ON CONFLICT(run_id,task_key) DO NOTHING RETURNING id'''), {'rows':json.dumps(rows)})
        inserted += len(result.all())
    return inserted


async def enqueue(db, run_id, kind, payload, identity=None):
    return await enqueue_many(db,run_id,[(kind,payload,identity)])


async def stage_children(db, task, children, batch_size):
    """Checkpoint source results before any backpressure deferral. No source re-fetch."""
    if not children: return
    rows=[{'chunk':i//batch_size,'children':children[i:i+batch_size]}
          for i in range(0,len(children),batch_size)]
    # Bound each SQL parameter, even for very broad search responses.
    for offset in range(0,len(rows),100):
        await db.execute(text('''INSERT INTO pcma.scrape_expansions(run_id,task_id,chunk,children)
            SELECT :run,:task,chunk,children FROM jsonb_to_recordset(CAST(:rows AS jsonb))
                AS x(chunk INTEGER,children JSONB) ON CONFLICT DO NOTHING'''),
            {'run':task['run_id'],'task':task['id'],'rows':json.dumps(rows[offset:offset+100])})
    await db.execute(text('UPDATE pcma.scrape_tasks SET expanding=TRUE WHERE id=:id'),task)


async def expand_batch(db, task, high_water, batch_size):
    row=(await db.execute(text('SELECT chunk,children FROM pcma.scrape_expansions WHERE task_id=:id ORDER BY chunk LIMIT 1 FOR UPDATE'),task)).mappings().first()
    if not row: return False
    pending=(await db.execute(text("SELECT COALESCE(sum(total),0) FROM pcma.scrape_task_counts WHERE run_id=:run AND status IN ('queued','running')"),{'run':task['run_id']})).scalar_one()
    # Only a producer-only queue may admit one child at capacity. Otherwise
    # preserve the checkpoint until case completion creates room in the queue.
    minimum=1 if task.get('_drain_checkpoint') else 0
    capacity=min(batch_size,max(minimum,high_water-int(pending)))
    if not capacity: return True
    children=row['children']; ready,rest=children[:capacity],children[capacity:]
    await enqueue_many(db,task['run_id'],ready,batch_size)
    if rest:
        await db.execute(text('UPDATE pcma.scrape_expansions SET children=CAST(:children AS jsonb) WHERE task_id=:id AND chunk=:chunk'),{'id':task['id'],'chunk':row['chunk'],'children':json.dumps(rest)})
    else:
        await db.execute(text('DELETE FROM pcma.scrape_expansions WHERE task_id=:id AND chunk=:chunk'),{'id':task['id'],'chunk':row['chunk']})
    return bool((await db.execute(text('SELECT 1 FROM pcma.scrape_expansions WHERE task_id=:id LIMIT 1'),task)).scalar_one_or_none())


async def create_run(db, request, actor=None, schedule_key=None):
    run_id = uuid4()
    criteria = request.criteria()
    # request_key makes a repeated HTTP submission idempotent.
    result = await db.execute(text('''INSERT INTO pcma.scrape_runs
        (id, name, outcome, status_filter, triggered_by, criteria, trigger_type, queued_at,
         started_at, request_key, schedule_key, snapshot_version)
        VALUES (:id, :name, 'queued', :status, :actor, CAST(:criteria AS jsonb), :trigger,
            CURRENT_TIMESTAMP, NULL, :request, :schedule, 1)
        ON CONFLICT DO NOTHING RETURNING id'''),
        dict(id=run_id, name=request.name, status=request.status, actor=actor,
             criteria=json.dumps(criteria), trigger='scheduled' if schedule_key else 'manual',
             request=request.requestId, schedule=schedule_key))
    inserted = result.scalar_one_or_none()
    if inserted is None:
        row = (await db.execute(text('''SELECT id, criteria, name, triggered_by FROM pcma.scrape_runs
            WHERE request_key = :request OR schedule_key = :schedule'''),
            dict(request=request.requestId, schedule=schedule_key))).mappings().one()
        if row['criteria'] != criteria or row['name'] != request.name or row['triggered_by'] != actor:
            raise ValueError('Request ID was already used for a different submission')
        return row['id']
    await enqueue(db, run_id, 'discover', {})
    await event(db, run_id, 'queued', 'Scheduled scan queued' if schedule_key else 'Manual scan queued', actor_id=actor)
    return run_id


ATTRIBUTES = {'cnr':'cnr_number','caseNo':'case_number','ref':'case_ref','regNo':'registration_number',
    'regYear':'registration_year','caseType':'case_type','caseTypeClass':'case_type_class',
    'state':'state','district':'district','complex':'complex_name','court':'court_name',
    'regDate':'registration_date','filingDate':'filing_date','decisionDate':'decision_date',
    'dispositionRaw':'disposition_raw','status':'status','numHearings':'hearings_count',
    'duration':'duration_days','lastPurpose':'last_purpose','nextHearing':'next_hearing','acts':'acts'}
DATES = {'regDate', 'filingDate', 'decisionDate', 'nextHearing'}


async def ingest(db, run_id, data):
    # Serialize a CNR across runs without loading its whole history twice.
    await db.execute(text('SELECT pg_advisory_xact_lock(hashtextextended(:cnr,772639107))'), {'cnr':data['cnr']})
    current = (await db.execute(select(Case).where(Case.cnr_number == data['cnr'])
        .options(selectinload(Case.hearings), noload(Case.documents)).with_for_update())).scalar_one_or_none()
    if current is not None:
        exists = (await db.execute(text('SELECT 1 FROM pcma.scrape_run_cases WHERE run_id=:run AND case_id=:case'),
                                  dict(run=run_id, case=current.id))).scalar_one_or_none()
        if exists: return  # Replayed tasks cannot change a completed snapshot or notify twice.
    before = CaseSchema.model_validate(current).model_dump(mode='json') if current else None
    if before:
        # An anonymized reference never changes when a case is refreshed.
        data['ref'] = before['ref'] or data['ref']
    kind = 'new' if before is None else ('updated' if any(before[key] != data[key] for key in [*ATTRIBUTES, 'hearings']) else 'unchanged')
    now = utcnow()
    notice = change_notice(before, data, now.isoformat())
    if current is None:
        current = Case(id=uuid4())
        db.add(current)
    for key, attribute in ATTRIBUTES.items():
        value = data[key]
        setattr(current, attribute, date.fromisoformat(value) if key in DATES and value else value)
    current.scrape_run_id = run_id
    current.last_scrape = now.strftime('%Y-%m')
    if notice: current.update_info = notice
    # Replace the latest hearing set atomically; historical sets live in snapshots.
    if before is None or before['hearings'] != data['hearings']:
        current.hearings = [CaseHearing(hearing_date=date.fromisoformat(h['date']), purpose=h['purpose'], sequence_order=i)
                            for i, h in enumerate(data['hearings'])]
    await db.flush()
    if data.get('finalDocuments') is not None:
        await save_documents(db, current.id, data['finalDocuments'], now)
    public_data = {k: v for k, v in data.items() if k not in ('finalDocuments', 'documentWarning')}
    snapshot = {**public_data, 'id': str(current.id), 'lastScrape': current.last_scrape, 'pinned': False, 'update': None}
    CaseSchema.model_validate(snapshot)
    await db.execute(text('''INSERT INTO pcma.scrape_run_cases(run_id, case_id, snapshot, change_kind, fetched_at)
        VALUES (:run, :case, CAST(:snapshot AS jsonb), :kind, :at)'''),
        dict(run=run_id, case=current.id, snapshot=json.dumps(snapshot), kind=kind, at=now))
    if notice:
        await db.execute(text('''INSERT INTO pcma.case_notifications(user_id, case_id, run_id, payload)
            SELECT user_id, case_id, :run, CAST(:payload AS jsonb) FROM pcma.case_pins WHERE case_id=:case
            ON CONFLICT(user_id, case_id) DO UPDATE SET run_id=EXCLUDED.run_id, payload=EXCLUDED.payload'''),
            dict(run=run_id, case=current.id, payload=json.dumps(notice)))


async def save_documents(db, case_id, documents, checked_at=None):
    from app.models.document import CaseDocument
    from sqlalchemy.dialects.postgresql import insert
    from app.document_refs import clean_reference, reference_key
    for document in documents:
        reference = clean_reference(document['reference'])
        statement = insert(CaseDocument).values(case_id=case_id, document_type='final',
            label='Final judgment', document_date=date.fromisoformat(document['date']) if document['date'] else None,
            source_key=reference_key(reference), source_reference=reference)
        await db.execute(statement.on_conflict_do_update(index_elements=['case_id', 'source_key'],
            set_={'source_reference': statement.excluded.source_reference,
                  'document_date': statement.excluded.document_date}))
    # A later missing order never deletes a previously captured reference.
    await db.execute(text('UPDATE pcma.cases SET documents_checked_at=:at WHERE id=:case'),
                     {'case': case_id, 'at': checked_at or utcnow()})
