"""Durable request admission and source circuit state for one coordinator.

All pool clients, including token/bootstrap requests, use this gate. This is not
permission to run replicas: the coordinator advisory lock is still required.
"""
import asyncio
import json
import logging
from uuid import uuid4
from sqlalchemy import text
from app.config import settings


log = logging.getLogger(__name__)


class OwnershipLost(RuntimeError):
    pass


class SourceDeferred(Exception):
    def __init__(self, seconds):
        self.seconds = max(1,seconds)


async def control_row(db, owner):
    row=(await db.execute(text('SELECT *,clock_timestamp() AS now FROM pcma.scraper_control WHERE id=TRUE FOR UPDATE'))).mappings().one()
    if row['owner'] != owner:
        raise OwnershipLost('Coordinator ownership changed')
    return row


class SourceGate:
    def __init__(self, sessions, owner, *, requester=None, interval=None):
        self.sessions=sessions
        self.owner=owner
        self.requester=requester or uuid4()
        self.interval=settings.SCRAPER_REQUEST_INTERVAL if interval is None else interval

    async def wait(self):
        while True:
            async with self.sessions() as db,db.begin():
                row=await control_row(db,self.owner)
                now=row['now']
                if row['paused_until']:
                    remaining=(row['paused_until']-now).total_seconds()
                    if remaining>0: raise SourceDeferred(remaining)
                    if row['probe_owner'] not in (None,self.requester) and row['probe_until'] and row['probe_until']>now:
                        raise SourceDeferred(3)
                delay=(row['next_request_at']-now).total_seconds()
                if delay<=0:
                    admitted = await db.execute(text('''UPDATE pcma.scraper_control SET
                        next_request_at=clock_timestamp()+make_interval(secs=>:interval),
                        requests=requests+1,last_request_at=clock_timestamp(),
                        probe_owner=CASE WHEN paused_until IS NOT NULL THEN :requester ELSE probe_owner END,
                        probe_until=CASE WHEN paused_until IS NOT NULL THEN clock_timestamp()+make_interval(secs=>:lease) ELSE probe_until END
                        WHERE id=TRUE RETURNING next_request_at'''),{'interval':self.interval,'requester':self.requester,'lease':settings.SCRAPER_LEASE_SECONDS})
                    # Return the durable reservation deadline for diagnostics.
                    # Client wake-up times can bunch after delayed commit replies.
                    return admitted.scalar_one()
            await asyncio.sleep(min(max(delay,0.001),self.interval))

    async def transition(self, db, before, name, task):
        after=await control_row(db,self.owner)
        fields=('failure_streak','cooldown_level','recovery_successes','paused_until','probe_owner','probe_until')
        message=json.dumps({'transition':name,'before':{k:before[k] for k in fields},
                            'after':{k:after[k] for k in fields}},default=str,sort_keys=True)
        log.info('source_transition %s',message)
        if task is not None:
            from app.scraper.store import event
            await event(db,task['run_id'],'source_transition',message,task['id'])

    async def report(self, db, error=None, *, task=None, representative=True):
        row=await control_row(db,self.owner)
        owns_probe=row['probe_owner']==self.requester
        if error is not None and error.retry_after:
            # An explicit source deadline can exceed our exponential backoff.
            # It applies even to a request-specific 4xx and never shortens an
            # existing cooldown. No task/client may probe before this deadline.
            await db.execute(text('''UPDATE pcma.scraper_control SET
                paused_until=GREATEST(paused_until,clock_timestamp()+make_interval(secs=>:delay)),
                recovery_successes=0,probe_owner=NULL,probe_until=NULL WHERE id=TRUE'''),{'delay':error.retry_after})
            await self.transition(db,row,'retry_after',task)
        if (error is not None and not error.source_failure) or not representative:
            # Court/record content and auxiliary catalogue refreshes establish no
            # business-task recovery. Release a probe without changing backoff.
            if owns_probe:
                await db.execute(text("""UPDATE pcma.scraper_control SET
                    probe_owner=NULL,probe_until=NULL,recovery_successes=0 WHERE id=TRUE"""))
                await self.transition(db,row,'probe_inconclusive',task)
            return False
        if error is None:
            if row['paused_until'] is not None and not owns_probe:
                return False  # A stale concurrent success cannot close another probe.
            if row['paused_until'] is not None:
                successes=row['recovery_successes']+1
                recovered=successes>=settings.SCRAPER_RECOVERY_SUCCESSES
                await db.execute(text("""UPDATE pcma.scraper_control SET failure_streak=0,
                    cooldown_level=CASE WHEN :recovered THEN 0 ELSE cooldown_level END,
                    recovery_successes=CASE WHEN :recovered THEN 0 ELSE :successes END,
                    paused_until=CASE WHEN :recovered THEN NULL ELSE
                        clock_timestamp()+make_interval(secs=>:delay) END,
                    probe_owner=NULL,probe_until=NULL,last_error_kind=NULL WHERE id=TRUE"""),
                    {'recovered':recovered,'successes':successes,'delay':settings.SCRAPER_RECOVERY_INTERVAL_SECONDS})
                await self.transition(db,row,'closed' if recovered else 'recovering',task)
            else:
                await db.execute(text("""UPDATE pcma.scraper_control SET failure_streak=0,
                    last_error_kind=NULL WHERE id=TRUE"""))
            return False
        streak=row['failure_streak']+1
        # Additional requests already in flight cannot multiply a newly opened
        # cooldown. The next leased probe is responsible for its next escalation.
        already_paused=bool(row['paused_until'] and row['paused_until']>row['now'] and not owns_probe)
        opened=not already_paused and (streak>=settings.SCRAPER_SOURCE_FAILURE_THRESHOLD or
                                      error.kind=='throttle' or owns_probe or bool(error.retry_after))
        if opened:
            level=min(row['cooldown_level']+1,16)
            delay=min(settings.SCRAPER_SOURCE_MAX_COOLDOWN_SECONDS,
                      settings.SCRAPER_SOURCE_COOLDOWN_SECONDS*2**(level-1))
            await db.execute(text("""UPDATE pcma.scraper_control SET failure_streak=:streak,cooldown_level=:level,
                paused_until=GREATEST(paused_until,clock_timestamp()+make_interval(secs=>:delay)),probe_owner=NULL,probe_until=NULL,
                recovery_successes=0,last_error_kind=:kind WHERE id=TRUE"""),
                {'streak':streak,'level':level,'delay':delay,'kind':error.kind})
            await self.transition(db,row,'opened',task)
        else:
            await db.execute(text("""UPDATE pcma.scraper_control SET failure_streak=:streak,
                recovery_successes=0,last_error_kind=:kind WHERE id=TRUE"""),{'streak':streak,'kind':error.kind})
        return opened
