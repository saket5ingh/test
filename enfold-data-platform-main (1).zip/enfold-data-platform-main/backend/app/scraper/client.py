"""Rate-limited v4 eCourts client, adapted from the existing application's protocol.

No Django imports, proxies, import-time HTTP, or silent error-to-empty conversion.
The durable worker handles retries; this client only refreshes an expired session.
"""
import asyncio
import base64
import json
import logging
import os
import time
import math
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from uuid import uuid4
from app.scraper.diagnostics import RequestDiagnostics, safe_context
import httpx
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7

BASE_URL = 'https://app.ecourts.gov.in/services_DC_4.0'
UID = 'in.gov.ecourts.eCourtsServices'
REQUEST_KEY = bytes.fromhex('4D6251655468576D5A7134743677397A')
RESPONSE_KEY = bytes.fromhex('3273357638782F413F4428472B4B6250')
log = logging.getLogger(__name__)


class UpstreamError(Exception):
    """Safe operational message; never include a response body, token or CNR."""
    def __init__(self, message, *, kind='response', retry_after=None, endpoint=None, session_generation=None):
        super().__init__(message)
        self.kind = kind
        self.retry_after = retry_after
        self.endpoint = endpoint
        self.session_generation = session_generation

    @property
    def source_failure(self):
        # Decoding/session rejection is source-wide; validated endpoint content
        # is classified separately. Non-transient HTTP4xx is request-specific.
        return self.kind in ('network','throttle','http','response','rejected')



def retry_after_seconds(value, now=None):
    """Parse delay-seconds / HTTP-date without retaining an untrusted header.

    Reject invalid or unrepresentable dates; never shorten an accepted delay.
    Leave a year of timestamp headroom for database/driver conversion.
    """
    if not isinstance(value,str) or len(value)>128: return None
    now=now or datetime.now(timezone.utc)
    value=value.strip()
    try:
        if value.isascii() and value.isdigit():
            seconds=int(value)
        else:
            deadline=parsedate_to_datetime(value)
            if deadline.tzinfo is None: return None
            seconds=max(0,math.ceil((deadline-now).total_seconds()))
        maximum=(datetime(9998,1,1,tzinfo=timezone.utc)-now).total_seconds()
        return seconds if 0<=seconds<=maximum else None
    except (ValueError,TypeError,OverflowError): return None


def encrypt(data):
    suffix = os.urandom(8).hex()
    iv = bytes.fromhex('556A586E32723575' + suffix)
    padder = PKCS7(128).padder()
    padded = padder.update(json.dumps(data).encode()) + padder.finalize()
    cipher = Cipher(algorithms.AES(REQUEST_KEY), modes.CBC(iv)).encryptor()
    return suffix + '0' + base64.b64encode(cipher.update(padded) + cipher.finalize()).decode()


def decrypt(body):
    try:
        body = body.strip()
        iv = bytes.fromhex(body[:32])
        ciphertext = base64.b64decode(body[32:], validate=True)
        cipher = Cipher(algorithms.AES(RESPONSE_KEY), modes.CBC(iv)).decryptor()
        padded = cipher.update(ciphertext) + cipher.finalize()
        unpadder = PKCS7(128).unpadder()
        return json.loads((unpadder.update(padded) + unpadder.finalize()).decode())
    except (ValueError, TypeError, UnicodeError) as error:
        # Never include tokens, URLs with encrypted params, or litigant data in logs.
        raise UpstreamError('Unrecognized eCourts response; possible throttling or protocol change') from error


class ECourtsClient:
    def __init__(self, *, interval=3.0, transport=None, limiter=None):
        self.http = httpx.AsyncClient(timeout=120, transport=transport, follow_redirects=False)
        self.transport = transport
        self.limiter = limiter
        self.reset_transport = False
        self.interval = interval
        self.last_request = 0.0
        self.token = None
        self.token_at = 0.0
        self.context = {}
        self.client_generation = str(uuid4())
        self.session_generation = None
        self.last_connection = None

    def set_context(self, task):
        self.context = safe_context(task)

    async def close(self):
        await self.http.aclose()

    def invalidate_session(self):
        self.token = None
        self.token_at = 0.0
        self.reset_transport = True
        self.session_generation = None

    async def validated(self, endpoint, payload, parse):
        try:
            data = await self.get(endpoint, payload)
        except UpstreamError:
            self.invalidate_session()
            raise
        try:
            result = parse(data)
        except (UpstreamError, KeyError, TypeError, ValueError) as error:
            # Only verified court-content failures are isolated. Missing search/
            # history envelopes can be session/protocol failures, so retain their
            # established refresh behavior rather than guessing their meaning.
            kind=error.kind if isinstance(error,UpstreamError) else 'response'
            message=str(error) if isinstance(error,UpstreamError) else f'{endpoint}: invalid response structure'
            session_generation=self.session_generation
            if kind!='validation': self.invalidate_session()
            log.warning('ecourts endpoint=%s validation=failed classification=%s error_type=%s',endpoint,kind,type(error).__name__)
            raise UpstreamError(message,kind=kind,endpoint=endpoint,session_generation=session_generation) from None
        log.info('ecourts endpoint=%s validation=success', endpoint)
        return result

    async def _request(self, endpoint, payload, token=None, *, method="GET"):
        if self.limiter is not None:
            await self.limiter.wait()
        else:
            await asyncio.sleep(max(0, self.interval - (time.monotonic() - self.last_request)))
        self.last_request = time.monotonic()
        started = self.last_request
        status, error_type, received_bytes = None, None, 0
        retry_after = None
        diagnostic = RequestDiagnostics(self)
        diagnostic.data['operation_endpoint'] = getattr(self,'operation_endpoint',endpoint)
        diagnostic.data['session_age_s'] = round(started-self.token_at,3) if token and self.token_at else None
        diagnostic.data['bootstrap'] = token is None
        if token is None: diagnostic.data['session_generation'] = None
        transport_error = None
        outcome = 'network_error'
        try:
            try:
                async with self.http.stream(method, f'{BASE_URL}/{endpoint}', params={'params': encrypt(payload)},
                    headers={'Authorization': f'Bearer {token}'} if token else {},
                    extensions={'trace':diagnostic.trace}) as response:
                    status=response.status_code
                    if status!=200: retry_after=retry_after_seconds(response.headers.get('retry-after'))
                    diagnostic.headers(response.extensions.get('http_version'),status,response.headers.raw)
                    body=bytearray()
                    async for chunk in response.aiter_bytes():
                        body.extend(chunk)
                        received_bytes=len(body)
            except httpx.HTTPError as error:
                transport_error=error
                error_type = type(error).__name__
                raise UpstreamError(f'{endpoint}: network failure ({error_type})', kind='network',retry_after=retry_after) from error
            if status != 200:
                outcome = 'http_error'
                raise UpstreamError(f'{endpoint}: HTTP {status}; retry later', kind='throttle' if status in (405, 429, 503) else 'http' if status >= 500 else 'request',
                    retry_after=retry_after)
            outcome = 'invalid_response'
            try:
                data = decrypt(body.decode('utf-8'))
            except UnicodeError:
                raise UpstreamError('Unrecognized eCourts response encoding') from None
            if not isinstance(data, dict) or data.get('status') == 'N':
                outcome = 'rejected'
                raise UpstreamError(f'{endpoint}: upstream rejected request', kind='rejected')
            outcome = 'decoded'  # Endpoint validation happens in validated(), not here.
            return data
        except UpstreamError as error:
            error.endpoint=endpoint
            error.session_generation=self.session_generation if token else None
            raise
        except asyncio.CancelledError:
            outcome = 'cancelled'
            raise
        finally:
            # Never log request URLs/params, tokens, bodies or exception messages.
            # Timings include the full response, but exclude deliberate pacing.
            write = log.info if outcome == 'decoded' else log.warning
            write('ecourts endpoint=%s outcome=%s http_status=%s elapsed_s=%.3f bytes=%d error_type=%s diagnostics=%s',
                  endpoint, outcome, status, time.monotonic() - started, received_bytes, error_type,
                  json.dumps(diagnostic.finish(transport_error),sort_keys=True,separators=(',',':')))

    async def get(self, endpoint, payload, *, method="GET"):
        self.operation_endpoint=endpoint
        if self.reset_transport:
            await self.http.aclose()
            self.http = httpx.AsyncClient(timeout=120, transport=self.transport, follow_redirects=False)
            self.reset_transport = False
            self.client_generation = str(uuid4())
            self.last_connection = None
        if not self.token or time.monotonic() - self.token_at >= 300:
            data = await self._request('appReleaseWebService.php', {'appVersion': '4.0.1', 'uid': UID})
            self.token = data.get('token')
            if not isinstance(self.token, str) or not self.token:
                raise UpstreamError('eCourts did not issue a session token')
            self.token_at = time.monotonic()
            self.session_generation = str(uuid4())
        try:
            return await self._request(endpoint, {**payload, 'uid': UID}, self.token, method=method)
        except UpstreamError:
            self.invalidate_session()  # A durable retry also replaces the connection pool.
            raise

    @staticmethod
    def rows(data, key, *, empty_ok=True):
        rows = data.get(key)
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows) or (not rows and not empty_ok):
            raise UpstreamError(f'eCourts returned missing/invalid {key}')
        return rows

    async def states(self):
        def parse(data):
            rows = self.rows(data, 'states', empty_ok=False)
            return [{'code': str(row['state_code']), 'name': row['state_name']} for row in rows]
        return await self.validated('stateWebService.php', {'action_code': 'fillState'}, parse)

    async def districts(self, state):
        def parse(data):
            rows = self.rows(data, 'districts', empty_ok=False)
            return [{'code': str(row['dist_code']), 'name': row['dist_name']} for row in rows]
        return await self.validated('districtWebService.php', {'state_code': state}, parse)

    async def courts(self, state, district):
        def parse(data):
            rows = self.rows(data, 'courtComplex', empty_ok=False)
            courts = [{'code': code.strip(), 'name': row['court_complex_name']} for row in rows
                      for code in str(row['njdg_est_code']).split(',') if code.strip()]
            if not courts or any(not court['code'].isdigit() for court in courts):
                raise UpstreamError('Missing or invalid court establishment codes')
            return courts
        return await self.validated('courtEstWebService.php', {'action_code': 'fillCourtComplex',
            'state_code': state, 'dist_code': district}, parse)

    def court_payload(self, scope):
        return {'state_code': scope['state']['code'], 'dist_code': scope['district']['code'],
                'court_code_arr': scope['court']['code'], 'language_flag': 'english', 'bilingual_flag': '0'}

    async def acts(self, scope):
        def parse(data):
            rows = self.rows(data, 'actsList', empty_ok=False)
            if not isinstance(rows[0].get('acts'), str):
                raise UpstreamError('Invalid court act list',kind='validation')
            values = [value.strip() for value in rows[0]['acts'].split('#') if value.strip()]
            if not values or any('~' not in value for value in values):
                raise UpstreamError('Empty or malformed court act catalogue',kind='validation')
            acts = [tuple(value.split('~', 1)) for value in values]
            if any(not code.strip() or not name.strip() for code, name in acts):
                raise UpstreamError('Incomplete court act catalogue entry',kind='validation')
            return acts
        return await self.validated('actWebService.php', {**self.court_payload(scope), 'searchText': ''}, parse)

    async def search(self, scope):
        def parse(data):
            result = data.get('0')
            if not isinstance(result, dict):
                raise UpstreamError('Invalid case search response', kind='response')
            rows = self.rows(result, 'caseNos')
            # Only an explicit, validated caseNos=[] is an empty success. A token
            # or no_of_establishments field alone cannot establish zero cases.
            if any(not isinstance(row.get('cino'), str) or not row['cino'].strip() for row in rows):
                raise UpstreamError('Search returned a case without a CNR', kind='response')
            return rows
        return await self.validated('searchByActWebService.php', {**self.court_payload(scope),
            'selectActTypeText': scope['act_code'], 'underSectionText': scope['section'],
            'pendingDisposed': scope['status']}, parse)

    async def history(self, scope):
        def parse(data):
            history = data.get('history')
            if not isinstance(history, dict) or not history:
                raise UpstreamError('Missing case history', kind='response')
            return history
        return await self.validated('caseHistoryWebService.php', {'state_code': scope['state']['code'],
            'dist_code': scope['district']['code'], 'court_code': scope['court']['code'],
            'language_flag': 'english', 'bilingual_flag': '0', 'cino': scope['cnr']}, parse)
