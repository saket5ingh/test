import csv
import io
import json

COLUMNS = [('cnr','CNR'),('ref','Reference'),('caseNo','Case number'),('caseType','Case type'),
    ('regNo','Registration number'),('regYear','Registration year'),('state','State'),('district','District'),
    ('complex','Complex'),('court','Court'),('regDate','Registration date'),('filingDate','Filing date'),
    ('decisionDate','Decision date'),('status','Status'),('dispositionRaw','Disposition'),
    ('numHearings','Hearing count'),('lastPurpose','Last hearing purpose'),('nextHearing','Next hearing'),
    ('acts','Acts and sections (JSON)'),('hearings','Hearing history (JSON)')]


def safe_cell(value):
    if isinstance(value, (list, dict)): value = json.dumps(value, ensure_ascii=False)
    if value is None: return ''
    value = str(value)
    # CSV quoting alone does not prevent Excel/Sheets from evaluating formulas.
    if value.lstrip().startswith(('=', '+', '-', '@')) or value.startswith(('\t', '\r', '\n')):
        value = "'" + value
    return value


def csv_line(values):
    buffer = io.StringIO(newline='')
    csv.writer(buffer).writerow([safe_cell(v) for v in values])
    return buffer.getvalue()
