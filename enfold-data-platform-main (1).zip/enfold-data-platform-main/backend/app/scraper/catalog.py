"""Validated, exact act aliases. Court act numbers are resolved afresh per court."""
import hashlib
import html
import json
from pathlib import Path
import re
import unicodedata
from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

CONFIG_PATH = Path(__file__).with_name('config') / 'act_aliases.json'
OPTION_KEYS = {'pocso', 'childmarriage', 'it', 'jj', 'ita', 'ipc', 'scst', 'dowry'}
Title = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=500)]
Identifier = Annotated[str, StringConstraints(pattern=r'^[a-z][a-z0-9_-]*$', max_length=64)]


def normalized(name):
    """Normalize typography only; never discard years or singularize law names."""
    value = unicodedata.normalize('NFKC', html.unescape(name or '')).lower().replace('&', ' and ')
    value = re.sub(r'(?<=[a-z])(?=\d)', ' ', value)
    value = re.sub(r'[^a-z0-9]+', ' ', value).strip()
    value = re.sub(r'\b[a-z](?:\s+[a-z])+\b', lambda m: m.group().replace(' ', ''), value)
    # Dotted S.C./S.T. and slash-separated SC/ST have the same letters.
    value = re.sub(r'\bsc st\b', 'scst', value)
    return re.sub(r'^the ', '', ' '.join(value.split()))


class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)


class Law(StrictModel):
    id: Identifier
    name: Title
    aliases: list[Title] = Field(min_length=1, max_length=100)
    # An empty year list accepts only the exact yearless label; it does not infer a law year.
    years: list[Annotated[int, Field(ge=1000, le=2999)]] = Field(max_length=10)
    preserve_year: bool


class Option(StrictModel):
    label: Title
    review_terms: list[Title] = Field(min_length=1, max_length=100)
    laws: list[Law] = Field(min_length=1, max_length=10)


class AliasConfig(StrictModel):
    schema_version: Literal[1]
    version: Annotated[str, StringConstraints(pattern=r'^\d{4}-\d{2}-\d{2}\.\d+$')]
    excluded_words: list[Title] = Field(min_length=1)
    options: dict[str, Option]

    @model_validator(mode='after')
    def validate_rules(self):
        if set(self.options) != OPTION_KEYS:
            raise ValueError('Keep the eight existing option keys; new frontend options require a code change')
        if any(normalized(word) != word or len(word.split()) != 1 for word in self.excluded_words):
            raise ValueError('Excluded words must be single normalized words')
        if not {'rules', 'amendment', 'bill'} <= set(self.excluded_words):
            raise ValueError('Rules, amendment and bill exclusions are required')
        names, ids = {}, set()
        for key, option in self.options.items():
            if any(not normalized(term) for term in option.review_terms):
                raise ValueError('Review terms must contain letters or numbers')
            for law in option.laws:
                if law.id in ids or len(set(law.years)) != len(law.years):
                    raise ValueError('Law IDs and each law year list must be unique')
                ids.add(law.id)
                aliases = set()
                for alias in law.aliases:
                    name = normalized(alias)
                    if not name or re.search(r'\d', name) or any(ord(c) < 32 for c in alias):
                        raise ValueError('Aliases must be plain yearless names; configure years separately')
                    if set(name.split()) & set(self.excluded_words):
                        raise ValueError('An alias cannot include an excluded instrument')
                    if name in aliases:
                        raise ValueError('Duplicate normalized alias; punctuation/case variants need no extra entry')
                    aliases.add(name)
                    for variant in [name, *(f'{name} {year}' for year in law.years)]:
                        if variant in names:
                            raise ValueError(f'Conflicting alias between {names[variant]} and {key}/{law.id}')
                        names[variant] = f'{key}/{law.id}'
        return self


def _unique_json_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise ValueError(f'Duplicate JSON key: {key}')
        result[key] = value
    return result


def load_config(path=CONFIG_PATH):
    return AliasConfig.model_validate(json.loads(Path(path).read_text(), object_pairs_hook=_unique_json_keys))


class Catalog:
    def __init__(self, config):
        self.config = config
        self.hash = hashlib.sha256(json.dumps(config.model_dump(), sort_keys=True).encode()).hexdigest()
        self.index = {}
        for key, option in config.options.items():
            for law in option.laws:
                for alias in law.aliases:
                    name = normalized(alias)
                    self.index[name] = (key, law, None)
                    for year in law.years:
                        self.index[f'{name} {year}'] = (key, law, year)

    @property
    def identity(self):
        return {'version': self.config.version, 'sha256': self.hash}

    def resolve(self, rows, key):
        option = self.config.options[key]
        matches, review = {}, []
        for code, raw in rows:
            if not isinstance(raw, str) or not raw.strip(): continue
            name = normalized(raw)
            match = self.index.get(name)
            if match and match[0] == key:
                _, law, year = match
                code = str(code)
                item = matches.setdefault(code, {'code': code, 'sourceLabels': [], 'law': law.id,
                    'year': year, 'option': key, 'config': self.identity})
                if item['law'] != law.id or item['year'] != year:
                    raise ValueError('Court act code has conflicting law labels')
                if raw not in item['sourceLabels']: item['sourceLabels'].append(raw)
            elif any(f' {normalized(term)} ' in f' {name} ' for term in option.review_terms):
                reason = 'excluded instrument' if set(name.split()) & set(self.config.excluded_words) else 'unapproved name or year'
                review.append({'code': str(code), 'label': raw, 'reason': reason})
        return [matches[code] for code in sorted(matches)], review

    def canonical_names(self, key):
        """Stored names for one configured option, keeping distinct laws/years."""
        return sorted({self.canonical(name) for name, match in self.index.items() if match[0] == key})

    def canonical(self, name):
        match = self.index.get(normalized(name))
        if not match: return html.unescape(name).strip()
        _, law, year = match
        return f'{law.name}, {year}' if year and law.preserve_year else law.name


CATALOG = Catalog(load_config())
# Preserve existing option IDs/contracts while reading names from one config.
ACTS = {key: (option.label, [alias for law in option.laws for alias in law.aliases])
        for key, option in CATALOG.config.options.items()}


def act_codes(rows, key):
    matches, _ = CATALOG.resolve(rows, key)
    return [item['code'] for item in matches]


def canonical_act(name):
    return CATALOG.canonical(name)


if __name__ == '__main__':
    print(f'Act mapping valid: {CATALOG.config.version}; {len(ACTS)} options; SHA256 {CATALOG.hash}')
