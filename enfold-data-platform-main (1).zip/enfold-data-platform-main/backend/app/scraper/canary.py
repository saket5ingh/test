"""Bounded read-only source check. Prints metadata/counts, never parties or tokens.

python -m app.scraper.canary --state Bihar --district Gaya
No database writes. At most two courts and one case-history request.
"""
import argparse
import asyncio
import json
from app.scraper.client import ECourtsClient, UpstreamError
from app.scraper.catalog import act_codes, ACTS
from app.scraper.normalize import normalize

async def check(state_name, district_name, act_key):
    client=ECourtsClient(interval=3)
    report={'case_verified':False}
    try:
        states=await client.states(); report['state_count']=len(states)
        state=next((s for s in states if s['name'].lower()==state_name.lower()),None)
        if state is None: raise ValueError('Requested state unavailable')
        districts=await client.districts(state['code']); report['district_count']=len(districts)
        district=next((d for d in districts if d['name'].lower()==district_name.lower()),None)
        if district is None: raise ValueError('Requested district unavailable')
        courts=await client.courts(state['code'],district['code']); report['court_count']=len(courts)
        for court in courts[:2]:
            scope={'state':state,'district':district,'court':court,'status':'Pending','section':''}
            acts=await client.acts(scope); report['court_act_count']=len(acts)
            codes=act_codes(acts,act_key)
            if not codes: continue
            scope['act_code']=codes[0]
            rows=await client.search(scope); report['search_count']=len(rows)
            if not rows: continue
            scope.update(cnr=rows[0]['cino'],case_no=rows[0].get('case_no'))
            history=await client.history(scope)
            report['history_keys']=sorted(history)
            normalized=normalize(history,scope)
            report['normalized']={'status':normalized['status'],'act_count':len(normalized['acts']),
                                  'hearing_count':normalized['numHearings']}
            report['case_verified']=True
            break
    except Exception as error:
        report['error']=str(error) if isinstance(error,(ValueError,UpstreamError)) else type(error).__name__
        print(json.dumps(report,indent=2))
        raise SystemExit(1)
    finally: await client.close()
    if not report['case_verified']:
        report['incomplete']='No matching case found in the bounded sample; only catalogue access was checked'
    print(json.dumps(report,indent=2))
    if not report['case_verified']: raise SystemExit(2)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state',default='Bihar'); parser.add_argument('--district',default='Gaya')
    parser.add_argument('--act',choices=list(ACTS),default='childmarriage')
    args=parser.parse_args()
    asyncio.run(check(args.state,args.district,args.act))
