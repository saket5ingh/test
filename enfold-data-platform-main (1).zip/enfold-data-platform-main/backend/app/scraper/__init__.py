"""FFG-owned scraping pipeline. Importing this package never contacts eCourts."""
