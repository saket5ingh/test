"""Fetch references for existing disposed cases; never rerun case ingestion.

Run with the worker database role: python -m app.scraper.backfill_documents --limit 100
Repeat bounded batches until no unchecked cases remain. --case-id permits a retry
of one already checked case, including a previously missing upload.
"""
import argparse
import asyncio
from uuid import UUID
from sqlalchemy import text
from app.database import async_session_maker, engine
from app.scraper.client import ECourtsClient
from app.scraper.normalize import final_documents
from app.scraper.store import save_documents
from app.config import settings


async def run(limit, case_id):
    client = ECourtsClient(interval=settings.SCRAPER_REQUEST_INTERVAL)
    completed = failed = 0
    try:
        async with async_session_maker() as db:
            rows = (await db.execute(text('''SELECT c.id,t.payload FROM pcma.cases c
                JOIN LATERAL (SELECT payload FROM pcma.scrape_tasks WHERE kind='case'
                    AND status='success' AND payload->>'cnr'=c.cnr_number
                    ORDER BY completed_at DESC LIMIT 1) t ON true
                WHERE c.status <> 'pending' AND
                    ((CAST(:case AS uuid) IS NULL AND c.documents_checked_at IS NULL)
                      OR c.id=CAST(:case AS uuid))
                ORDER BY c.id LIMIT :limit'''), {'case': case_id, 'limit': limit})).all()
        for row in rows:
            try:
                history = await client.history(row.payload)
                if history.get('cino') and str(history['cino']).strip().upper() != row.payload['cnr'].strip().upper():
                    raise ValueError('Case-history reference mismatch')
                documents = final_documents(history)
                async with async_session_maker() as db, db.begin():
                    await save_documents(db, row.id, documents)
                completed += 1
            except Exception as error:
                failed += 1
                print(f'Document discovery failed ({type(error).__name__}); retry in a later batch', flush=True)
        print(f'Checked {completed} cases; failed {failed}; selected {len(rows)}. No case details or pins changed.')
        return 1 if failed else 0
    finally:
        await client.close()
        await engine.dispose()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--limit', type=int, default=100)
    parser.add_argument('--case-id', type=UUID)
    args = parser.parse_args()
    if not 1 <= args.limit <= 1000: parser.error('--limit must be between 1 and 1000')
    return asyncio.run(run(args.limit, args.case_id))


if __name__ == '__main__':
    raise SystemExit(main())
