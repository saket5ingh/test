"""Bounded progress queries: counters plus at most sixty minute buckets per run."""
from datetime import datetime, timezone, timedelta
from sqlalchemy import text
from app.config import settings


async def summaries(db, ids):
    if not ids: return {}
    params={'ids':ids}
    data={key:{'tasks':{},'counts':{},'coverage':[],'progress':{},'metrics':{}} for key in ids}
    for r in (await db.execute(text('SELECT * FROM pcma.scrape_task_counts WHERE run_id=ANY(:ids) AND total>0'),params)).mappings():
        item=data[r['run_id']]
        item['tasks'][r['status']]=item['tasks'].get(r['status'],0)+r['total']
        item['coverage'].append({'kind':r['kind'],'status':r['status'],'count':r['total']})
    for r in (await db.execute(text('SELECT * FROM pcma.scrape_result_counts WHERE run_id=ANY(:ids) AND total>0'),params)).mappings():
        data[r['run_id']]['counts'][r['change_kind']]=r['total']
    for r in (await db.execute(text('SELECT * FROM pcma.scrape_run_progress WHERE run_id=ANY(:ids)'),params)).mappings():
        data[r['run_id']]['progress']=dict(r)
    for r in (await db.execute(text("""SELECT run_id,sum(succeeded)::bigint AS succeeded,
        sum(case_succeeded)::bigint AS cases,sum(retried)::bigint AS retried,
        sum(failed)::bigint AS failed,sum(source_errors)::bigint AS source_errors
        FROM pcma.scrape_metrics WHERE run_id=ANY(:ids)
        AND bucket>=date_trunc('minute',CURRENT_TIMESTAMP)-INTERVAL '59 minutes'
        GROUP BY run_id"""),params)).mappings():
        data[r['run_id']]['metrics']=dict(r)
    for r in (await db.execute(text('SELECT run_id,count(*) n FROM pcma.scrape_tasks WHERE run_id=ANY(:ids) AND review_required GROUP BY run_id'),params)).mappings():
        data[r['run_id']]['quarantined']=r['n']
    worker=(await db.execute(text("SELECT value,updated_at FROM pcma.scraper_metadata WHERE key='worker'"))).mappings().first()
    for item in data.values():
        item['worker']=dict(worker) if worker else {}
        item['coverage'].sort(key=lambda r:(r['kind'],r['status']))
    return data


def performance(row, summary, now=None):
    now=now or datetime.now(timezone.utc)
    p,m,w=summary['progress'],summary['metrics'],summary['worker']
    value=w.get('value',{})
    last=p.get('last_success_at')
    active=row['outcome']=='running'
    since=max(p.get('metrics_since') or now,row['started_at'] or now)
    observed=max(0,min(3600,(now-since).total_seconds()))
    stalled=active and (now-(last or row['started_at'] or now)).total_seconds()>=settings.SCRAPER_STALL_SECONDS
    healthy=bool(w.get('updated_at') and now-w['updated_at']<timedelta(seconds=30))
    attempts=m.get('succeeded',0)+m.get('retried',0)+m.get('failed',0)
    pause=value.get('sourcePausedUntil')
    paused=bool(pause and datetime.fromisoformat(pause)>now)
    cases=m.get('cases',0)
    backlog=sum(c['count'] for c in summary['coverage'] if c['kind']=='case' and c['status'] in ('queued','running'))
    # This estimates ONLY already-admitted case tasks. Future discovery and
    # checkpoints can add work, so never present it as the whole-run finish time.
    eta=round(backlog*observed/cases) if active and healthy and not stalled and not paused and observed>=300 and cases>=10 and backlog else None
    return dict(windowMinutes=60,observedSince=since,
        successfulTasksLastHour=m.get('succeeded',0),caseDetailsLastHour=cases,
        failedTasksLastHour=m.get('failed',0),retriedTasksLastHour=m.get('retried',0),
        sourceErrorsLastHour=m.get('source_errors',0),
        sourceErrorRate=round(m.get('source_errors',0)/attempts,4) if attempts else None,
        lastSuccessfulTaskAt=last,lastCaseAt=p.get('last_case_at'),deferredTasks=p.get('deferred_tasks',0),
        workerConcurrency=value.get('concurrency'),inFlight=value.get('inFlight'),
        workerLastSeen=w.get('updated_at'),workerHealthy=healthy,
        requestIntervalSeconds=value.get('requestIntervalSeconds'),
        observedRequestIntervalSeconds=value.get('observedRequestIntervalSeconds'),
        sourcePausedUntil=pause if paused else None,sourceFailureStreak=value.get('sourceFailureStreak',0),
        sourceRecoverySuccesses=value.get('sourceRecoverySuccesses',0),sourceRecoveryRequired=value.get('sourceRecoveryRequired',3),
        stalled=stalled,etaSeconds=eta,etaBasis='current_case_backlog' if eta is not None else None)
