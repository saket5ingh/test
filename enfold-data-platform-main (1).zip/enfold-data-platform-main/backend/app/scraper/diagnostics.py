"""Allowlisted transport telemetry. Never serialize request/response objects.

HTTPcore trace events expose phases, not a socket on failed reused requests.
Those connection correlations are explicitly labelled inferred, not observed.
"""
import time
from uuid import UUID, uuid4

PHASES = {'connection.connect_tcp', 'connection.start_tls', 'http11.send_request_headers',
          'http11.send_request_body', 'http11.receive_response_headers',
          'http11.receive_response_body', 'http11.response_closed'}
ERROR_TYPES = {'RemoteProtocolError','LocalProtocolError','ReadError','WriteError','ConnectError',
               'ReadTimeout','WriteTimeout','ConnectTimeout','PoolTimeout','SSLError',
               'SSLCertVerificationError','IncompleteRead','BrokenPipeError','ConnectionResetError',
               'ConnectionAbortedError','EndOfStream','CancelledError'}


def exception_details(error):
    """Classify known messages; do not return exception text, repr or arguments."""
    chain=[]; categories=[]; seen=set()
    for _ in range(5):
        if error is None or id(error) in seen: break
        seen.add(id(error))
        name=type(error).__name__
        chain.append(name if name in ERROR_TYPES else 'other')
        message=str(error).lower()
        if 'disconnected without sending a response' in message: categories.append('eof_before_response')
        elif 'incomplete chunked read' in message: categories.append('incomplete_chunked_body')
        elif 'without sending complete message body' in message: categories.append('incomplete_body')
        elif 'illegal status line' in message: categories.append('invalid_status_line')
        elif 'illegal header line' in message: categories.append('invalid_header_line')
        elif 'certificate verify failed' in message: categories.append('tls_certificate_failure')
        error=error.__cause__ or error.__context__
    return {'exception_chain':chain,'failure_categories':sorted(set(categories))}


def safe_context(task):
    if not isinstance(task,dict): return {}
    result={}
    for key in ('id','run_id'):
        try: result['task_id' if key=='id' else 'run_id']=str(UUID(str(task[key])))
        except (KeyError,ValueError,TypeError): pass
    if task.get('kind') in ('discover','state','district','court','search','case'):
        result['task_kind']=task['kind']
    if isinstance(task.get('attempts'),int): result['attempt']=task['attempts']
    payload=task.get('payload')
    payload=payload if isinstance(payload,dict) else {}
    for key in ('state','district','court'):
        location=payload.get(key)
        if not isinstance(location,dict): continue
        code=str(location.get('code',''))
        if code.isascii() and code.isdigit() and len(code)<=16: result[key+'_code']=code
    return result


class RequestDiagnostics:
    def __init__(self, client):
        self.client=client
        self.started=time.monotonic()
        self.phase_starts={}
        self.data={'context':dict(client.context),'client_generation':client.client_generation,
                   'session_generation':client.session_generation,'phases':[],
                   'connection_id':None,'connection_evidence':'unknown'}
        self.connect_started=False
        self.connection=None
        self.failure_phase=None
        self.last_connection=client.last_connection

    async def trace(self, name, info):
        # Do not log info: it includes URLs, headers, bodies and TLS objects.
        phase,_,event=name.rpartition('.')
        if phase not in PHASES or event not in ('started','complete','failed'): return
        now=time.monotonic()
        if event=='started':
            self.phase_starts[phase]=now
            if phase=='connection.connect_tcp':
                self.connect_started=True
                self.connection=None
                self.client.last_connection=None
                self.data.update(connection_attempt_id=str(uuid4()),connection_id=None,
                                 tcp_established=False,connection_evidence='tcp_attempt',connection_reused=False)
            elif phase=='http11.send_request_headers' and self.connection:
                # Only a connected transport that reaches HTTP can become a
                # future reuse candidate. Failed TCP/TLS attempts never can.
                self.client.last_connection=self.connection
            elif phase=='http11.send_request_headers' and not self.connect_started and self.last_connection:
                self.data.update(connection_id=self.last_connection['id'],connection_reused=True,
                                 connection_evidence='inferred_sequential_client_no_connect_trace',
                                 connection_age_s=round(now-self.last_connection['created'],3),
                                 connection_idle_s=round(now-self.last_connection['finished'],3) if self.last_connection['finished'] else None)
            return
        if len(self.data['phases'])<24:
            self.data['phases'].append({'phase':phase,'outcome':event,
                'elapsed_s':round(now-self.phase_starts.get(phase,now),3)})
        if event=='failed':
            self.failure_phase=phase
            self.data.update(exception_details(info.get('exception')))
        elif phase=='connection.connect_tcp':
            self.connection={'id':self.data['connection_attempt_id'],'created':now,'finished':None}
            self.data.update(connection_id=self.connection['id'],tcp_established=True,
                             connection_evidence='tcp_connected')
        elif phase=='http11.receive_response_headers':
            result=info.get('return_value')
            if isinstance(result,tuple) and len(result)>=4:
                version,status,_,headers=result[:4]
                self.headers(version,status,headers)
        elif phase=='connection.start_tls':
            stream=info.get('return_value')
            try:
                ssl=stream.get_extra_info('ssl_object')
                alpn=ssl.selected_alpn_protocol() if ssl else None
                if alpn in ('http/1.1','h2',None): self.data['tls_alpn']=alpn
            except (AttributeError,ValueError): pass

    def headers(self, version, status, headers):
        if version in (b'HTTP/1.0',b'HTTP/1.1',b'HTTP/2'):
            self.data['http_version']=version.decode('ascii')
        if isinstance(status,int): self.data['response_status']=status
        safe={}
        for key,value in headers:
            key=key.lower()
            if key in (b'content-length',b'retry-after') and value.isdigit() and len(value)<=12:
                safe[key.decode()]=int(value)
            elif key in (b'connection',b'transfer-encoding') and value.lower() in (b'close',b'keep-alive',b'chunked'):
                safe[key.decode()]=value.decode('ascii').lower()
        self.data['response_headers']=safe

    def finish(self, error=None):
        if error is not None: self.data.update(exception_details(error))
        self.data['failure_phase']=self.failure_phase
        if error is not None or self.failure_phase:
            self.client.last_connection=None
        elif self.client.last_connection:
            self.client.last_connection['finished']=time.monotonic()
        return self.data
