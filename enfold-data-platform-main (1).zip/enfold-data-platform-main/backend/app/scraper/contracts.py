from typing import Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from app.scraper.catalog import ACTS


class RunRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=255)
    stateCodes: list[str] = Field(default_factory=list, max_length=100)
    actKeys: list[str] = Field(default_factory=list, max_length=8)
    allStates: bool = False
    allActs: bool = False
    sections: list[str] = Field(default_factory=list, max_length=100)
    status: Literal['all', 'pending', 'disposed'] = 'all'
    requestId: UUID

    @field_validator('name')
    @classmethod
    def name_not_blank(cls, value):
        if not value.strip(): raise ValueError('Run name cannot be blank')
        return value.strip()

    @model_validator(mode='after')
    def selections(self):
        if self.allStates == bool(self.stateCodes): raise ValueError('Choose states or All states, not both')
        if self.allActs == bool(self.actKeys): raise ValueError('Choose acts or All acts, not both')
        if any(not code.isdigit() or len(code) > 10 for code in self.stateCodes): raise ValueError('Invalid state code')
        if any(key not in ACTS for key in self.actKeys): raise ValueError('Unsupported act')
        if any(not s.strip() or len(s) > 40 for s in self.sections): raise ValueError('Invalid section')
        self.stateCodes = sorted(set(self.stateCodes))
        self.actKeys = sorted(set(self.actKeys))
        self.sections = sorted(set(s.strip() for s in self.sections))
        return self

    def criteria(self):
        return self.model_dump(mode='json', exclude={'name', 'requestId'})
