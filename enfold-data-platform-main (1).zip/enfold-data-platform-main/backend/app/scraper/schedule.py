"""Pure calendar helpers shared by the worker and administrator UI API."""
from zoneinfo import ZoneInfo
from app.config import settings


def scheduled_slot(now):
    local = now.astimezone(ZoneInfo(settings.SCRAPER_TIMEZONE))
    day = 1 + (settings.SCRAPER_MONTHLY_WEEKDAY - local.replace(day=1).weekday()) % 7 + 7 * (settings.SCRAPER_MONTHLY_WEEK - 1)
    return local.replace(day=day, hour=settings.SCRAPER_MONTHLY_HOUR,
                         minute=settings.SCRAPER_MONTHLY_MINUTE, second=0, microsecond=0)


def due_month(now):
    if not settings.SCRAPER_MONTHLY_ENABLED:
        return None
    slot = scheduled_slot(now)
    return slot.strftime('%Y-%m') if now >= slot else None


def schedule_info(now):
    # This is the next calendar slot, not a prediction of worker availability.
    # Overdue work still follows due_month's existing catch-up behavior.
    slot = scheduled_slot(now)
    if slot <= now:
        year, month = (slot.year + 1, 1) if slot.month == 12 else (slot.year, slot.month + 1)
        slot = scheduled_slot(slot.replace(year=year, month=month, day=1))
    return dict(week=settings.SCRAPER_MONTHLY_WEEK, weekday=settings.SCRAPER_MONTHLY_WEEKDAY,
                hour=settings.SCRAPER_MONTHLY_HOUR, minute=settings.SCRAPER_MONTHLY_MINUTE,
                timezone=settings.SCRAPER_TIMEZONE,
                nextRunAt=slot if settings.SCRAPER_MONTHLY_ENABLED else None)
