"""Resolve references on demand. PDF bytes are bounded and held only in memory."""
import asyncio
from urllib.parse import urlsplit
import httpx
from app.document_refs import clean_reference
from app.scraper.client import ECourtsClient, UpstreamError

MAX_PDF_BYTES = 20 * 1024 * 1024
ALLOWED_PDF_HOSTS = {'app.ecourts.gov.in', 'csc.ecourts.gov.in'}


def safe_pdf_url(url):
    if not isinstance(url, str) or len(url) > 16384 or any(ord(c) < 33 for c in url):
        raise UpstreamError('Invalid document URL')
    try:
        parsed = urlsplit(url)
        allowed = (parsed.scheme == 'https' and parsed.hostname in ALLOWED_PDF_HOSTS
                   and parsed.port in (None, 443) and not parsed.username
                   and not parsed.password and not parsed.fragment)
    except ValueError:
        allowed = False
    if not allowed:
        raise UpstreamError('Untrusted document host')
    return url


async def fetch_pdf(reference):
    client = ECourtsClient(interval=2)
    client.http.timeout = httpx.Timeout(20)
    try:
        async with asyncio.timeout(60):
            resolved = await client.get('display_pdf_new.php',
                {**clean_reference(reference), 'bilingual_flag': '1'}, method='POST')
            url = safe_pdf_url(resolved.get('pdf_url'))
            # No Authorization header forwarded to the generated URL. No redirects:
            # every destination must remain on the explicit eCourts allowlist.
            async with client.http.stream('GET', url, follow_redirects=False) as response:
                if response.status_code != 200:
                    raise UpstreamError('Document download unavailable')
                length = response.headers.get('content-length')
                if length and (not length.isdigit() or int(length) > MAX_PDF_BYTES):
                    raise UpstreamError('Document exceeds download limit')
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    if len(body) + len(chunk) > MAX_PDF_BYTES:
                        raise UpstreamError('Document exceeds download limit')
                    body.extend(chunk)
                if not bytes(body[:1024]).lstrip().startswith(b'%PDF-'):
                    raise UpstreamError('eCourts did not return a PDF')
                return bytes(body)
    except (httpx.HTTPError, TimeoutError, ValueError) as error:
        # Exception text/URLs can contain document identifiers; never return them.
        raise UpstreamError('Document download unavailable') from error
    finally:
        await client.close()
