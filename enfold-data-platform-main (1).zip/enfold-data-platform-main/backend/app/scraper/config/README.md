# Maintaining act-name mappings

Edit `act_aliases.json` to add a **verified alternative name for an existing law**.
No Python or frontend edits are needed for an alias. This is a version-controlled
release file, not a live administrator setting. API and worker images include it.

## Editing an alias

1. Obtain the actual act-list label from the relevant eCourts court establishment.
   Confirm that it means the same law, rather than a predecessor, amendment,
   rule or unrelated law with a similar abbreviation. Record the court/source
   evidence in the change description; do not commit case records.
2. Add the name to that law's `aliases` list. Aliases are plain strings, not
   regular expressions. Do not include a year: add an approved title year to
   `years` instead. Both yearless names and those exact trailing years match.
3. Increment `version` (for example, `2026-10-10.1` to `2026-10-10.2`). Keep
   `schema_version`, option keys, law IDs and labels stable. New dropdown options
   or new law identities need a separately reviewed product change.
4. Add positive and negative regression examples in `backend/tests/test_act_catalog.py`.
   Validate from the repository root, with backend dependencies installed:

   ```sh
   PYTHONPATH=backend python -m app.scraper.catalog
   python -m pytest backend/tests/test_act_catalog.py backend/tests/test_scraper.py -q
   ```

5. Review, publish and deploy the tested API/worker release. There is no hot reload.
   Prefer changes between runs. Existing queued search tasks keep their recorded
   court code/mapping; court discovery tasks use the running release's config.
   Every new search records the actual config version **and content hash**, so
   mixed-release runs remain traceable. A single run's discovery version is not
   a claim that every later court task used that version.

Example of the current PCMA definition:

```json
{
  "id": "pcma",
  "name": "Prohibition of Child Marriage Act",
  "years": [2006],
  "preserve_year": false,
  "aliases": ["Prohibition of Child Marriage Act", "Prohibition of Child Marraige Act"]
}
```

## Matching and exclusions

Matching is exact after HTML-entity decoding, Unicode compatibility normalization,
case/space/punctuation normalization, a leading `The`, attached years (`Act2012`),
and dotted initials. It does **not** remove arbitrary years, singularize words,
use substring/fuzzy matching, or accept truncated titles. All matched codes from
that court are searched; codes are never configured as globally stable IDs.

The approved eight frontend keys stay unchanged. IPC and BNS have separate law
IDs under the existing `ipc` option. JJ 2000/2015 and explicit IPC/BNS years remain
in displayed case names. A yearless JJ label stays unspecified; registration date
never determines its law year. A section number is sent as entered for each
selected law; the system does not translate sections between predecessor laws.

On 14 October 2026 the client approved the child-marriage option to include
`The Prohibition Of Child Marriage Act 2006`, `Child Marriage Restraint Act 1929`,
`Child Marriage Act`, and `Prohibition of Child Marraige Act`. The 1929 law has
its own `cmra` identity; the generic label has `childmarriage_unspecified` with
`years: []`, accepting only the yearless label without inferring which law it is.
The explicitly approved `Marraige` spelling maps to PCMA. Other unapproved
abbreviations/typos, unknown years and truncations are not automatically included. `review_terms` only detect candidates;
adding a review term does not make it an accepted alias. Rules/amendments and
other excluded instruments are also not collected as the parent Act.

Near matches are persisted as `act_mapping_review` events in the existing admin
run **Audit history**, with the label, code, court scope, reason, version and hash.
This is an audit trail, not a new approval UI; review the evidence, edit the config
and start a new run to collect newly approved aliases. Such warnings do not make
an otherwise completed run fail, so a successful run does not prove full coverage.
No match is reported as **No approved act-name match**, not proof the law is absent.

Matched source labels/codes and mapping metadata are stored in search-task payloads
(and inherited by case tasks). Duplicate case tasks remain deduplicated by CNR;
all search tasks retain their own mapping evidence. This metadata is admin-only
and does not widen the field-officer case API. The case history is normalized
separately; collecting a case through PCMA does not relabel another law in its
history as PCMA. Existing snapshots are not rewritten.

Invalid JSON, unknown fields, missing options, conflicting aliases, duplicate
normalized aliases, non-integer years and excluded-instrument aliases fail startup
and CI instead of silently producing empty scrapes. Keep the regression examples
independent of the config: a test that generates every expectation from the config
cannot catch a wrongly edited mapping.
