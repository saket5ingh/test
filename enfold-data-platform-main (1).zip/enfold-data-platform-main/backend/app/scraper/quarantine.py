"""Conservative, evidence-based quarantine; called within the fenced task transaction."""
import json
from uuid import UUID
from sqlalchemy import text
from app.config import settings

ENDPOINTS={'court':'actWebService.php','search':'searchByActWebService.php','case':'caseHistoryWebService.php'}


def court_key(payload):
    parts=[]
    for key in ('state','district','court'):
        item=payload.get(key) if isinstance(payload,dict) else None
        code=str(item.get('code','')) if isinstance(item,dict) else ''
        if not code.isascii() or not code.isdigit() or len(code)>16: return None
        parts.append(code)
    return '/'.join(parts)


async def assess(db,task,error):
    key=court_key(task['payload'])
    if (error.kind not in ('response','rejected') or error.retry_after or not key or
        error.endpoint!=ENDPOINTS.get(task['kind']) or task['kind'] not in ENDPOINTS): return None
    try: session=UUID(str(error.session_generation))
    except (ValueError,TypeError): return None  # Bootstrap/unknown session is not court-specific evidence.
    row=(await db.execute(text("""UPDATE pcma.scrape_tasks SET review_failures=review_failures+1,
        review_sessions=review_sessions+CASE WHEN review_last_session IS DISTINCT FROM :session THEN 1 ELSE 0 END,
        review_last_session=:session,review_started_at=COALESCE(review_started_at,clock_timestamp())
        WHERE id=:id RETURNING review_failures,review_sessions,review_started_at,
        extract(epoch from clock_timestamp()-review_started_at) elapsed"""),{'id':task['id'],'session':session})).mappings().one()
    if (row['review_failures']<settings.SCRAPER_QUARANTINE_FAILURES or
        row['review_sessions']<settings.SCRAPER_QUARANTINE_SESSIONS or
        row['elapsed']<settings.SCRAPER_QUARANTINE_MIN_SECONDS): return None
    control=(await db.execute(text('SELECT paused_until,recovery_successes FROM pcma.scraper_control WHERE id=TRUE'))).mappings().one()
    if control['paused_until'] is not None or control['recovery_successes']: return None
    # Same validated business endpoint, another court, AFTER this failure cycle
    # began. A bootstrap success or unrelated discovery task is not sufficient.
    evidence=(await db.execute(text("""SELECT id,run_id,source_validated_at,
        payload->'state'->>'code' AS state,payload->'district'->>'code' AS district,
        payload->'court'->>'code' AS court FROM pcma.scrape_tasks
        WHERE run_id=:run AND kind=:kind AND status='success' AND NOT expanding AND id<>:id
        AND source_validated_at>:since
        AND source_validated_at>=clock_timestamp()-make_interval(secs=>:window)
        AND payload->'state'->>'code' ~ '^[0-9]{1,16}$'
        AND payload->'district'->>'code' ~ '^[0-9]{1,16}$'
        AND payload->'court'->>'code' ~ '^[0-9]{1,16}$'
        AND concat_ws('/',payload->'state'->>'code',payload->'district'->>'code',payload->'court'->>'code')<>:court
        ORDER BY source_validated_at DESC LIMIT 1"""),{'run':task['run_id'],'kind':task['kind'],'id':task['id'],
            'since':row['review_started_at'],'window':settings.SCRAPER_QUARANTINE_RECOVERY_SECONDS,'court':key})).mappings().first()
    if evidence is None: return None
    return {'endpoint':error.endpoint,'failedCourt':key,'failures':row['review_failures'],
            'sessions':row['review_sessions'],'since':row['review_started_at'].isoformat(),
            'successfulTask':str(evidence['id']),'successfulRun':str(evidence['run_id']),
            'successfulCourt':'/'.join(evidence[k] for k in ('state','district','court')),
            'successfulAt':evidence['source_validated_at'].isoformat()}


async def mark(db,task,evidence):
    reason='Persistent court response requires operator review. Coverage is incomplete; no empty or successful result is inferred.'
    await db.execute(text("""UPDATE pcma.scrape_tasks SET review_required=TRUE,review_reason=:reason,
        review_at=clock_timestamp(),review_evidence=CAST(:evidence AS jsonb) WHERE id=:id"""),
        {'id':task['id'],'reason':reason,'evidence':json.dumps(evidence)})
    return reason
