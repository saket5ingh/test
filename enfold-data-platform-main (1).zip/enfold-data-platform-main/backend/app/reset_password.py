"""Owner-only password reset; preserves identity/role and invalidates existing API sessions."""
import argparse
import asyncio
import getpass
import bcrypt
from sqlalchemy import select
from app.database import async_session_maker
from app.models.user import User


def password_hash(password: str, confirmation: str) -> str:
    if not 12 <= len(password.encode('utf-8')) <= 72:
        raise ValueError('Use a password of 12–72 UTF-8 bytes.')
    if password != confirmation:
        raise ValueError('Passwords do not match.')
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


async def reset(user_id: str, hashed: str):
    async with async_session_maker() as db:
        user = (await db.execute(select(User).where(User.user_id == user_id).with_for_update())).scalar_one_or_none()
        if user is None:
            raise ValueError('Account does not exist.')
        user.password_hash = hashed
        user.auth_version += 1
        await db.commit()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('user_id')
    args = parser.parse_args()
    try:
        hashed = password_hash(getpass.getpass('New password: '), getpass.getpass('Confirm password: '))
        asyncio.run(reset(args.user_id, hashed))
    except ValueError as error:
        raise SystemExit(str(error))
    print('Password reset. Existing API sessions are invalid. Account activation and role are unchanged.')


if __name__ == '__main__':
    main()
