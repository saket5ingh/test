"""Google Identity Services: existing accounts only, roles always read from our DB."""
import secrets
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from google.auth.exceptions import GoogleAuthError
from google.auth.transport.requests import Request as GoogleRequest
from google.oauth2 import id_token
from jose import jwt, JWTError
from pydantic import BaseModel, Field
from sqlalchemy import select, func, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool
from app.auth import create_access_token
from app.config import settings
from app.database import get_db
from app.models.user import User
from app.schemas.auth import AccountSchema, SessionSchema

router = APIRouter(prefix='/auth/google', tags=['auth'])
COOKIE = 'ffg_google_nonce'
COOKIE_PATH = '/api/auth/google'


class GoogleCredential(BaseModel):
    credential: str = Field(min_length=1, max_length=12000)


@router.get('/config')
async def configuration(response: Response):
    response.headers['Cache-Control'] = 'no-store'
    if not settings.GOOGLE_CLIENT_ID:
        return {'enabled': False, 'clientId': '', 'nonce': ''}
    nonce = secrets.token_urlsafe(32)
    challenge = jwt.encode({'typ': 'google_nonce', 'nonce': nonce,
                            'exp': datetime.now(timezone.utc).timestamp() + 600},
                           settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    response.set_cookie(COOKIE, challenge, max_age=600, httponly=True,
                        secure=settings.AUTH_COOKIE_SECURE, samesite='strict', path=COOKIE_PATH)
    return {'enabled': True, 'clientId': settings.GOOGLE_CLIENT_ID, 'nonce': nonce}


def verify_credential(credential: str):
    # Runs in a worker thread; no HTTP requests at import time. Bound network timeout.
    transport = GoogleRequest()
    def bounded_request(*args, **kwargs):
        kwargs['timeout'] = 10
        return transport(*args, **kwargs)
    return id_token.verify_oauth2_token(credential, bounded_request, settings.GOOGLE_CLIENT_ID)


def validate_identity(claims: dict, nonce: str):
    if not nonce or claims.get('nonce') != nonce or claims.get('email_verified') is not True:
        raise ValueError('Invalid Google identity')
    if not isinstance(claims.get('sub'), str) or not claims['sub'] or len(claims['sub']) > 255:
        raise ValueError('Invalid Google subject')
    email = claims.get('email', '').lower()
    domain = claims.get('hd', '')
    if settings.GOOGLE_ALLOWED_DOMAINS and domain not in settings.GOOGLE_ALLOWED_DOMAINS:
        raise ValueError('Workspace domain not allowed')
    # Google must be authoritative for the email before an unlinked account can be linked.
    authoritative = email.endswith('@gmail.com') or bool(domain)
    return email, authoritative


@router.post('', response_model=SessionSchema)
async def login_google(body: GoogleCredential, request: Request, response: Response,
                       db: AsyncSession = Depends(get_db)):
    if not settings.GOOGLE_CLIENT_ID:
        raise HTTPException(503, 'Google sign-in is not configured')
    try:
        challenge = jwt.decode(request.cookies.get(COOKIE, ''), settings.JWT_SECRET,
                               algorithms=[settings.JWT_ALGORITHM], options={'require_exp': True})
        if challenge.get('typ') != 'google_nonce':
            raise ValueError('Invalid challenge')
        claims = await run_in_threadpool(verify_credential, body.credential)
        email, authoritative = validate_identity(claims, challenge.get('nonce', ''))
    except (JWTError, ValueError, GoogleAuthError):
        raise HTTPException(401, 'Google sign-in could not be verified. Please try again.')

    user = (await db.execute(select(User).where(User.google_sub == claims['sub']))).scalar_one_or_none()
    if user is None and authoritative:
        user = (await db.execute(select(User).where(func.lower(User.email) == email))).scalar_one_or_none()
    if user is None or not user.is_active or user.google_sub not in (None, claims['sub']):
        raise HTTPException(403, 'An active provisioned account is required. Contact your administrator.')
    if user.google_sub is None:
        try:
            result = await db.execute(update(User).where(User.id == user.id, User.google_sub.is_(None))
                                      .values(google_sub=claims['sub']).execution_options(synchronize_session=False))
            if result.rowcount != 1:
                await db.rollback()
                raise HTTPException(409, 'Account changed during sign-in. Please try again.')
            await db.commit()
        except IntegrityError:
            await db.rollback()
            raise HTTPException(409, 'Account changed during sign-in. Please try again.')
    response.delete_cookie(COOKIE, path=COOKIE_PATH, secure=settings.AUTH_COOKIE_SECURE,
                           httponly=True, samesite='strict')
    response.headers['Cache-Control'] = 'no-store'
    return SessionSchema(account=AccountSchema.model_validate(user),
                         token=create_access_token({'sub': user.user_id, 'ver': user.auth_version}))
