from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, func
from app.database import get_db
from app.models.user import User
from app.schemas.auth import CredentialsSchema, SessionSchema, AccountSchema
from app.auth import create_access_token, get_current_user
from starlette.concurrency import run_in_threadpool

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/login", response_model=SessionSchema)
async def login(credentials: CredentialsSchema, db: AsyncSession = Depends(get_db)):
    identifier = credentials.userId.strip()
    result = await db.execute(select(User).where(or_(
        User.user_id == identifier, func.lower(User.email) == identifier.lower()
    )))
    users = result.scalars().all()
    # Ambiguous identifiers must not pick an arbitrary account.
    user = users[0] if len(users) == 1 else None
    if not user or not user.is_active or not await run_in_threadpool(user.verify_password, credentials.password):
        raise HTTPException(status_code=401, detail="Invalid user ID or password")
    
    token = create_access_token({"sub": user.user_id, "ver": user.auth_version})
    account = AccountSchema.model_validate(user)
    return SessionSchema(account=account, token=token)

@router.get("/me", response_model=AccountSchema)
async def me(user: User = Depends(get_current_user)):
    return AccountSchema.model_validate(user)
