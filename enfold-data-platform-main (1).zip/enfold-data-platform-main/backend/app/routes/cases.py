import calendar
from datetime import datetime
from typing import Annotated
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, delete, func
from sqlalchemy.orm import noload
from sqlalchemy.dialects.postgresql import insert
from app.models.pin import CasePin
from app.database import get_db
from app.models.case import Case
from app.schemas.case import CaseSchema, PinUpdateSchema, CasePageSchema, CaseUpdatesSchema
from app.schemas.query import CaseQuery
from app.schemas.scrape import ScrapeSchema
from app.auth import get_current_user
from app.models.user import User
from app.case_queries import case_conditions, pin_exists, attention_order

router = APIRouter(tags=['cases'])


def serialize_case(case: Case, user: User, pinned: bool) -> CaseSchema:
    result = CaseSchema.model_validate(case)
    result.pinned = pinned
    if user.role != 'admin':
        result.cnr = result.caseNo = result.regNo = result.complex = result.court = None
        result.hearings = []
    return result


@router.get('/cases', response_model=CasePageSchema)
async def get_cases(query: Annotated[CaseQuery, Query()], db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    conditions = case_conditions(query, current_user)
    total = (await db.execute(select(func.count()).select_from(Case).where(*conditions))).scalar_one()
    statement = (select(Case).where(*conditions).options(noload(Case.hearings), noload(Case.documents))
                 .order_by(*attention_order()).offset((query.page - 1) * query.pageSize).limit(query.pageSize))
    cases = (await db.execute(statement)).scalars().all()
    pins = set((await db.execute(select(CasePin.case_id).where(
        CasePin.user_id == current_user.id, CasePin.case_id.in_([c.id for c in cases])))).scalars()) if cases else set()
    return CasePageSchema(items=[serialize_case(c, current_user, c.id in pins) for c in cases],
                          total=total, page=query.page, pageSize=query.pageSize)


@router.get('/cases/updates', response_model=CaseUpdatesSchema)
async def get_updates(db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    from sqlalchemy import text
    from app.schemas.case import CaseUpdateSchema
    params = {'user': current_user.id}
    total = (await db.execute(text('SELECT count(*) FROM pcma.case_notifications WHERE user_id=:user'), params)).scalar_one()
    critical = (await db.execute(text("SELECT count(*) FROM pcma.case_notifications WHERE user_id=:user AND payload->>'severity'='critical'"), params)).scalar_one()
    notifications = (await db.execute(text("SELECT case_id,payload FROM pcma.case_notifications WHERE user_id=:user ORDER BY CASE WHEN payload->>'severity'='critical' THEN 0 ELSE 1 END, payload->>'at' DESC,case_id LIMIT 20"), params)).mappings().all()
    if not notifications: return CaseUpdatesSchema(items=[], total=total, critical=critical)
    cases = (await db.execute(select(Case).where(Case.id.in_([n['case_id'] for n in notifications]))
        .options(noload(Case.hearings), noload(Case.documents)))).scalars().all()
    lookup = {c.id: c for c in cases}
    items = []
    for notification in notifications:
        if notification['case_id'] not in lookup: continue
        item = serialize_case(lookup[notification['case_id']], current_user, True)
        item.update = CaseUpdateSchema.model_validate(notification['payload'])
        items.append(item)
    return CaseUpdatesSchema(items=items, total=total, critical=critical)


@router.get("/cases/{case_id}", response_model=CaseSchema)
async def get_case(case_id: UUID, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    case = (await db.execute(select(Case).where(Case.id == case_id).options(noload(Case.documents)))).scalar_one_or_none()
    if case is None:
        raise HTTPException(status_code=404, detail="Case not found")
    pin = await db.get(CasePin, (current_user.id, case_id))
    return serialize_case(case, current_user, pin is not None)


@router.put("/cases/{case_id}/pin", status_code=204)
async def pin_case(case_id: UUID, data: PinUpdateSchema, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    if await db.get(Case, case_id) is None:
        raise HTTPException(status_code=404, detail="Case not found")
    if data.pinned:
        await db.execute(insert(CasePin).values(user_id=current_user.id, case_id=case_id).on_conflict_do_nothing())
    else:
        await db.execute(delete(CasePin).where(CasePin.user_id == current_user.id, CasePin.case_id == case_id))
    await db.commit()


@router.get('/scrapes', response_model=list[ScrapeSchema])
async def get_scrapes(db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    rows = (await db.execute(select(Case.last_scrape, func.count().label('count'))
        .where(Case.last_scrape.is_not(None)).group_by(Case.last_scrape).order_by(desc(Case.last_scrape)))).all()
    scrapes = []
    for row in rows:
        try:
            dt = datetime.strptime(row.last_scrape, '%Y-%m')
            scrapes.append({'id': row.last_scrape, 'label': f'{calendar.month_name[dt.month]} {dt.year}',
                            'short': f'{calendar.month_abbr[dt.month]} {dt.year}',
                            'date': dt.strftime('%Y-%m-01'), 'count': row.count})
        except ValueError:
            continue
    return scrapes
