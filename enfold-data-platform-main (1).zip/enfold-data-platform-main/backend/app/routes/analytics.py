from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc, text, String, or_, case
from app.database import get_db
from app.auth import get_current_user
from app.models.case import Case
from app.schemas.analytics import StateCountSchema, OutcomeCountSchema, SectionCountSchema, YearCountSchema
from app.scraper.catalog import CATALOG

# Use the same approved family as scraping; a case citing two laws still counts once.
CHILD_MARRIAGE_NAMES = CATALOG.canonical_names('childmarriage')
child_marriage_case = or_(*(Case.acts.contains([{"name": name}]) for name in CHILD_MARRIAGE_NAMES))

router = APIRouter(prefix="/analytics", tags=["analytics"], dependencies=[Depends(get_current_user)])

@router.get("/by-state", response_model=list[StateCountSchema])
async def get_by_state(db: AsyncSession = Depends(get_db)):
    stmt = select(Case.state, func.count().label('value')).where(child_marriage_case).group_by(Case.state).order_by(desc('value'))
    result = await db.execute(stmt)
    return [{"state": r.state or "Unknown", "value": r.value} for r in result]

@router.get("/outcomes", response_model=list[OutcomeCountSchema])
async def get_outcomes(db: AsyncSession = Depends(get_db)):
    # Pending cases frequently have no disposition text; do not omit them.
    outcome = func.coalesce(func.nullif(func.trim(Case.disposition_raw), ''),
        case((Case.status == 'pending', 'Pending'), else_=func.initcap(Case.status)), 'Unknown')
    stmt = select(outcome.label('label'), func.count().label('value')).where(child_marriage_case).group_by(outcome).order_by(outcome)
    result = await db.execute(stmt)
    return [{"label": r.label, "value": r.value} for r in result]

@router.get("/by-section", response_model=list[SectionCountSchema])
async def get_by_section(db: AsyncSession = Depends(get_db)):
    # Section 9 of one law is not section 9 of another law. Dedupe within each law.
    query = text("""
        SELECT act_elem->>'name' AS act, section_elem AS section, COUNT(DISTINCT cases.id) AS value
        FROM pcma.cases,
        jsonb_array_elements(acts) AS act_elem,
        jsonb_array_elements_text(act_elem->'sections') AS section_elem
        WHERE act_elem->>'name' = ANY(:names) AND trim(section_elem) <> ''
        GROUP BY act_elem->>'name', section_elem
        ORDER BY act, value DESC, section
    """)
    result = await db.execute(query, {'names': CHILD_MARRIAGE_NAMES})
    return [{"act": r.act, "section": r.section, "value": r.value} for r in result]

@router.get("/by-year", response_model=list[YearCountSchema])
async def get_by_year(db: AsyncSession = Depends(get_db)):
    year = func.coalesce(Case.registration_year.cast(String), 'Unknown')
    stmt = select(year.label('year'), func.count().label('value')).where(child_marriage_case).group_by(year).order_by(year)
    result = await db.execute(stmt)
    return [{"year": r.year, "value": r.value} for r in result]
