"""Both application roles may download final judgments; references stay private."""
import asyncio
from datetime import date
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.auth import get_current_user
from app.database import get_db
from app.models.case import Case
from app.models.document import CaseDocument
from app.models.user import User
from app.scraper.documents import fetch_pdf
from app.scraper.client import UpstreamError

router = APIRouter(tags=['documents'])
_download_slots = asyncio.Semaphore(2)


class FinalJudgment(BaseModel):
    id: UUID
    date: date | None


@router.get('/cases/{case_id}/final-judgments', response_model=list[FinalJudgment])
async def list_judgments(case_id: UUID, response: Response, db: AsyncSession = Depends(get_db),
                         user: User = Depends(get_current_user)):
    response.headers['Cache-Control'] = 'private, no-store'
    if (await db.execute(select(Case.id).where(Case.id == case_id))).scalar_one_or_none() is None:
        raise HTTPException(404, 'Case not found')
    rows = (await db.execute(select(CaseDocument.id, CaseDocument.document_date)
        .where(CaseDocument.case_id == case_id, CaseDocument.document_type == 'final',
               CaseDocument.source_key.is_not(None), CaseDocument.source_reference.is_not(None))
        .order_by(CaseDocument.document_date.desc().nullslast(), CaseDocument.id))).all()
    return [FinalJudgment(id=row.id, date=row.document_date) for row in rows]


@router.get('/cases/{case_id}/final-judgments/{document_id}/download')
async def download_judgment(case_id: UUID, document_id: UUID, db: AsyncSession = Depends(get_db),
                            user: User = Depends(get_current_user)):
    # The case/document pair is checked on the server, not trusted from the UI.
    reference = (await db.execute(select(CaseDocument.source_reference).where(
        CaseDocument.id == document_id, CaseDocument.case_id == case_id,
        CaseDocument.document_type == 'final', CaseDocument.source_key.is_not(None)))).scalar_one_or_none()
    await db.rollback()  # Do not hold a transaction/connection during upstream I/O.
    if reference is None:
        raise HTTPException(404, 'Final judgment not available')
    if _download_slots.locked():
        raise HTTPException(503, 'Downloads are busy. Please try again shortly.', headers={'Retry-After': '10'})
    async with _download_slots:
        try:
            body = await fetch_pdf(reference)
        except UpstreamError:
            raise HTTPException(502, 'eCourts could not provide this document. Please try again later.') from None
    return Response(body, media_type='application/pdf', headers={
        'Content-Disposition': f'attachment; filename="final-judgment-{document_id}.pdf"',
        'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff'})
