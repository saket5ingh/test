from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from app.database import get_db
from app.auth import get_current_user
from app.models.user import User
from app.models.case import Case
from app.schemas.options import FilterOptionsSchema

router = APIRouter(tags=["options"])

@router.get("/options", response_model=FilterOptionsSchema)
async def get_options(db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    states = (await db.execute(select(Case.state).distinct().where(Case.state != None))).scalars().all()
    districts = (await db.execute(select(Case.district).distinct().where(Case.district != None))).scalars().all()
    statuses = (await db.execute(select(Case.status).distinct().where(Case.status != None))).scalars().all()
    purposes = (await db.execute(select(Case.last_purpose).distinct().where(Case.last_purpose != None))).scalars().all()
    caseTypes = (await db.execute(select(Case.case_type_class).distinct().where(Case.case_type_class != None))).scalars().all()
    complexes = (await db.execute(select(Case.complex_name).distinct().where(Case.complex_name != None))).scalars().all()
    courts = (await db.execute(select(Case.court_name).distinct().where(Case.court_name != None))).scalars().all()
    
    acts = (await db.execute(text("SELECT DISTINCT act->>'name' FROM pcma.cases CROSS JOIN LATERAL jsonb_array_elements(acts) act ORDER BY 1"))).scalars().all()
    total = (await db.execute(select(func.count()).select_from(Case))).scalar_one()

    return FilterOptionsSchema(
        totalCases=total,
        states=sorted(states),
        districts=sorted(districts),
        acts=acts,
        statuses=statuses,
        purposes=sorted(purposes),
        caseTypes=sorted(caseTypes),
        complexes=complexes if current_user.role == "admin" else [],
        courts=courts if current_user.role == "admin" else []
    )
