from uuid import UUID
import json
from pydantic import BaseModel, ConfigDict, Field, field_validator
from typing import Literal
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.auth import require_admin
from app.database import get_db, async_session_maker
from app.models.user import User
from app.config import settings
from app.scraper.catalog import ACTS
from app.scraper.schedule import schedule_info
from app.scraper.contracts import RunRequest
from app.scraper.store import create_run, event
from app.scraper.export import COLUMNS, csv_line
from app.scraper.monitor import summaries, performance

router = APIRouter(prefix='/scrapes', tags=['scrapes'], dependencies=[Depends(require_admin)])
TERMINAL = {'success', 'partial', 'failed', 'cancelled'}


async def get_run(db, run_id, lock=False):
    row = (await db.execute(text('''SELECT r.*,u.name AS initiated_by_name FROM pcma.scrape_runs r
        LEFT JOIN pcma.users u ON u.id=r.triggered_by WHERE r.id=:id'''
        + (' FOR UPDATE OF r' if lock else '')), {'id':run_id})).mappings().first()
    if row is None: raise HTTPException(404, 'Scrape run not found')
    return row


async def run_view(db, row, summary=None):
    summary=summary if summary is not None else (await summaries(db,[row['id']]))[row['id']]
    tasks,results,coverage=summary['tasks'],summary['counts'],summary['coverage']
    last_activity=summary['progress'].get('last_activity_at')
    return dict(id=row['id'], name=row['name'], criteria=row['criteria'], resolvedScope=row['resolved_scope'],
        trigger=row['trigger_type'], triggeredBy=row['triggered_by'], triggeredByName=row.get('initiated_by_name'), queuedAt=row['queued_at'],
        startedAt=row['started_at'], completedAt=row['completed_at'], outcome=row['outcome'],
        lastActivityAt=last_activity, performance=performance(row,summary),
        quarantined=summary.get('quarantined',0), coverageIncomplete=bool(tasks.get('failed',0)),
        cancelRequested=row['cancel_requested'], error=row['error_message'], tasks=tasks, counts=results,
        coverage=[dict(r) for r in coverage], total=sum(results.values()) if row['snapshot_version'] == 1 else row['total_cases_found'] or 0,
        snapshotsAvailable=row['snapshot_version'] == 1,
        legacyCriteria={'state':row['state'], 'acts':row['acts'], 'sections':row['sections'], 'status':row['status_filter']})


@router.get('/options')
async def options(db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(text("SELECT key,value,updated_at FROM pcma.scraper_metadata WHERE key IN ('states','worker')"))).mappings().all()
    data = {r['key']:r for r in rows}
    return {'states': data['states']['value'] if 'states' in data else [],
            'statesUpdatedAt': data['states']['updated_at'] if 'states' in data else None,
            'workerLastSeen': data['worker']['updated_at'] if 'worker' in data else None,
            'workerHealthy': 'worker' in data and data['worker']['updated_at'] > datetime.now(timezone.utc) - timedelta(minutes=10),
            'acts':[{'key':key,'label':label} for key,(label,_) in ACTS.items()],
            'monthlyEnabled':settings.SCRAPER_MONTHLY_ENABLED,
            'monthlySchedule':schedule_info(datetime.now(timezone.utc))}


@router.post('/run', status_code=202)
async def run_scrape(data: RunRequest, db: AsyncSession = Depends(get_db), user: User = Depends(require_admin)):
    try: run_id = await create_run(db, data, actor=user.id)
    except ValueError as error: raise HTTPException(409, str(error))
    await db.commit()
    return {'id':run_id}


@router.get('/runs')
async def list_runs(page: int = Query(1, ge=1), pageSize: int = Query(25, ge=1, le=100),
                    q: str = Query('', max_length=160),
                    outcome: Literal['all','pending','queued','running','success','partial','failed','cancelled'] = 'all',
                    trigger: Literal['all','manual','scheduled'] = 'all', db: AsyncSession = Depends(get_db)):
    clauses, params = [], {'limit':pageSize, 'offset':(page-1)*pageSize}
    if q.strip():
        clauses.append('r.name ILIKE :query'); params['query'] = search_pattern(q)
    if outcome != 'all':
        clauses.append('r.outcome=:outcome'); params['outcome'] = outcome
    if trigger != 'all':
        clauses.append('r.trigger_type=:trigger'); params['trigger'] = trigger
    where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_runs r' + where), params)).scalar_one()
    rows = (await db.execute(text('SELECT r.*,u.name AS initiated_by_name FROM pcma.scrape_runs r '
        'LEFT JOIN pcma.users u ON u.id=r.triggered_by' + where +
        ' ORDER BY r.queued_at DESC,r.id DESC LIMIT :limit OFFSET :offset'), params)).mappings().all()
    stats=await summaries(db,[row['id'] for row in rows])
    return {'items':[await run_view(db,row,stats[row['id']]) for row in rows], 'total':total, 'page':page, 'pageSize':pageSize}


@router.get('/runs/{run_id}')
async def detail(run_id: UUID, db: AsyncSession = Depends(get_db)):
    return await run_view(db, await get_run(db, run_id))


@router.post('/runs/{run_id}/cancel', status_code=202)
async def cancel(run_id: UUID, db: AsyncSession = Depends(get_db), user: User = Depends(require_admin)):
    row = await get_run(db, run_id, lock=True)
    if row['outcome'] in TERMINAL: raise HTTPException(409, 'This run has already finished')
    await db.execute(text("UPDATE pcma.scrape_runs SET cancel_requested=TRUE,outcome='cancelled',completed_at=CURRENT_TIMESTAMP WHERE id=:id"), {'id':run_id})
    await db.execute(text("UPDATE pcma.scrape_tasks SET status='cancelled',completed_at=CURRENT_TIMESTAMP WHERE run_id=:id AND status='queued'"), {'id':run_id})
    await event(db, run_id, 'cancel_requested', 'Administrator requested cancellation; in-flight work will be discarded', actor_id=user.id)
    await db.commit()
    return {'id':run_id}


@router.post('/runs/{run_id}/retry', status_code=202)
async def retry(run_id: UUID, db: AsyncSession = Depends(get_db), user: User = Depends(require_admin)):
    row = await get_run(db, run_id, lock=True)
    if row['outcome'] not in ('partial','failed','cancelled') or row['snapshot_version'] != 1:
        raise HTTPException(409, 'Only failed, partial or cancelled scraper runs can be retried')
    running = (await db.execute(text("SELECT COALESCE(sum(total),0) FROM pcma.scrape_task_counts WHERE run_id=:id AND status='running'"), {'id':run_id})).scalar_one()
    if running: raise HTTPException(409, 'Wait for cancellation of the in-flight request before retrying')
    eligible=(await db.execute(text("SELECT 1 FROM pcma.scrape_tasks WHERE run_id=:id AND status IN ('failed','cancelled') AND NOT review_required LIMIT 1"),{'id':run_id})).scalar_one_or_none()
    if eligible is None: raise HTTPException(409,'No ordinary unfinished tasks; quarantined tasks need individual operator review')
    # Keep attempts monotonic to fence stale workers. Each explicit retry grants a
    # fresh attempt budget via a stored base offset, rather than replacing snapshots.
    await db.execute(text("UPDATE pcma.scrape_tasks SET status='queued',available_at=CURRENT_TIMESTAMP,completed_at=NULL,error_message=NULL,error_kind=NULL,lease_owner=NULL,lease_until=NULL,retry_base=attempts WHERE run_id=:id AND status IN ('failed','cancelled') AND NOT review_required"), {'id':run_id})
    await db.execute(text("UPDATE pcma.scrape_runs SET outcome='queued',cancel_requested=FALSE,completed_at=NULL,error_message=NULL WHERE id=:id"), {'id':run_id})
    await event(db, run_id, 'retry_requested', 'Administrator requeued unsuccessful work; completed snapshots preserved', actor_id=user.id)
    await db.commit()
    return {'id':run_id}


class ReviewRetry(BaseModel):
    model_config=ConfigDict(extra='forbid')
    reason: str = Field(min_length=3,max_length=500)

    @field_validator('reason',mode='before')
    @classmethod
    def strip_reason(cls,value):
        return value.strip() if isinstance(value,str) else value


@router.post('/runs/{run_id}/tasks/{task_id}/review-retry',status_code=202)
async def review_retry(run_id: UUID, task_id: UUID, data: ReviewRetry,
                       db: AsyncSession=Depends(get_db),user: User=Depends(require_admin)):
    run=await get_run(db,run_id,lock=True)
    if run['cancel_requested']:
        inflight=(await db.execute(text("SELECT 1 FROM pcma.scrape_tasks WHERE run_id=:id AND status='running' LIMIT 1"),{'id':run_id})).scalar_one_or_none()
        if inflight: raise HTTPException(409,'Wait for the cancelled in-flight work to stop')
    task=(await db.execute(text('SELECT * FROM pcma.scrape_tasks WHERE id=:task AND run_id=:run FOR UPDATE'),{'task':task_id,'run':run_id})).mappings().first()
    if task is None: raise HTTPException(404,'Task not found in this run')
    if not task['review_required'] or task['status']!='failed': raise HTTPException(409,'Task is not awaiting operator review')
    # Selected task only. No rewind of identity, claim fences, lifetime counters,
    # saved records or earlier snapshots. Historical review evidence lives in audit.
    await event(db,run_id,'operator_review_retry',json.dumps({'reason':data.reason,
        'previousReason':task['review_reason'],'previousEvidence':task['review_evidence'],
        'previousFailures':task['review_failures'],'previousSessions':task['review_sessions']}),task_id,actor_id=user.id)
    await db.execute(text("""UPDATE pcma.scrape_tasks SET status='queued',review_required=FALSE,
        review_failures=0,review_sessions=0,review_started_at=NULL,review_last_session=NULL,
        retry_base=attempts,available_at=CURRENT_TIMESTAMP,completed_at=NULL,
        lease_owner=NULL,lease_until=NULL,error_message=NULL,error_kind=NULL WHERE id=:id"""),{'id':task_id})
    await db.execute(text("""UPDATE pcma.scrape_runs SET outcome=CASE WHEN outcome='running' THEN 'running' ELSE 'queued' END,
        cancel_requested=FALSE,completed_at=NULL WHERE id=:id"""),{'id':run_id})
    await db.commit()
    return {'id':task_id}


def search_pattern(value):
    """Literal substring search: users' percent/underscore characters aren't wildcards."""
    return '%' + value.strip().replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_') + '%'


@router.get('/runs/{run_id}/results')
async def results(run_id: UUID, page: int = Query(1, ge=1), pageSize: int = Query(25, ge=1, le=100),
                  q: str = Query('', max_length=160), state: str = Query('', max_length=100),
                  status: Literal['all','pending','disposed','acquitted','allowed','rejected'] = 'all',
                  change_kind: Literal['all','new','updated','unchanged'] = 'all', db: AsyncSession = Depends(get_db)):
    row = await get_run(db, run_id)
    if row['snapshot_version'] != 1: raise HTTPException(409, 'Historical results were not recorded for this legacy run')
    # Every predicate reads the saved snapshot, never the latest case record.
    clauses, params = ['run_id=:id'], {'id':run_id,'limit':pageSize,'offset':(page-1)*pageSize}
    if q.strip():
        clauses.append("(" + ' OR '.join(f"snapshot->>'{field}' ILIKE :query" for field in ('cnr','ref','district','state')) + ")")
        params['query'] = search_pattern(q)
    if state.strip(): clauses.append("snapshot->>'state'=:state"); params['state'] = state.strip()
    if status != 'all': clauses.append("snapshot->>'status'=:status"); params['status'] = status
    if change_kind != 'all': clauses.append('change_kind=:change'); params['change'] = change_kind
    where = ' AND '.join(clauses)
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_cases WHERE ' + where), params)).scalar_one()
    rows = (await db.execute(text('SELECT snapshot,fetched_at,change_kind FROM pcma.scrape_run_cases WHERE ' + where
        + ' ORDER BY case_id LIMIT :limit OFFSET :offset'), params)).mappings().all()
    return {'items':[dict(r) for r in rows], 'total':total,'page':page,'pageSize':pageSize}


@router.get('/runs/{run_id}/events')
async def events(run_id: UUID, page: int = Query(1, ge=1), pageSize: int = Query(50, ge=1, le=100),
                 q: str = Query('', max_length=160), kind: Literal['all','errors','warnings','activity'] = 'all',
                 db: AsyncSession = Depends(get_db)):
    await get_run(db, run_id)
    clauses, params = ['e.run_id=:id'], {'id':run_id,'offset':(page-1)*pageSize,'limit':pageSize}
    errors = "e.kind IN ('task_failed','task_retry','source_paused','source_retry_alert','operator_review_required','data_rejected','failed','partial')"
    warnings = "e.kind IN ('act_unavailable','act_mapping_review','document_warning')"
    if kind == 'errors': clauses.append(errors)
    elif kind == 'warnings': clauses.append(warnings)
    elif kind == 'activity': clauses.append(f'NOT ({errors} OR {warnings})')
    if q.strip(): clauses.append('e.message ILIKE :query'); params['query'] = search_pattern(q)
    where = ' AND '.join(clauses)
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_run_events e WHERE ' + where), params)).scalar_one()
    rows = (await db.execute(text('''SELECT e.*,u.name AS actor_name FROM pcma.scrape_run_events e
        LEFT JOIN pcma.users u ON u.id=e.actor_id WHERE ''' + where + ' ORDER BY e.at DESC,e.id DESC LIMIT :limit OFFSET :offset'), params)).mappings().all()
    return {'items':[dict(r) for r in rows],'total':total,'page':page,'pageSize':pageSize}


@router.get('/runs/{run_id}/tasks')
async def tasks(run_id: UUID, status: Literal['all','queued','running','success','failed','cancelled','quarantined'] = 'failed',
                page: int = Query(1, ge=1), pageSize: int = Query(25, ge=1, le=100), q: str = Query('', max_length=160),
                kind: Literal['all','discover','state','district','court','search','case'] = 'all', db: AsyncSession = Depends(get_db)):
    await get_run(db, run_id)
    params = {'run':run_id, 'offset':(page-1)*pageSize,'limit':pageSize}
    clauses = ['run_id=:run']
    if status == 'quarantined': clauses.append('review_required')
    elif status != 'all': clauses.append('status=:status'); params['status'] = status
    if kind != 'all': clauses.append('kind=:kind'); params['kind'] = kind
    if q.strip():
        clauses.append("(" + ' OR '.join(f'{field} ILIKE :query' for field in
            ("payload->'state'->>'name'", "payload->'district'->>'name'", "payload->'court'->>'name'", "payload->>'cnr'", 'error_message')) + ")")
        params['query'] = search_pattern(q)
    where = ' AND '.join(clauses)
    total = (await db.execute(text('SELECT count(*) FROM pcma.scrape_tasks WHERE ' + where), params)).scalar_one()
    rows = (await db.execute(text('SELECT id,kind,payload,status,attempts,error_message,error_kind,review_required,review_reason,review_at,review_evidence,review_failures,review_sessions FROM pcma.scrape_tasks WHERE '
        + where + ' ORDER BY id LIMIT :limit OFFSET :offset'), params)).mappings().all()
    return {'items':[dict(r) for r in rows], 'total':total, 'page':page, 'pageSize':pageSize}


@router.get('/runs/{run_id}/csv')
async def download_csv(run_id: UUID, db: AsyncSession = Depends(get_db)):
    row = await get_run(db, run_id)
    if row['snapshot_version'] != 1: raise HTTPException(409, 'Historical results were not recorded for this legacy run')
    if row['outcome'] not in TERMINAL: raise HTTPException(409, 'Wait for the run to finish or cancel it before downloading')
    # A server-side cursor bounds memory and keeps the export view consistent
    # while a retried partial run may add further snapshots.
    async def content():
        yield '\ufeff' + csv_line(['Run ID','Run name','Collected at',*[label for _,label in COLUMNS]])
        async with async_session_maker() as session, session.begin():
            await session.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY'))
            statement = text('SELECT snapshot,fetched_at FROM pcma.scrape_run_cases WHERE run_id=:id ORDER BY case_id')
            rows = await session.stream(statement.execution_options(yield_per=200), {'id':run_id})
            async for result in rows.mappings():
                yield csv_line([str(run_id),row['name'],result['fetched_at'].isoformat(),*[result['snapshot'].get(key) for key,_ in COLUMNS]])
    return StreamingResponse(content(), media_type='text/csv', headers={
        'Content-Disposition':f'attachment; filename="ffg-run-{run_id}.csv"', 'Cache-Control':'no-store'})


@router.get('/runs/{run_id}/results/{case_id}')
async def snapshot_detail(run_id: UUID, case_id: UUID, db: AsyncSession = Depends(get_db)):
    await get_run(db, run_id)
    row = (await db.execute(text('SELECT snapshot,fetched_at,change_kind FROM pcma.scrape_run_cases WHERE run_id=:run AND case_id=:case'),
        {'run':run_id,'case':case_id})).mappings().first()
    if row is None: raise HTTPException(404, 'Snapshot not found')
    return dict(row)
