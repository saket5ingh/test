from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import List
from datetime import datetime
from uuid import UUID

class ScrapeSchema(BaseModel):
    id: str
    label: str
    short: str
    date: str
    count: int = 0

class CustomScrapeSchema(BaseModel):
    id: UUID
    name: str
    state: str
    acts: str
    status: str = Field(validation_alias='status_filter')
    sections: str

    ranAt: datetime = Field(validation_alias='started_at')
    triggeredBy: str = Field(default="")
    outcome: str
    count: int = Field(validation_alias='total_cases_found')
    
    @field_validator('state', 'acts', 'sections', 'status', 'outcome', mode='before')
    @classmethod
    def missing_text(cls, value):
        return value or ''

    @field_validator('count', mode='before')
    @classmethod
    def missing_count(cls, value):
        return value or 0

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

class ScrapeRunResultSchema(BaseModel):
    total: int
    pending: int
    disposed: int
    flagged: int
    trend: List[int]

class ScrapeFormSchema(BaseModel):
    name: str
    state: str
    acts: str
    status: str
    sections: str
