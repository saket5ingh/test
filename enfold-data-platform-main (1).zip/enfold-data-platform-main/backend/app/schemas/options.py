from pydantic import BaseModel
from typing import List

class FilterOptionsSchema(BaseModel):
    totalCases: int
    states: List[str]
    districts: List[str]
    acts: List[str]
    statuses: List[str]
    purposes: List[str]
    caseTypes: List[str]
    complexes: List[str]
    courts: List[str]
