from pydantic import BaseModel, Field, ConfigDict
from typing import Literal

class CredentialsSchema(BaseModel):
    userId: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1, max_length=72)

class AccountSchema(BaseModel):
    name: str
    role: Literal['user', 'admin']
    roleLabel: str | None = Field(validation_alias='role_label', default=None)
    email: str
    initials: str | None = None

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

class SessionSchema(BaseModel):
    account: AccountSchema
    token: str
