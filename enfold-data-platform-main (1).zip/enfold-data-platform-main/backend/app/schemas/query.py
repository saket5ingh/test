from datetime import date
from typing import Literal
from pydantic import BaseModel, Field, model_validator


class CaseQuery(BaseModel):
    page: int = Field(default=1, ge=1)
    pageSize: int = Field(default=25, ge=1, le=100)
    q: str = Field(default='', max_length=200)
    scrape: str = Field(default='all', max_length=20)
    status: list[Literal['pending', 'disposed', 'acquitted', 'allowed', 'rejected']] = Field(default_factory=list, max_length=20)
    district: list[str] = Field(default_factory=list, max_length=100)
    acts: list[str] = Field(default_factory=list, max_length=100)
    caseType: list[str] = Field(default_factory=list, max_length=100)
    purpose: list[str] = Field(default_factory=list, max_length=100)
    complex: list[str] = Field(default_factory=list, max_length=100)
    court: list[str] = Field(default_factory=list, max_length=100)
    pinnedOnly: bool = False
    regYearFrom: int | None = Field(default=None, ge=1, le=9999)
    regYearTo: int | None = Field(default=None, ge=1, le=9999)
    filingFrom: date | None = None
    filingTo: date | None = None
    decisionFrom: date | None = None
    decisionTo: date | None = None

    @model_validator(mode='after')
    def validate_ranges(self):
        for start, end in [('regYearFrom', 'regYearTo'), ('filingFrom', 'filingTo'), ('decisionFrom', 'decisionTo')]:
            low, high = getattr(self, start), getattr(self, end)
            if low is not None and high is not None and low > high:
                raise ValueError(f'{start} must not exceed {end}')
        return self
