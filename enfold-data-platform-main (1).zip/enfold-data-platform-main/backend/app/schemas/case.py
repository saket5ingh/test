from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
import datetime
from uuid import UUID

class ActSchema(BaseModel):
    name: str
    sections: List[str]
    flag: Optional[bool] = None

class HearingSchema(BaseModel):
    date: datetime.date = Field(validation_alias='hearing_date')
    purpose: str
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

class CaseUpdateSchema(BaseModel):
    text: str
    at: str
    severity: str

class CaseSchema(BaseModel):
    id: UUID
    ref: Optional[str] = Field(validation_alias='case_ref', default="")
    cnr: Optional[str] = Field(validation_alias='cnr_number', default=None)
    caseNo: Optional[str] = Field(validation_alias='case_number', default="")
    regNo: Optional[int] = Field(validation_alias='registration_number', default=None)
    regYear: Optional[int] = Field(validation_alias='registration_year', default=None)
    caseType: Optional[str] = Field(validation_alias='case_type', default="")
    caseTypeClass: Optional[str] = Field(validation_alias='case_type_class', default="")
    state: str
    district: str = Field(default="")
    complex: Optional[str] = Field(validation_alias='complex_name', default=None)
    court: Optional[str] = Field(validation_alias='court_name', default=None)
    regDate: Optional[datetime.date] = Field(validation_alias='registration_date', default=None)
    filingDate: Optional[datetime.date] = Field(validation_alias='filing_date', default=None)
    decisionDate: Optional[datetime.date] = Field(validation_alias='decision_date', default=None)
    dispositionRaw: Optional[str] = Field(validation_alias='disposition_raw', default=None)
    status: str = Field(default="")
    numHearings: Optional[int] = Field(validation_alias='hearings_count', default=None)
    duration: Optional[int] = Field(validation_alias='duration_days', default=None)
    lastPurpose: Optional[str] = Field(validation_alias='last_purpose', default=None)
    acts: List[ActSchema] = Field(default_factory=list)
    hearings: List[HearingSchema] = Field(default_factory=list)
    pinned: bool = Field(default=False)
    lastScrape: Optional[str] = Field(validation_alias='last_scrape', default="")
    nextHearing: Optional[datetime.date] = Field(validation_alias='next_hearing', default=None)
    update: Optional[CaseUpdateSchema] = Field(validation_alias='update_info', default=None)

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

class PinUpdateSchema(BaseModel):
    pinned: bool


class CasePageSchema(BaseModel):
    items: List[CaseSchema]
    total: int
    page: int
    pageSize: int


class CaseUpdatesSchema(BaseModel):
    items: List[CaseSchema]
    total: int
    critical: int
