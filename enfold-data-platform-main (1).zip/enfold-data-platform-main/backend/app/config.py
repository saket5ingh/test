from pathlib import Path
from pydantic import Field, field_validator
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    DATABASE_URL: str
    JWT_SECRET: str = Field(min_length=32)
    JWT_ALGORITHM: str = 'HS256'
    CORS_ORIGINS: list[str] = ['http://localhost:5173', 'http://127.0.0.1:5173']
    JWT_EXPIRY_MINUTES: int = Field(default=480, gt=0)
    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_ALLOWED_DOMAINS: list[str] = []
    AUTH_COOKIE_SECURE: bool = True
    SCRAPER_REQUEST_INTERVAL: float = Field(default=3.0, ge=3)
    SCRAPER_CONCURRENCY: int = Field(default=1, ge=1, le=8)
    SCRAPER_LEASE_SECONDS: int = Field(default=600, ge=180, le=3600)
    SCRAPER_SHUTDOWN_SECONDS: int = Field(default=30, ge=1, le=120)
    SCRAPER_QUEUE_HIGH_WATER: int = Field(default=10000, ge=10, le=100000)
    SCRAPER_INSERT_BATCH: int = Field(default=500, ge=1, le=1000)
    SCRAPER_SOURCE_FAILURE_THRESHOLD: int = Field(default=5, ge=1, le=100)
    SCRAPER_SOURCE_COOLDOWN_SECONDS: int = Field(default=60, ge=1, le=1800)
    SCRAPER_SOURCE_MAX_COOLDOWN_SECONDS: int = Field(default=1800, ge=60, le=86400)
    SCRAPER_RECOVERY_SUCCESSES: int = Field(default=3, ge=2, le=10)
    SCRAPER_RECOVERY_INTERVAL_SECONDS: int = Field(default=60, ge=3, le=1800)
    SCRAPER_SOURCE_RETRY_ALERT_AFTER: int = Field(default=5, ge=1, le=100)
    SCRAPER_QUARANTINE_FAILURES: int = Field(default=5, ge=2, le=100)
    SCRAPER_QUARANTINE_MIN_SECONDS: int = Field(default=21600, ge=60, le=604800)
    SCRAPER_QUARANTINE_SESSIONS: int = Field(default=2, ge=2, le=20)
    SCRAPER_QUARANTINE_RECOVERY_SECONDS: int = Field(default=900, ge=60, le=86400)
    SCRAPER_STALL_SECONDS: int = Field(default=900, ge=60)
    SCRAPER_MAX_ATTEMPTS: int = Field(default=3, ge=1, le=10)
    SCRAPER_MONTHLY_ENABLED: bool = False
    # Retained for older .env files; scheduling now uses week and weekday.
    SCRAPER_MONTHLY_DAY: int | None = Field(default=None, ge=1, le=28, exclude=True)
    SCRAPER_MONTHLY_WEEK: int = Field(default=3, ge=1, le=4)
    SCRAPER_MONTHLY_WEEKDAY: int = Field(default=4, ge=0, le=6)  # Monday = 0
    SCRAPER_MONTHLY_HOUR: int = Field(default=0, ge=0, le=23)
    SCRAPER_MONTHLY_MINUTE: int = Field(default=0, ge=0, le=59)
    SCRAPER_TIMEZONE: str = 'Asia/Kolkata'

    @field_validator('SCRAPER_TIMEZONE')
    @classmethod
    def validate_scraper_timezone(cls, value):
        try: ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError) as error:
            raise ValueError('SCRAPER_TIMEZONE must be a valid IANA timezone') from error
        return value

    model_config = SettingsConfigDict(env_file=str(Path(__file__).resolve().parent.parent / '.env'))

settings = Settings()
