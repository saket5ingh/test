from sqlalchemy import Index, Column, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base


class CasePin(Base):
    __tablename__ = 'case_pins'
    __table_args__ = (
        Index('idx_case_pins_case_id', 'case_id'),
        {'schema': 'pcma'},
    )

    user_id = Column(UUID(as_uuid=True), ForeignKey('pcma.users.id', ondelete='CASCADE'), primary_key=True)
    case_id = Column(UUID(as_uuid=True), ForeignKey('pcma.cases.id', ondelete='CASCADE'), primary_key=True)
