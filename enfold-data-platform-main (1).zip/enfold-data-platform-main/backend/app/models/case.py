from sqlalchemy import CheckConstraint, Index, Text, text, Column, String, Integer, Boolean, DateTime, Date, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
import uuid
from app.database import Base
from datetime import datetime, timezone

class Case(Base):
    __tablename__ = 'cases'
    __table_args__ = (
        CheckConstraint("status IN ('pending', 'disposed', 'acquitted', 'allowed', 'rejected')", name='cases_status_check'),
        CheckConstraint('registration_year BETWEEN 1 AND 9999', name='cases_registration_year_check'),
        CheckConstraint('registration_number >= 0', name='cases_registration_number_check'),
        CheckConstraint('duration_days >= 0', name='cases_duration_check'),
        CheckConstraint('hearings_count >= 0', name='cases_hearings_count_check'),
        CheckConstraint('pcma.valid_acts(acts)', name='cases_acts_check'),
        CheckConstraint('pcma.valid_update(update_info)', name='cases_update_check'),
        CheckConstraint("last_scrape ~ '^[0-9]{4}-(0[1-9]|1[0-2])$'", name='cases_last_scrape_check'),
        Index('idx_cases_state_district', 'state', 'district'),
        Index('idx_cases_decision_date', 'decision_date'),
        Index('idx_cases_status', 'status'),
        Index('idx_cases_disposition_raw', 'disposition_raw'),
        Index('idx_cases_last_scrape', 'last_scrape'),
        Index('idx_cases_registration_year', 'registration_year'),
        Index('idx_cases_acts_gin', 'acts', postgresql_using='gin', postgresql_ops={'acts': 'jsonb_path_ops'}),
        Index('idx_cases_court_name_trgm', 'court_name', postgresql_using='gin', postgresql_ops={'court_name': 'gin_trgm_ops'}),
        Index('idx_cases_complex_name_trgm', 'complex_name', postgresql_using='gin', postgresql_ops={'complex_name': 'gin_trgm_ops'}),
        {'schema': 'pcma'},
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("uuid_generate_v4()"))
    scrape_run_id = Column(UUID(as_uuid=True), ForeignKey('pcma.scrape_runs.id', ondelete='SET NULL'))
    cnr_number = Column(String(32), unique=True, nullable=False)
    case_number = Column(String(64))
    case_ref = Column(String(64))
    case_type = Column(String(128))
    case_type_class = Column(String(64))
    registration_number = Column(Integer)
    registration_year = Column(Integer)
    state = Column(String(100), nullable=False)
    district = Column(String(100), nullable=False)
    complex_name = Column(String(255))
    court_name = Column(String(255))
    registration_date = Column(Date)
    filing_date = Column(Date)
    decision_date = Column(Date, nullable=True)
    disposition_raw = Column(String(255))
    status = Column(String(32), nullable=False, server_default='pending')
    duration_days = Column(Integer)
    hearings_count = Column(Integer, server_default="0")
    last_purpose = Column(Text)
    next_hearing = Column(Date, nullable=True)
    acts = Column(JSONB, nullable=False, server_default='[]')
    last_scrape = Column(String(20))
    pinned = Column(Boolean, nullable=False, default=False, server_default=text("false"))
    update_info = Column(JSONB(none_as_null=True), nullable=True)
    documents_checked_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=text("CURRENT_TIMESTAMP"), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), server_default=text("CURRENT_TIMESTAMP"), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    hearings = relationship("CaseHearing", back_populates="case", lazy="selectin", cascade="all, delete-orphan", order_by="(CaseHearing.hearing_date, CaseHearing.sequence_order, CaseHearing.id)")
    documents = relationship("CaseDocument", back_populates="case", lazy="raise", cascade="all, delete-orphan")
