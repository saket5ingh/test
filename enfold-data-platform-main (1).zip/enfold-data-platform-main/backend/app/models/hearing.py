from sqlalchemy import CheckConstraint, Index, Text, text, Column, Integer, Date, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import uuid
from app.database import Base
from datetime import datetime, timezone

class CaseHearing(Base):
    __tablename__ = 'case_hearings'
    __table_args__ = (
        CheckConstraint('sequence_order >= 0', name='hearings_sequence_check'),
        Index('idx_case_hearings_case_id', 'case_id'),
        {'schema': 'pcma'},
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("uuid_generate_v4()"))
    case_id = Column(UUID(as_uuid=True), ForeignKey('pcma.cases.id', ondelete='CASCADE'), nullable=False)
    hearing_date = Column(Date, nullable=False)
    purpose = Column(Text, nullable=False)
    sequence_order = Column(Integer, server_default="0")
    created_at = Column(DateTime(timezone=True), server_default=text("CURRENT_TIMESTAMP"), default=lambda: datetime.now(timezone.utc))

    case = relationship("Case", back_populates="hearings")
