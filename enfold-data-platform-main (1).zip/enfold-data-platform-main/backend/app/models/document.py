from sqlalchemy import CheckConstraint, Index, text, Column, String, Date, ForeignKey, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
import uuid
from app.database import Base
from datetime import datetime, timezone

class CaseDocument(Base):
    __tablename__ = 'case_documents'
    __table_args__ = (
        Index('idx_case_documents_case_id', 'case_id'),
        Index('idx_case_docs_unique_s3', 'case_id', 's3_key', unique=True, postgresql_where=text('s3_key IS NOT NULL')),
        Index('idx_case_docs_source', 'case_id', 'source_key', unique=True),
        CheckConstraint("(source_reference IS NULL AND source_key IS NULL) OR "
            "(source_reference IS NOT NULL AND source_key IS NOT NULL AND document_type = 'final' "
            "AND jsonb_typeof(source_reference) = 'object' AND source_key ~ '^[0-9a-f]{64}$' "
            "AND source_reference ?& ARRAY['filename','state_cd','dist_cd','court_code'])",
            name='document_reference_check'),
        {'schema': 'pcma'},
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("uuid_generate_v4()"))
    case_id = Column(UUID(as_uuid=True), ForeignKey('pcma.cases.id', ondelete='CASCADE'), nullable=False)
    document_type = Column(String(20), nullable=False)
    label = Column(String(500), nullable=False)
    document_date = Column(Date)
    s3_key = Column(String(500), nullable=True)
    external_link = Column(Text, nullable=True)
    params_blob = Column(Text, nullable=True)
    source_reference = Column(JSONB)
    source_key = Column(String(64))
    created_at = Column(DateTime(timezone=True), server_default=text("CURRENT_TIMESTAMP"), default=lambda: datetime.now(timezone.utc))

    case = relationship("Case", back_populates="documents")
