from sqlalchemy import CheckConstraint, Index, Text, text, Column, String, Integer, ForeignKey, DateTime, Boolean
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
import uuid
from app.database import Base

class ScrapeRun(Base):
    __tablename__ = 'scrape_runs'
    __table_args__ = (
        CheckConstraint("status_filter IN ('all', 'pending', 'disposed')", name='scrape_status_check'),
        CheckConstraint("outcome IN ('pending', 'queued', 'running', 'success', 'partial', 'failed', 'cancelled')", name='scrape_outcome_check'),
        CheckConstraint('total_cases_found >= 0', name='scrape_count_check'),
        CheckConstraint('completed_at >= started_at', name='scrape_dates_check'),
        CheckConstraint("trigger_type IN ('manual', 'scheduled')", name='scrape_trigger_check'),
        CheckConstraint("jsonb_typeof(criteria) = 'object'", name='scrape_criteria_check'),
        Index('idx_runs_queued', text('queued_at DESC'), text('id')),
        {'schema': 'pcma'},
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("uuid_generate_v4()"))
    name = Column(String(255), nullable=False)
    state = Column(String(100))
    acts = Column(String(500))
    sections = Column(String(255))
    status_filter = Column(String(20), server_default="all")
    outcome = Column(String(20), server_default="pending")
    total_cases_found = Column(Integer, server_default="0")
    error_message = Column(Text, nullable=True)
    triggered_by = Column(UUID(as_uuid=True), ForeignKey('pcma.users.id', ondelete='SET NULL'))
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True), nullable=True)

    criteria = Column(JSONB(none_as_null=True))
    resolved_scope = Column(JSONB(none_as_null=True))
    trigger_type = Column(String(20), nullable=False, server_default='manual')
    queued_at = Column(DateTime(timezone=True), nullable=False, server_default=text('CURRENT_TIMESTAMP'))
    cancel_requested = Column(Boolean, nullable=False, server_default=text('false'))
    schedule_key = Column(String(40), unique=True)
    request_key = Column(UUID(as_uuid=True), unique=True)
    snapshot_version = Column(Integer)
    dispatch_cursor = Column(Integer, nullable=False, server_default="0")
    user = relationship("User")
