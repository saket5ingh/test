from sqlalchemy import text, Column, String, Boolean, DateTime, Integer, CheckConstraint, Index, func, column
from sqlalchemy.dialects.postgresql import UUID
import uuid
from app.database import Base
import bcrypt
from datetime import datetime, timezone



class User(Base):
    __tablename__ = 'users'
    __table_args__ = (
        CheckConstraint("role IN ('user', 'admin')", name='users_role_check'),
        CheckConstraint('auth_version >= 0', name='users_auth_version_check'),
        Index('users_email_lower_unique', func.lower(column('email')), unique=True),
        {'schema': 'pcma'},
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("uuid_generate_v4()"))
    user_id = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, server_default='user')
    google_sub = Column(String(255), unique=True)
    auth_version = Column(Integer, nullable=False, server_default="0", default=0)
    role_label = Column(String(255))
    initials = Column(String(10))
    is_active = Column(Boolean, nullable=False, default=True, server_default=text("true"))
    created_at = Column(DateTime(timezone=True), server_default=text("CURRENT_TIMESTAMP"), default=lambda: datetime.now(timezone.utc))

    def verify_password(self, plain_password: str) -> bool:
        if not self.password_hash:
            return False
        # bcrypt only accepts 72 bytes, not 72 Unicode characters.
        if len(plain_password.encode('utf-8')) > 72:
            return False
        try:
            return bcrypt.checkpw(plain_password.encode('utf-8'), self.password_hash.encode('utf-8'))
        except ValueError:
            return False
