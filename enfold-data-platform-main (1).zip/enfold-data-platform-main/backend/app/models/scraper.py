"""Scraper mappings. SQL migrations remain authoritative for deployment."""
import uuid
from sqlalchemy import Column, String, Text, Integer, BigInteger, Boolean, DateTime, ForeignKey, ForeignKeyConstraint, CheckConstraint, Index, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base


class ScrapeTask(Base):
    __tablename__ = 'scrape_tasks'
    __table_args__ = (
        UniqueConstraint('run_id','task_key'),
        CheckConstraint("kind IN ('discover','state','district','court','search','case')"),
        CheckConstraint("status IN ('queued','running','success','failed','cancelled')"),
        CheckConstraint("jsonb_typeof(payload) = 'object'"),
        CheckConstraint('attempts >= 0'), CheckConstraint('retry_base >= 0'), CheckConstraint('source_attempts >= 0'),
        CheckConstraint('claim_version >= 0'),
        CheckConstraint('review_failures>=0'), CheckConstraint('review_sessions>=0'),
        CheckConstraint("NOT review_required OR (status='failed' AND review_reason IS NOT NULL AND review_at IS NOT NULL AND review_evidence IS NOT NULL)"),
        Index('idx_tasks_review','run_id','id',postgresql_where=text('review_required')),
        Index('idx_tasks_recovery_evidence','run_id','kind',text('source_validated_at DESC'),postgresql_where=text("status='success'")),
        Index('idx_tasks_claim_kind','run_id','kind','available_at','id',postgresql_where=text("status='queued'")),
        Index('idx_tasks_expired','lease_until','run_id',postgresql_where=text("status='running'")),
        Index('idx_tasks_run_kind_status','run_id','kind','status'),
        Index('idx_tasks_ready','status','available_at'), Index('idx_tasks_run_status','run_id','status'),
        Index('idx_case_task_document_scope', text("(payload->>'cnr')"), text('completed_at DESC'),
              postgresql_where=text("kind = 'case' AND status = 'success'")),
        {'schema':'pcma'},
    )
    id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,server_default=text('uuid_generate_v4()'))
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),nullable=False)
    task_key = Column(Text,nullable=False)
    kind = Column(String(20),nullable=False)
    payload = Column(JSONB,nullable=False)
    status = Column(String(20),nullable=False,server_default='queued')
    attempts = Column(Integer,nullable=False,server_default='0')
    retry_base = Column(Integer,nullable=False,server_default='0')
    source_attempts = Column(Integer,nullable=False,server_default='0')
    source_validated_at = Column(DateTime(timezone=True))
    review_failures = Column(Integer,nullable=False,server_default='0')
    review_sessions = Column(Integer,nullable=False,server_default='0')
    review_started_at = Column(DateTime(timezone=True))
    review_last_session = Column(UUID(as_uuid=True))
    review_required = Column(Boolean,nullable=False,server_default=text('false'))
    review_reason = Column(Text)
    review_at = Column(DateTime(timezone=True))
    review_evidence = Column(JSONB)
    available_at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    error_message = Column(Text)
    error_kind = Column(String(30))
    lease_owner = Column(UUID(as_uuid=True))
    lease_until = Column(DateTime(timezone=True))
    claim_version = Column(BigInteger, nullable=False, server_default='0')
    expanding = Column(Boolean, nullable=False, server_default=text('false'))


class ScrapeRunCase(Base):
    __tablename__ = 'scrape_run_cases'
    __table_args__ = (CheckConstraint("jsonb_typeof(snapshot) = 'object'"),
        CheckConstraint("change_kind IN ('new','updated','unchanged')"),
        Index('idx_run_cases_case','case_id'), {'schema':'pcma'})
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='RESTRICT'),primary_key=True)
    case_id = Column(UUID(as_uuid=True),ForeignKey('pcma.cases.id',ondelete='RESTRICT'),primary_key=True)
    fetched_at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    snapshot = Column(JSONB,nullable=False)
    change_kind = Column(String(20),nullable=False)


class ScrapeRunEvent(Base):
    __tablename__ = 'scrape_run_events'
    __table_args__ = (Index('idx_run_events','run_id','at','id'), {'schema':'pcma'})
    id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,server_default=text('uuid_generate_v4()'))
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),nullable=False)
    task_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_tasks.id',ondelete='SET NULL'))
    at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    kind = Column(String(40),nullable=False)
    message = Column(Text,nullable=False)
    actor_id = Column(UUID(as_uuid=True),ForeignKey('pcma.users.id',ondelete='SET NULL'))


class ScraperMetadata(Base):
    __tablename__ = 'scraper_metadata'
    __table_args__ = {'schema':'pcma'}
    key = Column(String(40),primary_key=True)
    value = Column(JSONB,nullable=False)
    updated_at = Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))


class CaseNotification(Base):
    __tablename__ = 'case_notifications'
    __table_args__ = (
        ForeignKeyConstraint(['user_id','case_id'],['pcma.case_pins.user_id','pcma.case_pins.case_id'],ondelete='CASCADE'),
        CheckConstraint('pcma.valid_update(payload)'), {'schema':'pcma'},
    )
    user_id = Column(UUID(as_uuid=True),primary_key=True)
    case_id = Column(UUID(as_uuid=True),primary_key=True)
    run_id = Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id'),nullable=False)
    payload = Column(JSONB,nullable=False)


class ScrapeTaskCount(Base):
    __tablename__='scrape_task_counts'
    __table_args__=(CheckConstraint('total >= 0'),{'schema':'pcma'})
    run_id=Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),primary_key=True)
    kind=Column(String(20),primary_key=True)
    status=Column(String(20),primary_key=True)
    total=Column(BigInteger,nullable=False)


class ScrapeResultCount(Base):
    __tablename__='scrape_result_counts'
    __table_args__=(CheckConstraint('total >= 0'),{'schema':'pcma'})
    run_id=Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),primary_key=True)
    change_kind=Column(String(20),primary_key=True)
    total=Column(BigInteger,nullable=False)


class ScrapeRunProgress(Base):
    __tablename__='scrape_run_progress'
    __table_args__=(CheckConstraint('deferred_tasks >= 0'),{'schema':'pcma'})
    run_id=Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),primary_key=True)
    last_activity_at=Column(DateTime(timezone=True))
    last_success_at=Column(DateTime(timezone=True))
    last_case_at=Column(DateTime(timezone=True))
    metrics_since=Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    deferred_tasks=Column(BigInteger,nullable=False,server_default='0')


class ScrapeMetric(Base):
    __tablename__='scrape_metrics'
    __table_args__={'schema':'pcma'}
    run_id=Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),primary_key=True)
    bucket=Column(DateTime(timezone=True),primary_key=True)
    succeeded=Column(BigInteger,nullable=False,server_default='0')
    case_succeeded=Column(BigInteger,nullable=False,server_default='0')
    retried=Column(BigInteger,nullable=False,server_default='0')
    failed=Column(BigInteger,nullable=False,server_default='0')
    source_errors=Column(BigInteger,nullable=False,server_default='0')


class ScrapeExpansion(Base):
    __tablename__='scrape_expansions'
    __table_args__=(CheckConstraint('chunk >= 0'),CheckConstraint("jsonb_typeof(children) = 'array'"),{'schema':'pcma'})
    run_id=Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_runs.id',ondelete='CASCADE'),nullable=False)
    task_id=Column(UUID(as_uuid=True),ForeignKey('pcma.scrape_tasks.id',ondelete='CASCADE'),primary_key=True)
    chunk=Column(Integer,primary_key=True)
    children=Column(JSONB,nullable=False)


class ScraperControl(Base):
    __tablename__='scraper_control'
    __table_args__=(CheckConstraint('id'),CheckConstraint('recovery_successes>=0'),{'schema':'pcma'})
    id=Column(Boolean,primary_key=True,server_default=text('true'))
    owner=Column(UUID(as_uuid=True))
    next_request_at=Column(DateTime(timezone=True),nullable=False,server_default=text('CURRENT_TIMESTAMP'))
    paused_until=Column(DateTime(timezone=True))
    failure_streak=Column(Integer,nullable=False,server_default='0')
    cooldown_level=Column(Integer,nullable=False,server_default='0')
    recovery_successes=Column(Integer,nullable=False,server_default='0')
    probe_owner=Column(UUID(as_uuid=True))
    probe_until=Column(DateTime(timezone=True))
    last_error_kind=Column(String(30))
    requests=Column(BigInteger,nullable=False,server_default='0')
    last_request_at=Column(DateTime(timezone=True))
