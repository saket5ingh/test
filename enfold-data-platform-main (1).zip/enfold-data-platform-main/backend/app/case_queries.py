from fastapi import HTTPException
from sqlalchemy import Text, case, cast, exists, or_, select
from app.models.case import Case
from app.models.pin import CasePin
from app.schemas.query import CaseQuery


def pin_exists(user_id):
    return exists(select(CasePin.case_id).where(CasePin.case_id == Case.id, CasePin.user_id == user_id))


def case_conditions(query: CaseQuery, user):
    # District selection is a filter, never an authorization boundary.
    conditions = []
    if (query.complex or query.court) and user.role != 'admin':
        raise HTTPException(status_code=403, detail='Court identifier filters require administrator access')
    for field, values in [
        (Case.status, query.status), (Case.district, query.district),
        (Case.case_type_class, query.caseType), (Case.last_purpose, query.purpose),
        (Case.complex_name, query.complex), (Case.court_name, query.court),
    ]:
        if values:
            conditions.append(field.in_(values))
    if query.acts:
        conditions.append(or_(*(Case.acts.contains([{'name': name}]) for name in query.acts)))
    if query.scrape != 'all':
        conditions.append(Case.last_scrape == query.scrape)
    if query.pinnedOnly:
        conditions.append(pin_exists(user.id))
    for field, lower, upper in [
        (Case.registration_year, query.regYearFrom, query.regYearTo),
        (Case.filing_date, query.filingFrom, query.filingTo),
        (Case.decision_date, query.decisionFrom, query.decisionTo),
    ]:
        if lower is not None:
            conditions.append(field >= lower)
        if upper is not None:
            conditions.append(field <= upper)
    fields = [Case.case_ref, Case.state, Case.district, Case.case_type, Case.disposition_raw,
              Case.status, Case.last_purpose, cast(Case.acts, Text)]
    if user.role == 'admin':
        fields += [Case.cnr_number, Case.case_number, cast(Case.registration_number, Text),
                   Case.complex_name, Case.court_name]
    for token in query.q.lower().split():
        # contains(autoescape=True) treats %, _ and / as literal user input.
        conditions.append(or_(*(field.icontains(token, autoescape=True) for field in fields)))
    return conditions


def attention_order():
    return [case((Case.update_info['severity'].astext == 'critical', 0),
                 (Case.update_info['severity'].astext == 'info', 1), else_=2),
            Case.last_scrape.desc().nullslast(), Case.registration_date.desc().nullslast(), Case.id]
